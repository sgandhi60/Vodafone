CTIStart.jsv and EntryPoint.jsv are ok - ignore error message:
        Attribute "posturl" must be declared for element type "log".

RoutingDTMF.jsv, RoutingRecordDTMF.jsv and RoutingSpeech.jsv are ok - ignore error message:
        The element type "if" must be terminated by the matching end-tad "</if>"

