package com.selfserv.ivr.data;

import java.util.Properties;

import javax.servlet.http.HttpSession;

public class HandlerHelper {
	private HttpSession session = null;				// get session from Servlet request, created if not existed yet
	private String centralJNDIName = null;			// JNDI name for central DB
	private String localJNDIName = null;			// JNDI name for local DB
	private String reportJNDIName = null;			// JNDI name for report DB
	private String callid = null;					// call ID 
	private String mobile = null;					// mobile number
	private boolean testCall = false;				// used for decision making scenarios
	private String logToken = null;					// used for logging purpose
	private Properties callProp = null;				// properties key-value pair
	private Circle circ = null;						// circle clsss that gets populated from the properties file
	private String circle = null;					// Circle name 0001.....0023
	private String coId = null;						// Contract Id

	private String media = null;					// media for Dup Bill - email or courier
	private String month = null;
	private String year = null;
	private String landline = null;
	private String pgmCode = null;
	private String tranType = null;					// DupBill Email or DupBill Courier

	public HandlerHelper(){
	}

	/**
	 * @return the callid
	 */
	public String getCallid() {
		return callid;
	}

	/**
	 * @param callid the callid to set
	 */
	public void setCallid(String callid) {
		this.callid = callid;
	}

	/**
	 * @return the callProp
	 */
	public Properties getCallProp() {
		return callProp;
	}

	/**
	 * @param callProp the callProp to set
	 */
	public void setCallProp(Properties callProp) {
		this.callProp = callProp;
	}

	/**
	 * @return the centralJNDIName
	 */
	public String getCentralJNDIName() {
		return centralJNDIName;
	}

	/**
	 * @param centralJNDIName the centralJNDIName to set
	 */
	public void setCentralJNDIName(String centralJNDIName) {
		this.centralJNDIName = centralJNDIName;
	}

	/**
	 * @return the circ
	 */
	public Circle getCirc() {
		return circ;
	}

	/**
	 * @param circ the circ to set
	 */
	public void setCirc(Circle circ) {
		this.circ = circ;
	}

	/**
	 * @return the circle
	 */
	public String getCircle() {
		return circle;
	}

	/**
	 * @param circle the circle to set
	 */
	public void setCircle(String circle) {
		this.circle = circle;
	}

	/**
	 * @return the coId
	 */
	public String getCoId() {
		return coId;
	}

	/**
	 * @param coId the coId to set
	 */
	public void setCoId(String coId) {
		this.coId = coId;
	}

	/**
	 * @return the localJNDIName
	 */
	public String getLocalJNDIName() {
		return localJNDIName;
	}

	/**
	 * @param localJNDIName the localJNDIName to set
	 */
	public void setLocalJNDIName(String localJNDIName) {
		this.localJNDIName = localJNDIName;
	}

	/**
	 * @return the reportJNDIName
	 */
	public String getReportJNDIName() {
		return reportJNDIName;
	}

	/**
	 * @param reportJNDIName the reportJNDIName to set
	 */
	public void setReportJNDIName(String reportJNDIName) {
		this.reportJNDIName = reportJNDIName;
	}

	/**
	 * @return the logToken
	 */
	public String getLogToken() {
		return logToken;
	}

	/**
	 * @param logToken the logToken to set
	 */
	public void setLogToken(String logToken) {
		this.logToken = logToken;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the session
	 */
	public HttpSession getSession() {
		return session;
	}

	/**
	 * @param session the session to set
	 */
	public void setSession(HttpSession session) {
		this.session = session;
	}

	/**
	 * @return the testCall
	 */
	public boolean isTestCall() {
		return testCall;
	}

	/**
	 * @param testCall the testCall to set
	 */
	public void setTestCall(boolean testCall) {
		this.testCall = testCall;
	}

	/**
	 * @return the landline
	 */
	public String getLandline() {
		return landline;
	}

	/**
	 * @param landline the landline to set
	 */
	public void setLandline(String landline) {
		this.landline = landline;
	}

	/**
	 * @return the media
	 */
	public String getMedia() {
		return media;
	}

	/**
	 * @param media the media to set
	 */
	public void setMedia(String media) {
		this.media = media;
	}

	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * @return the pgmCode
	 */
	public String getPgmCode() {
		return pgmCode;
	}

	/**
	 * @param pgmCode the pgmCode to set
	 */
	public void setPgmCode(String pgmCode) {
		this.pgmCode = pgmCode;
	}

	/**
	 * @return the tranType
	 */
	public String getTranType() {
		return tranType;
	}

	/**
	 * @param tranType the tranType to set
	 */
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}


}
