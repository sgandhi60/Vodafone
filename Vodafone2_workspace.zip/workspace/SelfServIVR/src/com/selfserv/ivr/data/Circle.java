/*
 * Created on Mar 12, 2007
 *
 * 
 */
package com.selfserv.ivr.data;

import java.io.Serializable;

/**
 * @author 
 *
 * 
 */
public class Circle implements Serializable{
	private static final long serialVersionUID = 1L;	
    //   Add fields here  
	String circle;
	String circleName;
	String transferCharge;
	String complaintMenuActivePost;
	String complaintMenuActivePre;
	String maxTransfer;
	String localLanguage;
	String defaultLanguage;
	String localJNDIName;
	String reportJNDIName;
	String dnisType;
	
	String toContinueChoice1;
	String toContinueChoice2;	
	String toContinueChoice3;
	String toContinueChoice1Lang;
	String toContinueChoice2Lang;
	String toContinueChoice3Lang;

	
	String toSetChoice1;
	String toSetChoice2;	
	String toSetChoice3;
	String toSetChoice1Lang;
	String toSetChoice2Lang;
	String toSetChoice3Lang;
	
	String ccMinAmt;
	String ccMaxAmt;
	
	String defVDNTypeA;
	String defVDNTypeB;
	String defVDNTypeC;
	String defVDNTypeD;
	String defVdnGPRS;
	
	String hotKeyDNIS;
	String hotKeyType;
	
	String ctiEnabledFlag;
	String ctiSwitch;
	String cdtType;
	
    String spPackageName;
    
    String gprsFlag;
    //   Getters and Setters placed here
	
		
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getDefaultLanguage() {
		return defaultLanguage;
	}
	public void setDefaultLanguage(String defaultLanguage) {
		this.defaultLanguage = defaultLanguage;
	}
	public String getMaxTransfer() {
		return maxTransfer;
	}
	public void setMaxTransfer(String maxTransfer) {
		this.maxTransfer = maxTransfer;
	}
	public String getTransferCharge() {
		return transferCharge;
	}
	public void setTransferCharge(String transferCharge) {
		this.transferCharge = transferCharge;
	}
	public String getDnisType() {
		return dnisType;
	}
	public void setDnisType(String dnisType) {
		this.dnisType = dnisType;
	}
	public String getToContinueChoice1() {
		return toContinueChoice1;
	}
	public void setToContinueChoice1(String toContinueChoice1) {
		this.toContinueChoice1 = toContinueChoice1;
	}
	public String getToContinueChoice1Lang() {
		return toContinueChoice1Lang;
	}
	public void setToContinueChoice1Lang(String toContinueChoice1Lang) {
		this.toContinueChoice1Lang = toContinueChoice1Lang;
	}
	public String getToContinueChoice2() {
		return toContinueChoice2;
	}
	public void setToContinueChoice2(String toContinueChoice2) {
		this.toContinueChoice2 = toContinueChoice2;
	}
	public String getToContinueChoice2Lang() {
		return toContinueChoice2Lang;
	}
	public void setToContinueChoice2Lang(String toContinueChoice2Lang) {
		this.toContinueChoice2Lang = toContinueChoice2Lang;
	}
	public String getToContinueChoice3() {
		return toContinueChoice3;
	}
	public void setToContinueChoice3(String toContinueChoice3) {
		this.toContinueChoice3 = toContinueChoice3;
	}
	public String getToContinueChoice3Lang() {
		return toContinueChoice3Lang;
	}
	public void setToContinueChoice3Lang(String toContinueChoice3Lang) {
		this.toContinueChoice3Lang = toContinueChoice3Lang;
	}
	public String getToSetChoice1() {
		return toSetChoice1;
	}
	public void setToSetChoice1(String toSetChoice1) {
		this.toSetChoice1 = toSetChoice1;
	}
	public String getToSetChoice1Lang() {
		return toSetChoice1Lang;
	}
	public void setToSetChoice1Lang(String toSetChoice1Lang) {
		this.toSetChoice1Lang = toSetChoice1Lang;
	}
	public String getToSetChoice2() {
		return toSetChoice2;
	}
	public void setToSetChoice2(String toSetChoice2) {
		this.toSetChoice2 = toSetChoice2;
	}
	public String getToSetChoice2Lang() {
		return toSetChoice2Lang;
	}
	public void setToSetChoice2Lang(String toSetChoice2Lang) {
		this.toSetChoice2Lang = toSetChoice2Lang;
	}
	public String getToSetChoice3() {
		return toSetChoice3;
	}
	public void setToSetChoice3(String toSetChoice3) {
		this.toSetChoice3 = toSetChoice3;
	}
	public String getToSetChoice3Lang() {
		return toSetChoice3Lang;
	}
	public void setToSetChoice3Lang(String toSetChoice3Lang) {
		this.toSetChoice3Lang = toSetChoice3Lang;
	}
	public String getLocalLanguage() {
		return localLanguage;
	}
	public void setLocalLanguage(String localLanguage) {
		this.localLanguage = localLanguage;
	}
	public String getLocalJNDIName() {
		return localJNDIName;
	}
	public void setLocalJNDIName(String localJNDIName) {
		this.localJNDIName = localJNDIName;
	}
	public String getReportJNDIName() {
		return reportJNDIName;
	}
	public void setReportJNDIName(String reportJNDIName) {
		this.reportJNDIName = reportJNDIName;
	}
	public String getCircleName() {
		return circleName;
	}
	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
	public String getCcMaxAmt() {
		return ccMaxAmt;
	}
	public void setCcMaxAmt(String ccMaxAmt) {
		this.ccMaxAmt = ccMaxAmt;
	}
	public String getCcMinAmt() {
		return ccMinAmt;
	}
	public void setCcMinAmt(String ccMinAmt) {
		this.ccMinAmt = ccMinAmt;
	}
	public String getDefVDNTypeA() {
		return defVDNTypeA;
	}
	public void setDefVDNTypeA(String defVDNTypeA) {
		this.defVDNTypeA = defVDNTypeA;
	}
	public String getDefVDNTypeB() {
		return defVDNTypeB;
	}
	public void setDefVDNTypeB(String defVDNTypeB) {
		this.defVDNTypeB = defVDNTypeB;
	}
	public String getDefVDNTypeC() {
		return defVDNTypeC;
	}
	public void setDefVDNTypeC(String defVDNTypeC) {
		this.defVDNTypeC = defVDNTypeC;
	}
	public String getDefVDNTypeD() {
		return defVDNTypeD;
	}
	public void setDefVDNTypeD(String defVDNTypeD) {
		this.defVDNTypeD = defVDNTypeD;
	}
	public String getSpPackageName() {
		return spPackageName;
	}
	public void setSpPackageName(String spPackageName) {
		this.spPackageName = spPackageName;
	}
	public String getComplaintMenuActivePost() {
		return complaintMenuActivePost;
	}
	public void setComplaintMenuActivePost(String complaintMenuActivePost) {
		this.complaintMenuActivePost = complaintMenuActivePost;
	}
	public String getComplaintMenuActivePre() {
		return complaintMenuActivePre;
	}
	public void setComplaintMenuActivePre(String complaintMenuActivePre) {
		this.complaintMenuActivePre = complaintMenuActivePre;
	}
	public String getHotKeyDNIS() {
		return hotKeyDNIS;
	}
	public void setHotKeyDNIS(String hotKeyDNIS) {
		this.hotKeyDNIS = hotKeyDNIS;
	}
	public String getHotKeyType() {
		return hotKeyType;
	}
	public void setHotKeyType(String hotKeyType) {
		this.hotKeyType = hotKeyType;
	}
	public String getCtiEnabledFlag() {
		return ctiEnabledFlag;
	}
	public void setCtiEnabledFlag(String ctiEnabledFlag) {
		this.ctiEnabledFlag = ctiEnabledFlag;
	}
	public String getCdtType() {
		return cdtType;
	}
	public void setCdtType(String cdtType) {
		this.cdtType = cdtType;
	}
	public String getCtiSwitch() {
		return ctiSwitch;
	}
	public void setCtiSwitch(String ctiSwitch) {
		this.ctiSwitch = ctiSwitch;
	}
	public String getGprsFlag() {
		return gprsFlag;
	}
	public void setGprsFlag(String gprsFlag) {
		this.gprsFlag = gprsFlag;
	}
	public String getDefVdnGPRS() {
		return defVdnGPRS;
	}
	public void setDefVdnGPRS(String defVdnGPRS) {
		this.defVdnGPRS = defVdnGPRS;
	}
	
}