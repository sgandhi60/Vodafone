/*
 * Created on Mar 12, 2007
 *
 * 
 */
package com.selfserv.ivr.data;

import java.io.Serializable;

/**
 * @author 
 *
 * 
 */
public class Report implements Serializable{
	
    //   Add fields here       
	
	
	
    //   Getters and Setters placed here
}