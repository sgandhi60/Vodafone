/*
 * Created on Mar 12, 2007
 *
 * 
 */
package com.selfserv.ivr.data;

import java.io.Serializable;

/**
 * @author 
 *
 * 
 */
public class Customer implements Serializable{
	
	private static final long serialVersionUID = 1L;
		String dbCType;		/* Set by CustomerType handler.  Possible values are: 	POSTPAID
																						PREPAID
																						PREMIUM
																						SPECIAL*/
		
	    String callFlowType;	/* Set by the Application (XML).  Possible values are:	LandLinePrePaid
	    																				LandLinePostPaid
	    																				PrePaid
	    																				PostPaid
	    																				InfoOnly*/
	    
	    String barredFlag;		/* Set by CustomerType handler. The caller is barred and should not be eligible to Xfer. 
	    															Possible values are:	"Y" - (customer is barred)
	    																					"N" - (customer is not barred from CCE Xfer)*/
	    
	    String firstTimeCallerFlag ="N";  /* Set by CustomerType handler, it is this the first time for the caller to access the IVR
        															Possible values are:  	"Y" - (first time for the caller in the IVR)
        																					"N" - (customer called before)*/
	    String gprs_Flag = null;		// set by CustomerType handler 
	    
	    String inroamerFlag = "N";		/*	Set by TableSeries handler, categorizing a caller as an in-roamer (Vodafone customer, but roaming)
	    															Possible values are 	"Y" - 
	    																					"N"  - 
	    																					null - If a null is found in the DB, the value is set to "N"*/
	    
	    String callerFound = "N";			/* Set by the CustomerType handler
	    								if TypeA or TypeB caller, do LDB (and CDB if necessary), 
	    										if found dbCType is set, and callerFound="Y"
	    										else set dbCType based on Circle.dnisMapping, and set callerFound="N"
	    							 	if TypeC, look up tbl_series, if not found, callerFound="N", DBRC="F_NF"
	    							 		*/
	    
	    String pukNumber = null;		//caller's Personal Unlock Key
	    
	    String landlineNumber = null;	//caller's landline number
	    
	    String mobile = null;			//last 10 digits of the CLI/ANI
	    
	    String prefLang = null;			//caller's prefered language from TBL_PREF.PREFLANG
	    
	    String vdn_category = null;		//caller category (PREMIUM, etc) from TBL_CTYPE.VDN_CATEGORY
	    
	    String tran_type = null;		//Type of the caller's transaction 
	    
	    String dailyXfers = "0";		//counter for the daily transfers to operator.  Set by the CheckBarred handler from TBL_CDAY_BARRED.XFER_COUNT
	    
	    String prgcode = null;			//customer type set from TBL_GEN
	    
	    String custCode = null;			//customer code set from TBL_GEN
	    
	    String cust_id = null;			//cust_id id set from TBL_GEN
	    
	    String coid = null;				//contract id set from TBL_GEN
	    
	    String title = null;			// title set from TBL_GEN
	    
	    String firstName = null;			// firstName set from TBL_GEN
	    
	    String lastName = null;			// lastName set from TBL_GEN
	    
	    String address1 = null;			// address1 set from TBL_GEN
	    
	    String address2 = null;			// address2 set from TBL_GEN
	    
	    String address3 = null;			// address3 set from TBL_GEN
	    
	    String city = null;			// city set from TBL_GEN

	    String creditType = null;		// Credit Type from Credit Matrix SP - 2 chars for High risk, Low risk, etc..

	    String prgname = null;			//-- SCS - added 7-2-2008 needed for credit matrix handler
	    
	    String whichDB = "N";			/*Represents the DB where the customer was found, 
	    								  Possible values:	N - None
	    								  					L -Local
	    								  					C-Central
	    								*/
//	    String  smsSent = "no";         // Has a SMS message been sucessfully sent during this call.
//	                                    //  This field can be  "no"  or  "yes"
	    int  smsCount = 0;           	// increment this counter each time SMS message sent sucessfully 
	    								// during this call.
        
	    
	    boolean tableSeriesCalled = false;	// Has TBL_SERIES already been looked up?
	    boolean ivrCallDetailsCalled = false;	// Has IVRCallDetails already been called?
	    boolean ivrMainCalled = false;	// Has IVRMain been called?
	    boolean tableGenCalled = false;	// Has TBL_GEN already been looked up?
	    boolean creditMatrixCalled = false;	// Has ivr_credit_matrix already been looked up?
	    
	    // ****************************************************************************************************
	    // SCS - Added 7-1-2008 and 7-2-2008
	    //
	    //          
	    // ActivateService - used to activate/deactivate a service
        //
	    // Handler: IVRServices
	    //		serviceID_xxxx is used for IVRServices handler outputs 
	    //       this list is from Pradeeps note on TBL_SNCODE
	    //
	    //		VALUES:  'a' - active, 'd' - deactive
	    //       note: a value of null should be treated same as deactivated
	    //
	    //      Assumption: -- TBL_SNCODE2 is circle based and queried and stored in the context
	    //						upon 1st request in a property file format.  
	    //						The information from colums Service_Key and Service_code will represent 
	    //						a key value pair -- Example 14=DC_STD
	    //					   The IVRServices handler then uses the those key value pairs to 
	    //						map the returned services string to the fields below. 
	    //
	    // NOTE: Handler ActivateService updates these values as well 
	    //
	    String  serviceID_DCSTD = "d";	//STD service (lond distance calls)
	    String  serviceID_DCISD = "d";	//ISD service (INTERNATIONAL calls)
	    String  serviceID_DCHA  = "d";	//Vodafone Live (previously called Hutch Access)
	    String  serviceID_DCPH  = "d";	//Vodafone Mobile connect (previously called Planet Hutch)	
	    String  serviceID_DCIR  = "d";	//International Roaming
	    String  serviceID_DCNR  = "d";	//National Roaming
	    String  serviceID_DCBIR = "d";	//Basic International Roaming
	    // Mirt:  Added flag in hopes that Itemized Bill will be part of TBL_SNCODE2.  Open Issue to India
	    //        The DCIB portion of var name will/may change once this is resolved
	    String  serviceID_DCIB = "d";	//Itemized Billing
	    
	    // IVRServices handler populates these codes based on TBL_SNCODE2
	    //   when the property name-value object is created.
	    //
	    // Handler: ActivateService uses these values 
	    String  serviceID_DCSTD_code = null;	//STD service (lond distance calls)
	    String  serviceID_DCISD_code = null;	//ISD service (INTERNATIONAL calls)
	    String  serviceID_DCHA_code  = null;	//Vodafone Live (previously called Hutch Access)
	    String  serviceID_DCPH_code  = null;	//Vodafone Mobile connect (previously called Planet Hutch)	
	    String  serviceID_DCIR_code  = null;	//International Roaming
	    String  serviceID_DCNR_code  = null;	//National Roaming
	    String  serviceID_DCBIR_code = null;	//Basic International Roaming
	    // Mirt:  Added code in hopes that Itemized Bill will be part of TBL_SNCODE2.  Open Issue to India
	    //        The DCIB portion of var name will/may change once this is resolved
	    String  serviceID_DCIB_code = null;
	    
	    // Handler:  GetBirthDate
	    String birthDate = null;		// will be null or callers BDay from TBL_GEN
	    String birthFlag = "N";			// From TBL_SERIES - used by handler only
	    
	    // Handler: TableBirth
	    String playedBirthMsgFlag = "Y"; // if set to 'N' will play Birthday greeting
	    
	    // Handler: GetBillingInfo  (Pg 10)  -- populated from CDB or LDB 
        float  billCurrentOutstandingAmt = 0;
        String  billPayableByDate = null;
        float  billUnbilledAmt = 0;
        float  billLastPaymentAmt = 0;
        String  billLastPaymentDate = null;
        float  billCreditLimitAmt = 0;
        float  billDepositRequiredAmt = 0;
        String  billBillingCycle = null;
        String  billBillEmail = null;
        String  billBillZipCode = null;		// needed for Bill pymt logic in pg 16 - see pg 16 for DB info

        // Handler: VDN
        //
        // Notes: 
        //      where to transfer caller to based on keys: CUST_TYPE, TRAN_TYPE, LANG, CATEGORY 
        //		these values are available in this class  
        
        String  vdnRoutePoint = null; 	// where to transfer caller to   
        
        // Handler: PaymentGateway  (Pg 15)
        String  paygateRefNumber = null;	// refernce number for successful paymt rtnd from paymet gateway

        // Handler: GetMPIN -- note this handler is called from XML and internally by other handlers - Ex. CSSServer)
        String mpin = null;					// from stored proceedure ivr_mpin if not null or BLANK MPIN exists
        
        // Handler: CSSServer  - calls GetMPIN and updates the MPIN 
        
        // Handler: GetServiceFlag    (Pg 22   Uses TBL_OPTALD)
        String  serviceFlag = "N";

        // Handler: CreditMatrix  (Pg 29)
        String cmServiceAllowed = "N";
        float cmDepositRequired = 0;

        // Handler:  SMSBilling  
        String pymtphrase = null;   // string of audio files that we may need to play - Pradeep to investigate
        
	    //  ******************* SCS - end of additions 07/02/2008 ******************************
	    
        // Shailesh - Added 9/11/2008 - Don't forget this date
        // To support Activation/Deactivation Report
	    String  serviceFlag_DCSTD = "N";	//STD service (lond distance calls)
	    String  serviceFlag_DCISD = "N";	//ISD service (INTERNATIONAL calls)
	    String  serviceFlag_DCHA  = "N";	//Vodafone Live (previously called Hutch Access)
	    String  serviceFlag_DCPH  = "N";	//Vodafone Mobile connect (previously called Planet Hutch)	
	    String  serviceFlag_DCIR  = "N";	//International Roaming
	    String  serviceFlag_DCNR  = "N";	//National Roaming
	    String  serviceFlag_DCBIR = "N";	//Basic International Roaming
	    String  serviceFlag_DCIB  = "N";	//Itemized Billing
	    String  serviceFlag_DCDB  = "N";	//Duplicate Billing
	    String  serviceFlag_DCLC  = "N";	//Language Change
	    
	    public String getDailyXfers() {
			return dailyXfers;
		}

		public void setDailyXfers(String dailyXfers) {
			this.dailyXfers = dailyXfers;
		}

		public String getVdn_category() {
			return vdn_category;
		}

		public void setVdn_category(String vdn_category) {
			this.vdn_category = vdn_category;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getPukNumber() {
			return pukNumber;
		}

		public void setPukNumber(String pukNumber) {
			this.pukNumber = pukNumber;
		}

		//   Getters and Setters placed here
		public static long getSerialVersionUID() {
			return serialVersionUID;
		}

		public String getBarredFlag() {
			return barredFlag;
		}

		public void setBarredFlag(String barredFlag) {
			this.barredFlag = barredFlag;
		}

		public String getCallFlowType() {
			return callFlowType;
		}

		public void setCallFlowType(String callFlowType) {
			this.callFlowType = callFlowType;
		}

		public String getDbCType() {
			return dbCType;
		}

		public void setDbCType(String dbCType) {
			this.dbCType = dbCType;
		}

		public String getFirstTimeCallerFlag() {
			return firstTimeCallerFlag;
		}

		public void setFirstTimeCallerFlag(String firstTimeCallerFlag) {
			this.firstTimeCallerFlag = firstTimeCallerFlag;
		}

		public String getInroamerFlag() {
			return inroamerFlag;
		}

		public void setInroamerFlag(String inroamerFlag) {
			this.inroamerFlag = inroamerFlag;
		}

		public String getCallerFound() {
			return callerFound;
		}

		public void setCallerFound(String callerFound) {
			this.callerFound = callerFound;
		}

		public String getLandlineNumber() {
			return landlineNumber;
		}

		public void setLandlineNumber(String landlineNumber) {
			this.landlineNumber = landlineNumber;
		}

		public String getPrefLang() {
			return prefLang;
		}

		public void setPrefLang(String prefLang) {
			this.prefLang = prefLang;
		}

		public String getCoid() {
			return coid;
		}

		public void setCoid(String coid) {
			this.coid = coid;
		}

		public String getCust_id() {
			return cust_id;
		}

		public void setCust_id(String cust_id) {
			this.cust_id = cust_id;
		}

		public String getCustCode() {
			return custCode;
		}

		public void setCustCode(String custCode) {
			this.custCode = custCode;
		}

		public String getPrgcode() {
			return prgcode;
		}

		public void setPrgcode(String prgcode) {
			this.prgcode = prgcode;
		}

		public String getWhichDB() {
			return whichDB;
		}

		public void setWhichDB(String whichDB) {
			this.whichDB = whichDB;
		}

		public String getServiceID_DCBIR() {
			return serviceID_DCBIR;
		}

		public void setServiceID_DCBIR(String serviceID_DCBIR) {
			this.serviceID_DCBIR = serviceID_DCBIR;
		}

		public String getServiceID_DCHA() {
			return serviceID_DCHA;
		}

		public void setServiceID_DCHA(String serviceID_DCHA) {
			this.serviceID_DCHA = serviceID_DCHA;
		}

		public String getServiceID_DCIR() {
			return serviceID_DCIR;
		}

		public void setServiceID_DCIR(String serviceID_DCIR) {
			this.serviceID_DCIR = serviceID_DCIR;
		}

		public String getServiceID_DCISD() {
			return serviceID_DCISD;
		}

		public void setServiceID_DCISD(String serviceID_DCISD) {
			this.serviceID_DCISD = serviceID_DCISD;
		}

		public String getServiceID_DCNR() {
			return serviceID_DCNR;
		}

		public void setServiceID_DCNR(String serviceID_DCNR) {
			this.serviceID_DCNR = serviceID_DCNR;
		}

		public String getServiceID_DCPH() {
			return serviceID_DCPH;
		}

		public void setServiceID_DCPH(String serviceID_DCPH) {
			this.serviceID_DCPH = serviceID_DCPH;
		}

		public String getServiceID_DCSTD() {
			return serviceID_DCSTD;
		}

		public void setServiceID_DCSTD(String serviceID_DCSTD) {
			this.serviceID_DCSTD = serviceID_DCSTD;
		}

		public String getServiceID_DCIB() {
			return serviceID_DCIB;
		}

		public void setServiceID_DCIB(String serviceID_DCIB) {
			this.serviceID_DCIB = serviceID_DCIB;
		}

		public String getServiceID_DCIB_code() {
			return serviceID_DCIB_code;
		}

		public void setServiceID_DCIB_code(String serviceID_DCIB_code) {
			this.serviceID_DCIB_code = serviceID_DCIB_code;
		}

		public String getBillBillEmail() {
			return billBillEmail;
		}

		public void setBillBillEmail(String billBillEmail) {
			this.billBillEmail = billBillEmail;
		}

		public String getBillBillingCycle() {
			return billBillingCycle;
		}

		public void setBillBillingCycle(String billBillingCycle) {
			this.billBillingCycle = billBillingCycle;
		}

		public String getBillBillZipCode() {
			return billBillZipCode;
		}

		public void setBillBillZipCode(String billBillZipCode) {
			this.billBillZipCode = billBillZipCode;
		}


		public String getBillLastPaymentDate() {
			return billLastPaymentDate;
		}

		public void setBillLastPaymentDate(String billLastPaymentDate) {
			this.billLastPaymentDate = billLastPaymentDate;
		}

		public String getBillPayableByDate() {
			return billPayableByDate;
		}

		public void setBillPayableByDate(String billPayableByDate) {
			this.billPayableByDate = billPayableByDate;
		}

		public float getBillCreditLimitAmt() {
			return billCreditLimitAmt;
		}

		public void setBillCreditLimitAmt(float billCreditLimitAmt) {
			this.billCreditLimitAmt = billCreditLimitAmt;
		}

		public float getBillCurrentOutstandingAmt() {
			return billCurrentOutstandingAmt;
		}

		public void setBillCurrentOutstandingAmt(float billCurrentOutstandingAmt) {
			this.billCurrentOutstandingAmt = billCurrentOutstandingAmt;
		}

		public float getBillDepositRequiredAmt() {
			return billDepositRequiredAmt;
		}

		public void setBillDepositRequiredAmt(float billDepositRequiredAmt) {
			this.billDepositRequiredAmt = billDepositRequiredAmt;
		}

		public float getBillLastPaymentAmt() {
			return billLastPaymentAmt;
		}

		public void setBillLastPaymentAmt(float billLastPaymentAmt) {
			this.billLastPaymentAmt = billLastPaymentAmt;
		}

		public float getBillUnbilledAmt() {
			return billUnbilledAmt;
		}

		public void setBillUnbilledAmt(float billUnbilledAmt) {
			this.billUnbilledAmt = billUnbilledAmt;
		}

		public String getBirthDate() {
			return birthDate;
		}

		public void setBirthDate(String birthDate) {
			this.birthDate = birthDate;
		}

		public String getBirthFlag() {
			return birthFlag;
		}

		public void setBirthFlag(String birthFlag) {
			this.birthFlag = birthFlag;
		}

		public float getCmDepositRequired() {
			return cmDepositRequired;
		}

		public void setCmDepositRequired(float cmDepositRequired) {
			this.cmDepositRequired = cmDepositRequired;
		}

		public String getCmServiceAllowed() {
			return cmServiceAllowed;
		}

		public void setCmServiceAllowed(String cmServiceAllowed) {
			this.cmServiceAllowed = cmServiceAllowed;
		}

		public String getMpin() {
			return mpin;
		}

		public void setMpin(String mpin) {
			this.mpin = mpin;
		}

		public String getPaygateRefNumber() {
			return paygateRefNumber;
		}

		public void setPaygateRefNumber(String paygateRefNumber) {
			this.paygateRefNumber = paygateRefNumber;
		}

		public String getPlayedBirthMsgFlag() {
			return playedBirthMsgFlag;
		}

		public void setPlayedBirthMsgFlag(String playedBirthMsgFlag) {
			this.playedBirthMsgFlag = playedBirthMsgFlag;
		}

		public String getPrgname() {
			return prgname;
		}

		public void setPrgname(String prgname) {
			this.prgname = prgname;
		}

		public String getPymtphrase() {
			return pymtphrase;
		}

		public void setPymtphrase(String pymtphrase) {
			this.pymtphrase = pymtphrase;
		}

		public String getServiceFlag() {
			return serviceFlag;
		}

		public void setServiceFlag(String serviceFlag) {
			this.serviceFlag = serviceFlag;
		}

		public String getServiceID_DCBIR_code() {
			return serviceID_DCBIR_code;
		}

		public void setServiceID_DCBIR_code(String serviceID_DCBIR_code) {
			this.serviceID_DCBIR_code = serviceID_DCBIR_code;
		}

		public String getServiceID_DCHA_code() {
			return serviceID_DCHA_code;
		}

		public void setServiceID_DCHA_code(String serviceID_DCHA_code) {
			this.serviceID_DCHA_code = serviceID_DCHA_code;
		}

		public String getServiceID_DCIR_code() {
			return serviceID_DCIR_code;
		}

		public void setServiceID_DCIR_code(String serviceID_DCIR_code) {
			this.serviceID_DCIR_code = serviceID_DCIR_code;
		}

		public String getServiceID_DCISD_code() {
			return serviceID_DCISD_code;
		}

		public void setServiceID_DCISD_code(String serviceID_DCISD_code) {
			this.serviceID_DCISD_code = serviceID_DCISD_code;
		}

		public String getServiceID_DCNR_code() {
			return serviceID_DCNR_code;
		}

		public void setServiceID_DCNR_code(String serviceID_DCNR_code) {
			this.serviceID_DCNR_code = serviceID_DCNR_code;
		}

		public String getServiceID_DCPH_code() {
			return serviceID_DCPH_code;
		}

		public void setServiceID_DCPH_code(String serviceID_DCPH_code) {
			this.serviceID_DCPH_code = serviceID_DCPH_code;
		}

		public String getServiceID_DCSTD_code() {
			return serviceID_DCSTD_code;
		}

		public void setServiceID_DCSTD_code(String serviceID_DCSTD_code) {
			this.serviceID_DCSTD_code = serviceID_DCSTD_code;
		}

		public String getVdnRoutePoint() {
			return vdnRoutePoint;
		}

		public void setVdnRoutePoint(String vdnRoutePoint) {
			this.vdnRoutePoint = vdnRoutePoint;
		}

		public String getTran_type() {
			return tran_type;
		}

		public void setTran_type(String tran_type) {
			this.tran_type = tran_type;
		}

		public boolean isTableSeriesCalled() {
			return tableSeriesCalled;
		}

		public void setTableSeriesCalled(boolean tableSeriesCalled) {
			this.tableSeriesCalled = tableSeriesCalled;
		}

		public boolean isIvrCallDetailsCalled() {
			return ivrCallDetailsCalled;
		}

		public void setIvrCallDetailsCalled(boolean ivrCallDetailsCalled) {
			this.ivrCallDetailsCalled = ivrCallDetailsCalled;
		}

		public boolean isIvrMainCalled() {
			return ivrMainCalled;
		}

		public void setIvrMainCalled(boolean ivrMainCalled) {
			this.ivrMainCalled = ivrMainCalled;
		}

		/**
		 * @return the smsCount
		 */
		public int getSmsCount() {
			return smsCount;
		}

		/**
		 * @param smsCount the smsCount to set
		 */
		public void setSmsCount(int smsCount) {
			this.smsCount = smsCount;
		}

		/**
		 * @return the serviceFlag_DCBIR
		 */
		public String getServiceFlag_DCBIR() {
			return serviceFlag_DCBIR;
		}

		/**
		 * @param serviceFlag_DCBIR the serviceFlag_DCBIR to set
		 */
		public void setServiceFlag_DCBIR(String serviceFlag_DCBIR) {
			this.serviceFlag_DCBIR = serviceFlag_DCBIR;
		}

		/**
		 * @return the serviceFlag_DCHA
		 */
		public String getServiceFlag_DCHA() {
			return serviceFlag_DCHA;
		}

		/**
		 * @param serviceFlag_DCHA the serviceFlag_DCHA to set
		 */
		public void setServiceFlag_DCHA(String serviceFlag_DCHA) {
			this.serviceFlag_DCHA = serviceFlag_DCHA;
		}

		/**
		 * @return the serviceFlag_DCIB
		 */
		public String getServiceFlag_DCIB() {
			return serviceFlag_DCIB;
		}

		/**
		 * @param serviceFlag_DCIB the serviceFlag_DCIB to set
		 */
		public void setServiceFlag_DCIB(String serviceFlag_DCIB) {
			this.serviceFlag_DCIB = serviceFlag_DCIB;
		}

		/**
		 * @return the serviceFlag_DCIR
		 */
		public String getServiceFlag_DCIR() {
			return serviceFlag_DCIR;
		}

		/**
		 * @param serviceFlag_DCIR the serviceFlag_DCIR to set
		 */
		public void setServiceFlag_DCIR(String serviceFlag_DCIR) {
			this.serviceFlag_DCIR = serviceFlag_DCIR;
		}

		/**
		 * @return the serviceFlag_DCISD
		 */
		public String getServiceFlag_DCISD() {
			return serviceFlag_DCISD;
		}

		/**
		 * @param serviceFlag_DCISD the serviceFlag_DCISD to set
		 */
		public void setServiceFlag_DCISD(String serviceFlag_DCISD) {
			this.serviceFlag_DCISD = serviceFlag_DCISD;
		}

		/**
		 * @return the serviceFlag_DCNR
		 */
		public String getServiceFlag_DCNR() {
			return serviceFlag_DCNR;
		}

		/**
		 * @param serviceFlag_DCNR the serviceFlag_DCNR to set
		 */
		public void setServiceFlag_DCNR(String serviceFlag_DCNR) {
			this.serviceFlag_DCNR = serviceFlag_DCNR;
		}

		/**
		 * @return the serviceFlag_DCPH
		 */
		public String getServiceFlag_DCPH() {
			return serviceFlag_DCPH;
		}

		/**
		 * @param serviceFlag_DCPH the serviceFlag_DCPH to set
		 */
		public void setServiceFlag_DCPH(String serviceFlag_DCPH) {
			this.serviceFlag_DCPH = serviceFlag_DCPH;
		}

		/**
		 * @return the serviceFlag_DCSTD
		 */
		public String getServiceFlag_DCSTD() {
			return serviceFlag_DCSTD;
		}

		/**
		 * @param serviceFlag_DCSTD the serviceFlag_DCSTD to set
		 */
		public void setServiceFlag_DCSTD(String serviceFlag_DCSTD) {
			this.serviceFlag_DCSTD = serviceFlag_DCSTD;
		}

		/**
		 * @return the serviceFlag_DCDB
		 */
		public String getServiceFlag_DCDB() {
			return serviceFlag_DCDB;
		}

		/**
		 * @param serviceFlag_DCDB the serviceFlag_DCDB to set
		 */
		public void setServiceFlag_DCDB(String serviceFlag_DCDB) {
			this.serviceFlag_DCDB = serviceFlag_DCDB;
		}

		/**
		 * @return the serviceFlag_DCLC
		 */
		public String getServiceFlag_DCLC() {
			return serviceFlag_DCLC;
		}

		/**
		 * @param serviceFlag_DCLC the serviceFlag_DCLC to set
		 */
		public void setServiceFlag_DCLC(String serviceFlag_DCLC) {
			this.serviceFlag_DCLC = serviceFlag_DCLC;
		}

		/**
		 * @return the creditMatrixCalled
		 */
		public boolean isCreditMatrixCalled() {
			return creditMatrixCalled;
		}

		/**
		 * @param creditMatrixCalled the creditMatrixCalled to set
		 */
		public void setCreditMatrixCalled(boolean creditMatrixCalled) {
			this.creditMatrixCalled = creditMatrixCalled;
		}

		/**
		 * @return the tableGenCalled
		 */
		public boolean isTableGenCalled() {
			return tableGenCalled;
		}

		/**
		 * @param tableGenCalled the tableGenCalled to set
		 */
		public void setTableGenCalled(boolean tableGenCalled) {
			this.tableGenCalled = tableGenCalled;
		}

		/**
		 * @return the address1
		 */
		public String getAddress1() {
			return address1;
		}

		/**
		 * @param address1 the address1 to set
		 */
		public void setAddress1(String address1) {
			this.address1 = address1;
		}

		/**
		 * @return the address2
		 */
		public String getAddress2() {
			return address2;
		}

		/**
		 * @param address2 the address2 to set
		 */
		public void setAddress2(String address2) {
			this.address2 = address2;
		}

		/**
		 * @return the address3
		 */
		public String getAddress3() {
			return address3;
		}

		/**
		 * @param address3 the address3 to set
		 */
		public void setAddress3(String address3) {
			this.address3 = address3;
		}

		/**
		 * @return the city
		 */
		public String getCity() {
			return city;
		}

		/**
		 * @param city the city to set
		 */
		public void setCity(String city) {
			this.city = city;
		}

		/**
		 * @return the firstName
		 */
		public String getFirstName() {
			return firstName;
		}

		/**
		 * @param firstName the firstName to set
		 */
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		/**
		 * @return the lastName
		 */
		public String getLastName() {
			return lastName;
		}

		/**
		 * @param lastName the lastName to set
		 */
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		/**
		 * @return the title
		 */
		public String getTitle() {
			return title;
		}

		/**
		 * @param title the title to set
		 */
		public void setTitle(String title) {
			this.title = title;
		}

		/**
		 * @return the creditType
		 */
		public String getCreditType() {
			return creditType;
		}

		/**
		 * @param creditType the creditType to set
		 */
		public void setCreditType(String creditType) {
			this.creditType = creditType;
		}

		/**
		 * @return the gprs_Flag
		 */
		public String getGprs_Flag() {
			return gprs_Flag;
		}

		/**
		 * @param gprs_Flag the gprs_Flag to set
		 */
		public void setGprs_Flag(String gprs_Flag) {
			this.gprs_Flag = gprs_Flag;
		}    
		
}