/*
 * Created on Jun 10, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.misc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.local.PayIvrDAO;
import com.selfserv.ivr.selfservdao.local.TransIdDAO;

/**
 * @author mansey
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PaymentInfoDAO {

	private static Logger LOGGER = Logger.getLogger(PaymentInfoDAO.class);
	private String mobile = null;
	private String callid = null;
	private String jndiName = null;
	private String gatewayURL = null;
	private String coTimeout = null;
	private String soTimeout = null;
	
	private static String[] PARAM_LIST = {"TI", "SO", "AT", "DT", "CN", "ED", "CV", "MO", "CU", "CO", "CH"};

	private static final String TRANSID_PREPEND_STR = "IVR";
	private static final String AMOUNT_PREPEND_STR = "RS";
	private static final String TIMESTAMP_FORMAT = "ddMMMyyyyHHmmss";
	private static final String DATE_FORMAT = "ddMMyy";
	private static final int MIN_SEQUENCE_NUMBER = 444599;
	private static final int MAX_SEQUENCE_NUMBER = 999999;
	private static int SEQUENCE_NUMBER = MIN_SEQUENCE_NUMBER;
	private static final String TIMEOUT_RESPONSE = "The operation has timed-out.";
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public PaymentInfoDAO(String jndiName, String mobile, String callid, String url, 
			String cTimeout, String sTimeout, boolean bTestCall) throws SQLException {
		this.mobile = mobile;
		this.callid = callid;
		this.jndiName = jndiName;
		this.gatewayURL = url;
		this.coTimeout = cTimeout;
		this.soTimeout = sTimeout;
		testCall = bTestCall;

		logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered PaymentInfoDAO"));
	}

	/*
	 * Format of HTTP Get request:
	 * http:// kiosknorth.vodafone.in/IvrCC.asp?TI=IVRDEL1&amp;AT=RS11&amp;DT=05Jul2006183045&amp;CN=5546199368915005&amp;ED=0125&amp;CV=111&amp;MO=9811918178&amp;CU=&amp;CO=DEL&amp;CH=00031050706
	 *
	 * TI= transaction id , it is circle code appended by sequence number which should be unique for respective circle.
	 * E.g. circlecode for Mumbai is IVRMUM, Gujarat is IVRGUJ etc.  For this parameter prepend IVR to 3 character circle code
	 *
	 * SO= BILLPAY/DEPOSIT
	 * �Billpay� if bill payment and �deposit� if deposit payment.
	 *
	 * AT = amount of payment starting with RS.
	 * DT = time stamp of payment. Format = DDMONYYYYHH24MISS
	 * CN= credit card no
	 * ED= expiry date  Format = MMYY
	 * CV= CVV1 number
	 * MO=requested mobile no
	 * CU= null
	 * CO= circle code as mentioned in transaction id (in this parameter
	 * CH = circle id | unique sequence no (same as in transaction id) | date format: DDMMYY
	 * 
	 */

	public PaymentInfoResp makePayment(PaymentInfoReq pymntInfo) {

		PaymentInfoResp pymntResp = null;
		Date currTime = null;
		String sourceName = null;
		Calendar today = null;
		String transactionId = null;

		String respString = null;
		int seqNum = getNextSequenceNumber();

		StringBuffer transId = new StringBuffer(TRANSID_PREPEND_STR);
		String circleCode = pymntInfo.getCircleName().substring(0, 3).toUpperCase();

		transId.append(circleCode);
		sourceName = transId.toString();
		// append sequence # to transId
		transId.append(seqNum);
		// get transaction ID for later use
		transactionId = transId.toString();

		NameValuePair[] params = new NameValuePair[PARAM_LIST.length];

		params[0] = new NameValuePair(PARAM_LIST[0], transactionId);
		String paymentType = null;
		if (pymntInfo.getPaymentType().toUpperCase().equals(PaymentInfoReq.PAYMENT_TYPE_DEPOSIT)) {
			paymentType = "DEPOSIT";
		} else {
			paymentType = "BILLPAY";
		}
		params[1] = new NameValuePair(PARAM_LIST[1], paymentType);

		StringBuffer amountStr = new StringBuffer(AMOUNT_PREPEND_STR);
		amountStr.append(pymntInfo.getAmount());

		params[2] = new NameValuePair(PARAM_LIST[2], amountStr.toString());

		today = Calendar.getInstance();
		currTime = today.getTime();

		SimpleDateFormat df = new SimpleDateFormat(TIMESTAMP_FORMAT);
		String currTimeStr = df.format(currTime);

		params[3] = new NameValuePair(PARAM_LIST[3], currTimeStr);
		params[4] = new NameValuePair(PARAM_LIST[4], pymntInfo.getCardNumber());
		params[5] = new NameValuePair(PARAM_LIST[5], pymntInfo.getExpiryDate());
		params[6] = new NameValuePair(PARAM_LIST[6], pymntInfo.getCvvNumber());
		params[7] = new NameValuePair(PARAM_LIST[7], pymntInfo.getMobileNumber());
		params[8] = new NameValuePair(PARAM_LIST[8], "");
		params[9] = new NameValuePair(PARAM_LIST[9], circleCode);

		SimpleDateFormat df1 = new SimpleDateFormat(DATE_FORMAT);
		String currDateStr = df1.format(currTime);

		StringBuffer circleInfo = new StringBuffer(pymntInfo.getCircleCode());
		circleInfo.append(seqNum);	// sequence #
		circleInfo.append(currDateStr);

		params[10] = new NameValuePair(PARAM_LIST[10], circleInfo.toString());

		// TODO:  These are only for testing so that we can accept self-generated certificates
		// remove the next 2 calls to org.apache....
		// 1.) unregister the current https protocol.
		//org.apache.commons.httpclient.protocol.Protocol.unregisterProtocol("https");
		// 2.) reregister the new https protocol to use the easy ssl protocol socket factory.
		//org.apache.commons.httpclient.protocol.Protocol.registerProtocol("https", new Protocol("https", new org.apache.commons.contrib.EasySSLProtocolSocketFactory(), 9443));

		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(gatewayURL);
		
		try {
			httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(new Integer(coTimeout).intValue());
			httpclient.getHttpConnectionManager().getParams().setSoTimeout(new Integer(soTimeout).intValue());

			// interface requires parameters in a POST request
			httpPost.setRequestBody(params);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - Sending POST request for transaction ID = ").append(transactionId));				
			}
			
			httpclient.executeMethod(httpPost);
			//respString = get.getResponseBodyAsString();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					httpPost.getResponseBodyAsStream(), httpPost.getResponseCharSet()));
			StringBuffer str = new StringBuffer();
			String tempStr = null;
			while ((tempStr = reader.readLine()) != null) {
				str.append(tempStr);
			}
			respString = str.toString();
		}
		catch(HttpException e) {
			LOGGER.error(e.getMessage());
		}
		catch(IOException e) {
			LOGGER.error(e.getMessage());
		}
		catch(Exception e) {
			LOGGER.error(e.getMessage());

		}
		finally {
			httpPost.releaseConnection();
		}

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Response String = ").append(respString));

		pymntResp = new PaymentInfoResp();
		pymntResp.setCustomerID(pymntInfo.getCustomerID());
		pymntResp.setCircleID(pymntInfo.getCircleCode());
		pymntResp.setMobileNumber(pymntInfo.getMobileNumber());
		pymntResp.setSourceName(sourceName);
		pymntResp.setTransType(PaymentInfoResp.TRANS_TYPE_PAYMENT);
		if (pymntInfo.getPaymentType().compareTo(PaymentInfoReq.PAYMENT_TYPE_BILLPAY) == 0) {
			pymntResp.setServName(PaymentInfoResp.SERV_NAME_PAYMENT);
		} else {
			pymntResp.setServName(PaymentInfoResp.SERV_NAME_DEPOSIT);
		}
		pymntResp.setTransDate(today);
		pymntResp.setAmount(pymntInfo.getAmount());
		pymntResp.setTraceNumber(seqNum);
		pymntResp.setSnCode("0");
		if (respString == null) {	// timeout
			pymntResp.setResponseFlag(PaymentInfoResp.TIMEOUT_FLAG);
			pymntResp.setResponse(TIMEOUT_RESPONSE);
		} else {
			String[] splitRespStr = respString.split(":");
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Response String length = ").append(splitRespStr.length));
			if (splitRespStr.length >= 1)
				pymntResp.setResponseFlag(splitRespStr[0]);
			else
				pymntResp.setResponseFlag(PaymentInfoResp.ERROR_FLAG);
			pymntResp.setResponse(respString);
			if (splitRespStr.length >= 3)
				pymntResp.setReferenceNumber(splitRespStr[2]);
		}

		// insert record in table
		try {
			PayIvrDAO payIvrDao = new PayIvrDAO(this.jndiName, this.mobile, this.callid, this.testCall);
			int addCount = payIvrDao.insert(pymntResp);
			if (addCount == 1) {
				pymntResp.setDBRC("S");
			} else {
				pymntResp.setDBRC("F_NF");
				pymntResp.setDBMsg("Error while inserting record");
			}

		}
		catch (SQLException e) {
			LOGGER.error(e.getMessage());
			pymntResp.setDBRC("F_C");
			pymntResp.setDBMsg(e.getMessage());
		}

		return pymntResp;

	}

	private synchronized int getNextSequenceNumber() {
		int transId = 0;

		try {
			TransIdDAO transDAO = new TransIdDAO(jndiName, mobile, callid, testCall);
			transId = transDAO.getNextTransId();
		}
		catch(SQLException e) {
			LOGGER.error(e.getMessage());
		}

		return transId;
	}

}
