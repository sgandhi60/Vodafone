package com.selfserv.ivr.selfservdao.central;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class IVRCallDetailsDAO extends BaseDAO{

	private final static Logger LOGGER = Logger.getLogger(IVRCallDetailsDAO.class);

	private Connection conn = null;
	private CallableStatement cstmt = null;
	private String jndiName = null;
	private String callid = null;
	private String mobile = null;

	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private String spPackageName = null;

	public IVRCallDetailsDAO(String jndiName, String mobile, String callid, boolean bTestCall, String packageName) {
		// initialization
		this.jndiName = jndiName;
		this.callid = callid;
		this.mobile = mobile;
		this.testCall = bTestCall;
		this.spPackageName = packageName;

		logToken = new StringBuffer("[").append(callid).append("] ").toString();
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered IVRCallDetailsDAO"));
	}

	public IVRCallDetailsXfer executeSP(String crcl_id, int coid, int cust_id) {
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - *******Entered IVRCallDetailsDAO::executeSP()"));
		IVRCallDetailsXfer ivrCallDetailsXfer = executeSPForBilling(crcl_id, coid, cust_id);

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ********Exiting IVRCallDetailsDAO"));
		return ivrCallDetailsXfer;
	}

	
	
	public IVRCallDetailsXfer executeSPForBilling(String crcl_id, int coid, int cust_id) {
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - *******Entered IVRCallDetailsDAO::executeSPForBilling()"));
		
		IVRCallDetailsXfer ivrCallDetailsXfer = new IVRCallDetailsXfer();
		
		//Connect to the DB
		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
	        ivrCallDetailsXfer.setDBRC("F_C");
			LOGGER.error(new StringBuffer(logToken).append(" - Exception getting a connection to the CDB: ").append(e.getMessage()));
		}

		//get information from the SP
		try {
			/*ivr_call_details(crcl_id IN VARCHAR2,coid IN NUMBER, cust_id IN NUMBER, 
					cust_code OUT VARCHAR2, bCycle OUT VARCHAR2, balance OUT NUMBER, birthdt OUT DATE, lbc_date OUT DATE, climit OUT	 NUMBER, 
					pgcode OUT NUMBER, pgname OUT	VARCHAR2, 
					email OUT VARCHAR2, tmcode OUT NUMBER, schm OUT VARCHAR2, schnm OUT VARCHAR2, 
					STS OUT VARCHAR2, ret_ubamt OUT NUMBER,ret_duedt OUT DATE, ret_deposit OUT VARCHAR2, ret_payments OUT VARCHAR2, 
					ret_lbldamt OUT NUMBER, ret_msg OUT VARCHAR2,zipcd OUT VARCHAR2);*/
			
			if (conn!=null){
				if(testCall){
					LOGGER.debug(new StringBuffer(logToken).append(" - Invoking SP: ivr_call_details"));
					LOGGER.debug(new StringBuffer(logToken).append(" - circle: ").append(crcl_id));
					LOGGER.debug(new StringBuffer(logToken).append(" - coid: ").append(coid));
					LOGGER.debug(new StringBuffer(logToken).append(" - cust_id:").append(cust_id));
				}
				String query = StoredProcedureQuery.getQuery(StoredProcedureQuery.IVR_CALL_DETAILS, spPackageName);
				cstmt = conn.prepareCall(query);
				
				//Setting IN params: crcl_id, msisdn
				cstmt.setString(1,crcl_id);
				cstmt.setInt(2,coid);
				cstmt.setInt(3,cust_id); 
				
				//registering OUT params: 	cust_code, bCycle,  balance,  birthdt,  lbc_date,  climit, pgcode,  pgname,  email, tmcode, schm, schnm, STS, ret_ubamt, ret_duedt,  ret_deposit,  ret_payments, ret_lbldamt, ret_msg, zipcd
				cstmt.registerOutParameter(4, Types.VARCHAR);
				cstmt.registerOutParameter(5, Types.VARCHAR);
				cstmt.registerOutParameter(6, Types.FLOAT);
				cstmt.registerOutParameter(7, Types.DATE);
				cstmt.registerOutParameter(8, Types.DATE);
				cstmt.registerOutParameter(9, Types.FLOAT);
				cstmt.registerOutParameter(10, Types.INTEGER);
				cstmt.registerOutParameter(11, Types.VARCHAR);
				
				cstmt.registerOutParameter(12, Types.VARCHAR);
				cstmt.registerOutParameter(13, Types.INTEGER);
				cstmt.registerOutParameter(14, Types.VARCHAR);
				cstmt.registerOutParameter(15, Types.VARCHAR);
				cstmt.registerOutParameter(16, Types.VARCHAR);
				cstmt.registerOutParameter(17, Types.FLOAT);
				cstmt.registerOutParameter(18, Types.DATE);
				cstmt.registerOutParameter(19, Types.VARCHAR);
				cstmt.registerOutParameter(20, Types.VARCHAR);
				cstmt.registerOutParameter(21, Types.FLOAT);
				cstmt.registerOutParameter(22, Types.VARCHAR);
				cstmt.registerOutParameter(23, Types.VARCHAR);
				
				cstmt.execute();
				
				String cust_code = null;
				String bCycle = null;
				float balance = 0;
				Date birthDate = null;
				Date lbc_date = null;
				float creditLimit = 0;
				String pgname = null;
				String pgcode = null;
				String email = null;
				int tariffCode = 0;
				String scheme = null;
				String schemeName = null;
				String status = null;
				float ret_unBilliedAmount = 0;
				Date ret_dueDate = null;
				float ret_deposit = 0;
				String ret_payments = null;
				float ret_lastBilledAmount = 0;
				String ret_msg = null;
				String zipCode = null;

				cust_code = cstmt.getString(4);
				bCycle = cstmt.getString(5);
				balance = cstmt.getFloat(6);
				birthDate = cstmt.getDate(7);
				lbc_date = cstmt.getDate(8);
				creditLimit = cstmt.getFloat(9);
				pgcode = cstmt.getString(10);
				pgname = cstmt.getString(11);
				email = cstmt.getString(12);
				tariffCode = cstmt.getInt(13);
				scheme = cstmt.getString(14);
				schemeName = cstmt.getString(15);
				status = cstmt.getString(16);
				ret_unBilliedAmount = cstmt.getFloat(17);
				ret_dueDate = cstmt.getDate(18);
				ret_deposit = cstmt.getFloat(19);
				ret_payments = cstmt.getString(20);
				ret_lastBilledAmount = cstmt.getFloat(21);
				ret_msg = cstmt.getString(22);
				zipCode = cstmt.getString(23);

				// set all the fields in response object
				ivrCallDetailsXfer.setDBRC("S");
				
				ivrCallDetailsXfer.setCust_code(cust_code);
				ivrCallDetailsXfer.setBCycle(bCycle);
				ivrCallDetailsXfer.setBalance(balance);
				ivrCallDetailsXfer.setBirthDate(birthDate);
				ivrCallDetailsXfer.setLbc_date(lbc_date);
				ivrCallDetailsXfer.setCreditLimit(creditLimit);
				ivrCallDetailsXfer.setPgcode(pgcode);
				ivrCallDetailsXfer.setPgname(pgname);
				ivrCallDetailsXfer.setEmail(email);
				ivrCallDetailsXfer.setTariffCode(tariffCode);
				ivrCallDetailsXfer.setScheme(scheme);
				ivrCallDetailsXfer.setSchemeName(schemeName);
				ivrCallDetailsXfer.setStatus(status);
				ivrCallDetailsXfer.setRet_unBilliedAmount(ret_unBilliedAmount);
				ivrCallDetailsXfer.setRet_dueDate(ret_dueDate);
				ivrCallDetailsXfer.setRet_deposit(ret_deposit);
				ivrCallDetailsXfer.setRet_payments(ret_payments);
				ivrCallDetailsXfer.setRet_lastBilledAmount(ret_lastBilledAmount);
				ivrCallDetailsXfer.setRet_msg(ret_msg);
				ivrCallDetailsXfer.setZipCode(zipCode);

				if (cust_code == null || cust_code.length() == 0) {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append("Record not found for coid: ")
								.append(coid).append("; cust_id: ").append(cust_id));
					ivrCallDetailsXfer.setDBRC("F_NF");
				} else {
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" Data from CDB SP - ivr_call_details: "));
						
						LOGGER.debug(new StringBuffer(logToken)
									.append(" cust_code: ").append(cust_code)
									.append(" bCycle: ").append(bCycle)
									.append(" balance: ").append(balance)
									.append(" birthDate: ").append(birthDate)
									.append(" lbc_date: ").append(lbc_date)
									.append(" creditLimit: ").append(creditLimit)
									.append(" pgcode: ").append(pgcode)
									.append(" pgname: ").append(pgname)
									.append(" email: ").append(email)
									.append(" tariffCode: ").append(tariffCode)
									.append(" scheme: ").append(scheme)
									.append(" schemeName: ").append(schemeName)
									.append(" status: ").append(status)
									.append(" ret_unBilliedAmount: ").append(ret_unBilliedAmount)
									.append(" ret_dueDate: ").append(ret_dueDate)
									.append(" ret_deposit: ").append(ret_deposit)
									.append(" ret_payments: ").append(ret_payments)
									.append(" ret_lastBilledAmount: ").append(ret_lastBilledAmount)
									.append(" ret_msg: ").append(ret_msg)
									.append(" zipCode: ").append(zipCode));
					}
	
					ivrCallDetailsXfer.setDBRC("S");
				}


			} else {	       
				ivrCallDetailsXfer.setDBRC("F_C");
				LOGGER.error(new StringBuffer(logToken).append(" - Error getting a connection to the CDB: "));
			}			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception in CDB::ivr_call_details -> could not return stored procedure values. Exception: " + e.getMessage()));
            ivrCallDetailsXfer.setDBRC("F_NF");
			e.printStackTrace();
		}finally{
			 releaseResource(conn, cstmt, null);		 
		}
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ********Exiting IVRCallDetailsDAO"));
		return ivrCallDetailsXfer;
	}
}