package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TableSeriesDAO extends BaseDAO{
	private static Logger LOGGER = Logger.getLogger(TableSeriesDAO.class);
	private Connection conn = null;
	String mobile = null;
	String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	//private final String SQL_QUERY_STMT = "Select CIRCLENAME, CIRCLECODE, BIRTHFLAG, INROAMER_FLAG from TBL_SERIES Where FIRST4DIGIT = ?";
	private final String SQL_QUERY_STMT = "Select CIRCLENAME, CIRCLECODE, INROAMER_FLAG, BIRTHFLAG from TBL_SERIES Where FIRST4DIGIT = ?";
//	private final String SQL_QUERY_BIRTHFLAG_STMT = "Select BIRTHFLAG from TBL_SERIES Where FIRST4DIGIT = ?";
/*	
	public TableSeriesDAO(String jndiName, String mobile, String callid) throws SQLException {
		conn = getConnection(jndiName, mobile, callid);
		LOGGER.debug(new StringBuffer("[").append(callid).append("][").append(mobile).append("]").append(" - Constructor - Connected to LDB "+jndiName));
	}
*/
	public TableSeriesDAO(String localJNDIName, String cell, String callID, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = callID;
		this.testCall = bTestCall;
		
		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
				LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableSeriesDAO"));

		try {
			conn = getConnection(localJNDIName, mobile, callID);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public int insertRecord() {
		return 0;
	}

	public boolean deleteRecord() {
		return false;
	}
	
	public TableSeriesXfer findRecord(String mobile) {
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record"));
	
		PreparedStatement stmt = null;
	    ResultSet rs = null;
	    TableSeriesXfer tsXfer = new TableSeriesXfer();
	    
		 try{
			 if ( conn != null ) {
				 stmt = conn.prepareStatement(SQL_QUERY_STMT);
				 String first4digits = mobile.substring(0,4);
	             stmt.setString(1, first4digits);
	             
	             rs = stmt.executeQuery();
	             String inroamerFlag = null;
	             String birthFlag = null;
	             String circleName = null;
	             String circleCode = null;
	             
	             if (rs.next()){
		        	 if (rs.getString(1)!=null) {
		            	 circleName = rs.getString(1);
		            	 circleCode = rs.getString(2);
		            	 inroamerFlag = rs.getString(3);
		            	 birthFlag = rs.getString(4);
		            	 tsXfer.setCircleName(circleName);
		            	 tsXfer.setCircleCode(circleCode);
		            	 tsXfer.setInroamerFlag(inroamerFlag);
		            	 tsXfer.setBirthFlag(birthFlag);
		            	 
		            	 tsXfer.setDBRC("S");
		            	 
						 if (testCall) {
							 LOGGER.debug(new StringBuffer(logToken).append(" - TBL_SERIES record found"));	            	 
				             LOGGER.debug(new StringBuffer(logToken).append(" - first4Digits = " + first4digits));	
				             LOGGER.debug(new StringBuffer(logToken).append(" - Circle name = " + circleName));
				             LOGGER.debug(new StringBuffer(logToken).append(" - Circle code = " + circleCode));
			            	 LOGGER.debug(new StringBuffer(logToken).append(" - Inroamer flag = " + inroamerFlag));
			            	 LOGGER.debug(new StringBuffer(logToken).append(" - BirthDay flag = " + birthFlag));
						 }
		        	 } else { // empty record
			        	 if (testCall) {
			        		 LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for mobile="+mobile));
			        	 }
			        	 tsXfer.setDBRC("F_NF");
			        	 tsXfer.setDBMsg("Empty record found in the LDB");
		        	 }
		         } else{//no result set found
		        	 if (testCall) {
		        		 LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for mobile="+mobile));
		        	 }
		        	 tsXfer.setDBRC("F_NF");
		        	 tsXfer.setDBMsg("No match found in the LDB");
	             }
			 } else {
	        	 if (testCall) {
	        		 LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for mobile="+mobile));
	        	 }
	        	 tsXfer.setDBRC("F_C");
	        	 tsXfer.setDBMsg("No connection made to DB");
			 }
		 }catch(Exception e){//Problem encounterd getting query results
			 if (testCall)
				 LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the InroamerFlag from TBL_SERIES" + e.getMessage()));
			 tsXfer.setDBRC("F_C");
			 e.printStackTrace();
		 }finally{
			 releaseResource(conn, stmt, rs);		 
		 }
	
		 if (testCall)
			 LOGGER.debug(new StringBuffer(logToken).append(" - Exiting TableSeriesDAO::findRecord()"));
		return tsXfer;
	}
	
/*	This is NOT used now
	public TableSeriesXfer retrieveBirthFlag(String mobile) {
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - retrieving birthflag"));
	
		PreparedStatement stmt = null;
	    ResultSet rs = null;
	    TableSeriesXfer tsXfer = new TableSeriesXfer();
	    
		 try{
			 stmt = conn.prepareStatement(SQL_QUERY_BIRTHFLAG_STMT);
			 String first4digits = mobile.substring(0,4);
             stmt.setString(1, first4digits);
             
             rs = stmt.executeQuery();
             String birthFlag = null;
             if (rs.next()){
	        	 if (rs.getString(1)!=null) {
	            	 birthFlag = rs.getString(1);
	            	 tsXfer.setBirthFlag(birthFlag);
	            	 tsXfer.setDBRC("S");

	            	 if (testCall) {
	            		 LOGGER.debug(new StringBuffer(logToken).append(" - BirthFlag found"));	            	 
	            		 LOGGER.debug(new StringBuffer(logToken).append(" - first4Digits = " + first4digits));	            	 
	            		 LOGGER.debug(new StringBuffer(logToken).append(" - Birth flag = " + birthFlag));
	            	 }
	        	 } else { // empty record
		        	 if (testCall) {
		        		 LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for mobile="+mobile));
		        	 }
		        	 tsXfer.setDBRC("F_NF");
		        	 tsXfer.setDBMsg("Empty record found in the LDB");
	        	 }
	         } else{//no match found
	        	 if (testCall) {
	        		 LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for mobile="+mobile));
	        	 }
	        	 tsXfer.setDBRC("F_NF");
	        	 tsXfer.setDBMsg("No match found in the LDB");
	         }
		 }catch(Exception e){//Problem encounterd getting query results
			 String msg = e.getMessage();			 
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the BirthFlag from TBL_SERIES" + e.getMessage()));
			
			 tsXfer.setDBRC("F_C");
			 tsXfer.setDBMsg(msg);
			 e.printStackTrace();
		 }finally{
			 releaseResource(conn, stmt, rs);		 
		 }
	
		 if (testCall)
			 LOGGER.debug(new StringBuffer(logToken).append(" - Exiting TableSeriesDAO::findRecord()"));
		 return tsXfer;
	}
*/
}