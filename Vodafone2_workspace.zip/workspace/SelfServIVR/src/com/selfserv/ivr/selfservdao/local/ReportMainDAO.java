package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class ReportMainDAO extends BaseDAO{
	private Connection conn = null;
	//private final String SQL_QUERY_CHECK_CDAY = "Select DAY_CALLS, XFER_COUNT from TBL_CDAY_BARRED Where MOBILE = ? and DAY_CALLS = ?";//'24/MAR/08'
	private final String SQL_INSERT = "Insert into TBL_RPT_MAIN" +
										"(STARTTIME,ENDTIME,MSISDN,LANDLINE,CCATEG,MENUS,LASTOPT,LANG,XFER,UCID,CALL_DURATION,CALL_COMPLETION,EXIT_REASON,CTYPE,ACTIVATED,DEACTIVATED) " +
										"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//										"values(to_date('?', 'dd/mm/yyyy hh:mm:ss'),to_date('?', 'dd/mm/yyyy hh:mm:ss'),?,?,?,?,?,?,?,?,?,?)";

	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private static Logger LOGGER = Logger.getLogger(ReportMainDAO.class);

	public ReportMainDAO(String jndiName, String cell, String callID, boolean bTestCall) throws SQLException {
		// initialization 
			this.mobile = cell;
			this.callid = callID;
			this.testCall = bTestCall;

			this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

			if (testCall)
				LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered ReportMainDAO"));

		try {
			conn = getConnection(jndiName, mobile, callID);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	
	/**
	 * Inserts a record by incrementing the daily transfer count to operators
	 * @return
	 */
	public DBXfer insertRecord(Date startTime, Date endTime, String msisdn, String landline, 
			String category, String menus, String lastOpt, String lang, String xferFlag, 
			String ucid, long callDuration, String callCompletion, String exitReason, 
			String cType, String activated, String deactivated) {

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - Entered ReportDAO::insertRecord()"));

		PreparedStatement stmt = null;;
		DBXfer dbXfer = new DBXfer();
		int result = -1;

		if ( (landline == null) || (landline.trim().length() == 0) )
			landline = "-1";
		Timestamp startTimestamp = new Timestamp(startTime.getTime());
		Timestamp endTimestamp = new Timestamp(endTime.getTime());

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append("Record to be inserted into DB with the following data :"));
			LOGGER.debug(new StringBuffer(logToken)
			.append(" Start Time =").append(startTimestamp.toString())
			.append(", End Time =").append(endTimestamp.toString())
			.append(", MSISDN =").append(msisdn)
			.append(", Landline =").append(landline)
			.append(", Category =").append(category)
			.append(", menus =").append(menus)
			.append(", LastOpt =").append(lastOpt)
			.append(", Language =").append(lang)
			.append(", Xfer Flag =").append(xferFlag)
			.append(", UCID =").append(ucid)
			.append(", Call Duration =").append(callDuration)
			.append(", Call Completion =").append(callCompletion)
			.append(", Exit Reason =").append(exitReason)
			.append(", CTYPE =").append(cType)
			.append(", activated=").append(activated)
			.append(", deactivated=").append(deactivated));
		}

		try {
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_INSERT);

				stmt.setTimestamp(1, startTimestamp);		//STARTTIME
				stmt.setTimestamp(2, endTimestamp);			//ENDTIME
				stmt.setString(3, msisdn); 					//MSISDN
				stmt.setString(4, landline); 				//LANDLINE
				stmt.setString(5, category); 				//CCATEG
				stmt.setString(6, menus); 					//MENUS
				stmt.setString(7, lastOpt);					//LASTOPT
				stmt.setString(8, lang); 					//Language
				stmt.setString(9, xferFlag); 				//XFER
				stmt.setString(10, ucid); 					//UCID
				stmt.setLong(11, callDuration); 			//CALL_DURATION
				stmt.setString(12, callCompletion); 		//CALL_COMPLETION
				stmt.setString(13, exitReason); 			//EXIT_REASON
				stmt.setString(14, cType); 					//CTYPE
				stmt.setString(15, activated); 				//ACTIVATED
				stmt.setString(16, deactivated); 			//DEACTIVATED

				result = stmt.executeUpdate();
				if (result == 1) {
					dbXfer.setDBRC("S");
				} else {
					dbXfer.setDBRC("F_NF");
					dbXfer.setDBMsg(" No record inserted in DB");
				}

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append("record(s)"));
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB"));
				}
				dbXfer.setDBRC("F_C");
				dbXfer.setDBMsg(" No connection made to DB");
			}
		} catch (SQLException e) {
			String msg = e.getMessage();	
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_RPT_ - " + e.getMessage()));

			dbXfer.setDBRC("F_C");
			dbXfer.setDBMsg(msg);
		} finally {
			releaseResource(conn, stmt, null);		 
		}

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Exiting ReportDAO::insertRecord()"));
		return dbXfer;
}
	
}
