package com.selfserv.ivr.selfservdao.local;

public class TableBillPymtXfer {
	private String DBRC = null;
	private String smsMessages = null;
	private String pymtPhrase = null; 
	private int centers = 0;
	private String DBMsg = null;
	/**
	 * @return the centers
	 */
	public int getCenters() {
		return centers;
	}
	/**
	 * @param centers the centers to set
	 */
	public void setCenters(int centers) {
		this.centers = centers;
	}
	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}
	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}
	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	/**
	 * @return the smsMessages
	 */
	public String getSmsMessages() {
		return smsMessages;
	}
	/**
	 * @param smsMessages the smsMessages to set
	 */
	public void setSmsMessages(String smsMessages) {
		this.smsMessages = smsMessages;
	}
	/**
	 * @return the pymtPhrase
	 */
	public String getPymtPhrase() {
		return pymtPhrase;
	}
	/**
	 * @param pymtPhrase the pymtPhrase to set
	 */
	public void setPymtPhrase(String pymtPhrase) {
		this.pymtPhrase = pymtPhrase;
	}
	
}
