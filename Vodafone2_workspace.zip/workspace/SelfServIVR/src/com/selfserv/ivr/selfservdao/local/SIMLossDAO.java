package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

import com.selfserv.ivr.handler.CustomerType;
import com.selfserv.ivr.selfservdao.BaseDAO;
import com.selfserv.ivr.selfservdao.DateTime;

public class SIMLossDAO extends BaseDAO{
	private Connection conn = null;
	//private final String SQL_QUERY_CHECK_CDAY = "Select DAY_CALLS, XFER_COUNT from TBL_CDAY_BARRED Where MOBILE = ? and DAY_CALLS = ?";//'24/MAR/08'
	private final String SQL_INSERT = "Insert into TBL_SIMLOSS"+
										"(MOBILE, LANDLINE, CUSTTYPE, SIMSTATUS, REQDATE, REQTIME) "+
										"values(?,?,?,?,?,?)";

	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	private String logToken = null;
	private static Logger LOGGER = Logger.getLogger(SIMLossDAO.class);

	public SIMLossDAO(String jndiName, String cell, String callID, boolean testCall) {
		// initialization 
		mobile= cell;
		callid = callID;
		this.testCall = testCall;
		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
		try {
			conn = getConnection(jndiName, cell, callID);

		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
		}
	}

	
	/**
	 * Inserts a record by incrementing the daily transfer count to operators
	 * @return
	 */
	public int insertRecord(String landline, String dbCType){
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Entered SIMLossDAO::insertRecord()"));
		PreparedStatement stmt;
		
		if ( (landline == null) || (landline.trim().length() == 0) )
			landline = "-1";
		
		//getting the date format
		Date dt = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MMM");
		String mon=formatter.format(dt).toUpperCase();
		
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reqdate = formatter.format(dt);
		
		formatter = new SimpleDateFormat("HHmmss");
		String reqtime = formatter.format(dt);
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Month=").append(mon).append(", reqdate=").append(reqdate).append(", reqtime=").append(reqtime));
		
		try {
			 stmt = conn.prepareStatement(SQL_INSERT);
			 
			 stmt.setString(1, mobile); 				//mobile
			 stmt.setString(2, landline); 				//landline	
			 stmt.setString(3, dbCType); 				//custtype
			 stmt.setString(4, "O"); 					//simstatus
			 stmt.setString(5, reqdate);				//reqdate
			 stmt.setString(6, reqtime); 				//reqtime
			 
	         int result = stmt.executeUpdate();
	         if (testCall) {
	        	 LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append("record(s)"));
	        	 LOGGER.debug(new StringBuffer(logToken).append(" - Exiting SIMLossDAO::insertRecord()"));
	         }
	         return result;
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_SIMLOSS" + e.getMessage()));
			return -1;
		}
	}
	
}
