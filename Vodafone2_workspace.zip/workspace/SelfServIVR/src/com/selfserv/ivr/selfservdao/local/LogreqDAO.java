package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;


public class LogreqDAO extends BaseDAO{
	private Connection conn = null;
	private String callid = null;
	//private final String SQL_QUERY_CHECK_CDAY = "Select DAY_CALLS, XFER_COUNT from TBL_CDAY_BARRED Where MOBILE = ? and DAY_CALLS = ?";//'24/MAR/08'
	private final String SQL_INSERT = "Insert into TBL_LOGREQ"+
										"(MOBILE,LANDLINE,CUSTTYPE,FAXNUMBER,FAXTYPE,MEDIA,EMAIL,TRANTYPE,MONTH,REQDATE,REATIME,STATUS,REASON,SMS_MSG,INT_RESP,CUSTCODE,CONTRACTID,FAXJOBID) "+
										"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private String mobile = null;
	private static Logger LOGGER = Logger.getLogger(LogreqDAO.class);
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;


	public LogreqDAO(String jndiName, String cell, String callID, boolean bTestCall) throws SQLException {
		// initialization 
		this.callid = callID;
		this.mobile = cell;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered LogreqDAO"));
		try {
			conn = getConnection(jndiName,mobile,callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	
	
	/**
	 * Inserts a record by incrementing the daily transfer count to operators
	 * @return
	 */
	public int insertRecord(String landline, String prgcode, String trantype, String smsMsg, String custCode, String coid){
	    if (testCall) 
	    	LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered LogReqDAO:insertRecord"));
		PreparedStatement stmt;
		int result = -1;
		
		if ( (landline == null) || (landline.trim().length() == 0) )
			landline = "-1";
		
		//getting the date format
		Date dt = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MMM");
		String mon=formatter.format(dt).toUpperCase();
		
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reqdate = formatter.format(dt);
		
		formatter = new SimpleDateFormat("HHmmss");
		String reatime = formatter.format(dt);
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Month=").append(mon).append(", reqdate=").append(reqdate).append(", reatime=").append(reatime));
		
		try {
			if ( conn != null ) {
				 stmt = conn.prepareStatement(SQL_INSERT);
				 stmt.setString(1, mobile); 				//mobile
				 stmt.setString(2, landline); 				//landline	
				 stmt.setString(3, prgcode); 				//custtype
				 stmt.setString(4, "N"); 					//faxnumber
				 stmt.setString(5, "N");					//faxtype
				 stmt.setString(6, "SMS"); 					//media
				 stmt.setString(7, "N"); 					//email
				 stmt.setString(8, trantype); 				//trantype
				 stmt.setString(9, mon); 				    //month
				 stmt.setString(10, reqdate); 				//reqdate
				 stmt.setString(11, reatime); 				//reatime
				 stmt.setString(12, "O"); 					//status
				 stmt.setString(13, null); 					//reason
				 stmt.setString(14, smsMsg); 				//sms_msg
				 stmt.setString(15, null); 					//int_resp
				 stmt.setString(16, custCode); 				//custcode
				 stmt.setString(17, coid); 					//contractid
				 stmt.setString(18, null); 					//faxjob
				 
		         result = stmt.executeUpdate();
		         if (testCall) {
		        	 LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append(" record(s)"));
		         }
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB"));
				}
				result = -1;
			}
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_LOGREQ - ").append(e.getMessage()));
			e.printStackTrace();
			return -1;
		}
		
		 if (testCall) 
			 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting LogreqDAO:insertRecord"));
		return result;
	}

	
	/**
	 * Inserts a record for Duplicate Bill
	 * @return
	 */
	public int insertRecordForDupBill(String landline, String prgcode, String media, String email, String trantype, String mon, String custCode, String coid){
	    if (testCall) 
	    	LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered LogreqDAO:insertRecordForDupBill()"));

	    PreparedStatement stmt;
		int result = -1;
		
		if ( (landline == null) || (landline.trim().length() == 0) )
			landline = "-1";
		
		//getting the date format
		Date dt = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MMM");
//		String mon=formatter.format(dt).toUpperCase();
		
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reqdate = formatter.format(dt);
		
		formatter = new SimpleDateFormat("HHmmss");
		String reatime = formatter.format(dt);
		
//		LOGGER.debug(new StringBuffer(l).append(" - Month=").append(mon).append(", reqdate=").append(reqdate).append(", reatime=").append(reatime));
		
		try {
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_INSERT);
				stmt.setString(1, mobile); 				//mobile
				stmt.setString(2, landline); 				//landline	
				stmt.setString(3, prgcode); 				//custtype
				stmt.setString(4, "N"); 					//faxnumber
				stmt.setString(5, "N");					//faxtype
				stmt.setString(6, media); 					//media
				stmt.setString(7, email); 					//email
				stmt.setString(8, trantype); 				//trantype
				stmt.setString(9, mon.substring(0,3));     //month
				stmt.setString(10, reqdate); 				//reqdate
				stmt.setString(11, reatime); 				//reatime
				stmt.setString(12, "O"); 					//status
				stmt.setString(13, null); 					//reason
				stmt.setString(14, null); 					//sms_msg
				stmt.setString(15, null); 					//int_resp
				stmt.setString(16, custCode); 				//custcode
				stmt.setString(17, coid); 					//contractid
				stmt.setString(18, null); 					//faxjob

				result = stmt.executeUpdate();
				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append(" record(s)"));
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB"));
				}
				result = -1;
			}
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_LOGREQ" + e.getMessage()));
		}
		
		 if (testCall) 
			 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting LogreqDAO:insertRecordForDupBill"));
		return result;
	}

}
