/*
 * Created on Jun 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.selfserv.ivr.selfservdao.BaseDAO;


/**
 * @author mansey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TransIdDAO extends BaseDAO {

	private String mobile = null;
	private String callid = null;
	private String jndiName = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	/**
	 * Commons logging for application logging <code>LOGGER</code>.
	 */
	private static Logger LOGGER = Logger.getLogger(TransIdDAO.class);

	private final static String SQL_SELECT = "select TRANSID_SEQ.nextval from dual";

	public TransIdDAO(String jndiName, String mobile, String callid, boolean bTestCall) throws SQLException {
		this.mobile = mobile;
		this.callid = callid;
		this.jndiName = jndiName;
		testCall = bTestCall;

		logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered TransIdDAO"));

	}

	public final int getNextTransId() {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int nextTransId = 0;

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" in getNextTransId"));
		}//end if

		try {
			conn = getConnection(jndiName, mobile, callid);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - Connected to LDB ").append(jndiName));
			}
			/* 
			 * first get circleId from DB
			 */
			stmt = conn.prepareStatement(SQL_SELECT);

			rs = stmt.executeQuery();
			if (rs.next()) {
				nextTransId = rs.getInt(1);
         		if (testCall) {
         			LOGGER.debug(new StringBuffer(logToken).append(" - transaction ID =").append(nextTransId));
	        	}
	         } else {//no result set found
	        	 if (testCall) {
	        		 LOGGER.debug(new StringBuffer(logToken).append(" - could not retrive next transaction ID"));
	        	 }
	         }
		}//end try
		catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(e.getMessage()));
		}//end catch
		finally {
			releaseResource(conn, stmt, rs);
		}//end finally

		return nextTransId;
	}//end method getNextTransId


}
