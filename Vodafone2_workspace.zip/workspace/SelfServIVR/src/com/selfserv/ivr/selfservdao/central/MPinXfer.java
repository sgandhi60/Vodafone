package com.selfserv.ivr.selfservdao.central;

public class MPinXfer {
	private String DBRC = null;
	private String mPin = null;
	private String DBMsg = null;
	
	MPinXfer(){
	}

	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}

	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}

	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}

	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	/**
	 * @return the mPin
	 */
	public String getMPin() {
		return mPin;
	}

	/**
	 * @param pin the mPin to set
	 */
	public void setMPin(String pin) {
		mPin = pin;
	}

}
