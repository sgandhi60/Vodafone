/*
 * Created on Jun 11, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.local;

import java.util.Calendar;

/**
 * @author mansey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MPinFailInfo {
	private String mobileNumber = null;
	private String landlineNumber = null;
	private String programCode = null;
	private String transaction = null;
	private Calendar transactionTime = null;
	

	/**
	 * @return Returns the landlineNumber.
	 */
	public final String getLandlineNumber() {
		return landlineNumber;
	}
	/**
	 * @param landlineNumber The landlineNumber to set.
	 */
	public final void setLandlineNumber(String landlineNumber) {
		this.landlineNumber = landlineNumber;
	}
	/**
	 * @return Returns the mobileNumber.
	 */
	public final String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber The mobileNumber to set.
	 */
	public final void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return Returns the programCode.
	 */
	public final String getProgramCode() {
		return programCode;
	}
	/**
	 * @param programCode The programCode to set.
	 */
	public final void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	/**
	 * @return Returns the transaction.
	 */
	public final String getTransaction() {
		return transaction;
	}
	/**
	 * @param transaction The transaction to set.
	 */
	public final void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	/**
	 * @return Returns the transactionTime.
	 */
	public final Calendar getTransactionTime() {
		return transactionTime;
	}
	/**
	 * @param transactionTime The transactionTime to set.
	 */
	public final void setTransactionTime(Calendar transactionTime) {
		this.transactionTime = transactionTime;
	}
}
