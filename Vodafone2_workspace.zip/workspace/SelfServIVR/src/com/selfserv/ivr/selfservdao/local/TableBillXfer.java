package com.selfserv.ivr.selfservdao.local;

import java.util.Date;

public class TableBillXfer {
	private String DBRC = null;
	private int cust_id = 0;
	private String coid = null;
	private float curOutStandAmt = 0;
	private float billedAmt = 0;
	private float unBilledAmt = 0;
	private Date dueDate = null;
	private float lastpayment = 0;
	private Date lastPayDate = null;
	private float creditLimit = 0;
	private String billCycle = null;
	private String DBMsg = null;
	
	public String getDBMsg() {
		return DBMsg;
	}
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public String getBillCycle() {
		return billCycle;
	}
	public void setBillCycle(String billCycle) {
		this.billCycle = billCycle;
	}
	public float getBilledAmt() {
		return billedAmt;
	}
	public void setBilledAmt(float billedAmt) {
		this.billedAmt = billedAmt;
	}
	public String getCoid() {
		return coid;
	}
	public void setCoid(String coid) {
		this.coid = coid;
	}
	public float getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(float creditLimit) {
		this.creditLimit = creditLimit;
	}
	public float getCurOutStandAmt() {
		return curOutStandAmt;
	}
	public void setCurOutStandAmt(float curOutStandAmt) {
		this.curOutStandAmt = curOutStandAmt;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public Date getLastPayDate() {
		return lastPayDate;
	}
	public void setLastPayDate(Date lastPayDate) {
		this.lastPayDate = lastPayDate;
	}
	public float getLastpayment() {
		return lastpayment;
	}
	public void setLastpayment(float lastpayment) {
		this.lastpayment = lastpayment;
	}
	public float getUnBilledAmt() {
		return unBilledAmt;
	}
	public void setUnBilledAmt(float unBilledAmt) {
		this.unBilledAmt = unBilledAmt;
	}
	
}
