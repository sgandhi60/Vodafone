package com.selfserv.ivr.selfservdao.central;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;


public class IVRMainDAO extends BaseDAO{
	
	private final static Logger LOGGER = Logger.getLogger(IVRMainDAO.class);
	private String jndiName = null;
	private String callid = null;
	private String mobile = null;

	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private String spPackageName = null;

	public IVRMainDAO(String jndiName, String mobile, String callid, boolean bTestCall, String packageName) {
		// initialization
		this.jndiName = jndiName;
		this.callid = callid;
		this.mobile = mobile;
		this.testCall = bTestCall;
		this.spPackageName = packageName;

		logToken = new StringBuffer("[").append(callid).append("] ").toString();
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered IVRMainDAO"));
	}


	public IVRMainXfer executeSP(String circle, String mobile) {
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered IVRMainDAO:executeSP()"));
		
		IVRMainXfer ivrMainXfer = new IVRMainXfer();
		Connection conn = null;
		CallableStatement cstmt = null;
		int coid = 0;
        int cust_id = 0;
        int dnid = 0;
        String ret_msg = null;
		
		//invoke SP:IVR_main 
		try {
			conn = getConnection(jndiName, mobile, callid);

			if (conn!=null){
				
				//IVR_main(crcl_id IN VARCHAR2,msisdn IN VARCHAR2,coid OUT NUMBER,cust_id OUT NUMBER,dnid OUT NUMBER,ret_msg OUT VARCHAR2);
				
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Executing SP: IVR_main"));
					LOGGER.debug(new StringBuffer(logToken).append(" - CircleID: ").append(circle));
					LOGGER.debug(new StringBuffer(logToken).append(" - mobile: ").append(mobile));
				}
				String query = StoredProcedureQuery.getQuery(StoredProcedureQuery.IVR_MAIN, spPackageName);
				cstmt = conn.prepareCall(query);
				
				//Set IN parameters
				cstmt.setString(1,circle);							//IN crcl_id
				cstmt.setString(2,mobile);							//IN msisdn
				
				//Register OUT parameters
				cstmt.registerOutParameter(3, Types.INTEGER);		//OUT param coid
				cstmt.registerOutParameter(4, Types.INTEGER);		//OUT param cust_id
				cstmt.registerOutParameter(5, Types.INTEGER);		//OUT param dnid
				cstmt.registerOutParameter(6, Types.VARCHAR);		//OUT param ret_msg

				cstmt.execute();
				
				coid = cstmt.getInt(3);
				cust_id = cstmt.getInt(4);
				dnid = cstmt.getInt(5);
				ret_msg = cstmt.getString(6);
				
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - coid = " + coid));
					LOGGER.debug(new StringBuffer(logToken).append(" - cust_id = " + cust_id));
					LOGGER.debug(new StringBuffer(logToken).append(" - dnid = " + dnid));
					LOGGER.debug(new StringBuffer(logToken).append(" - ret_msg = " + ret_msg));
				}
				
				if (coid <= 0){
					ivrMainXfer.setDBRC("F_NF");
				} else {
					ivrMainXfer.setDBRC("S");
				}
				
				ivrMainXfer.setCoid(coid);
				ivrMainXfer.setCust_id(cust_id);
			} else {	       
				ivrMainXfer.setDBRC("F_C");
				LOGGER.error(new StringBuffer(logToken).append(" - Error getting a connection to the CDB: "));
			}//if
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception in CDB::ivr_main -> could not return stored procedure values. Exception: ").append(e.getMessage()));
            ivrMainXfer.setDBRC("F_C");
			//e.printStackTrace();	
		}
		finally{
			releaseResource(conn, cstmt, null);	
		}
		if (testCall) 
			LOGGER.debug(new StringBuffer(logToken).append(" - *******Exiting IVRMainDAO"));
		return ivrMainXfer;
	}
}