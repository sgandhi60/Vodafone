package com.selfserv.ivr.selfservdao.local;

import java.util.Properties;

public class TableSncode2Xfer {
	private String DBRC = null;
	private Properties codeKeyProp = null;		// properties object as Code and key as key=value pair
	private Properties keyCodeProp = null;		// properties object as Key and Code as key=value pair
	private String DBMsg = null;

	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}
	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}
	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	/**
	 * @return the codeKeyProp
	 */
	public Properties getCodeKeyProp() {
		return codeKeyProp;
	}
	/**
	 * @param codeKeyProp the codeKeyProp to set
	 */
	public void setCodeKeyProp(Properties codeKeyProp) {
		this.codeKeyProp = codeKeyProp;
	}
	/**
	 * @return the keyCodeProp
	 */
	public Properties getKeyCodeProp() {
		return keyCodeProp;
	}
	/**
	 * @param keyCodeProp the keyCodeProp to set
	 */
	public void setKeyCodeProp(Properties keyCodeProp) {
		this.keyCodeProp = keyCodeProp;
	}
	
	
}
