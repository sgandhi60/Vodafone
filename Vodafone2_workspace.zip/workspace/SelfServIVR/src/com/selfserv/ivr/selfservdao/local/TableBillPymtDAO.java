package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TableBillPymtDAO extends BaseDAO{
	//private final String SQL_QUERY_STMT = "Select CUSTOMER_ID CUSTCODE CO_ID TITLE FNAME LNAME BIRTHDATE EMAIL BILLCYCLE CSC LIMIT PRGCODE PRGNAME CO_ACTIVATED CH_STATUS TMCODE SHDES PUK MOBILE PINCODE ADDRESS1	ADDRESS2 ADDRESS3 CITY from TBL_GEN Where Mobile = ?";
	private final String SQL_QUERY_STMT = "Select PYMTPHRASE, TOTALCENTRES, SMS_MSG FROM TBL_BILPYMT Where PINCODE = ?";
	private static Logger LOGGER = Logger.getLogger(TableBillPymtDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public TableBillPymtDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableBillPymtDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public TableBillPymtXfer findRecord(String pinCode){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for PinCode= ").append(pinCode));

		PreparedStatement stmt = null;
		ResultSet rs = null;
		TableBillPymtXfer tblBillPymtXfer = new TableBillPymtXfer();

		try{
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_QUERY_STMT);
				stmt.setString(1, pinCode);

				rs = stmt.executeQuery();
				if (rs.next()){
					if (rs.getString(1)!=null){

						String paymanetPhrase = rs.getString(1);
						int totCenters = rs.getInt(2);
						String smsMessages = rs.getString(3);

						tblBillPymtXfer.setPymtPhrase(paymanetPhrase);
						tblBillPymtXfer.setCenters(totCenters);
						tblBillPymtXfer.setSmsMessages(smsMessages);
						tblBillPymtXfer.setDBRC("S");

						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" - Match found; SMS Messages=").append(smsMessages).append(" Total Centers: ").append(totCenters));
					} else { // empty record
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for PinCode= ").append(pinCode));
						}
						tblBillPymtXfer.setDBRC("F_NF");
						tblBillPymtXfer.setDBMsg("Empty record found in the LDB");
					}
				}else{//no result set found
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for PinCode= ").append(pinCode));
					}
					tblBillPymtXfer.setDBRC("F_NF");
					tblBillPymtXfer.setDBMsg("No match found in the LDB");
				}
			}else{//no connection
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for PinCode= ").append(pinCode));
				}
				tblBillPymtXfer.setDBRC("F_C");
				tblBillPymtXfer.setDBMsg("No connection made to DB");
			} // if (conn!=null)
		}catch(Exception e){//Problem encounterd getting query results
			String msg = e.getMessage();			 
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the ServiceFlag from TBL_BILPYMT - " + e.getMessage()));

			tblBillPymtXfer.setDBRC("F_C");
			tblBillPymtXfer.setDBMsg(msg);
			e.printStackTrace();
		}finally{
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TableBillPymtDAO"));
			releaseResource(conn, stmt, rs);		 
		}
		return tblBillPymtXfer;
	}
}
