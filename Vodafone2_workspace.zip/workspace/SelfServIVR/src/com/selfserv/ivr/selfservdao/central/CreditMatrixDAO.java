package com.selfserv.ivr.selfservdao.central;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class CreditMatrixDAO extends BaseDAO{
	private Connection conn = null;
	private CallableStatement cstmt = null;
	private final static Logger LOGGER = Logger.getLogger(CreditMatrixDAO.class);
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private String spPackageName = null;

	public CreditMatrixDAO(String jndiName, String cell, String cid, boolean bTestCall, String packageName) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;
		this.spPackageName = packageName;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered CreditMatrixDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the CDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public CreditMatrixXfer executeSP(String crcl_id, int cust_id, int coid, String pgName, String svcCd) {
		CreditMatrixXfer cmXfer = new CreditMatrixXfer();
		
		try {
			/*IVR_CREDIT_MATRIX (crcl_id IN VARCHAR2,
			 * 			 cust_id IN NUMBER,
			 * 			 coid IN NUMBER,
			 * 			 pgname IN VARCHAR2,
			 * 			 svcCd IN VARCHAR2,
			 * 			 ret_pgname OUT VARCHAR2,
			 * 			 ret_creditcd OUT VARCHAR2,
			 * 			 ret_serv_allwd OUT VARCHAR2,    Y or N
			 * 			 ret_deprqd1 OUT NUMBER,
			 * 			 ret_deprqd12 OUT NUMBER,
			 *           ret_msg OUT VARCHAR2);*/
			
	        if (testCall)
	        	LOGGER.debug(new StringBuffer(logToken).append(" - Invoking CDB SP IVR_CREDIT_MATRIX with: circle: ").append(crcl_id)
	        			.append(" CustId: ").append(cust_id)
	        			.append(" ContractId: ").append(coid)
	        			.append(" Pgm Name: ").append(pgName)
	        			.append(" and svcCd: ").append(svcCd));

			if (conn!=null){
				String query = StoredProcedureQuery.getQuery(StoredProcedureQuery.IVR_CREDIT_MATRIX, spPackageName);
				cstmt = conn.prepareCall(query);
				
				//Setting IN params: crcl_id, msisdn
				cstmt.setString(1,crcl_id);
				cstmt.setInt(2,cust_id);
				cstmt.setInt(3,coid);
				cstmt.setString(4,pgName);
				cstmt.setString(5,svcCd);
				
				//registering OUT params:
				cstmt.registerOutParameter(6, Types.VARCHAR);	//css_pgname
				cstmt.registerOutParameter(7, Types.VARCHAR);	//ret_creditcd
				cstmt.registerOutParameter(8, Types.VARCHAR);	//ret_serv_allwd
				cstmt.registerOutParameter(9, Types.FLOAT);		//ret_deprqd1
				cstmt.registerOutParameter(10, Types.FLOAT);	//ret_deprqd2
				cstmt.registerOutParameter(11, Types.VARCHAR);	//ret_msg
				
				cstmt.execute();
				
				String creditType = cstmt.getString(7);
				String svcAllowed = cstmt.getString(8);
				float depReqd1 = cstmt.getFloat(9);
//				float depReqd2 = cstmt.getFloat(10);
				
				cmXfer.setSvcAllowed(svcAllowed);
				cmXfer.setDepReqd(depReqd1);
				cmXfer.setCreditType(creditType);
				
				if (svcAllowed == null || svcAllowed.length() == 0) {
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the SP for CircleID= ").append(crcl_id)
			        			.append(" CustId: ").append(cust_id)
			        			.append(" ContractId: ").append(coid)
			        			.append(" Pgm Name: ").append(pgName)
			        			.append(" and svcCd: ").append(svcCd));
					}
					cmXfer.setDBRC("F_NF");
					cmXfer.setDBMsg("No match found in the CDB");
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - Successful retrieval of credit info. SvcAllowed= ").append(svcAllowed));
					cmXfer.setDBRC("S");
				}
			}else{//no connection
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for CircleID= ").append(crcl_id)
		        			.append(" CustId: ").append(cust_id)
		        			.append(" ContractId: ").append(coid)
		        			.append(" Pgm Name: ").append(pgName)
		        			.append(" and svcCd: ").append(svcCd));
				}
				cmXfer.setDBRC("F_C");
				cmXfer.setDBMsg("No connection made to DB");
			} // if (conn!=null)
		} catch (SQLException e) {
			String msg = e.getMessage();
            LOGGER.warn(new StringBuffer(logToken).append(" - Exception invoking CDB SP IVR_CREDIT_MATRIX: ").append(msg));
            
            cmXfer.setDBRC("F_C");
            cmXfer.setDBMsg(msg);
            e.printStackTrace();
		} finally{
			 releaseResource(conn, cstmt, null);		 
		}
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting CreditMatrixDAO"));
		return cmXfer;
	}
}