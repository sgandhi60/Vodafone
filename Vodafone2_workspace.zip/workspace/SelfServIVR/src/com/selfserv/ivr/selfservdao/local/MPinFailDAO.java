/*
 * Created on Jun 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;
import com.selfserv.ivr.selfservdao.BaseDAO;

/**
 * @author mansey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MPinFailDAO extends BaseDAO {
	
	private String mobile = null;
	private String callid = null;
	private String jndiName = null;
	
	/**
	 * Commons logging for application logging <code>LOGGER</code>.
	 */
	private static Logger LOGGER = Logger.getLogger(MPinFailDAO.class);
	
	private final static String SQL_INSERT = "insert into TBL_RPT_MPINFAIL "
		+ "(CALLDATE,MSISDN,CTYPE,LANDLINE,TRANSACTION)"
		+ " values(?,?,?,?,?)";
	
	public MPinFailDAO(String jndiName, String mobile, String callid) throws SQLException {
		this.mobile = mobile;
		this.callid = callid;
		this.jndiName = jndiName;

		if (LOGGER.isTraceEnabled()) {
			LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - ******* Entered MPinFailDAO"));

		}
	}
	
	public final int insert(final MPinFailInfo mpinFailInfo) {

		Connection conn = null;
		PreparedStatement stmt = null;
		int addCount = 0;

		if (LOGGER.isTraceEnabled()) {
			LOGGER.debug(new StringBuffer("[").append(callid).append("]").append("paymentInfo Record for mobile number ")
							.append(mpinFailInfo.getMobileNumber()));

		}//end if

		try {
			conn = getConnection(jndiName, mobile, callid);
			if (LOGGER.isTraceEnabled()) {
				LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - Connected to LDB "+jndiName));
			}
			/* 
			 * first get circleId from DB
			 */
			stmt = conn.prepareStatement(SQL_INSERT);

			stmt.setTimestamp(1, new Timestamp(mpinFailInfo.getTransactionTime().getTimeInMillis()));
			stmt.setString(2, mpinFailInfo.getMobileNumber());
			stmt.setString(3, mpinFailInfo.getProgramCode());
			String landline = mpinFailInfo.getLandlineNumber();
			if ( (landline == null) || (landline.trim().length() == 0) )
				landline = "-1";

			stmt.setString(4, landline);
			stmt.setString(5, mpinFailInfo.getTransaction());
			
			addCount = stmt.executeUpdate();
			
			if (addCount == 1) {
				if (LOGGER.isTraceEnabled()) {
					LOGGER.debug(new StringBuffer("[").append(callid).append("]").append("added Record for mobile number ")
							.append(mpinFailInfo.getMobileNumber()));
				}//end if								
				
			}//end if
			else {
				if (LOGGER.isTraceEnabled()) {
					LOGGER.debug(new StringBuffer("[").append(callid).append("]").append("Could not add record for mobile number ")
							.append(mpinFailInfo.getMobileNumber()));
				}//end if
			}

		}//end try
		catch (SQLException e) {
			LOGGER.error(new StringBuffer("[").append(callid).append("]").append(e.getMessage()));
			addCount = 0;
		}//end catch
		finally {
			releaseResource(conn, stmt, null);
		}//end finally
		
		return addCount;
	}//end method addCircle


}
