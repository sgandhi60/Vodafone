/*
 * Created on Jun 11, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.misc;


/**
 * @author mansey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CSSServerReq {
	
	public static final String BILL_THROUGH_EMAIL = "Email";
	public static final String BILL_THROUGH_COURIER = "Courier";
	
	private String mobileNumber = null;
	private String circleCode = null;
	private String mpin = null;
	private boolean landline = false;
	private String billThrough = null;
	private String month = null;
	private String year = null;
	private String landlineNumber = null;
	private String programCode = null;
	private String transaction = null;

	/**
	 * @return Returns the circleCode.
	 */
	public final String getCircleCode() {
		return circleCode;
	}
	/**
	 * @param circleCode The circleCode to set.
	 */
	public final void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	/**
	 * @return Returns the landline.
	 */
	public final boolean isLandline() {
		return landline;
	}
	/**
	 * @param landline The landline to set.
	 */
	public final void setLandline(boolean landline) {
		this.landline = landline;
	}
	/**
	 * @return Returns the mobileNumber.
	 */
	public final String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber The mobileNumber to set.
	 */
	public final void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return Returns the mpin.
	 */
	public final String getMpin() {
		return mpin;
	}
	/**
	 * @param mpin The mpin to set.
	 */
	public final void setMpin(String mpin) {
		this.mpin = mpin;
	}
	/**
	 * @return Returns the billThrough.
	 */
	public final String getBillThrough() {
		return billThrough;
	}
	/**
	 * @param billThrough The billThrough to set.
	 */
	public final void setBillThrough(String billThrough) {
		this.billThrough = billThrough;
	}
	/**
	 * @return Returns the month.
	 */
	public final String getMonth() {
		return month;
	}
	/**
	 * @param month The month to set.  Format MMM (Jan, Feb, Mar, ...)
	 */
	public final void setMonth(String month) {
		this.month = month;
	}
	/**
	 * @return Returns the year.
	 */
	public final String getYear() {
		return year;
	}
	/**
	 * @param year The year to set. Format YY (01, 02, 03, ...)
	 */
	public final void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return Returns the landlineNumber.
	 */
	public final String getLandlineNumber() {
		return landlineNumber;
	}
	/**
	 * @param landlineNumber The landlineNumber to set.
	 */
	public final void setLandlineNumber(String landlineNumber) {
		this.landlineNumber = landlineNumber;
	}
	/**
	 * @return Returns the programCode.
	 */
	public final String getProgramCode() {
		return programCode;
	}
	/**
	 * @param programCode The programCode to set.
	 */
	public final void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	/**
	 * @return Returns the transaction.
	 */
	public final String getTransaction() {
		return transaction;
	}
	/**
	 * @param transcation The transaction to set.
	 */
	public final void setTransaction(String transaction) {
		this.transaction = transaction;
	}

}
