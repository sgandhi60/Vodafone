package com.selfserv.ivr.selfservdao.local;

public class TableSeriesXfer {
	private String inroamerFlag = null;
	private String birthFlag = null;
	private String circleName = null;
	private String circleCode = null;
	private String DBRC = null;
	private String DBMsg = null;

	public String getDBMsg() {
		return DBMsg;
	}

	public void setDBMsg(String msg) {
		DBMsg = msg;
	}

	public String getDBRC() {
		return DBRC;
	}

	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	public String getInroamerFlag() {
		return inroamerFlag;
	}

	public void setInroamerFlag(String inroamerFlag) {
		this.inroamerFlag = inroamerFlag;
	}

	public TableSeriesXfer(){
		setInroamerFlag(null);
		setDBRC("S");
	}

	public String getBirthFlag() {
		return birthFlag;
	}

	public void setBirthFlag(String birthFlag) {
		this.birthFlag = birthFlag;
	}

	public String getCircleCode() {
		return circleCode;
	}

	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}

	public String getCircleName() {
		return circleName;
	}

	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
}
