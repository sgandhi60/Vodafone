package com.selfserv.ivr.selfservdao.local;

public class BarredXfer {
	private String barred = null;
	private String cday_barred = null;
	private int cdayCount = 0;
	private String DBRC = null;
	public String getBarred() {
		return barred;
	}
	public void setBarred(String barred) {
		this.barred = barred;
	}
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public String getCday_barred() {
		return cday_barred;
	}
	public void setCday_barred(String cday_barred) {
		this.cday_barred = cday_barred;
	}
	public int getCdayCount() {
		return cdayCount;
	}
	public void setCdayCount(int cdayCount) {
		this.cdayCount = cdayCount;
	}

}
