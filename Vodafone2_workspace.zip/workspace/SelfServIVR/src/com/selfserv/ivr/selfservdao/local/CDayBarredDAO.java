package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;
import com.selfserv.ivr.selfservdao.local.BarredXfer;

public class CDayBarredDAO extends BaseDAO{
	private Connection conn = null;
	private final String SQL_QUERY = "Select XFER_COUNT from TBL_CDAY_BARRED Where MOBILE = ? and DAY_CALLS = TO_DATE(?,'DD/MM/YY')";//'24/MAR/08'
	//
	private final String SQL_UPDATE = "Update TBL_CDAY_BARRED SET XFER_COUNT = ? WHERE MOBILE = ? AND DAY_CALLS = TO_DATE(?,'DD/MM/YY')";
	private final String SQL_INSERT = "Insert into TBL_CDAY_BARRED"+
										"(MOBILE, DAY_CALLS, XFER_COUNT) "+
										"values(?,TO_DATE(?,'DD/MM/YY'),?)";
	private String mobile = null;
	private String callid = null;
	private String jndiName = null;
	private boolean testCall = false;
	private String logToken = null;
	private static Logger LOGGER = Logger.getLogger(CDayBarredDAO.class);

	public CDayBarredDAO(String localJNDIName, String cell, String callID, boolean testCall) {
		
		this.testCall = testCall;
		mobile= cell;
		callid = callID;
		jndiName = localJNDIName;
		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
		if (this.testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered CDayBarredDAO"));
		}
	}

	public BarredXfer findRecord(){
		 BarredXfer barredXfer = new BarredXfer();
		 PreparedStatement stmt = null;
		 int xferCount = 0;
		 ResultSet resSet = null;

		try {
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - finding record"));
			}
			conn = getConnection(jndiName, mobile, callid);
			stmt = conn.prepareStatement(SQL_QUERY);
			
			Date dt = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
			String queryDate=formatter.format(dt);

			stmt.setString(1, mobile);  
			stmt.setString(2, queryDate);
			resSet = stmt.executeQuery();
			
			if (resSet.next()){
				xferCount = resSet.getInt(1);
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Found record, daily transfers=").append(xferCount));
				}
				barredXfer.setCdayCount(xferCount);
		        barredXfer.setDBRC("S");
			}else{
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Didn't find a record"));
				}
				barredXfer.setDBRC("F_NF");
			}
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception attempting to find a record: ").append(e.getMessage()));
			barredXfer.setDBRC("F_C");
			//e.printStackTrace();
		}finally{
			releaseResource(conn, stmt, resSet);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting CDayBarredDAO"));
			}
		}
		return barredXfer;
	}
	
	/**
	 * Updates a record by incrementing the daily transfer count to operators
	 * @return
	 */
	public int updateRecord(int dailyXfers){
		PreparedStatement stmt = null;
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Updating record: ").append(mobile));
		}
		int result = 0;
		try {
			 conn = getConnection(jndiName, mobile, callid);
			 Date dt = new Date();
			 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
			 String updateDate=formatter.format(dt);
			 
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append(" - Update date: ").append(updateDate).append(", Increasing daily transfers to: ").append(dailyXfers));
			 }
			 stmt = conn.prepareStatement(SQL_UPDATE);	//"Update TBL_CDAY_BARRED SET XFER_COUNT = ? WHERE MOBILE = ?";
			 
			 stmt.setInt(1, dailyXfers); 								 
			 stmt.setString(2, mobile); 
			 stmt.setString(3, updateDate);
			 
	         result = stmt.executeUpdate();
		} catch (SQLException e) {
			//e.printStackTrace();
            LOGGER.error(new StringBuffer(logToken).append(" - Exception attempting to update the cday_barred record in LDB: ").append(e.getMessage()));
			result = -1;
		}finally{
			releaseResource(conn, stmt, null);		 
		}
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting CDayBarredDAO"));
		}
		return result;
	}
	
	public int insertRecord(String mobile) {
		PreparedStatement stmt = null;
		int result = 0;
		try {					 
			 conn = getConnection(jndiName, mobile, callid);
			 Date dt = new Date();
			 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
			 String insertDate=formatter.format(dt);
			 
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append(" - Insert date: " + insertDate));
			 }
			 stmt = conn.prepareStatement(SQL_INSERT);
			 stmt.setString(1, mobile); 		    //mobile
			 stmt.setString(2, insertDate); 		//calldate;  to_date('12/24/06','MM/DD/YY')	
			 stmt.setInt(3,1); 
			 
	         result = stmt.executeUpdate();
	         if (testCall)
	        	 LOGGER.debug(new StringBuffer(logToken).append(" - Inserted the cday_barred record"));
		} catch (SQLException e) {
            LOGGER.error(new StringBuffer(logToken).append(" - Exception attempting to insert the cday_barred record in LDB: ").append(e.getMessage()));
			//e.printStackTrace();
		}finally{
			if (testCall) {
				LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting CDayBarredDAO"));
			}
			releaseResource(conn, stmt, null);		 
		}
		return result;	
	}

	public boolean deleteRecord() {
		return false;
	}
	
	public static void main(String argv[]){
		CDayBarredDAO cdayBarredDAO = new CDayBarredDAO("DS_Circle001","1111111111","test", true);
	}
}
