package com.selfserv.ivr.selfservdao.local;

public class CTYPEXfer {
	String ctype = null;
	String firstTimeCaller = null;
	String vdn_category = null;
	String callerFound = null;
	String DBRC = null;
	String pgmcode = null;
	String pgmname = null;
	String gprs_Flag = null;
	
	public CTYPEXfer(){
	}
	
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public String getCtype() {
		return ctype;
	}
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}
	public String getFirstTimeCaller() {
		return firstTimeCaller;
	}
	public void setFirstTimeCaller(String firstTimeCaller) {
		this.firstTimeCaller = firstTimeCaller;
	}

	public String getVdn_category() {
		return vdn_category;
	}

	public void setVdn_category(String vdn_category) {
		this.vdn_category = vdn_category;
	}

	public String getCallerFound() {
		return callerFound;
	}

	public void setCallerFound(String callerFound) {
		this.callerFound = callerFound;
	}

	public String getGprs_Flag() {
		return gprs_Flag;
	}

	public void setGprs_Flag(String gprs_Flag) {
		this.gprs_Flag = gprs_Flag;
	}

	public String getPgmcode() {
		return pgmcode;
	}

	public void setPgmcode(String pgmcode) {
		this.pgmcode = pgmcode;
	}

	public String getPgmname() {
		return pgmname;
	}

	public void setPgmname(String pgmname) {
		this.pgmname = pgmname;
	}
}
