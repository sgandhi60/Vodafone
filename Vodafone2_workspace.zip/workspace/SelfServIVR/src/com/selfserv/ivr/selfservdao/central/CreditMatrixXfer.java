package com.selfserv.ivr.selfservdao.central;

public class CreditMatrixXfer {
	private String DBRC = null;
	private String DBMsg = null;
	private String svcAllowed = null;
	private float depReqd = 0;
	private String creditType = null;
	
	CreditMatrixXfer(){
	}

	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}

	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}

	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}

	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	/**
	 * @return the depReqd
	 */
	public float getDepReqd() {
		return depReqd;
	}

	/**
	 * @param depReqd the depReqd to set
	 */
	public void setDepReqd(float depReqd) {
		this.depReqd = depReqd;
	}

	/**
	 * @return the svcAllowed
	 */
	public String getSvcAllowed() {
		return svcAllowed;
	}

	/**
	 * @param svcAllowed the svcAllowed to set
	 */
	public void setSvcAllowed(String svcAllowed) {
		this.svcAllowed = svcAllowed;
	}

	/**
	 * @return the creditType
	 */
	public String getCreditType() {
		return creditType;
	}

	/**
	 * @param creditType the creditType to set
	 */
	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}

}
