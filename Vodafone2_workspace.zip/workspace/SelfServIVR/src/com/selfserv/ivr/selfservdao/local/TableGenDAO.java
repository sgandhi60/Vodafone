package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TableGenDAO extends BaseDAO{
	//private final String SQL_QUERY_STMT = "Select CUSTOMER_ID CUSTCODE CO_ID TITLE FNAME LNAME BIRTHDATE EMAIL BILLCYCLE CSC LIMIT PRGCODE PRGNAME CO_ACTIVATED CH_STATUS TMCODE SHDES PUK MOBILE PINCODE ADDRESS1	ADDRESS2 ADDRESS3 CITY from TBL_GEN Where Mobile = ?";
	private final String SQL_QUERY_STMT = "Select CUSTCODE, CO_ID, PRGCODE, BIRTHDATE, EMAIL, TITLE, FNAME, LNAME, ADDRESS1, ADDRESS2, ADDRESS3, CITY, PINCODE FROM TBL_GEN Where Mobile = ?";
	private static Logger LOGGER = Logger.getLogger(TableGenDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public TableGenDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableGenDAO"));

		try {
			conn = getConnection(jndiName, cell, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public TableGenXfer findRecord(String mobile){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for mobile=").append(mobile));
		
		PreparedStatement stmt = null;
	    ResultSet rs = null;
	    TableGenXfer tableGenXfer = new TableGenXfer();
	
		 try{
			if (conn!=null) {
				 stmt = conn.prepareStatement(SQL_QUERY_STMT);
		         stmt.setString(1, mobile);
		         rs = stmt.executeQuery();
		         if (rs.next()){
		        	 if (rs.getString(1)!=null) {
		        		 
		        		 String custCode = rs.getString(1);
		        		 String coid = rs.getString(2);
		        		 String prgCode = rs.getString(3);
		        		 Date birthDate = rs.getDate(4);
		        		 String email = rs.getString(5);
		        		 String title = rs.getString(6);
		        		 String fname = rs.getString(7);
		        		 String lname = rs.getString(8);
		        		 String addr1 = rs.getString(9);
		        		 String addr2 = rs.getString(10);
		        		 String addr3 = rs.getString(11);
		        		 String city = rs.getString(12);
		        		 String pinCode = rs.getString(13);
		        		 
		        		 tableGenXfer.setCoid(coid);
		        		 tableGenXfer.setCustcode(custCode);
		        		 tableGenXfer.setPrgcode(prgCode);
		        		 tableGenXfer.setBirthDate(birthDate);
		        		 tableGenXfer.setEmail(email);
		        		 tableGenXfer.setTitle(title);	        		 
		        		 tableGenXfer.setFname(fname);	        		 
		        		 tableGenXfer.setLname(lname);	        		 
		        		 tableGenXfer.setAddr1(addr1);	        		 
		        		 tableGenXfer.setAddr2(addr2);	        		 
		        		 tableGenXfer.setAddr3(addr3);	        		 
		        		 tableGenXfer.setCity(city);	        		 
		        		 tableGenXfer.setPinCode(pinCode);	        		 
		        		 tableGenXfer.setDBRC("S");

		        		 if (testCall)
		        			 LOGGER.debug(new StringBuffer(logToken).append(" - Match found; coid=").append(coid)
		        					 .append(" custCode=").append(custCode).append("  prgCode=").append(prgCode).append(" birthDate=").append(birthDate));
		        	 } else { // empty record
			        	 if (testCall) {
			        		 LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for mobile="+mobile));
			        	 }
			        	 tableGenXfer.setDBRC("F_NF");
			        	 tableGenXfer.setDBMsg("Empty record found in the LDB");
		        	 }
		         }else{//no result set found
		        	 if (testCall) {
		        		 LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for mobile="+mobile));
		        	 }
					 tableGenXfer.setDBRC("F_NF");
					 tableGenXfer.setDBMsg("No match found in the LDB");
		         }
			}else{//no connection
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for mobile="+mobile));
				}
				tableGenXfer.setDBRC("F_C");
				tableGenXfer.setDBMsg("No connection made to DB");
			} // if (conn!=null)
		 }catch(Exception e){//Problem encounterd getting query results
			 String msg = e.getMessage();			 
			 if (testCall)
				 LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the BirthDate from TBL_GEN" + e.getMessage()));
			
			 tableGenXfer.setDBRC("F_C");
			 tableGenXfer.setDBMsg(msg);
		 }finally{
			 if (testCall)
				 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TableGenDAO"));
			releaseResource(conn, stmt, rs);		 
		 }
		 return tableGenXfer;
	}
}
