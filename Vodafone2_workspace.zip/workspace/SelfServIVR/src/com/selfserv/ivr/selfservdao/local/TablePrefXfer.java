package com.selfserv.ivr.selfservdao.local;

public class TablePrefXfer {
	String languagePref = null;
	String DBRC = null;
	
	public TablePrefXfer() {
	}

	public String getLanguagePref() {
		return languagePref;
	}

	public void setLanguagePref(String languagePref) {
		this.languagePref = languagePref;
	}

	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	public String getDBRC() {
		return DBRC;
	}

}
