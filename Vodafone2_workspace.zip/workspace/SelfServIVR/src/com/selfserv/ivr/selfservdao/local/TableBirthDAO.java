package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TableBirthDAO extends BaseDAO{
	private final String SQL_QUERY = "Select FLAG FROM TBL_BIRTH Where mobile = ?";
	private final String SQL_UPDATE = "Update TBL_BIRTH SET FLAG  = ? WHERE MOBILE = ?";
	private final String SQL_INSERT = "Insert into TBL_BIRTH(MOBILE, FLAG) values (?, ?)";


	private static Logger LOGGER = Logger.getLogger(TableBirthDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private String jndi = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public TableBirthDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;
		this.jndi = jndiName;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableBirthDAO"));
	}

	public TableBirthXfer findRecord(String mobile){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for mobile= ").append(mobile));

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		TableBirthXfer tblBirthXfer = new TableBirthXfer();

		try{
			try {
				conn = getConnection(jndi, mobile, callid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
				e.printStackTrace();
			}

			if ( conn!=null ) {
				stmt = conn.prepareStatement(SQL_QUERY);
				stmt.setString(1, mobile);
				rs = stmt.executeQuery();
				if (rs.next()){
					if (rs.getString(1)!=null){

						String flag = rs.getString(1);

						tblBirthXfer.setFlag(flag);
						tblBirthXfer.setDBRC("S");

						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" - Match found; Flag=").append(flag));
					} else { // empty record
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for mobile="+mobile));
						}
						tblBirthXfer.setDBRC("F_NF");
						tblBirthXfer.setDBMsg("Empty record found in the LDB");
					}
				} else { //no result set found
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for mobile= ").append(mobile));
					}
					tblBirthXfer.setDBRC("F_NF");
					tblBirthXfer.setDBMsg("No match found in the LDB");
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for mobile= ").append(mobile));
				}
				tblBirthXfer.setDBRC("F_C");
				tblBirthXfer.setDBMsg("No connection made to DB");
			}
		}catch(Exception e){//Problem encounterd getting query results
			String msg = e.getMessage();			 
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the Flag from TBL_BIRTH" + e.getMessage()));

			tblBirthXfer.setDBRC("F_C");
			tblBirthXfer.setDBMsg(msg);
		}finally{
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TableBirthDAO"));
			releaseResource(conn, stmt, rs);		 
		}
		return tblBirthXfer;
	}

	/**
	 * Inserts a record by incrementing the daily transfer count to operators
	 * @return
	 */
	public TableBirthXfer insertRecord(String mobile, String flag) {

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - Entered TableBirthDAO::insertRecord()"));

		Connection conn = null;
		PreparedStatement stmt = null;
		int result = 0;
		TableBirthXfer tblBirthXfer = new TableBirthXfer();

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append("Record to be inserted into DB with the following data :"));
			LOGGER.debug(new StringBuffer(logToken).append(" Mobile =").append(mobile)
					.append(", Flag =").append(flag));
		}

		try {
			try {
				conn = getConnection(jndi, mobile, callid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
				e.printStackTrace();
			}
			
			if ( conn!=null ) {
				stmt = conn.prepareStatement(SQL_INSERT);
				
				stmt.setString(1, mobile); 			 	//Mobile
				stmt.setString(2, flag); 				//Birthday msg played flag
				
				result = stmt.executeUpdate();
				if (result > 0) 
					tblBirthXfer.setDBRC("S");
				else {
					tblBirthXfer.setDBRC("F_NF");
					tblBirthXfer.setDBMsg("Error while inserting record in TBL_BIRTH");
				}
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append(" record(s)"));
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for mobile= ").append(mobile));
				}
				tblBirthXfer.setDBRC("F_C");
				tblBirthXfer.setDBMsg("No connection made to DB");
			}
		} catch (SQLException e) {
			String msg = e.getMessage();	
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_BIRTH" + e.getMessage()));

			tblBirthXfer.setDBRC("F_C");
			tblBirthXfer.setDBMsg(msg);
		} finally {
			releaseResource(conn, stmt, null);		 
		}

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Exiting TableBirthDAO::insertRecord()"));
		return tblBirthXfer;
	}


	/**
	 * Updates a record 
	 * @return
	 */
	public TableBirthXfer updateRecord(String mobile, String flag) {

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - Entered TableBirthDAO::updateRecord()"));

		Connection conn = null;
		PreparedStatement stmt = null;
		int result = 0;
		TableBirthXfer tblBirthXfer = new TableBirthXfer();

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append("Record to be updated into DB with the following data :"));
			LOGGER.debug(new StringBuffer(logToken).append(" Mobile =").append(mobile)
					.append(", Flag =").append(flag));
		}

		try {
			try {
				conn = getConnection(jndi, mobile, callid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
				e.printStackTrace();
			}
			
			if ( conn!=null ) {
				stmt = conn.prepareStatement(SQL_UPDATE);

				stmt.setString(1, flag); 				//Birthday msg played flag
				stmt.setString(2, mobile); 			 	//Mobile

				result = stmt.executeUpdate();
				if (result > 0) 
					tblBirthXfer.setDBRC("S");
				else {
					tblBirthXfer.setDBRC("F_NF");
					tblBirthXfer.setDBMsg("Error while updating record in TBL_BIRTH");
				}
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Updated ").append(result).append(" record(s)"));
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for mobile= ").append(mobile));
				}
				tblBirthXfer.setDBRC("F_C");
				tblBirthXfer.setDBMsg("No connection made to DB");
			}
		} catch (SQLException e) {
			String msg = e.getMessage();	
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught updating record into table TBL_BIRTH" + e.getMessage()));

			tblBirthXfer.setDBRC("F_C");
			tblBirthXfer.setDBMsg(msg);
		} finally {
			releaseResource(conn, stmt, null);		 
		}

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Exiting TableBirthDAO::updateRecord()"));
		return tblBirthXfer;
	}


}
