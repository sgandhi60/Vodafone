package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class VDNDAO extends BaseDAO{
	//private final String SQL_QUERY_STMT = "Select CUSTOMER_ID CUSTCODE CO_ID TITLE FNAME LNAME BIRTHDATE EMAIL BILLCYCLE CSC LIMIT PRGCODE PRGNAME CO_ACTIVATED CH_STATUS TMCODE SHDES PUK MOBILE PINCODE ADDRESS1	ADDRESS2 ADDRESS3 CITY from TBL_GEN Where Mobile = ?";
	private final String SQL_QUERY_STMT = "Select VDN FROM TBL_VDN Where CUST_TYPE = ? and TRAN_TYPE = ? and LANG = ? and CATEGORY = ?";
	private static Logger LOGGER = Logger.getLogger(VDNDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public VDNDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered VDNDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public VDNXfer findRecord(String cust_type, String tran_type, String lang, String category){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for Cust_type= ").append(cust_type)
					.append(" Tran_type= ").append(tran_type)
					.append(" Lang= ").append(lang)
					.append(" Category= ").append(category));

		PreparedStatement stmt = null;
		ResultSet rs = null;
		VDNXfer vdnXfer = new VDNXfer();

		try{
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_QUERY_STMT);
				stmt.setString(1, cust_type);
				stmt.setString(2, tran_type);
				stmt.setString(3, lang);
				stmt.setString(4, category);

				rs = stmt.executeQuery();
				if (rs.next()){
					if (rs.getString(1)!=null){

						String vdn = rs.getString(1);

						vdnXfer.setVdnRoutePoint(vdn);
						vdnXfer.setDBRC("S");

						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" - Match found; VDN=").append(vdn));
					} else { // empty record
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for Cust_type= ").append(cust_type)
									.append(" Tran_type= ").append(tran_type)
									.append(" Lang= ").append(lang)
									.append(" Category= ").append(category));
						}
						vdnXfer.setDBRC("F_NF");
						vdnXfer.setDBMsg("Empty record found in the LDB");
					}
				}else{//no result set found
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for Cust_type= ").append(cust_type)
								.append(" Tran_type= ").append(tran_type)
								.append(" Lang= ").append(lang)
								.append(" Category= ").append(category));
					}
					vdnXfer.setDBRC("F_NF");
					vdnXfer.setDBMsg("No match found in the LDB");
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for Cust_type= ").append(cust_type)
							.append(" Tran_type= ").append(tran_type)
							.append(" Lang= ").append(lang)
							.append(" Category= ").append(category));
				}
				vdnXfer.setDBRC("F_NF");
				vdnXfer.setDBMsg("No connection made to DB");
			}
		}catch(Exception e){//Problem encounterd getting query results
			String msg = e.getMessage();			 
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the ServiceFlag from TBL_VDN" + e.getMessage()));

			vdnXfer.setDBRC("F_C");
			vdnXfer.setDBMsg(msg);
		}finally{
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting VDNDAO"));
			releaseResource(conn, stmt, rs);		 
		}
		return vdnXfer;
	}
}
