package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TableBillDAO extends BaseDAO{
	//private final String SQL_QUERY_STMT = "Select CUSTOMER_ID CUSTCODE CO_ID TITLE FNAME LNAME BIRTHDATE EMAIL BILLCYCLE CSC LIMIT PRGCODE PRGNAME CO_ACTIVATED CH_STATUS TMCODE SHDES PUK MOBILE PINCODE ADDRESS1	ADDRESS2 ADDRESS3 CITY from TBL_GEN Where Mobile = ?";
	private final String SQL_QUERY_STMT = "Select CUSTOMER_ID, CONTRACTID, CURROS, BILLEDAMT, UNBILLEDAMT, DUEDATE, LASTPYMTAMT, LASTPAIDATE, CREDITLIMIT, BILLCYCLE FROM TBL_BILL Where mobile = ?";
	private static Logger LOGGER = Logger.getLogger(TableBillDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public TableBillDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableBillDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public TableBillXfer findRecord(String mobile){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for mobile= ").append(mobile));

		PreparedStatement stmt = null;
		ResultSet rs = null;
		TableBillXfer tblBillXfer = new TableBillXfer();

		try{
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_QUERY_STMT);
				stmt.setString(1, mobile);
				rs = stmt.executeQuery();
				if (rs.next()){
					if (rs.getString(1)!=null){

						int cust_id = rs.getInt(1);
						String coid = rs.getString(2);
						float curOutStandAmt = rs.getFloat(3);
						float billedAmt = rs.getFloat(4);
						float unBilledAmt = rs.getFloat(5);
						Date dueDate = rs.getDate(6);
						float lastpayment = rs.getFloat(7);
						Date lastPayDate = rs.getDate(8);
						float creditLimit = rs.getFloat(9);
						String billCycle = rs.getString(10);
/*
						java.util.Date dueDateUtil = new java.util.Date(dueDate.getTime());
						java.util.Date lastPayDateUtil = new java.util.Date(lastPayDate.getTime());

						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" Data from LDB - TBL_BILL: "));

							LOGGER.debug(new StringBuffer(logToken)
							.append(" cust_id: ").append(cust_id)
							.append(" coid: ").append(coid)
							.append(" curOutStandAmt: ").append(curOutStandAmt)
							.append(" billedAmt: ").append(billedAmt)
							.append(" unBilledAmt: ").append(unBilledAmt)
							.append(" dueDate: ").append(dueDateUtil != null ? dueDateUtil.getTime() : null)
							.append(" lastpayment: ").append(lastpayment)
							.append(" lastPayDate: ").append(lastPayDateUtil!= null ? lastPayDateUtil.getTime() : null)
							.append(" creditLimit: ").append(creditLimit)
							.append(" billCycle: ").append(billCycle));
						}
*/
						// set all the fields in response object
						tblBillXfer.setDBRC("S");

						tblBillXfer.setCust_id(cust_id);
						tblBillXfer.setCoid(coid);
						tblBillXfer.setCurOutStandAmt(curOutStandAmt);
						tblBillXfer.setBilledAmt(billedAmt);
						tblBillXfer.setUnBilledAmt(unBilledAmt);
						tblBillXfer.setDueDate(dueDate);
						tblBillXfer.setLastpayment(lastpayment);
						tblBillXfer.setLastPayDate(lastPayDate);
						tblBillXfer.setCreditLimit(creditLimit);
						tblBillXfer.setBillCycle(billCycle);

						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" - Match found for mobile=").append(mobile));
					} else { // empty record
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for mobile="+mobile));
						}
						tblBillXfer.setDBRC("F_NF");
						tblBillXfer.setDBMsg("Empty record found in the LDB");
					}
				}else{//no result set found
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for mobile= ").append(mobile));
					}
					tblBillXfer.setDBRC("F_NF");
					tblBillXfer.setDBMsg("No match found in the LDB");
				}
			}else{//no connection
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for mobile= ").append(mobile));
				}
				tblBillXfer.setDBRC("F_C");
				tblBillXfer.setDBMsg("No connection made to DB");
			} // if (conn!=null)
		}catch(Exception e){//Problem encounterd getting query results
			String msg = e.getMessage();			 
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the ServiceFlag from TBL_BILL - " + e.getMessage()));

			tblBillXfer.setDBRC("F_C");
			tblBillXfer.setDBMsg(msg);
		}finally{
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TableBillDAO"));
			releaseResource(conn, stmt, rs);		 
		}
		return tblBillXfer;
	}
}
