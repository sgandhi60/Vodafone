package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.selfserv.ivr.selfservdao.BaseDAO;

import org.apache.log4j.Logger;

public class BarredDAO extends BaseDAO{
	private Connection conn = null;
	private final String SQL_QUERY = "Select STARTTIME, ENDTIME, FLAG from TBL_BARRED Where MSISDN = ?";

	private String callid = null;
	private String mobile = null;
	private boolean testCall = false;
	private String logToken = null;
	private static Logger LOGGER = Logger.getLogger(BarredDAO.class);

	
	public BarredDAO(String jndiName, String cell, String callID, boolean testCall) {
	// initialization 
		callid = callID;
		mobile = cell;
		this.testCall = testCall;
		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered BarredDAO"));
		}
		try {
			conn = getConnection(jndiName, cell, callID);
		} catch (SQLException e) {
			 LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
		}
	}

	public int insertRecord() {
		return 0;
	}

	public boolean deleteRecord() {
		return false;
	}
	
	public BarredXfer findRecord(String mobile) {
		PreparedStatement stmt = null;
        ResultSet rs = null;
        String dbrc = null;
        BarredXfer cbXfer = new BarredXfer();
		
		try {
       	 	
			stmt = conn.prepareStatement(SQL_QUERY);
 			stmt.setString(1, mobile);			
			rs = stmt.executeQuery();
             if (rs.next()){
            	 cbXfer.setBarred(rs.getString(3));
            	 dbrc = "S"	;							 
             }else{
            	 //No match in the TBL__BARRED
            	 if (testCall) {
            		 LOGGER.debug(new StringBuffer(logToken).append(" - No match found in TBL_BARRED"));
            	 }
    			 dbrc = "F_NF";
            }
			 cbXfer.setDBRC(dbrc);
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting BarredDAO -> ").append(dbrc));
			 }
		} catch (SQLException e) {
			 LOGGER.error(new StringBuffer(logToken).append(" - Exception caught querying TBL_BARRED"));
			 dbrc = "F_C";	
			 e.printStackTrace();
		}finally{
			 releaseResource(conn, stmt, rs);		
		 }
 		return cbXfer;
	}
}