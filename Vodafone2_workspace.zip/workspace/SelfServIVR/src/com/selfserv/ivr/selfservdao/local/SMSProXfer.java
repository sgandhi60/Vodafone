package com.selfserv.ivr.selfservdao.local;

import java.util.Properties;

public class SMSProXfer {
	private String DBRC = null;
	private Properties smsPro = null;
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public Properties getSmsPro() {
		return smsPro;
	}
	public void setSmsPro(Properties smsPro) {
		this.smsPro = smsPro;
	}
}
