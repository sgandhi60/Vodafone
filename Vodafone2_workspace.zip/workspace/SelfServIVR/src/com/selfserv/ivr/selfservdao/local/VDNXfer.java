package com.selfserv.ivr.selfservdao.local;

public class VDNXfer {
	private String dbRC = null;
	private String vdnRoutePoint = null;
	private String DBMsg = null;
	
	public String getDbMsg() {
		return DbMsg;
	}
	public void setDbMsg(String dbMsg) {
		DbMsg = dbMsg;
	}
	public String getDBRC() {
		return dBRC;
	}
	public void setDBRC(String dbrc) {
		dBRC = dbrc;
	}
	public String getVdnRoutePoint() {
		return vdnRoutePoint;
	}
	public void setVdnRoutePoint(String vdnRoutePoint) {
		this.vdnRoutePoint = vdnRoutePoint;
	}
	
}
