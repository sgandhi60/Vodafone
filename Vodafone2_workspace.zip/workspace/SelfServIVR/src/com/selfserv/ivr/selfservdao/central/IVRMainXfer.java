package com.selfserv.ivr.selfservdao.central;

public class IVRMainXfer {
	private int coid = 0;
	private int cust_id = 0;
	private int dnid = 0;
	private String ret_msg = null;
	private String DBRC = null;
	
	public IVRMainXfer(){
	}

	public int getCoid() {
		return coid;
	}

	public void setCoid(int coid) {
		this.coid = coid;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public int getDnid() {
		return dnid;
	}

	public void setDnid(int dnid) {
		this.dnid = dnid;
	}

	public String getRet_msg() {
		return ret_msg;
	}

	public void setRet_msg(String ret_msg) {
		this.ret_msg = ret_msg;
	}

	public void setDBRC(String dbrc) {
		this.DBRC = dbrc;
	}

	public String getDBRC() {
		return DBRC;
	}
}
