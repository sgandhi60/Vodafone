package com.selfserv.ivr.selfservdao.local;

public class DBXfer {
	private String DBRC = null;
	private String DBMsg = null;
	
	DBXfer(){
	}

	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}

	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}

	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}

	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

}
