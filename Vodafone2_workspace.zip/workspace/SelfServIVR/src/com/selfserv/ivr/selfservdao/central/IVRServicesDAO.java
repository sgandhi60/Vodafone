package com.selfserv.ivr.selfservdao.central;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class IVRServicesDAO extends BaseDAO {
	private Connection conn = null;
	private CallableStatement cstmt = null;
	private final static Logger LOGGER = Logger.getLogger(IVRServicesDAO.class);
	private String mobile = null;
	private String callid = null;
	private IVRSvcsXfer ivrSvcsXfer = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private String spPackageName = null;

	public IVRServicesDAO(String jndiName, String cell, String cid, boolean bTestCall, String packageName) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;
		this.spPackageName = packageName;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered IVRServicesDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the CDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public IVRSvcsXfer executeSP(String crcl_id, int coid) {
		ivrSvcsXfer = new IVRSvcsXfer();
		
		try {
			/*ivr_services(crcl_id IN VARCHAR2,
			 * 			 coid IN NUMBER,
			 *           ret_services OUT VARCHAR2,
			 *           ret_msg OUT VARCHAR2);*/
			
	        if (testCall)
	        	LOGGER.debug(new StringBuffer(logToken).append(" - Invoking CDB SP IVR_SERVICES with: circle: ").append(crcl_id)
	        			.append(" and coid: ").append(coid));

			if (conn!=null){
				String query = StoredProcedureQuery.getQuery(StoredProcedureQuery.IVR_SERVICES, spPackageName);
				cstmt = conn.prepareCall(query);
				
				//Setting IN params: crcl_id, coid
				cstmt.setString(1,crcl_id);
				cstmt.setInt(2,coid);
				
				//registering OUT params:
				cstmt.registerOutParameter(3, Types.VARCHAR);	//ret_services
				cstmt.registerOutParameter(4, Types.VARCHAR);	//ret_msg
				
				cstmt.execute();
				
				String services = cstmt.getString(3);

				ivrSvcsXfer.setServices(services);
				
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" - Successful return of services = ").append(services));
				ivrSvcsXfer.setDBRC("S");
/* 
				if (services == null || services.length() == 0) {
					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the SP for CircleID= ").append(crcl_id)
								.append(" and coid: ").append(coid));
					ivrSvcsXfer.setDBRC("F_NF");
					ivrSvcsXfer.setDBMsg("No match found in the CDB");
					
				} else {
				}
*/				
			} // if (conn!=null)
		} catch (SQLException e) {
			String msg = e.getMessage();
            LOGGER.warn(new StringBuffer(logToken).append(" - Exception invoking CDB SP IVR_SERVICES: ").append(msg));
            
            ivrSvcsXfer.setDBRC("F_C");
            ivrSvcsXfer.setDBMsg(msg);
			e.printStackTrace();
		} finally{
			 releaseResource(conn, cstmt, null);		 
		}
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting IVRServicesDAO"));
		return ivrSvcsXfer;
	}
}