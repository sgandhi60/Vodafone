package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class VASLogDAO extends BaseDAO{
	private Connection conn = null;
	private String callid = null;
	private final String SQL_INSERT = "Insert into TBL_VASLOG"+
										"(MOBILE,LANDLINE,CUSTTYPE,SERVICE,SERVICEREQ,REQDATE,STATUS) "+
										"values(?,?,?,?,?,?,?)";

	private String mobile = null;
	private static Logger LOGGER = Logger.getLogger(VASLogDAO.class);
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public VASLogDAO(String jndiName, String cell, String callID, boolean bTestCall) throws SQLException {
		// initialization 
		this.callid = callID;
		this.mobile = cell;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered VASLogDAO"));
		try {
			conn = getConnection(jndiName,mobile,callid);
		} catch (SQLException e) {
			LOGGER.debug(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Inserts a record
	 * @return
	 */
	public int insertRecord(String landline, String mobile, String custType, String vasSvc, String vasSvcReq, String reqDate){
	    if (testCall) 
	    	LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered VASLogDAO:insertRecord"));

	    PreparedStatement stmt;
		int result = -1;
		
		if ( (landline == null) || (landline.trim().length() == 0) )
			landline = "-1";
		
		try {
			if ( conn != null ) {
				 stmt = conn.prepareStatement(SQL_INSERT);
				 stmt.setString(1, mobile); 				//mobile
				 stmt.setString(2, landline); 				//landline	
				 stmt.setString(3, custType); 				//custtype
				 stmt.setString(4, vasSvc); 				//service
				 stmt.setString(5, vasSvcReq);				//serivereq
				 stmt.setString(6, reqDate); 				//reqdate
				 stmt.setString(7, "O"); 					//status
				 
		         result = stmt.executeUpdate();
		         if (testCall) 
		        	 LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append(" record(s)"));
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB"));
				}
				result = -1;
			}
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_VASLOG - " + e.getMessage()));
			e.printStackTrace();
			result = -1;
		}
		
		 if (testCall) 
			 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting VASLogDAO:insertRecord"));
		return result;
	}

}
