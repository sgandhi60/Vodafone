package com.selfserv.ivr.selfservdao;

import java.util.Hashtable;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

/**
 * Service Locator for data source context lookup.
 */
public class DBServiceLocator {
private static Logger LOGGER = Logger.getLogger(DBServiceLocator.class);
private static DataSource dsSource = null;
private static Hashtable<String, DataSource> dsHashtable = new Hashtable<String, DataSource>();
 
/**
 * @return DataSource javax.sql.DataSource
 */
public static DataSource getDBDataSource(String jndiName, String mobile, String callid){

	//lookup hasthable for the datasource
  dsSource = (DataSource)dsHashtable.get(jndiName);
  if (dsSource == null) {
    try {
      InitialContext ic = new InitialContext();
      dsSource = (DataSource) ic.lookup(jndiName);
      dsHashtable.put(jndiName, dsSource);
  	  if (LOGGER.isTraceEnabled())
  		  LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - Got new DataSource"));
  		
    } catch (Exception e) {
       LOGGER.error(e.getMessage());
    }
  }
  else{
	  if (LOGGER.isTraceEnabled())
		  LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - Got the DataSource from the hashtable"));
  }
   return dsSource;
 }
}