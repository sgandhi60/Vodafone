package com.selfserv.ivr.selfservdao.local;

public class ServiceFlagXfer {
	private String DBRC = null;
	private String serviceFlag = null;
	private String DBMsg = null;
	
	public String getDBMsg() {
		return DBMsg;
	}
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public String getServiceFlag() {
		return serviceFlag;
	}
	public void setServiceFlag(String serviceFlag) {
		this.serviceFlag = serviceFlag;
	}
	
}
