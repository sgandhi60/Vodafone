package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TablePrefDAO extends BaseDAO{
	private final String SQL_QUERY = "Select PREF_LANG from TBL_PREF Where MOBILE = ?";
	private final String SQL_UPDATE = "Update TBL_PREF SET PREF_LANG  = ? WHERE MOBILE = ?";
	private final String SQL_INSERT = "Insert into TBL_PREF(MOBILE, CUST_TYPE, PREF_LANG) values (?, ?, ?)";

	private static Logger LOGGER = Logger.getLogger(TablePrefDAO.class);
	private Connection conn = null;
	private String callid = null;
	private boolean testCall = false;
	private String logToken = null;
	
	public TablePrefDAO(String jndiName,String mobile,String callID, boolean testCall) throws SQLException {
		this.testCall = testCall;
		callid = callID;
		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
		conn = getConnection(jndiName,mobile,callID);
		if (this.testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered TablePrefDAO")); 
			LOGGER.debug(new StringBuffer(logToken).append(" - Connected to LDB "+jndiName));
		}
	}

	public TablePrefXfer findRecord(String mobile){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record: ").append(mobile));
		
		PreparedStatement stmt = null;
        ResultSet rs = null;
        TablePrefXfer tpXfer = new TablePrefXfer();

        
		 try{
			 stmt = conn.prepareStatement(SQL_QUERY);
             stmt.setString(1, mobile);
             rs = stmt.executeQuery();
             if (rs.next()){
            	 if (rs.getString(1)!=null){
            		 String langPref = rs.getString(1);
            		 tpXfer.setLanguagePref(langPref);
            		 if (testCall) {
            			 LOGGER.debug(new StringBuffer(logToken).append(" - Match found!"));
            			 LOGGER.debug(new StringBuffer(logToken).append(" - language preference = ").append(langPref));
            		 }
            	 }
            	 tpXfer.setDBRC("S");
             }else{//no result set found
            	 if (testCall) {
            		 LOGGER.debug(new StringBuffer(logToken).append(" - No match in the LDB."));
            		 LOGGER.debug(new StringBuffer(logToken).append(" - Language preference not set"));
            	 }
            	 tpXfer.setDBRC("F_NF");
             }
		 }catch(Exception e){//Problem encounterd getting query results
			 LOGGER.error(new StringBuffer(logToken).append(" - Exception when getting the preferred language from TBL_PREF" + e.getMessage()));
		 }finally{
			 releaseResource(conn, stmt, rs);		 
		 }
		 return tpXfer;
	}
	

	public int updateRecord(String mobile, String dbLang) {
		PreparedStatement stmt = null;
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Updating record: ").append(mobile).append("; language: ").append(dbLang));
		int rc = 0;
		try {
			 stmt = conn.prepareStatement(SQL_UPDATE);
			 stmt.setString(1, dbLang); 								 
			 stmt.setString(2, mobile); 								     
	         rc = stmt.executeUpdate();
	         if (testCall)
	 			LOGGER.debug(new StringBuffer(logToken).append(" - Language update return code: ").append(rc));

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			rc = -1;
		}finally{
			 releaseResource(conn, stmt, null);		 
		}
		return rc;
	}
	
	public int insertRecord(String mobile, String dbLang, String ctype) {
		PreparedStatement stmt = null;
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Insert record: ").append(mobile)
					.append("; language: ").append(dbLang)
					.append("; customer type: ").append(ctype));
		int rc = 0;
		try {
			 stmt = conn.prepareStatement(SQL_INSERT);
			 stmt.setString(1, mobile); 								 
			 stmt.setString(2, ctype);
			 stmt.setString(3, dbLang);
	         rc = stmt.executeUpdate();
	         if (testCall)
	 			LOGGER.debug(new StringBuffer(logToken).append(" - Lanuage insert return code: ").append(rc));

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			rc = -1;
		}finally{
			 releaseResource(conn, stmt, null);		 
		}
		return rc;
	}
}
