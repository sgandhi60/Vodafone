package com.selfserv.ivr.selfservdao.local;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

/*
 * Report errors that occur when accessing LDB or CDB as follows:
 * 		- for CDB, errors are inserted into LDB TBL_RPT_ERRORS for both DB access or SP execution exceptions
 * 		- for LDB, errors are inserted only for table access exceptions
 */

public class ReportErrorDAO extends BaseDAO{
	private Connection conn = null;
	private CallableStatement cstmt = null;
	private final static Logger LOGGER = Logger.getLogger(ReportErrorDAO.class);
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	private final String SQL_INSERT = "Insert into TBL_RPT_ERROR"+
									"(CALLDATE, MSISDN, ERRMSG, TBLSTATUS, UCID) "+
									"values(TO_DATE(?,'DD/MM/YYYY HH:Mi:SS AM'),?,?,?,?)";

	public ReportErrorDAO(String jndiName, String cell, String cid, boolean bTestCall) {
//	public ReportErrorDAO(String jndiName, String cell, String cid) {
	// initialization
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered ReportErrorDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - Connected to LDB"));
			}
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception when connection to the LDB: ").append(e.getMessage()));
		}
	}

	public int insertRecord(String dbmsg) {
		PreparedStatement stmt;
		
		//getting the date format: 4/22/2008 7:59:21 PM
		Date dt = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aa");
		String logdate=formatter.format(dt);
		
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - error logdate: " + logdate));
		}
		
		int rc = 0;
		try {		
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_INSERT);

				stmt.setString(1, logdate); 	//calldate;  to_date('12/24/2006 3:00:00 PM','MM/DD/YYYY HH:Mi:SS AM')
				stmt.setString(2, mobile); 		//mobile	
				stmt.setString(3, dbmsg); 		//error msg
				stmt.setString(4, ""); 			//tablestatus
				stmt.setString(5, "");			//ucid

				rc = stmt.executeUpdate();
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Inserted the error record"));
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB"));
				}
				rc = -1;
			}
		} catch (SQLException e) {
            LOGGER.warn(new StringBuffer(logToken).append(" - Exception attempting to insert error message into LDB: ").append(e.getMessage()));
			e.printStackTrace();
//			rc = -1;
		}finally{
			 releaseResource(conn, cstmt, null);		 
		}
		
		if (testCall) 
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting ReportErrorDAO"));
		return rc;	
	}
}