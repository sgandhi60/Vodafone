package com.selfserv.ivr.selfservdao.central;

public class IVRSvcsXfer {
	private String DBRC = null;
	private String services = null;
	private String DBMsg = null;
	
	public IVRSvcsXfer(){
	}

	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}

	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}

	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}

	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	/**
	 * @return the services
	 */
	public String getServices() {
		return services;
	}

	/**
	 * @param services the services to set
	 */
	public void setServices(String services) {
		this.services = services;
	}
}
