/*
 * Created on Jun 11, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.misc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Calendar;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.local.MPinFailDAO;
import com.selfserv.ivr.selfservdao.local.MPinFailInfo;

/**
 * @author mansey
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CSSServerDAO {
	private static Logger LOGGER = Logger.getLogger(CSSServerDAO.class);
	private String mobile = null;
	private String callid = null;
	private String jndiName = null;
	private String sessionId = null;
	private String userId = null;
	private String userPw = null;
	private String cssURL = null;
	private String coTimeout = null;
	private String soTimeout = null;
	
	// TODO: URL and userid/pw should be configurable
//	private static final String userId = "nwss";
//	private static final String userPw = "nwss";
//	private static String CSS_URL = "http://localhost:9080/IVRTest/CSSServer";
	private static final String PARAM_MEDIA_VALUE = "IVR";
	
	private static final String PARAM_CELL_NO = "cellNo";
	private static final String PARAM_CIRCLE_CODE = "txtCircle";
	private static final String PARAM_MEDIA = "txtMedia";
	private static final String PARAM_APP_USER = "txtAppUser";
	private static final String PARAM_APP_PASSWORD = "txtAppPassword";
	private static final String PARAM_WSS_CODE = "txtWSSCode";
	private static final String PARAM_MPIN = "txtMPin";
	private static final String PARAM_SEND_THR = "txtSendThr";
	private static final String PARAM_MONTH = "txtMonth";
	private static final String PARAM_YEAR = "txtYear";
	private static final String PARAM_SESSION_ID = "txtSessionId";
	private static final String PARAM_CELL = "txtCell";
	
	private static final String CREATE_SESSION_RESP = "CREATESESSION";
	private static final String DUPBILL_RESP = "DUPBILL";
	private static final String CREATE_MPIN_RESP = "CREATEMPIN";
	private static final String CHANGE_MPIN_RESP = "CHGMPIN";
	private static final String ACTIVATE_IBILL_RESP = "ACTITEMBILL";
	private static final String DEACTIVATE_IBILL_RESP = "DEACTITEMBILL";
	private static final String DROP_SESSION_RESP = "DROPSESSION";
	private static final String ERROR_RESP = "ERROR";
	
	private static final String NO_SESSION_ERROR_STR = "You must first create a session";
	private static final String CSS_RESPONSE_PARSE_ERROR_STR = "Error in parsing CSS response";
	private static final String DROP_SESSION_ERROR_STR = "Drop current session before creating new one";
	private static final String TIMEOUT_ERROR_STR = "The operation has timed-out.";

//	public CSSServerDAO(String jndiName, String mobile, String callid, String url, String uid, 
//			String pwd, String cTimeout, String sTimeout, boolean bTestCall) throws SQLException {
	public CSSServerDAO(String jndiName, String mobile, String callid, String url, String uid, String pwd, String cTimeout, String sTimeout) throws SQLException {
		this.mobile = mobile;
		this.callid = callid;
		this.jndiName = jndiName;
		this.cssURL = url;
		this.userId = uid;
		this.userPw = pwd;
		this.coTimeout = cTimeout;
		this.soTimeout = sTimeout;

		if (LOGGER.isTraceEnabled()) {
			LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - ******* Entered CSSServerDAO"));

		}
	}
	/**
	 * @return Returns the sessionId.
	 */
	public final String getSessionId() {
		return sessionId;
	}
	
	public CSSServerResp createSession(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp?
		cellNo=9811023181
		&txtCircle=0003
		&txtMedia=IVR
		&txtAppUser=nwss
		&txtAppPassword=nwss
		&txtWSSCode=CRSS
		&txtMPin=5493
		&txtCell=N

		*/
		
		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer().append(" - Entered CSSSErverDAO:createSession "));

		if (sessionId != null) {
			resp = new CSSServerResp();
			resp.setCode(CSSServerResp.DROP_SESSION_ERROR_CODE);
			resp.setMessage(DROP_SESSION_ERROR_STR);
			return resp;
		}

		int numOfParams = req.isLandline() ? 8 : 7;
		NameValuePair[] params = new NameValuePair[numOfParams];
		
		params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
		params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
		params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
		params[3] = new NameValuePair(PARAM_APP_USER, userId);
		params[4] = new NameValuePair(PARAM_APP_PASSWORD, userPw);
		params[5] = new NameValuePair(PARAM_WSS_CODE, "CRSS");
		if (req.isLandline()) {
			params[6] = new NameValuePair(PARAM_MPIN, req.getMpin());
			params[7] = new NameValuePair(PARAM_CELL, "N");
		} else {
			params[6] = new NameValuePair(PARAM_CELL, "Y");
		}
		
		Calendar now = Calendar.getInstance();
		resp = executeRequest(params, CREATE_SESSION_RESP);
		
		if (resp.getCode() == CSSServerResp.SUCCESS_CODE) {
			this.sessionId = new String (resp.getMessage());
		} else {
			// write error to DB
			MPinFailInfo info = new MPinFailInfo();
			
			info.setMobileNumber(req.getMobileNumber());
			info.setProgramCode(req.getProgramCode());
			info.setLandlineNumber(req.getLandlineNumber());
			info.setTransaction(req.getTransaction());
			info.setTransactionTime(now);
			
			try {
				MPinFailDAO mpinFailDAO = new MPinFailDAO(this.jndiName, this.mobile, this.callid);
				int addCount = mpinFailDAO.insert(info);
				if (addCount == 1) {
					resp.setDBRC("S");
				} else {
					resp.setDBRC("F_NF");
				}
			}
			catch (SQLException e) {
				LOGGER.error(e.getMessage());
				resp.setDBRC("F_C");
			}
			
		}
		

		if (LOGGER.isTraceEnabled()) {
			LOGGER.debug(new StringBuffer().append(" - cssResp: ").append(resp));
			LOGGER.debug(new StringBuffer().append(" - exiting CSSSErverDAO:createSession "));
		}
		return resp;
		
	}
	
	public CSSServerResp duplicateBill(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp?
		cellNo=9811023181
		&txtCircle=0003
		&txtWSSCode=DBILL
		&txtMedia=IVR
		&txtSendThr=Email
		&txtMonth=Jan
		&txtYear=05
		&txtSessionId=0a0100f4ce54e1859102d1143f784eae4396dd1bed9

		*/

		if (this.sessionId == null) {
			resp = new CSSServerResp();
			resp.setCode(CSSServerResp.NO_SESSION_ERROR_CODE);
			resp.setMessage(NO_SESSION_ERROR_STR);

		} else {
			int numOfParams = 8;
			NameValuePair[] params = new NameValuePair[numOfParams];
			
			params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
			params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
			params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
			params[3] = new NameValuePair(PARAM_WSS_CODE, "DBILL");
			params[4] = new NameValuePair(PARAM_SEND_THR, req.getBillThrough());
			params[5] = new NameValuePair(PARAM_MONTH, req.getMonth());
			params[6] = new NameValuePair(PARAM_YEAR, req.getYear());
			params[7] = new NameValuePair(PARAM_SESSION_ID, this.sessionId);
			
			resp = executeRequest(params, DUPBILL_RESP);
		}
		
		return resp;
		
	}
	
	public CSSServerResp createMpin(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		 http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp?
		 cellNo=9811023181&txtCircle=0003
		 &txtMedia=IVR
		 &txtWSSCode=AMPIN

		*/

		int numOfParams = 4;
		NameValuePair[] params = new NameValuePair[numOfParams];
		
		params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
		params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
		params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
		params[3] = new NameValuePair(PARAM_WSS_CODE, "AMPIN");
		
		resp = executeRequest(params, CREATE_MPIN_RESP);
		
		return resp;
		
	}
	
	public CSSServerResp changeMpin(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		 http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp?
		 cellNo=9811023181
		 &txtCircle=0003
		 &txtWSSCode=CMPIN
		 &txtMedia=IVR
		 &txtSessionId=0a0100f4ce54e1859102d1143f784eae4396dd1bed9

		*/

		if (this.sessionId == null) {
			resp = new CSSServerResp();
			resp.setCode(CSSServerResp.NO_SESSION_ERROR_CODE);
			resp.setMessage(NO_SESSION_ERROR_STR);

		} else {
			int numOfParams = 5;
			NameValuePair[] params = new NameValuePair[numOfParams];
			
			params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
			params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
			params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
			params[3] = new NameValuePair(PARAM_WSS_CODE, "CMPIN");
			params[4] = new NameValuePair(PARAM_SESSION_ID, this.sessionId);
			
			resp = executeRequest(params, CHANGE_MPIN_RESP);
		}
		
		return resp;
		
	}
	
	public CSSServerResp activateIBill(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		 http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp?
		 cellNo=9811023181
		 &txtCircle=0003
		 &txtWSSCode=AIB
		 &txtMedia=IVR
		 &txtSessionId=0a0100f4ce54e1859102d1143f784eae4396dd1bed9

		*/
		
		if (this.sessionId == null) {
			resp = new CSSServerResp();
			resp.setCode(CSSServerResp.NO_SESSION_ERROR_CODE);
			resp.setMessage(NO_SESSION_ERROR_STR);

		} else {

			int numOfParams = 5;
			NameValuePair[] params = new NameValuePair[numOfParams];
			
			params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
			params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
			params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
			params[3] = new NameValuePair(PARAM_WSS_CODE, "AIB");
			params[4] = new NameValuePair(PARAM_SESSION_ID, this.sessionId);
			
			resp = executeRequest(params, ACTIVATE_IBILL_RESP);
		}
		
		return resp;
		
	}
	
	public CSSServerResp deactivateIBill(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		 http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp?
		 cellNo=9811023181
		 &txtCircle=0003
		 &txtWSSCode=DIB
		 &txtMedia=IVR
		 &txtSessionId=0a0100f4ce54e1859102d1143f784eae4396dd1bed9

		*/

		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer().append(" - entered CSSSErverDAO:deactivateBull "));

		if (this.sessionId == null) {
			resp = new CSSServerResp();
			resp.setCode(CSSServerResp.NO_SESSION_ERROR_CODE);
			resp.setMessage(NO_SESSION_ERROR_STR);

		} else {
			int numOfParams = 5;
			NameValuePair[] params = new NameValuePair[numOfParams];
			
			params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
			params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
			params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
			params[3] = new NameValuePair(PARAM_WSS_CODE, "DIB");
			params[4] = new NameValuePair(PARAM_SESSION_ID, this.sessionId);
			
			resp = executeRequest(params, DEACTIVATE_IBILL_RESP);
		}
		


		if (LOGGER.isTraceEnabled()) {
			LOGGER.debug(new StringBuffer().append(" - cssResp: ").append(resp));
			LOGGER.debug(new StringBuffer().append(" - exiting CSSSErverDAO:deactivateBull "));
		}
		return resp;
		
	}
	
	public CSSServerResp dropSession(final CSSServerReq req) {
		CSSServerResp resp = null;
		/*
		 http://10.1.0.244:7777/NWSS-SMS-IVR/HutchNwssMain.jsp
		 ?cellNo=9811023181
		 &txtCircle=0003
		 &txtMedia=IVR
		 &txtAppUser=nwss
		 &txtAppPassword=nwss
		 &txtWSSCode=CLSS
		 &txtMPin=5206

		*/

		int numOfParams = 7;
		NameValuePair[] params = new NameValuePair[numOfParams];
		
		params[0] = new NameValuePair(PARAM_CELL_NO, req.getMobileNumber());
		params[1] = new NameValuePair(PARAM_CIRCLE_CODE, req.getCircleCode());
		params[2] = new NameValuePair(PARAM_MEDIA, PARAM_MEDIA_VALUE);
		params[3] = new NameValuePair(PARAM_APP_USER, userId);
		params[4] = new NameValuePair(PARAM_APP_PASSWORD, userPw);
		params[5] = new NameValuePair(PARAM_WSS_CODE, "CLSS");
		params[6] = new NameValuePair(PARAM_MPIN, req.getMpin());
		
		resp = executeRequest(params, DROP_SESSION_RESP);
		
		this.sessionId = null;
		
		return resp;
		
	}
	
	private CSSServerResp executeRequest(NameValuePair[] params, final String responseElement) {
		
		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer().append(" - cssURL: ").append(cssURL));

		HttpClient httpclient = new HttpClient();
		GetMethod httpget = new GetMethod(cssURL);
		String respXMLString = null;
		CSSServerResp resp = new CSSServerResp();

		try {
			// TODO: these timeouts should be made configurable
			httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(new Integer(coTimeout).intValue());
			httpclient.getHttpConnectionManager().getParams().setSoTimeout(new Integer(soTimeout).intValue());

			httpget.setQueryString(params);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(new StringBuffer().append(" - CSSServer Get Data = ").append(httpget.getQueryString()));				
			}
			httpclient.executeMethod(httpget);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
		            httpget.getResponseBodyAsStream(), httpget.getResponseCharSet()));
			StringBuffer str = new StringBuffer();
			String tempStr = null;
			while ((tempStr = reader.readLine()) != null) {
				str.append(tempStr);
			}
			respXMLString = str.toString();
		}
		catch(HttpException e) {
			LOGGER.error(e.getMessage());
		}
		catch(IOException e) {
			LOGGER.error(e.getMessage());
		}
		catch(Exception e) {
			LOGGER.error(e.getMessage());
			
		}
		finally {
			httpget.releaseConnection();
		}
		
		if (respXMLString == null) {	// timeout
			resp.setCode(CSSServerResp.TIMEOUT_ERROR_CODE);
			resp.setMessage(TIMEOUT_ERROR_STR);
		} else {
			String elementValue = getElementValue(respXMLString, responseElement);
			if (elementValue == null) {
				elementValue = getElementValue(respXMLString, ERROR_RESP);
			}
			if (elementValue != null) {
	
				/*
				StringBuffer buf = new StringBuffer();
				// strip any new line and line feed characters
	
				for (int i = 0; i < elementValue.length(); i++) {
					char c = elementValue.charAt(i);
					if (c != '\n' && c != '\r') {
						buf.append(c);
					}
				}
				String ev = buf.toString();
				String str[] = ev.split("\\|");
				*/
				String str[] = elementValue.split("\\|");
				if (str == null || str.length != 2) {	//error
					resp.setCode(CSSServerResp.CSS_RESPONSE_PARSE_ERROR_CODE);
					resp.setMessage(CSS_RESPONSE_PARSE_ERROR_STR);
				} else {
					resp.setCode(Integer.parseInt(str[0]));
					resp.setMessage(str[1]);
				}
				
			} else {
				resp.setCode(CSSServerResp.CSS_RESPONSE_PARSE_ERROR_CODE);
				resp.setMessage(CSS_RESPONSE_PARSE_ERROR_STR);
			}
		}
		
		return resp;
	}
	
	private String getElementValue(String xml, String elementName) {
		int index1, index2;
		String value = null;
		index1 = xml.indexOf("<" + elementName + ">");
		if (index1 >= 0){
			index2 = xml.indexOf("</" + elementName + ">", index1);
			if (index2 >= index1) value = xml.substring(index1 + elementName.length() + 2, index2);
		}
		return value;
	}//end method getElementValue
}
