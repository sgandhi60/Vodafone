package com.selfserv.ivr.selfservdao.central;

public class ActSvcXfer {
	private String DBRC = null;
	private String DBMsg = null;
	private String status = null;
	private String tat = null;
	
	ActSvcXfer(){
	}

	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}

	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}

	/**
	 * @return the dBRC
	 */
	public String getDBRC() {
		return DBRC;
	}

	/**
	 * @param dbrc the dBRC to set
	 */
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the tat
	 */
	public String getTat() {
		return tat;
	}

	/**
	 * @param tat the tat to set
	 */
	public void setTat(String tat) {
		this.tat = tat;
	}
}
