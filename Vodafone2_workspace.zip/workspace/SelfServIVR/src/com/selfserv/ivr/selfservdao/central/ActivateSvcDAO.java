package com.selfserv.ivr.selfservdao.central;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class ActivateSvcDAO extends BaseDAO{
	private Connection conn = null;
	private CallableStatement cstmt = null;
	private final static Logger LOGGER = Logger.getLogger(ActivateSvcDAO.class);
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private String spPackageName = null;

	public ActivateSvcDAO(String jndiName, String cell, String cid, boolean bTestCall, String packageName) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;
		this.spPackageName = packageName;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered ActivateSvcDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the CDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public ActSvcXfer executeSP(String crcl_id, String msisdn, int sncode, String actStatus, String v_r) {
		ActSvcXfer actSvcXfer = new ActSvcXfer();
		
		try {
			/*IVR_SR_CREATION (crcl_id IN VARCHAR2,
			 * 			 msisdn IN VARCHAR2,
			 * 			 SNCODE IN NUMBER,
			 * 			 ActStatus IN VARCHAR2,
			 * 			 V_R IN VARCHAR2,
			 * 			 ret_sts OUT VARCHAR2,
			 * 			 ret_tat OUT VARCHAR2,
			 *           ret_msg OUT VARCHAR2);*/
			
	        if (testCall)
	        	LOGGER.debug(new StringBuffer(logToken).append(" - Invoking CDB SP IVR_SR_CREATION with: circle: ").append(crcl_id)
	        			.append(" msisdn: ").append(msisdn)
	        			.append(" sncode: ").append(sncode)
	        			.append(" ActStatus: ").append(actStatus)
	        			.append(" and v_r: ").append(v_r));

			if (conn!=null){
				String query = StoredProcedureQuery.getQuery(StoredProcedureQuery.IVR_SR_CREATION, spPackageName);
				cstmt = conn.prepareCall(query);
				
				//Setting IN params: crcl_id, msisdn
				cstmt.setString(1,crcl_id);
				cstmt.setString(2,msisdn);
				cstmt.setInt(3,sncode);
				cstmt.setString(4,actStatus);
				cstmt.setString(5,v_r);
				
				//registering OUT params:
				cstmt.registerOutParameter(6, Types.VARCHAR);	//ret_sts
				cstmt.registerOutParameter(7, Types.VARCHAR);	//ret_tat
				cstmt.registerOutParameter(8, Types.VARCHAR);	//ret_msg
				
				cstmt.execute();
				
				String status = cstmt.getString(6);
				String turnAroundTime = cstmt.getString(7);
				String ret_msg = cstmt.getString(8);

				actSvcXfer.setStatus(status);
				actSvcXfer.setTat(turnAroundTime);
				
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" - ret_msg = ").append(ret_msg));
				
				if (ret_msg != null && ret_msg.equals("0")) {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - Successful Creation. Status = ").append(status));
					actSvcXfer.setDBRC("S");
				} else {
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the SP for CircleID= ").append(crcl_id)
			        			.append(" msisdn: ").append(msisdn)
			        			.append(" sncode: ").append(sncode)
			        			.append(" ActStatus: ").append(actStatus)
			        			.append(" v_r: ").append(v_r));
					}
					actSvcXfer.setDBRC("F_NF");
					actSvcXfer.setDBMsg("No match found in the CDB");
				}

			} // if (conn!=null)
		} catch (SQLException e) {
			String msg = e.getMessage();
            LOGGER.warn(new StringBuffer(logToken).append(" - Exception invoking CDB SP IVR_SR_CREATION: ").append(msg));
            
            actSvcXfer.setDBRC("F_C");
            actSvcXfer.setDBMsg(msg);
			e.printStackTrace();
		} finally{
			 releaseResource(conn, cstmt, null);		 
		}
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting ActivateSvcDAO"));
		return actSvcXfer;
	}
}