package com.selfserv.ivr.selfservdao.central;

import java.util.Date;

public class IVRCallDetailsXfer {
	private String DBRC = null;
	private String pgname = null;
	private String pgcode = null;
	private String cust_code = null;
	private String bCycle = null;
	private float balance = 0;
	private Date birthDate = null;
	private Date lbc_date = null;
	private float creditLimit = 0;
	private String email = null;
	private int tariffCode = 0;
	private String scheme = null;
	private String schemeName = null;
	private String status = null;
	private float ret_unBilliedAmount = 0;
	private Date ret_dueDate = null;
	private float ret_deposit = 0;
	private String ret_payments = null;
	private float ret_lastBilledAmount = 0;
	private String ret_msg = null;
	private String zipCode = null;
	
	IVRCallDetailsXfer(){
	}
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public String getPgname() {
		return pgname;
	}
	public void setPgname(String pgname) {
		this.pgname = pgname;
	}
	public String getCust_code() {
		return cust_code;
	}
	public void setCust_code(String cust_code) {
		this.cust_code = cust_code;
	}
	public String getPgcode() {
		return pgcode;
	}
	public void setPgcode(String pgcode) {
		this.pgcode = pgcode;
	}
	public String getBCycle() {
		return bCycle;
	}
	public void setBCycle(String cycle) {
		bCycle = cycle;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public float getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(float creditLimit) {
		this.creditLimit = creditLimit;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getLbc_date() {
		return lbc_date;
	}
	public void setLbc_date(Date lbc_date) {
		this.lbc_date = lbc_date;
	}
	public Date getRet_dueDate() {
		return ret_dueDate;
	}
	public void setRet_dueDate(Date ret_dueDate) {
		this.ret_dueDate = ret_dueDate;
	}
	public String getRet_msg() {
		return ret_msg;
	}
	public void setRet_msg(String ret_msg) {
		this.ret_msg = ret_msg;
	}
	public String getRet_payments() {
		return ret_payments;
	}
	public void setRet_payments(String ret_payments) {
		this.ret_payments = ret_payments;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public float getRet_deposit() {
		return ret_deposit;
	}
	public void setRet_deposit(float ret_deposit) {
		this.ret_deposit = ret_deposit;
	}
	public float getRet_lastBilledAmount() {
		return ret_lastBilledAmount;
	}
	public void setRet_lastBilledAmount(float ret_lastBilledAmount) {
		this.ret_lastBilledAmount = ret_lastBilledAmount;
	}
	public float getRet_unBilliedAmount() {
		return ret_unBilliedAmount;
	}
	public void setRet_unBilliedAmount(float ret_unBilliedAmount) {
		this.ret_unBilliedAmount = ret_unBilliedAmount;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTariffCode() {
		return tariffCode;
	}
	public void setTariffCode(int tariffCode) {
		this.tariffCode = tariffCode;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
}
