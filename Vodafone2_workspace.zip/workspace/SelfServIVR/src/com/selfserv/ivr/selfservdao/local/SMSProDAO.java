package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.selfserv.ivr.handler.CustomerType;
import com.selfserv.ivr.selfservdao.BaseDAO;
/*
 * Caches the LDB SMS_PRO table for a particular circle
 */
public class SMSProDAO extends BaseDAO{
	private final String SQL_QUERY_STMT = "Select DESCRIPTION, SMS_MSG from TBL_SMS_PRO";
	private static Logger LOGGER = Logger.getLogger(SMSProDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;

	public SMSProDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		mobile = cell;
		callid = cid;
		conn = getConnection(jndiName, mobile, callid);
		testCall = bTestCall;
		if (testCall)
			LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - connected to LDB ").append(jndiName));
	}

	public SMSProXfer findRecord(){
		if (testCall)
			LOGGER.debug(new StringBuffer("[").append(callid).append("]").append(" - caching TBL_SMS_PRO"));
		
		PreparedStatement stmt = null;
	    ResultSet rs = null;
	    SMSProXfer smsProXfer = new SMSProXfer();

		 try{
			 stmt = conn.prepareStatement(SQL_QUERY_STMT);
	         rs = stmt.executeQuery();
	         Properties props = new Properties();
	         while (rs.next()){
            	props.setProperty(rs.getString(1),rs.getString(2));
	         }
	         smsProXfer.setSmsPro(props);
	         smsProXfer.setDBRC("S");
		 }catch(Exception e){//Problem encounterd getting query results
			 LOGGER.error(new StringBuffer("[").append(callid).append("]").append(" - Exception encountered accessing TBL_SMS_PRO").append(e.getMessage()));
			 smsProXfer.setDBRC("F_C");
		 }finally{
			 releaseResource(conn, stmt, rs);		 
		 }
		 
		 return smsProXfer;
	}
}