package com.selfserv.ivr.selfservdao.central;

public class StoredProcedureQuery {
	
	/**
	* Default Constructor.
	*/
	private StoredProcedureQuery() {
	  super();
	}
	private static final String callStr = "call ";
	public static final String IVR_SR_CREATION = ".IVR_SR_CREATION(?, ?, ?, ?, ?, ?, ?, ?)";
	public static final String IVR_CREDIT_MATRIX = ".IVR_CREDIT_MATRIX(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public static final String IVR_MPIN = ".IVR_MPIN(?, ?, ?, ?)";
	public static final String IVR_CALL_DETAILS = ".IVR_CALL_DETAILS(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public static final String IVR_MAIN = ".IVR_MAIN(?, ?, ?, ?, ?, ?)";
	public static final String IVR_SERVICES = ".IVR_SERVICES(?, ?, ?, ?)";
	public static final String IVR_PUKCODE = ".IVR_PUKCODE(?, ?, ?, ?)";
	
	public static String getQuery(final String sp, final String packageName) {
		
		StringBuffer query = new StringBuffer(callStr).append(packageName).append(sp);
		return query.toString();
		
	}

}
