package com.selfserv.ivr.selfservdao.central;

public class PUKXfer {
	private String DBRC = null;
	private String puk = null;
	private String DBMsg = null;
	
	PUKXfer(){
	}

	public String getDBRC() {
		return DBRC;
	}

	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	public String getPuk() {
		return puk;
	}

	public void setPuk(String puk) {
		this.puk = puk;
	}

	public String getDBMsg() {
		return DBMsg;
	}

	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
}
