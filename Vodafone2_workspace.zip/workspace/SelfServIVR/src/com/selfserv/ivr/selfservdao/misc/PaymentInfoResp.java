/*
 * Created on Jun 11, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.misc;

import java.util.Calendar;

/**
 * @author mansey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PaymentInfoResp {
	public static final String SUCCESS_FLAG = "S";
	public static final String ERROR_FLAG = "E";
	public static final String TIMEOUT_FLAG = "T";
	
	public static final String TRANS_TYPE_PAYMENT = "P";
	
	public static final String SERV_NAME_PAYMENT = "BP";
	public static final String SERV_NAME_DEPOSIT = "DEPOSIT";
	
	private String responseFlag = null;
	private String customerID = null;
	private String mobileNumber = null;
	private String circleID = null;
	private String sourceName = null;
	private String transType = null;
	private String servName = null;
	private Calendar transDate = null;
	private int amount = 0;
	private int traceNumber = 0;
	private String response = null;
	private String snCode = null; 
	private String referenceNumber = null;
	
	private String DBRC;
	private String DBMsg;

	/**
	 * @return Returns the amount.
	 */
	public final int getAmount() {
		return amount;
	}
	/**
	 * @param amount The amount to set.
	 */
	public final void setAmount(int amount) {
		this.amount = amount;
	}
	/**
	 * @return Returns the circleID.
	 */
	public final String getCircleID() {
		return circleID;
	}
	/**
	 * @param circleID The circleID to set.
	 */
	public final void setCircleID(String circleID) {
		this.circleID = circleID;
	}
	/**
	 * @return Returns the customerID.
	 */
	public final String getCustomerID() {
		return customerID;
	}
	/**
	 * @param customerID The customerID to set.
	 */
	public final void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	/**
	 * @return Returns the dBRC.
	 */
	public final String getDBRC() {
		return DBRC;
	}
	/**
	 * @param dbrc The dBRC to set.
	 */
	public final void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	/**
	 * @return Returns the mobileNumber.
	 */
	public final String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber The mobileNumber to set.
	 */
	public final void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return Returns the referenceNumber.
	 */
	public final String getReferenceNumber() {
		return referenceNumber;
	}
	/**
	 * @param referenceNumber The referenceNumber to set.
	 */
	public final void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	/**
	 * @return Returns the response.
	 */
	public final String getResponse() {
		return response;
	}
	/**
	 * @param response The response to set.
	 */
	public final void setResponse(String response) {
		this.response = response;
	}
	/**
	 * @return Returns the responseFlag.
	 */
	public final String getResponseFlag() {
		return responseFlag;
	}
	/**
	 * @param responseFlag The responseFlag to set.
	 */
	public final void setResponseFlag(String responseFlag) {
		this.responseFlag = responseFlag;
	}
	/**
	 * @return Returns the servName.
	 */
	public final String getServName() {
		return servName;
	}
	/**
	 * @param servName The servName to set.
	 */
	public final void setServName(String servName) {
		this.servName = servName;
	}
	/**
	 * @return Returns the snCode.
	 */
	public final String getSnCode() {
		return snCode;
	}
	/**
	 * @param snCode The snCode to set.
	 */
	public final void setSnCode(String snCode) {
		this.snCode = snCode;
	}
	/**
	 * @return Returns the sourceName.
	 */
	public final String getSourceName() {
		return sourceName;
	}
	/**
	 * @param sourceName The sourceName to set.
	 */
	public final void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	/**
	 * @return Returns the traceNumber.
	 */
	public final int getTraceNumber() {
		return traceNumber;
	}
	/**
	 * @param traceNumber The traceNumber to set.
	 */
	public final void setTraceNumber(int traceNumber) {
		this.traceNumber = traceNumber;
	}
	/**
	 * @return Returns the transDate.
	 */
	public final Calendar getTransDate() {
		return transDate;
	}
	/**
	 * @param transDate The transDate to set.
	 */
	public final void setTransDate(Calendar transDate) {
		this.transDate = transDate;
	}
	/**
	 * @return Returns the transType.
	 */
	public final String getTransType() {
		return transType;
	}
	/**
	 * @param transType The transType to set.
	 */
	public final void setTransType(String transType) {
		this.transType = transType;
	}
	/**
	 * @return the dBMsg
	 */
	public String getDBMsg() {
		return DBMsg;
	}
	/**
	 * @param msg the dBMsg to set
	 */
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
}
