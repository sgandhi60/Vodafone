package com.selfserv.ivr.selfservdao.local;

public class TableBirthXfer {
	private String DBRC = null;
	private String flag = null;
	private String DBMsg = null;
	
	public String getDBMsg() {
		return DBMsg;
	}
	public void setDBMsg(String msg) {
		DBMsg = msg;
	}
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String Flag) {
		this.flag = Flag;
	}
	
}
