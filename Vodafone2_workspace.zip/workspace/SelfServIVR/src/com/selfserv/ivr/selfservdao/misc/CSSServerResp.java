/*
 * Created on Jun 11, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.selfservdao.misc;

/**
 * @author mansey
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CSSServerResp {
	public static final int SUCCESS_CODE = 0;
	public static final int CSS_RESPONSE_PARSE_ERROR_CODE = 2;
	public static final int DROP_SESSION_ERROR_CODE = 8;
	public static final int NO_SESSION_ERROR_CODE = 9;
	public static final int TIMEOUT_ERROR_CODE = 999;
	
	private int code = 0;
	private String message = null;
	private String DBRC;
	
	/**
	 * @return Returns the code.
	 */
	public final int getCode() {
		return code;
	}
	/**
	 * @param code The code to set.
	 */
	public final void setCode(int code) {
		this.code = code;
	}
	/**
	 * @return Returns the message.
	 */
	public final String getMessage() {
		return message;
	}
	/**
	 * @param message The message to set.
	 */
	public final void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return Returns the dBRC.
	 */
	public final String getDBRC() {
		return DBRC;
	}
	/**
	 * @param dbrc The dBRC to set.
	 */
	public final void setDBRC(String dbrc) {
		DBRC = dbrc;
	}
}
