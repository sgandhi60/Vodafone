package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class ServiceFlagDAO extends BaseDAO{
	//private final String SQL_QUERY_STMT = "Select CUSTOMER_ID CUSTCODE CO_ID TITLE FNAME LNAME BIRTHDATE EMAIL BILLCYCLE CSC LIMIT PRGCODE PRGNAME CO_ACTIVATED CH_STATUS TMCODE SHDES PUK MOBILE PINCODE ADDRESS1	ADDRESS2 ADDRESS3 CITY from TBL_GEN Where Mobile = ?";
	private final String SQL_QUERY_STMT = "Select SERVICEFLAG FROM TBL_OPTALD Where CIRCLECODE = ? and CUSTSEG = ?";
	private static Logger LOGGER = Logger.getLogger(ServiceFlagDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public ServiceFlagDAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		this.mobile = cell;
		this.callid = cid;
		this.testCall = bTestCall;

		this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered ServiceFlagDAO"));

		try {
			conn = getConnection(jndiName, mobile, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public ServiceFlagXfer findRecord(String crcl_id, String custSeg){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for CircleID= ").append(crcl_id)
					.append(" and CustSeg= ").append(custSeg));

		PreparedStatement stmt = null;
		ResultSet rs = null;
		ServiceFlagXfer serviceFlagXfer = new ServiceFlagXfer();

		try{
			if (conn!=null) {
				stmt = conn.prepareStatement(SQL_QUERY_STMT);
				stmt.setString(1, crcl_id);
				stmt.setString(2, custSeg);
				rs = stmt.executeQuery();
				if (rs.next()){
					if (rs.getString(1)!=null){

						String svcFlag = rs.getString(1);

						serviceFlagXfer.setServiceFlag(svcFlag);
						serviceFlagXfer.setDBRC("S");

						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" - Match found; ServiceFlag=").append(svcFlag));
					} else { // empty record
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for CircleID= ").append(crcl_id)
									.append(" and CustSeg= ").append(custSeg));
						}
						serviceFlagXfer.setDBRC("F_NF");
						serviceFlagXfer.setDBMsg("Empty record found in the LDB");
					}
				}else{//no result set found
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for CircleID= ").append(crcl_id)
								.append(" and CustSeg= ").append(custSeg));
					}
					serviceFlagXfer.setDBRC("F_NF");
					serviceFlagXfer.setDBMsg("No match found in the LDB");
				}
			}else{//no connection
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for CircleID= ").append(crcl_id)
							.append(" and CustSeg= ").append(custSeg));
				}
				serviceFlagXfer.setDBRC("F_C");
				serviceFlagXfer.setDBMsg("No connection made to DB");
			} // if (conn!=null)
		}catch(Exception e){//Problem encounterd getting query results
			String msg = e.getMessage();			 
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the ServiceFlag from TBL_OPTALD - " + e.getMessage()));

			serviceFlagXfer.setDBRC("F_C");
			serviceFlagXfer.setDBMsg(msg);
		}finally{
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting ServiceFlagDAO"));
			releaseResource(conn, stmt, rs);		 
		}
		return serviceFlagXfer;
	}
}
