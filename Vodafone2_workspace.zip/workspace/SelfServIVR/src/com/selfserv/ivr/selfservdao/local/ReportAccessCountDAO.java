package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class ReportAccessCountDAO extends BaseDAO{
	private Connection conn = null;
	//private final String SQL_QUERY_CHECK_CDAY = "Select DAY_CALLS, XFER_COUNT from TBL_CDAY_BARRED Where MOBILE = ? and DAY_CALLS = ?";//'24/MAR/08'
	private final String SQL_INSERT = "Insert into TBL_RPT_ACCESS_CNT" +
										"(CALLID,STARTTIME,ENDTIME,TYPE,MSISDN,CALLEDFROM,LANG,COMPLAINT_FLAG,SMS_COUNT,OPTION1,OPTION2,OPTION3,OPTION4,OPTION5) " +
										"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//										"values(?,to_date('?', 'dd/mm/yyyy hh:mm:ss'),to_date('?', 'dd/mm/yyyy hh:mm:ss'),?,?,?,?,?,?,?,?,?,?,?)";

	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;
	private static Logger LOGGER = Logger.getLogger(ReportAccessCountDAO.class);
	
	public ReportAccessCountDAO(String jndiName, String cell, String callID, boolean bTestCall) throws SQLException {
		// initialization 
			this.mobile = cell;
			this.callid = callID;
			this.testCall = bTestCall;

			this.logToken = new StringBuffer("[").append(callid).append("] ").toString();

			if (testCall) 
				LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered ReportAccessCountDAO"));

		try {
			conn = getConnection(jndiName, mobile, callID);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	
	/**
	 * Inserts a record by incrementing the daily transfer count to operators
	 * @return
	 */
	public DBXfer insertRecord(String callid, Date startTime, Date endTime, String type, String msisdn, 
							String calledFrom, String lang, String complaintFlag, int  smsCount, 
							int option1, int option2, int option3, int option4, int option5) {
		
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - Entered ReportAccessCountDAO::insertRecord()"));
		
		PreparedStatement stmt = null;
		DBXfer dbXfer = new DBXfer();
		int result = -1;
		
		if ( (calledFrom == null) || (calledFrom.trim().length() == 0) )
			calledFrom = "-1";
		Timestamp startTimestamp = new Timestamp(startTime.getTime());
		Timestamp endTimestamp = new Timestamp(endTime.getTime());

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append("Record to be inserted into DB with the following data :"));
			LOGGER.debug(new StringBuffer(logToken)
											  .append(" CallID =").append(callid)
											  .append("  Type =").append(type)
											  .append(", STARTTIME =").append(startTimestamp.toString())
											  .append(", ENDTIME =").append(endTimestamp.toString())
											  .append(", MSISDN =").append(msisdn)
											  .append(", CalledFrom =").append(calledFrom)
											  .append(", Language =").append(lang)
											  .append(", Complaint Flag =").append(complaintFlag)
											  .append(", SMS Count =").append(smsCount)
											  .append(", Option1 =").append(option1)
											  .append(", Option2 =").append(option2)
											  .append(", Option3 =").append(option3)
											  .append(", Option4 =").append(option4)
											  .append(", Option5 =").append(option5));
		}
		
		try {
			if ( conn != null ) {
				stmt = conn.prepareStatement(SQL_INSERT);

				stmt.setString(1, callid); 					//Callid
				stmt.setTimestamp(2, startTimestamp);		//STARTTIME
				stmt.setTimestamp(3, endTimestamp);			//ENDTIME
//				stmt.setDate(2, new java.sql.Date(startTime.getTime()));		//STARTTIME
//				stmt.setDate(2, new java.sql.Date(endTime.getTime()));			//ENDTIME
				stmt.setString(4, type); 					//type - Prepaid or Postpaid ?
				stmt.setString(5, msisdn); 					//MSISDN
				stmt.setString(6, calledFrom); 				//CalledFrom
				stmt.setString(7, lang); 					//Language
				stmt.setString(8, complaintFlag); 			//Complaint Flag
				stmt.setInt(9, smsCount);					//SMS Count
				stmt.setInt(10, option1); 					//Choice 1
				stmt.setInt(11, option2); 					//Choice 2
				stmt.setInt(12, option3); 					//Choice 3
				stmt.setInt(13, option4); 					//Choice 4
				stmt.setInt(14, option5); 					//Choice 5

				result = stmt.executeUpdate();
				if (result == 1) {
					dbXfer.setDBRC("S");
				} else {
					dbXfer.setDBRC("F_NF");
					dbXfer.setDBMsg(" No record inserted in DB");
				}

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Inserted ").append(result).append("record(s)"));
				}
			} else {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB"));
				}
				dbXfer.setDBRC("F_C");
				dbXfer.setDBMsg(" No connection made to DB");
			}
		} catch (SQLException e) {
			String msg = e.getMessage();	
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to insert record into table TBL_RPT_ACCESS_CNT - " + e.getMessage()));

			dbXfer.setDBRC("F_C");
			dbXfer.setDBMsg(msg);
		} finally {
			releaseResource(conn, stmt, null);		 
		}

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Exiting ReportAccessCountDAO::insertRecord()"));
		return dbXfer;
	}
	
}
