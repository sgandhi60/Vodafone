package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.selfserv.ivr.handler.CustomerType;
import com.selfserv.ivr.selfservdao.BaseDAO;

public class SMSShopsDAO extends BaseDAO{
	private final String SQL_QUERY_STMT = "Select TOTAL_CENTRES, SMS_MSG1, SMS_MSG2, SMS_MSG3 from SMS_SHOPS Where PINCODE = ?";
	private static Logger LOGGER = Logger.getLogger(SMSShopsDAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	private String logToken = null;

	public SMSShopsDAO(String jndiName, String cell, String cid, boolean testCall) throws SQLException {
		mobile = cell;
		callid = cid;
		this.testCall = testCall;
		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
		conn = getConnection(jndiName,cell, cid);
		if (this.testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - constructor - Connected to LDB ").append(jndiName));
		}
	}

	public SMSShopsXfer findRecord(String pinCode){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding SMS message for pinCode=").append(pinCode));
		
		PreparedStatement stmt = null;
	    ResultSet rs = null;
	    SMSShopsXfer smsShopsXfer = new SMSShopsXfer();

	    
		 try{
			 stmt = conn.prepareStatement(SQL_QUERY_STMT);
	         stmt.setString(1, pinCode);
	         rs = stmt.executeQuery();
	         if (rs.next()){
        		 int totalCenters = rs.getInt(1);
        		 if (testCall)
        			 LOGGER.debug(new StringBuffer(logToken).append(" - Match found;  totalCenters = ").append(totalCenters));
            	 
            	 smsShopsXfer.setTotalCenters(totalCenters);
            	 
            	 for (int i=0; i<totalCenters;i++){
            		 smsShopsXfer.setSmsMsg(rs.getString(i+2),i);
            	 }
            		 smsShopsXfer.setDBRC("S");
	         }else{//no result set found
	        	 if (testCall)
	        		 LOGGER.debug(new StringBuffer(logToken).append(" - No match in the LDB."));
				 smsShopsXfer.setDBRC("F_NF");
	         }
		 }catch(Exception e){//Problem encounterd getting query results
			 LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered accessing SMS_SHOPS").append(e.getMessage()));
			 smsShopsXfer.setDBRC("F_C");
		 }finally{
			 releaseResource(conn, stmt, rs);		 
		 }
		 
		 return smsShopsXfer;
	}
}






