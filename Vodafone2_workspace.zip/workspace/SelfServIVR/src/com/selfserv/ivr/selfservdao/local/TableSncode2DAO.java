package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class TableSncode2DAO extends BaseDAO{
	//private final String SQL_QUERY_STMT = "Select CUSTOMER_ID CUSTCODE CO_ID TITLE FNAME LNAME BIRTHDATE EMAIL BILLCYCLE CSC LIMIT PRGCODE PRGNAME CO_ACTIVATED CH_STATUS TMCODE SHDES PUK MOBILE PINCODE ADDRESS1	ADDRESS2 ADDRESS3 CITY from TBL_GEN Where Mobile = ?";
	private final String SQL_QUERY_STMT = "Select SERVICE_KEY, SERVICE_CODE FROM TBL_SNCODE2";
	private static Logger LOGGER = Logger.getLogger(TableSncode2DAO.class);
	private Connection conn = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	private String logToken = null;

	public TableSncode2DAO(String jndiName, String cell, String cid, boolean bTestCall) throws SQLException {
		// initialization 
		mobile = cell;
		callid = cid;
		testCall = bTestCall;

		logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableSncode2DAO"));

		try {
			conn = getConnection(jndiName, cell, callid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
			throw e;
		}
	}

	public TableSncode2Xfer findRecords(){
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - finding record for mobile=").append(mobile));
		
		PreparedStatement stmt = null;
	    ResultSet rs = null;
	    TableSncode2Xfer tableSncode2Xfer = new TableSncode2Xfer();
	    String svcKey = null;
	    String svcCode = null;
	    int count = 0;
	    Properties propCodeKey = null;    // properties object as Code and key as key=value pair
	    Properties propKeyCode = null;    // properties object as Key and Code as key=value pair
	    
		 try{
			 stmt = conn.prepareStatement(SQL_QUERY_STMT);
	         rs = stmt.executeQuery();
	         propCodeKey = new Properties();
	         propKeyCode = new Properties();
	         
	         while (rs.next()){
        		 tableSncode2Xfer.setDBRC("S");
	        	 if (rs.getString(1)!= null) {
	        		 
	        		 svcKey = rs.getString(1);
	        		 svcCode = rs.getString(2);
	        		 propCodeKey.put(svcCode, svcKey);        		 
	        		 propKeyCode.put(svcKey, svcCode);        		 

	        		 if (testCall)
	        			 LOGGER.debug(new StringBuffer(logToken).append(" - Record# ").append(++count)
	        					 .append(": - SvcKey= ").append(svcKey).append(" svcCode= ").append(svcCode));
	        	 } else { // empty record
		        	 if (testCall) {
		        		 LOGGER.debug(new StringBuffer(logToken).append(" - Empty record found in the LDB for mobile="+mobile));
		        	 }
		        	 tableSncode2Xfer.setDBRC("F_NF");
		        	 tableSncode2Xfer.setDBMsg("Empty record found in the LDB");
	        	 }
/*	         }else{//no result set found
	        	 if (testCall) {
	        		 LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the LDB for mobile="+mobile));
	        	 }
				 tableSncode2Xfer.setDBRC("F_NF");
				 tableSncode2Xfer.setDBMsg("No match found in the LDB");
*/
	         } // while
 		 }catch(Exception e){//Problem encounterd getting query results
			 String msg = e.getMessage();			 
			 if (testCall)
				 LOGGER.debug(new StringBuffer(logToken).append(" - Exception encountered getting the records from TBL_SNCODE2" + e.getMessage()));
			
			 tableSncode2Xfer.setDBRC("F_C");
			 tableSncode2Xfer.setDBMsg(msg);
		 }finally{
			releaseResource(conn, stmt, rs);		 
		 }

		 tableSncode2Xfer.setCodeKeyProp(propCodeKey);
		 tableSncode2Xfer.setKeyCodeProp(propKeyCode);

		 if (testCall) {
			 LOGGER.debug(new StringBuffer(logToken).append(" - Total # of records found= ").append(count));
			 LOGGER.debug(new StringBuffer(logToken).append(" - Total # of entries in properties= ").append(propCodeKey.size()));
			 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TableSncode2DAO"));
		 }
		 return tableSncode2Xfer;
	}
}
