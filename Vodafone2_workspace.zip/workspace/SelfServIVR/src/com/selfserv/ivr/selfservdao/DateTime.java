package com.selfserv.ivr.selfservdao;

import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * This class returns the current time formatted base on an string passed as a parameter, for example
 *     	"yyyy/MM/dd HH:mm:ss", "MM/dd/yy", "DD/MMM/YY"
 *
 *@param dtFormat - the date and time format that should be used to return the current date and/or time
 */
public class DateTime {
    public static String getDateTime(String dtFormat) {
    	Calendar cal = Calendar.getInstance();
    	SimpleDateFormat sdf = new SimpleDateFormat(dtFormat);
        return sdf.format(cal.getTime());
    }
    
    public static long getDate(){
    	Calendar cal = Calendar.getInstance();
    	cal.set(2008,06,9);
        return cal.getTimeInMillis(); 	
    }
    
    public static void main(String argv[]){
    	System.out.println(getDate());
    	for (int i=0;i<100000;i++){
    		//do nothing
    	}

//    	 Get difference in milliseconds
        //long diffMs = lastUpdate.getTimeInMillis()-now.getTimeInMillis();
        //long diffSecs = diffMs/(1000);           // difference in secs
        //long diffMins = diffMs/(60*1000);        // difference in mins 
        //long diffHours = diffMs/(60*60*1000);    // difference in hours
        //long diffDays =  diffMs/(24*60*60*1000);  // difference in days
     
    	System.out.println(getDate());
    }
}
