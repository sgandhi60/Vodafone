package com.selfserv.ivr.selfservdao.central;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.selfserv.ivr.selfservdao.BaseDAO;

public class PUKDAO extends BaseDAO{
	private Connection conn = null;
	private CallableStatement cstmt = null;
	private final static Logger LOGGER = Logger.getLogger(PUKDAO.class);
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	private String logToken = null;
	private PUKXfer pukXfer = null;
	private String spPackageName = null;

	public PUKDAO(String jndiName, String cell, String cid, boolean bTestCall, String packageName) throws SQLException {
	// initialization
		mobile = cell;
		callid = cid;
		testCall = bTestCall;
		this.spPackageName = packageName;
		conn = getConnection(jndiName,mobile, cid);
		logToken = new StringBuffer("[").append(callid).append("] ").toString();
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered PUKDAO"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Connected to CDB"));
		}
	}

	public PUKXfer executeSP(String crcl_id, int coid) {
		pukXfer = new PUKXfer();
		
		try {
			/*ivr_pukcode(crcl_id IN VARCHAR2,
			 * 				 coid IN NUMBER,
			 *          ret_pukcd OUT VARCHAR2,
			 *            ret_msg OUT VARCHAR2);*/
			
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Invoking CDB SP IVR_PUKCODE with: circle: ")
						.append(crcl_id).append(" and coid: ").append(coid));

			if (conn!=null){
				String query = StoredProcedureQuery.getQuery(StoredProcedureQuery.IVR_PUKCODE, spPackageName);
				cstmt = conn.prepareCall(query);
				
				//Setting IN params: crcl_id, coid
				cstmt.setString(1,crcl_id);
				cstmt.setInt(2,coid);
				
				//registering OUT params:
				cstmt.registerOutParameter(3, Types.VARCHAR);	//ret_pukcd
				cstmt.registerOutParameter(4, Types.VARCHAR);	//ret_msg
				
				cstmt.execute();
				
				String puk = cstmt.getString(3);
				
				if (puk == null || puk.length() == 0) {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - No match found in the SP for CircleID= ").append(crcl_id)
								.append("and msisdn= ").append(mobile));
					pukXfer.setPuk(puk);
					pukXfer.setDBRC("F_NF");
					pukXfer.setDBMsg("No match found in the CDB");
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - Successful return of MPIN = ").append(puk));
					pukXfer.setPuk(puk);
					pukXfer.setDBRC("S");
				}

			}
		} catch (SQLException e) {
			String msg = e.getMessage();
            LOGGER.warn(new StringBuffer(logToken).append(" - Exception invoking CDB SP IVR_PUKCODE: ").append(msg));
            
            pukXfer.setDBRC("F_NF");
			pukXfer.setDBMsg(msg);
			e.printStackTrace();
		} finally{
			 releaseResource(conn, cstmt, null);		 
		}
		
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting PUKDAO"));
		return pukXfer;
	}
}