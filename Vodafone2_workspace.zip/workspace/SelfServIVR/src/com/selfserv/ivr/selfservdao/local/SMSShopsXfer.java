package com.selfserv.ivr.selfservdao.local;

public class SMSShopsXfer {
	private String DBRC = null;
	private int totalCenters = 0;
	private String smsMsgs [] = new String[3];
	public String getDBRC() {
		return DBRC;
	}
	public void setDBRC(String dbrc) {
		DBRC = dbrc;
	}

	
	public String getSmsMsg(int i) {
		return smsMsgs[i];
	}
	public void setSmsMsg(String smsMsg, int i) {
		this.smsMsgs[i] = smsMsg;
	}
	public String [] getSmsMsgs(){
		return this.smsMsgs;
	}
	public int getTotalCenters() {
		return totalCenters;
	}
	public void setTotalCenters(int totalCenters) {
		this.totalCenters = totalCenters;
	}
}