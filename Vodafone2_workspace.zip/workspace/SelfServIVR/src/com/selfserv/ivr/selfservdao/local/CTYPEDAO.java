package com.selfserv.ivr.selfservdao.local;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.selfserv.ivr.selfservdao.BaseDAO;

import org.apache.log4j.Logger;

public class CTYPEDAO extends BaseDAO{
	private static Logger LOGGER = Logger.getLogger(CTYPEDAO.class);
	private Connection conn = null;
	private CTYPEXfer ctypeXfer = null;
	private String mobile = null;
	private String callid = null;
	private boolean testCall = false;
	private String logToken = null;
	
	private final String SQL_QUERY_STMT = "Select MOBILE, PRGCODE, PRGNAME, CTYPE, GPRS_FLAG, VDN_CATEGORY, FLAG from TBL_CTYPE Where MOBILE = ?";
	private final String SQL_UPDATE_STMT = "Update TBL_CTYPE SET FLAG = \'N\' WHERE MOBILE = ?";
		
	public CTYPEDAO(String jndiName, String cell, String callID, boolean testCall) throws SQLException {
		mobile = cell;
		this.callid = callID;
		this.testCall = testCall;
		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
		conn = getConnection(jndiName, cell, callid);
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Connected to LDB ").append(jndiName));
	}

	public int insertRecord() {
		return 0;
	}

	public boolean deleteRecord() {
		return false;
	}
	
	public CTYPEXfer findRecord(String mobile) {
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entering CTYPEDAO::findRecord"));

		PreparedStatement stmt = null;
        ResultSet rs = null;
        ctypeXfer = new CTYPEXfer();
		try {
			stmt = conn.prepareStatement(SQL_QUERY_STMT);
		    
 			stmt.setString(1, mobile);
			rs = stmt.executeQuery();
			
			if (rs!=null){
				if (rs.next()){
					 String prgcode = rs.getString(2);			//PRGCODE
					 String prgname = rs.getString(3);			//PRGNAME
					 String ctype = rs.getString(4);			//CTYPE
					 String gprsFlag = rs.getString(5);			//GPRS_FLAG
					 String vdn_category = rs.getString(6);		//VDN_CATEGORY
					 String flag = rs.getString(7);				//FLAG
					 if (testCall) {
						 LOGGER.info(new StringBuffer(logToken).append(" - LDB TBL_CTYPE Record found!"));
						 LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(mobile));
						 LOGGER.debug(new StringBuffer(logToken).append(" - prgcode=").append(prgcode));
						 LOGGER.debug(new StringBuffer(logToken).append(" - prgname=").append(prgname));
						 LOGGER.debug(new StringBuffer(logToken).append(" - gprsFlag=").append(gprsFlag));
						 LOGGER.debug(new StringBuffer(logToken).append(" - ctype=").append(ctype));
						 LOGGER.debug(new StringBuffer(logToken).append(" - vdn_category=").append(vdn_category));
						 LOGGER.debug(new StringBuffer(logToken).append(" - firstTimeCaller=").append(flag));
					 }
					 
					 //update the first time caller flag
				     if (flag==null){
				    	 flag="N";
				    	 if (testCall) {
				    		 LOGGER.debug(new StringBuffer(logToken).append(" - firstTimeCaller was null and reset to N"));
				    	 }
				     }else{
				    	 if (flag.equals("Y")){							//first time caller
					         updateFirstTimeCaller(mobile, conn);		//update record to show that the caller is not first time caller any more
				    	 }
				     }
					 ctypeXfer.setCtype(ctype);
					 ctypeXfer.setGprs_Flag(gprsFlag);
					 ctypeXfer.setPgmname(prgname);
					 ctypeXfer.setPgmcode(prgcode);
					 ctypeXfer.setVdn_category(vdn_category);
					 ctypeXfer.setFirstTimeCaller(flag);
					 ctypeXfer.setCallerFound("Y");
				     ctypeXfer.setDBRC("S");
				 }else{
					 //empty result set
					 if (testCall) {
						 LOGGER.debug(new StringBuffer(logToken).append(" - No record found in LDB TBL_CTYPE"));
					 }
					 ctypeXfer.setCallerFound("N");					 
					 ctypeXfer.setDBRC("F_NF");
				 }
			}else{
				//no result set retrieved
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - No record found in LDB TBL_CTYPE"));
				}
				 ctypeXfer.setCallerFound("N");					 
				 ctypeXfer.setDBRC("F_NF");
			}
		} catch (SQLException e) {
			ctypeXfer.setDBRC("F_C");
			e.printStackTrace();
		} finally {
			releaseResource(conn, stmt, rs);
		}//end finally
		
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting CTYPEDAO::findRecord"));
		}
 		return ctypeXfer;
	}

	public int updateFirstTimeCaller(String mobile, Connection conn) {
        PreparedStatement update_stmt = null;
        int rc = 0;
		try {
			update_stmt = conn.prepareStatement(SQL_UPDATE_STMT);
	        update_stmt.setString(1,mobile);
	        rc = update_stmt.executeUpdate();
	        if (rc == 0){
	        	if (testCall) {
	        		LOGGER.debug(new StringBuffer(logToken).append(" - The first time caller status for customer mobile#=").append(mobile).append(" was not updated!"));
	        	}
	        } else {
		        if (testCall) {
		        	LOGGER.debug(new StringBuffer(logToken).append(" - The caller is not a first time caller anymore"));
		        }
	        }
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught trying to update the first time caller status: ").append(e.getMessage()));
			e.printStackTrace();
		} 
		finally {
			releaseResource(conn, update_stmt, null);
		}//end finally
		return rc;
	}
}