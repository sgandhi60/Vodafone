/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Move will move currencyVarB to currencyVarA
 * 
 *   Add, Subtract and Multiply will folloe the format
 * 
 *      currencyVarA = currencyVarB  '+' | '-' | '*' currencyVarC
 */
public class Skeleton extends HttpServlet implements Servlet{

	private static Logger LOGGER = Logger.getLogger(Skeleton.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering Skeleton"));

		// Get attributes from the session	
		String objectNameSample = (String) session.getAttribute("objectNameSample");

		// Log the sttributes
		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("objectNameSample = "+objectNameSample));
		}

		// Set session variable for reply
		session.setAttribute("objectNameSample", objectNameSample);

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Exiting Skeleton"));

		return;
	}


}
