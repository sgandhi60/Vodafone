package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.IVRMainDAO;
import com.selfserv.ivr.selfservdao.central.IVRMainXfer;
import com.selfserv.ivr.selfservdao.central.PUKDAO;
import com.selfserv.ivr.selfservdao.central.PUKXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;

/**
 * Servlet implementation class for Servlet: PUK
 *
 */
 public class PUK extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	 
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** This servlet retrieves the PUK (Personal Unlock Key) from the central DB 
	  * 	IN:  session.blockedNumber
	  * 	OUT: customer.pukNumber
	  * 	OUT: session.DBRC
	  * 
	  * The query to the CDB involves 2 SP: 
	  * 	ivr_main, and
	  * 	ivr_pukcode
	  * 
	  * If the query to the CDB fails, the message is added to the LDB in table TBL_RPT_ERROR
	  */
	
	private static Logger LOGGER = Logger.getLogger(PUK.class);
		
	public PUK() {
		super();
	}   	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Lookup CDB
		 HttpSession session = req.getSession(true);  // get session from Servlet request, created if not existed yet

		 Properties callProp = null;
		 Customer customer = null;
		 String circle = null;
		 String centralJNDIName = null;
		 String blockedNumber = null;
		 String reportJNDIName = null;
		 Circle circ = null;
		 		 
		 String callid = (String) session.getAttribute("callid");
		 
		 customer = (Customer)session.getAttribute("customer");
		 String mobile = customer.getMobile();

		 boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

			//create the log Token for later use, use StringBuffer to reduce number
			// of String objects
		 String logToken = new StringBuffer("[").append(callid).append("]").toString();

		 try{
			 
			 blockedNumber = (String) session.getAttribute("blockedNumber");
			 
			 circ = (Circle)session.getAttribute("circle");	
			 circle = circ.getCircle();								//0001, 0002, ....,0023
			 reportJNDIName = circ.getReportJNDIName();
			 
			 callProp = (Properties) session.getAttribute("callProp");
			 centralJNDIName = callProp.getProperty("centralJNDIName");
			 
			 if (testCall) {
//				 LOGGER.info(new StringBuffer(logToken).append(" - ***************************"));
				 LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered PUK Servlet"));
//				 LOGGER.info(new StringBuffer(logToken).append(" - ***************************"));
				 LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			 }
		 }catch(Exception e){
				LOGGER.error(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e));
		 }

		 
		 //if (backendDBAccess.equals("false")){											//******* DUMMY dbCType ****** No DB 
		 if (callProp.getProperty("dBhandlerPUK").equals("false")){		
		 	 customer.setPukNumber("123456");
			 session.setAttribute("customer", customer);
			 session.setAttribute("DBRC", "S");
		 }else{//Querying the DB's
			 
			 // Get the coid either from session.customer, or if not available, invoke IVR_MAIN stored procedure in the CDB
			 int coid = 0;
			 boolean setCustInfo = false;
			 boolean callMain = false;
			 if (mobile.equals(blockedNumber)) {
				 if (customer.isIvrMainCalled()) {
					 coid = Integer.parseInt(customer.getCoid());
					 if (testCall) {
						 LOGGER.debug(new StringBuffer(logToken).append(" - Got coid=").append(coid).append(" from session.customer"));
					 }
				 }else{
					 callMain = true;
					 setCustInfo = true;
				 }
			 } else {
				 setCustInfo = false;
				 callMain = true;
			 }
			 
			if (callMain) {
				 IVRMainXfer ivrMainXfer = null;
				 if (testCall) {
					 LOGGER.debug(new StringBuffer(logToken).append(" - Invoking CDB SP: IVR_MAIN"));
					 LOGGER.debug(new StringBuffer(logToken).append(" - coid is not cached in customer. Invoking IVR_MAIN"));
				 }
				 IVRMainDAO ivrMainDAO = new IVRMainDAO(centralJNDIName, callid, mobile, testCall, circ.getSpPackageName());
				 ivrMainXfer = ivrMainDAO.executeSP(circle,blockedNumber);  		//******* Query Stored Procedure IVR_Main
				 				 
				 //session.setAttribute("DBRC", "S");
				 coid = ivrMainXfer.getCoid();												// cache the coid in customer
				 if (setCustInfo) {
					 CustomerDetails.setCustomerDetails(customer, ivrMainXfer, null);
				 }
				 if (testCall) {
					 LOGGER.debug(new StringBuffer(logToken).append(" - Got coid=").append(coid).append(" from SP: IVR_MAIN"));
				 }
			}
			
			//Get the PUK from the CDB
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - invoking SP: ivr_pukcode"));
			}
			PUKDAO ivrPukDAO = null;
			try {
				ivrPukDAO = new PUKDAO(centralJNDIName,blockedNumber,callid, testCall, circ.getSpPackageName());
			} catch (SQLException sqle) {
	           session.setAttribute("DBRC", "F_NF");
	           LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB with SP IVR_PUKCODE: ").append(sqle.getMessage()));
	           sqle.printStackTrace();
	           return;
			}
			
			 PUKXfer pukXfer = ivrPukDAO.executeSP(circle, coid);
			 String dbrc = pukXfer.getDBRC();
			 
			 if (dbrc.equals("S")){
				 String puk =  pukXfer.getPuk();
				 customer.setPukNumber(puk);
				 session.setAttribute("customer", customer);
				 if (testCall) {
					 LOGGER.debug(new StringBuffer(logToken).append(" - set customer.puk= ").append(puk));
				 }
			 }else{
				 //enter exception in the TBL_RPT_ERROR table
				 ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				 int RC = rptErrorDAO.insertRecord(pukXfer.getDBMsg());
			 }
			 session.setAttribute("DBRC", dbrc);
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append(" - set session.DBRC=").append(session.getAttribute("DBRC")));
			 }
		 }
		 if (testCall)
			 LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting PUK Servlet"));
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}   	  	    
}