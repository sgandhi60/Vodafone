/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.misc.PaymentInfoDAO;
import com.selfserv.ivr.selfservdao.misc.PaymentInfoReq;
import com.selfserv.ivr.selfservdao.misc.PaymentInfoResp;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class PaymentGateway extends HttpServlet implements Servlet{

	private static Logger LOGGER = Logger.getLogger(PaymentGateway.class);


	public PaymentGateway() {
		super();
	}   	


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();


		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering PaymentGateway Servlet"));

		Properties callProp = null;			// properties key-value pair
		String localJNDIName = null;			// JNDI name for Local DB
		String reportJNDIName = null;			// JNDI name for Report DB
		Customer customer = null;
		Circle circ = null;
		String circle = null;					// Circle Id 0001.....0023
		String circleName = null;				// Circle name Mumbai...
		String mobile = null;					// mobile number
		String cust_id = null;					// Cust_Id
		String ccNumber = null;					// credit card #
		String cvvNumber = null;				// credit card verification code
		String ccExpDate = null;				// credit card exp date
		String ccAmount = null;					// credit card amount
		int iCCAmount = 0;						// credit card amount as int
		String ccTranType = null;				// P for Payment, D for Deposit
		String refNumber = null;				// payment reference number
		String dbrc = null;
		int RC = -1;

		try{
			customer = (Customer) session.getAttribute("customer");
			if (customer != null) {
				mobile = customer.getMobile();
				cust_id = customer.getCust_id();
			}

			if (session != null) {
				callProp = (Properties) session.getAttribute("callProp");

				ccNumber = (String) session.getAttribute("ccNumberEntered");
				cvvNumber = (String) session.getAttribute("cvvNumberEntered");
				ccExpDate = (String) session.getAttribute("ccExpDateEntered");
				ccTranType = (String) session.getAttribute("ccTranType");
				ccAmount = (String) session.getAttribute("ccAmountEntered");
				
				if ( (ccAmount != null) && (ccAmount.length()!= 0) ) {
					int index = ccAmount.indexOf(".");
					if (index != -1) {
						ccAmount = ccAmount.substring(0, index);
					}
					iCCAmount = Integer.parseInt(ccAmount);
				} else {
					iCCAmount = 0;
				}

				circ = (Circle) session.getAttribute("circle");
			}

			if (circ != null) {
				circle = circ.getCircle();
				circleName = circ.getCircleName();

				localJNDIName = circ.getLocalJNDIName();
				reportJNDIName = circ.getReportJNDIName();
			}
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - Cust_id: ").append(cust_id));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle Name: ").append(circleName));
//			LOGGER.debug(new StringBuffer(logToken).append(" - ccNumber: ").append(ccNumber));
//			LOGGER.debug(new StringBuffer(logToken).append(" - cvvNumber: ").append(cvvNumber));
//			LOGGER.debug(new StringBuffer(logToken).append(" - ccExpDate: ").append(ccExpDate));
			LOGGER.debug(new StringBuffer(logToken).append(" - ccAmount: ").append(ccAmount));
			LOGGER.debug(new StringBuffer(logToken).append(" - ccTranType: ").append(ccTranType));
		}

		if (callProp.getProperty("dBhandlerPaymentGateway").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerPaymentGateway=false => using No backend"));

			customer.setPaygateRefNumber("11223344");

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerPaymentGateway=true =>Attempting to retrieve Payment Reference #"));

			PaymentInfoReq paymentInfo = null;
			PaymentInfoResp pymntResp = null;
			PaymentInfoDAO paymentDao = null;
			String url = null;
			String cTimeout = null;
			String sTimeout = null;

			try {
				// prepare req object
				paymentInfo = new PaymentInfoReq();

				if (paymentInfo != null) {
					paymentInfo.setCustomerID(cust_id);
					paymentInfo.setCircleName(circleName);
					paymentInfo.setCircleCode(circle);
					paymentInfo.setAmount(iCCAmount);
					paymentInfo.setCardNumber(ccNumber);
					paymentInfo.setExpiryDate(ccExpDate);
					paymentInfo.setCvvNumber(cvvNumber);
					paymentInfo.setMobileNumber(mobile);
					paymentInfo.setPaymentType(ccTranType);
				}

				// get configurable fields from global.properties
				Properties globalProp = (Properties) session.getServletContext().getAttribute("globalProp");
				if ( globalProp != null ) {
					url = (String) globalProp.getProperty("pymtgtwy.url");
					cTimeout = (String) globalProp.getProperty("pymtgtwy.ConnectionTimeout");
					sTimeout = (String) globalProp.getProperty("pymtgtwy.SocketTimeout");
				}

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Payment Gateway URL:").append(url));
					LOGGER.debug(new StringBuffer(logToken).append(" - Payment Gateway ConnectionTimeout: ").append(cTimeout));
					LOGGER.debug(new StringBuffer(logToken).append(" - Payment Gateway SocketTimeout: ").append(sTimeout));
				}
				
				paymentDao = new PaymentInfoDAO(reportJNDIName, mobile, callid, url, cTimeout, sTimeout, testCall);
//				} catch (SQLException sqle) {
			} catch (Exception e) {
				dbrc = "F_C";
				session.setAttribute("DBRC",dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to Payment Gateway: ").append(e.getMessage()));
				e.printStackTrace();
				return;
			}

			try {
				pymntResp = paymentDao.makePayment(paymentInfo);
				String flag = pymntResp.getResponseFlag();
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" - Response Flag = ").append(flag));

				if (flag.equals("S")){
					dbrc = "S";
					refNumber = pymntResp.getReferenceNumber();
					if (testCall)
						LOGGER.info(new StringBuffer(logToken).append(" - refNumber = ").append(refNumber));
					customer.setPaygateRefNumber(refNumber);

					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" PaymentRefNumber retrieved successfully - PaymentRefNumber: ").append(refNumber));
				} else if (flag.equals("T")){
					dbrc = "F_TO";
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Timeout occured while retrieving PaymentRefNumber - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(pymntResp.getResponse());
				} else {
					dbrc = "F_NA";
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving PaymentRefNumber - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(pymntResp.getResponse());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" PaymentRefNumber NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Payment gateway Ref #: ").append(customer.getPaygateRefNumber()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting PaymentGateway"));
		}


		return;
	}


}
