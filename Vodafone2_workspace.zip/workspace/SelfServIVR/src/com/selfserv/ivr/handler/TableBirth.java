/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.TableBirthDAO;
import com.selfserv.ivr.selfservdao.local.TableBirthXfer;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class TableBirth extends HttpServlet implements Servlet{
	
	private static Logger LOGGER = Logger.getLogger(TableBirth.class);

	
 	public TableBirth() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering TableBirth"));

		Properties callProp = null;			// properties key-value pair
		Circle circ = null;
		String flag = null;
		
		String mobile = null;					// mobile number
		Customer customer = null;
		TableBirthXfer tblBirthXfer = null;
		TableBirthDAO tblBirthDAO = null;
		String dbrc = null;
		String localJNDIName = null;			// JNDI name for Local DB
		String reportJNDIName = null;			// JNDI name for Local DB
		int RC = -1;


		try{
			customer = (Customer)session.getAttribute("customer");
			if (customer != null) {
				mobile = (String) customer.getMobile();
			}
			
			if (session != null) {
				callProp = (Properties) session.getAttribute("callProp");
				circ = (Circle) session.getAttribute("circle");
			}
			
			if (circ != null) {
				localJNDIName = circ.getLocalJNDIName();
				reportJNDIName = circ.getReportJNDIName();
			}

		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
		}

		if (callProp.getProperty("dBhandlerTableBirth").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerTableBirth=false => using No backend"));

			customer.setPlayedBirthMsgFlag("Y");

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerTableBirth=true => Attempting to retrieve flag"));

			try {
				tblBirthDAO = new TableBirthDAO(localJNDIName, mobile, callid, testCall);
			} catch (SQLException sqle) {
				session.setAttribute("DBRC", "F_C");
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_BIRTH: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				tblBirthXfer = tblBirthDAO.findRecord(mobile);
				dbrc = tblBirthXfer.getDBRC();

				if (dbrc.equals("S")){ 
					flag = tblBirthXfer.getFlag();
					customer.setPlayedBirthMsgFlag(flag);		

					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" Record Exists - PlayedBirthMsgFlag retrieved successfully - PlayedBirthMsgFlag: ").append(flag));
					
					if (flag.equals("N")) {
						tblBirthXfer = tblBirthDAO.updateRecord(mobile, "Y");
						dbrc = tblBirthXfer.getDBRC();
						customer.setPlayedBirthMsgFlag("N");		

						if (dbrc.equals("S")){
							if (testCall) 
								LOGGER.debug(new StringBuffer(logToken).append(" PlayedBirthMsgFlag updated successfully"));
						} else {
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(" Error while updating record in TBL_BIRTH for mobile= ").append(mobile));

							//enter exception in the TBL_RPT_ERROR table
							ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
							RC = rptErrorDAO.insertRecord(tblBirthXfer.getDBMsg());
						}
					}
					
//				} else if (dbrc.equals("F_NF")){
				} else {

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" No Record found in TBL_BIRTH for mobile= ").append(mobile).append(" - Insert new record"));

					tblBirthXfer = tblBirthDAO.insertRecord(mobile, "Y");
					dbrc = tblBirthXfer.getDBRC();
					customer.setPlayedBirthMsgFlag("N");		
					if (dbrc.equals("S")){
						if (testCall) 
							LOGGER.debug(new StringBuffer(logToken).append(" PlayedBirthMsgFlag inserted successfully"));
					} else {
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" Error while inserting record in TBL_BIRTH for mobile= ").append(mobile));

						//enter exception in the TBL_RPT_ERROR table
						ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
						RC = rptErrorDAO.insertRecord(tblBirthXfer.getDBMsg());
					}
				}
			} catch (Exception e) {
				dbrc = "F_C";
				customer.setPlayedBirthMsgFlag("N");		
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" PlayedBirthMsgFlag NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
			session.setAttribute("DBRC", dbrc);
			session.setAttribute("customer", customer);

		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - PlayedBirthMsgFlag: ").append(customer.getPlayedBirthMsgFlag()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting TableBirth"));
		}


		return;
	}

 
}
