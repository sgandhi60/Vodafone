/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.selfserv.ivr.data.Customer;
/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Function:
 *            Using Billing Cycle date from Customer Class  (customer.getBillBillingCycle)
 *            determine the current and previous month to be offered to the caller.
 *            
 *            
 *   Inputs:
 *            This handler will used the following session variables:
 *            
 *                customer.getBillBillingCycle()  day date billing cycle value.  Ex: 18 = 18th of the month
 *                
 *   Outputs:
 *            This handler will set the following session variables:
 *            
 *                   curMonth  =  Current Month/Day - 10 days
 *                   lstMonth  =  Current Month - 1 month
 *         
 * 
 */
public class DupBillMonth extends HttpServlet implements Servlet{
	
	private static final long serialVersionUID = 1L;
	
	private static Logger LOGGER = Logger.getLogger(DupBillMonth.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering DupBillMonth"));

		// Get Customer Class from Session
		Customer customer = (Customer) session.getAttribute("customer");

		// Translate the month to send for the handlers.   
		String[] monthConvert = new String[] { "", "JAN", "FEB", "MAR", "SPR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
		// Output variable(s)
		Date tdy = new Date();		
		Calendar cal = Calendar.getInstance();		
		cal.setTime(tdy);
		String curMonth = null;
		String lstMonth = null;	
		int monthNow;

		// Make the 10 day adjustment and adjust month for easier calculations
		cal.add(Calendar.DAY_OF_MONTH, - 10); 

		// Get years for the months to announce
		// The years may be adjusted backwards when business logic is applied
		int intCurMonthYear = cal.get(Calendar.YEAR);
		int intLstMonthYear = intCurMonthYear;

		monthNow = cal.get(Calendar.MONTH)+1;


		//  Adjust month values to play 
		if (cal.get(Calendar.DAY_OF_MONTH) >= Integer.parseInt(customer.getBillBillingCycle())){

			curMonth = String.valueOf(monthNow);

			if (monthNow == 1){
				lstMonth = String.valueOf(12);
				intLstMonthYear--;
			}
			else
				lstMonth = String.valueOf(monthNow - 1);
		}else{	
			if (monthNow == 1){
				curMonth = String.valueOf(12);
				intCurMonthYear--;
				lstMonth = String.valueOf(11);
				intLstMonthYear--;
			}else{
				curMonth = String.valueOf(monthNow - 1);
				if (monthNow == 2){
					lstMonth = String.valueOf(12);
					intLstMonthYear--;
				}
				else
					lstMonth = String.valueOf(monthNow - 2);
			}
		}

		String strCurMonthYear = String.valueOf(intCurMonthYear);
		String strLstMonthYear = String.valueOf(intLstMonthYear);

		// Set session variable for reply
		session.setAttribute("curMonth", curMonth);
		session.setAttribute("lstMonth", lstMonth);
		session.setAttribute("curMonthText", monthConvert[Integer.valueOf(curMonth)]);
		session.setAttribute("lstMonthText", monthConvert[Integer.valueOf(lstMonth)]);
		session.setAttribute("strCurMonthYear", strCurMonthYear);
		session.setAttribute("strLstMonthYear", strLstMonthYear);

		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("cal.getTime() = "+cal.getTime()));
			LOGGER.debug(new StringBuffer(logToken).append("monthNow = "+monthNow));
			LOGGER.debug(new StringBuffer(logToken).append("curMonth = "+curMonth));
			LOGGER.debug(new StringBuffer(logToken).append("strCurMonthYear = "+strCurMonthYear));
			LOGGER.debug(new StringBuffer(logToken).append("lstMonth = "+lstMonth));
			LOGGER.debug(new StringBuffer(logToken).append("strLstMonthYear = "+strLstMonthYear));
			LOGGER.info(new StringBuffer(logToken).append("Exiting DupBillMonth"));
		}

		return;
	}
	

}
