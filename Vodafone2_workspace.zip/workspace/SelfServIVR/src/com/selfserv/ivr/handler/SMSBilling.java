/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.data.HandlerHelper;
import com.selfserv.ivr.selfservdao.local.LogreqDAO;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.TableBillPymtDAO;
import com.selfserv.ivr.selfservdao.local.TableBillPymtXfer;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class SMSBilling extends HttpServlet implements Servlet{
	
	private static Logger LOGGER = Logger.getLogger(SMSBilling.class);

	
 	public SMSBilling() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering SMSBilling"));

		Properties callProp = null;			// properties key-value pair
		String localJNDIName = null;			// JNDI name for Local DB
		String reportJNDIName = null;			// JNDI name for Replace DB
		Customer customer = null;
		Circle circ = null;
		String mobile = null;					// mobile number
		String smsPinCode = null;			
		String dbrc = null;
		int RC = -1;
		String smsMsgs = null;
		String pymtPhrase = null;
		int totalCenters = 0;
		TableBillPymtXfer tblBillPymtXfer = null;
		HandlerHelper helper = null;
		
		
		try{
			customer = (Customer)session.getAttribute("customer");

			mobile = customer.getMobile();

			callProp = (Properties) session.getAttribute("callProp");
			smsPinCode = (String) session.getAttribute("smsPin");
			circ = (Circle) session.getAttribute("circle");

			localJNDIName = circ.getLocalJNDIName();
			reportJNDIName = circ.getReportJNDIName();
			
			// instantiate helper class object and initialize it
			helper = new HandlerHelper();
			
			if (helper != null) {
				helper.setCallid(callid);
				helper.setLocalJNDIName(localJNDIName);
				helper.setReportJNDIName(reportJNDIName);
				helper.setLogToken(logToken);
				helper.setMobile(mobile);
				helper.setSession(session);
				helper.setTestCall(testCall);
		}
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - SMSPin: ").append(smsPinCode));
		}

		if (callProp.getProperty("dBhandlerSMSBilling").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerSMSBilling=false => using No backend"));

			customer.setPymtphrase("0000");

			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerSMSBilling=true => Attempting to perform TBL_BILPYMT"));

			TableBillPymtDAO tblBillPymtDAO = null;
			StringTokenizer st = null; 
			String msg = null;

			try {
				tblBillPymtDAO = new TableBillPymtDAO(localJNDIName, mobile, callid, testCall);
			} catch (SQLException sqle) {
				session.setAttribute("DBRC", "F_C");
				msg = sqle.getMessage();
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_OPTALD: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				tblBillPymtXfer = tblBillPymtDAO.findRecord(smsPinCode);
				dbrc = tblBillPymtXfer.getDBRC();

				if (dbrc.equals("S")){
					smsMsgs = tblBillPymtXfer.getSmsMessages();
					pymtPhrase = tblBillPymtXfer.getPymtPhrase();
					totalCenters = tblBillPymtXfer.getCenters();
					
					if (smsMsgs != null) {
						st = new StringTokenizer(smsMsgs, ",");
						if (st != null) {
							if (st.countTokens() != totalCenters) {
								dbrc = "F_C";
								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(" # of SMS Msgs does not match with Total # of Centers: - Add entry into Error table - ")
											.append(" SMS Msgs=").append(smsMsgs)
											.append("# of SMS Messages=").append(st.countTokens())
											.append(" Total Centers: ").append(totalCenters));
								
								//enter exception in the TBL_RPT_ERROR table
								ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
								RC = rptErrorDAO.insertRecord(" # of SMS Msgs does not match with Total # of Centers - SMS Msgs=" + smsMsgs + " Total Centers: " + totalCenters);
							} else {
								customer.setPymtphrase(pymtPhrase);
								
								// insert SMS msg into TBL_LOGREQ
								insertSMSRecord(helper, smsMsgs, totalCenters);
								
								if (testCall) 
									LOGGER.debug(new StringBuffer(logToken).append(" TBL_BILPYMT processed successfully - ")
											.append(" SMS Msgs=").append(smsMsgs).append(" Total Centers: ").append(totalCenters));
							} // st.countTokens
						} else {
							dbrc = "F_C";
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(" SMSMsgs is NULL. Invalid SMS Msgs - Add entry into Error table - ")
										.append(" SMS Msgs=").append(smsMsgs)
										.append(" # of SMS Messages=").append(st.countTokens())
										.append(" Total Centers: ").append(totalCenters));
							
							//enter exception in the TBL_RPT_ERROR table
							ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
							RC = rptErrorDAO.insertRecord(" SMSMsgs is NULL. Invalid SMS Msgs - SMS Msgs=" + smsMsgs);
						}// st != null
					} else {
						dbrc = "F_C";
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" SMSMsgs is NULL. Invalid SMS Msgs - Add entry into Error table - ")
									.append(" SMS Msgs=").append(smsMsgs)
									.append(" # of SMS Messages=").append(st.countTokens())
									.append(" Total Centers: ").append(totalCenters));
						
						//enter exception in the TBL_RPT_ERROR table
						ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
						RC = rptErrorDAO.insertRecord(" SMSMsgs is NULL. Invalid SMS Msgs - SMS Msgs=" + smsMsgs);
					} //smsMsgs != null
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving SMSMsgs from DB - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(tblBillPymtXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" SMSMsgs NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
			session.setAttribute("DBRC", dbrc);
			session.setAttribute("customer", customer);
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer :"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Payment Phrase: ").append(customer.getPymtphrase()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.debug(new StringBuffer(logToken).append(" - SMSCount: ").append(customer.getSmsCount()));
			LOGGER.info(new StringBuffer(logToken).append("Exiting SMSBilling"));
		}


		return;
	}

	private void insertSMSRecord(HandlerHelper smsBillingHelper, String msgs, int centers) {

		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String localJNDIName = null;
		String reportJNDIName = null;

		if (smsBillingHelper != null) {
			logToken = smsBillingHelper.getLogToken();
			testCall = smsBillingHelper.isTestCall();
			session = smsBillingHelper.getSession();
			mobile = smsBillingHelper.getMobile();
			callid = smsBillingHelper.getCallid();
			localJNDIName = smsBillingHelper.getLocalJNDIName();
			reportJNDIName = smsBillingHelper.getReportJNDIName();
		}
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entered SMSBilling:insertSMSRecord() - Attempting to insert record"));

		String dbrc = null;
		int RC = -1;


		Customer customer = (Customer) session.getAttribute("customer");

		String prgcode = customer.getPrgcode();
		String custCode = customer.getCustCode();
		String coid = customer.getCoid();
		String landline = customer.getLandlineNumber();
		String trantype = (String) session.getAttribute("smsTranType");

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - SMSBilling:insertSMSRecord() - Got all attributes from the session and customer"));
			LOGGER.debug(new StringBuffer(logToken).append(" - prgcode: ").append(prgcode));
			LOGGER.debug(new StringBuffer(logToken).append(" - custCode#: ").append(custCode));
			LOGGER.debug(new StringBuffer(logToken).append(" - coid: ").append(coid));
			LOGGER.debug(new StringBuffer(logToken).append(" - landline: ").append(landline));
			LOGGER.debug(new StringBuffer(logToken).append(" - trantype: ").append(trantype));
		}

		LogreqDAO logreqDAO = null;
		StringTokenizer stSMS = new StringTokenizer(msgs, ",");
		String [] smsToken = new String[stSMS.countTokens()];
		int j=0;
		while (stSMS.hasMoreElements()) {
			smsToken[j++] = stSMS.nextToken().trim();
		}

		//insert record in TBL_LOGREQ		
		try {
			logreqDAO = new LogreqDAO(reportJNDIName, mobile, callid, testCall);
		} catch (SQLException sqle) {
			dbrc = "F_C";
			session.setAttribute("DBRC", dbrc);
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to TBL_LOGREQ: ").append(sqle.getMessage()));
			sqle.printStackTrace();
			return;
		}

		try {
			int rc = 0;
			int i=0;
			for (i=0; i < centers; i++) {
				rc = logreqDAO.insertRecord(landline, prgcode, trantype, smsToken[i], custCode, coid);
			}
			if (rc > 0) { //at lease one SMS message was inserted in the DB
				dbrc = "S";
				//update smsCounter by # of SMS messages sent
				int totalSMSs = customer.getSmsCount();
				totalSMSs += centers;
				customer.setSmsCount(totalSMSs);
				
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(i).append(" Record(s) successfully inserted in TBL_LOGREQ "));
			} else {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Error inserting record in TBL_LOGREQ - Add entry into Error table"));

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord("Error inserting record in TBL_LOGREQ");
			}
		} catch (Exception e) {
			dbrc = "F_C";
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" Exception inserting record in TBL_LOGREQ - Add entry into Error table - ").append(e.getMessage()));
			e.printStackTrace();

			//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			RC = rptErrorDAO.insertRecord(e.getMessage());
		}

		session.setAttribute("DBRC", dbrc);	
		session.setAttribute("customer", customer);

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.debug(new StringBuffer(logToken).append(" - SMSCount: ").append(customer.getSmsCount()));
			
			LOGGER.debug(new StringBuffer(logToken).append("exiting SMSBilling:insertSMSRecord() "));
		}
		return;

	} //insertSMSRecord


}
