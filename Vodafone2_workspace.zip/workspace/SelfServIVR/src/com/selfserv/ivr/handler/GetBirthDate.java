/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;

import com.selfserv.ivr.selfservdao.central.IVRCallDetailsDAO;
import com.selfserv.ivr.selfservdao.central.IVRCallDetailsXfer;
import com.selfserv.ivr.selfservdao.central.IVRMainDAO;
import com.selfserv.ivr.selfservdao.central.IVRMainXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.TableGenDAO;
import com.selfserv.ivr.selfservdao.local.TableGenXfer;
import com.selfserv.ivr.selfservdao.local.TableSeriesDAO;
import com.selfserv.ivr.selfservdao.local.TableSeriesXfer;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class GetBirthDate extends HttpServlet implements Servlet{
	
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(GetBirthDate.class);
	
 	public GetBirthDate() {
		super();
	}   	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	                                      throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		// create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering GetBirthDate handler"));

		Properties callProp = null; // properties key-value pair
		Customer customer = null;
		Circle circ = null;
		String localJNDIName = null; // JNDI name for Local DB
		String centralJNDIName = null;		// JNDI name for Central DB
		String mobile = null;
		String birthFlag = null;
		TableSeriesXfer tableSeriesXfer = null;
		String dbrc = null;
		String birthDate = null;
		TableGenXfer tableGenXfer = null;
		String circle = null;
		
		try {
			customer = (Customer) session.getAttribute("customer");

			mobile = (String) customer.getMobile();
			callProp = (Properties) session.getAttribute("callProp");
			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			localJNDIName = circ.getLocalJNDIName();
			centralJNDIName = callProp.getProperty("centralJNDIName");

		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
		}

		if (callProp.getProperty("dBhandlerGetBirthDate").equals("false")) {// No DB ****** DUMMY barred flag ******
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetBirthDate=false => using No backend"));
			}

			customer.setBirthFlag("N");
			customer.setBirthDate(null);
			customer.setTableSeriesCalled(true);

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetBirthDate=true => Attempting to retrieve birthflag"));
			}

			if (customer.isTableSeriesCalled()) {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Table Series already called; no table lookup"));
				}
				dbrc = "S";
			} else {
				try {
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Table Series not called before; performing table lookup"));
					}
					TableSeriesDAO tableSeriesDAO = new TableSeriesDAO(circ.getLocalJNDIName(), mobile, callid, testCall);
					tableSeriesXfer = tableSeriesDAO.findRecord(mobile);
					dbrc = tableSeriesXfer.getDBRC();
					if (dbrc.equals("S")){
						customer.setInroamerFlag(tableSeriesXfer.getInroamerFlag());
						customer.setBirthFlag(tableSeriesXfer.getBirthFlag());
						customer.setTableSeriesCalled(true);
						if (tableSeriesXfer.getInroamerFlag().equalsIgnoreCase("Y")) {
							circ.setCircle(tableSeriesXfer.getCircleCode());
						}
					}
				} catch (SQLException e) {
					LOGGER.warn(new StringBuffer(logToken).append(" - Exception caught attempting to instantiate tableSeriesDAO. ").append(e.getMessage()));
					dbrc = "F_C";
				}
			}
			birthFlag = customer.getBirthFlag();
			if (dbrc.equals("S") && birthFlag.equalsIgnoreCase("Y")) {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append("Retrieving BirthDate"));
				}
				
				if (customer.isIvrCallDetailsCalled()) {
					dbrc = "S";
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append("IVR_CALL_DETAILS already called; retrieving from customer record"));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append("IVR_CALL_DETAILS not called; getting from TBL_GEN"));
				
					if (customer.isTableGenCalled()) {
						dbrc = "S";
						if (testCall) 
							LOGGER.debug(new StringBuffer(logToken).append(" TableGenDAO already called; not executing again."));
					} else {

						TableGenDAO tblGenDAO = null;
						try {
							tblGenDAO = new TableGenDAO(localJNDIName, mobile, callid, testCall);
						} catch (SQLException sqle) {
							dbrc = "F_C";
							session.setAttribute("DBRC", dbrc);
							LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to instantiate tableGenDAO. ").append(sqle.getMessage()));
						}
						if (dbrc.equals("S")) {
							try { // retrieve birthdate for this mobile #
								tableGenXfer = tblGenDAO.findRecord(mobile);
								dbrc = tableGenXfer.getDBRC();
								
								if (dbrc.equals("S")){
									String pinCode = tableGenXfer.getPinCode();

									customer.setBillBillEmail(tableGenXfer.getEmail());
									if (pinCode != null) {
										customer.setBillBillZipCode(pinCode.substring(0, 6));
									} else {
										customer.setBillBillZipCode(null);
									}

									customer.setTitle(tableGenXfer.getTitle());
									customer.setFirstName(tableGenXfer.getFname());
									customer.setLastName(tableGenXfer.getLname());
									customer.setAddress1(tableGenXfer.getAddr1());
									customer.setAddress2(tableGenXfer.getAddr2());
									customer.setAddress3(tableGenXfer.getAddr3());
									customer.setCity(tableGenXfer.getCity());
									
//									customer.setPrgcode(tableGenXfer.getPrgcode());
									customer.setCustCode(tableGenXfer.getCustcode());
									customer.setCoid(tableGenXfer.getCoid());

									String bDate = null;
									SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
									if (tableGenXfer.getBirthDate() != null) {
										birthDate = formatter.format(tableGenXfer.getBirthDate());
									}
									customer.setBirthDate(bDate);			
									
									customer.setTableGenCalled(true);
									
									if (testCall)
										LOGGER.debug(new StringBuffer(logToken).append(" - BirthDate retrieved successfully - BirthDate: ").append(birthDate));
									
								} else {
									if (testCall)
										LOGGER.debug(new StringBuffer(logToken).append(" - No record found in TBL_GEN for mobile number: ").append(mobile));
								}
							} catch (Exception e) {
								dbrc = "F_C";
								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(" - BirthDate NOT retrieved from DB - Add entry into Error table").append(e.getMessage()));
								e.printStackTrace();
							}
						}
					} // else
				} // else
			} else {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" No need to retrieve BirthDate"));
			}

			session.setAttribute("DBRC", dbrc);
			session.setAttribute("customer", customer);
			session.setAttribute("circle", circ);
		}// else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - BirthDate: ").append(customer.getBirthDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - BirthFlag: ").append(customer.getBirthFlag()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting GetBirthDate"));
		}


		return;
	}


}
