package com.selfserv.ivr.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.IVRCallDetailsXfer;
import com.selfserv.ivr.selfservdao.central.IVRMainXfer;

public class CustomerDetails {
	
	static void setCustomerDetails(Customer customer, IVRMainXfer ivrMainXfer, IVRCallDetailsXfer callDetailsXfer) {
		
		String paymentDate = null;
		String lastPymtDate = null;
		String paymentAmt = null;
		String dueDate = null;
		String birthDate = null;
		float lastPymtAmt = 0;

		if (ivrMainXfer != null) {
			customer.setCoid(Integer.toString(ivrMainXfer.getCoid()));
			customer.setCust_id(Integer.toString(ivrMainXfer.getCust_id()));
		}
		if (callDetailsXfer != null) {
			customer.setCustCode(callDetailsXfer.getCust_code());
			customer.setPrgcode(callDetailsXfer.getPgcode());
			customer.setPrgname(callDetailsXfer.getPgname());
			
			SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
			SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MMM-yyyy");
			if (callDetailsXfer.getRet_dueDate() != null) {
				dueDate = formatter.format(callDetailsXfer.getRet_dueDate());
			}
	
			String paymentsWithDate = callDetailsXfer.getRet_payments();
			if (paymentsWithDate != null) {
				int index = paymentsWithDate.indexOf("|");
				if (index != -1) {
					paymentDate = paymentsWithDate.substring(0, index);
					try {
						java.util.Date lastPymtDt = formatter2.parse(paymentDate);
						lastPymtDate = formatter.format(lastPymtDt);
						paymentAmt = paymentsWithDate.substring(index +1);
						lastPymtAmt = new Float(paymentAmt).floatValue();
					}
					catch (ParseException e) {
						lastPymtDate = null;
						lastPymtAmt = 0;
					}
				}
			}
			
			customer.setBillCurrentOutstandingAmt(callDetailsXfer.getBalance());
			customer.setBillPayableByDate(dueDate);
			customer.setBillUnbilledAmt(callDetailsXfer.getRet_unBilliedAmount());
			customer.setBillLastPaymentAmt(lastPymtAmt);
			customer.setBillLastPaymentDate(lastPymtDate);
			customer.setBillCreditLimitAmt(callDetailsXfer.getCreditLimit());
			customer.setBillDepositRequiredAmt(callDetailsXfer.getRet_deposit());
			customer.setBillBillingCycle(callDetailsXfer.getBCycle());
			customer.setBillBillEmail(callDetailsXfer.getEmail());
			
			if (callDetailsXfer.getZipCode() != null) {
				customer.setBillBillZipCode(callDetailsXfer.getZipCode().substring(0,6));		
			} else {
				customer.setBillBillZipCode(null);		
			}
	
			customer.setCustCode(callDetailsXfer.getCust_code());
			
			if (callDetailsXfer.getBirthDate() != null) {
				birthDate = formatter.format(callDetailsXfer.getBirthDate());
//				customer.setBirthDate(Long.toString(callDetailsXfer.getBirthDate().getTime()));
				customer.setBirthDate(birthDate);
			} else {
				customer.setBirthDate(null);
			}
			
			customer.setPrgcode(callDetailsXfer.getPgcode());
			customer.setPrgname(callDetailsXfer.getPgname());
		}
		
	}

}
