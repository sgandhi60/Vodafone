/*
 * Created on une 27, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.DBXfer;
import com.selfserv.ivr.selfservdao.local.ReportAccessCountDAO;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.ReportMainDAO;

/**
 * @author fangwang
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class CleanupHandler extends HttpServlet implements Servlet{
	
	private static Logger LOGGER = Logger.getLogger(CleanupHandler.class);

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		// Get customer 
		Customer customer = (Customer) session.getAttribute("customer");

		// Get Complaint Call Flag
		String complaintCall = (String) session.getAttribute("complaintCall");

		// Get attributes from the session
		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering CleanupHandler"));

		// Get the menuMainMap property information
		Properties mainMenuMap = (Properties) session.getServletContext().getAttribute("mainMenuMap");	
		// Get the menuMainMap property information
		Properties menuMap = (Properties) session.getServletContext().getAttribute("menuMap");

		// Get Call FootPrint
		String footPrint = null;
		/*	if (testCall){
		footPrint = "Welcome->StartHere:->CheckCliRc:->10000_CheckTypeABC:->10000_CheckCTypeRc:->10000_CheckCType:->20036_PrePaidMainMenuLanguage:->ToContinueInChoice:2d->ToContinueInSetLang:->ToContinueInSetAudioLang:->20036_CheckIfFirstTimeCaller:->20036_PrePaidMainMenu_Promo:->CheckForQueryComplaintMenu:->PrePaidComplaintMenu:1d->20036_PrePaidMainMenu:5d->20048_PrePaidPUKSIMlossLang:2d->20049_PrePaidPUK:->55000_PUKStart:->55000_EntrerMobileNumber:9544281351d->55000_EnterMobileNumberConfirm:1d->55000_CheckPUKRc:->55000_PUKLookupResult:9d->90000_CCEStart:->90000_CCECheckBarredRc:->90000_CCECheckBarredCount:->90000_CCECheckForCharge:->90000_CCECharge:2d->MainMenuSelect:->20036_PrePaidMainMenu:2d->20041_PrePaidVAS:1d->20041_PrePaidVAS_CallerTunes_Promo:->20041_PrePaidVAS_CallerTunes:*d->MainMenuSelect:->20036_PrePaidMainMenu:1d->20037_PrePaidBalanceAndRecharge_Promo:->20037_PrePaidBalanceAndRecharge:->HUP";
		//footPrint = "Welcome->StartHere:->CheckCliRc:->50000_LandLineStart:->ToContinueInChoice:1d->ToContinueInSetLang:->ToContinueInSetAudioLang:->50000_AreYouCust:1d->50000_EntrerMobileNumber:9544281351d->50000_EnterMobileNumberConfirm:1d->50000_CheckSeriesRc:->50000_CheckCTypeRc:->50000_SetLandLineNumber:->SetOptionFlag:->50000_CheckCType:->51000_LLPrePaidMainMenu:*d->MainMenuSelect:->50000_LandLineStart:->ToContinueInChoice:1d->ToContinueInSetLang:->ToContinueInSetAudioLang:->50000_AreYouCust:1d->50000_EntrerMobileNumber:9544281351d->50000_EnterMobileNumberConfirm:1d->50000_CheckSeriesRc:->50000_CheckCTypeRc:->50000_SetLandLineNumber:->SetOptionFlag:->50000_CheckCType:->51000_LLPrePaidMainMenu:2d->55000_PUKStart:->55000_EntrerMobileNumber:1234567890d->55000_EnterMobileNumberConfirm:1d->55000_CheckPUKRc:->55000_PUKLookupResult:*d->MainMenuSelect:->50000_LandLineStart:->ToContinueInChoice:1d->ToContinueInSetLang:->ToContinueInSetAudioLang:->50000_AreYouCust:1d->50000_EntrerMobileNumber:9544281351d->50000_EnterMobileNumberConfirm:1d->50000_CheckSeriesRc:->50000_CheckCTypeRc:->50000_SetLandLineNumber:->SetOptionFlag:->50000_CheckCType:->51000_LLPrePaidMainMenu:1d->90000_CCEStart:";
	} else {
		footPrint = (String) session.getAttribute("callRoute");
	}
		 */
		StringBuffer fp = (StringBuffer) session.getAttribute("callRoute");
		footPrint = fp.toString();



		String xferYesNo = "No";
		String callCompletion = null;

		String callExitReason = null;

		// Get exit reaosn for parsoing
		callExitReason = (String)session.getAttribute("callExitReason");

		// Create the counters for Main Menu Choices
		int choice1 = 0;
		int choice2 = 0;
		int choice3 = 0;
		int choice4 = 0;
		int choice5 = 0;

		StringBuffer stb = null;
		String lastMenu = null;

		// ---------------------------------------
		//  Logic For Call End Cleanup
		// ---------------------------------------

		//  Determine if a Main Menu was reached in the call

		boolean mmFound = false;
		int     idx = 0;

		//Obtain list of keys of Main Menus			
		Enumeration eMM = mainMenuMap.propertyNames();

		// ---------------------------------------
		//  Main Menu Reached In Call Search
		// ---------------------------------------   
		// For each Main Menu listed in the property file we want to determine which if any were entered and 
		// how many time.  Once entered we want to determine what option was taken to leave the Main Menu
		// Save off base footPrint

		String key = null;
		String footWork = footPrint;
		while (eMM.hasMoreElements()) {
			// Get the next Key
			key = (String) eMM.nextElement();    
			// Determine which if any Main Menu Value exists in the footPrint
			idx = footWork.indexOf(mainMenuMap.getProperty(key));	  

			// Debug logging
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("MainMenu Index Result = ").append(mainMenuMap.getProperty(key)));
			}

			if (idx != -1){
				if (testCall)
//					LOGGER.debug(new StringBuffer(logToken).append("MainMenu Found, Main Menu Index  = ").append(idx));
					LOGGER.debug(new StringBuffer(logToken).append(" MainMenu Found at ").append("index = ").append(idx).append(" for Key ").append(mainMenuMap.getProperty(key)));
				mmFound = true;
				break;
			}
		}

		// -----------------------------------------------
		//  Determine how many times the matching Main Menu was entered and update Choice Counts
		// -----------------------------------------------   
		// If Main Menu was detected for the call.
		if (mmFound){
			while (idx != -1){

				// Debug logging
				if (testCall){
					LOGGER.debug(new StringBuffer(logToken).append("Soon to be new footWork = ").append(footWork.substring(idx)));
				}

				// Shift string to the left to where Main Menu entry starts.   Logging above should show new footWork
				String toe = footWork.substring(idx);

				// Get the Menu Portion just after the option that was selected
				String menu = toe.substring(0, toe.indexOf("->"));

				if (testCall){
					LOGGER.debug(new StringBuffer(logToken).append("menu being checked = ").append(menu));
				}


				//  Need to add check to see if a selection was made of did the caller HUP
				//  If there wsa no choice then we don't want to do the following choice logic
				//  Also need to check what value is there when no option is selected.
				if (!menu.endsWith(":") && !menu.endsWith("-")){

					// Get the Selection Made
					String choice = menu.substring((menu.indexOf(":")+1), (menu.indexOf(":")+2));
					// Debug logging
					if (testCall){
						LOGGER.debug(new StringBuffer(logToken).append("choice made = ").append(choice));
					}

					// Increment choice counters
					if (choice.equalsIgnoreCase("1"))
						choice1++;
					else if (choice.equalsIgnoreCase("2"))
						choice2++;
					else if (choice.equalsIgnoreCase("3"))
						choice3++;
					else if (choice.equalsIgnoreCase("4"))
						choice4++;
					else if (choice.equalsIgnoreCase("5"))
						choice5++;
				}else{
					// Break from loop since the caller either had inv input or call HUP
					break;
				}

				// Move past this Main Menu instance to see if the menu was hit again.  
				footWork = toe.substring(toe.indexOf("->"));

				// Debug logging
				if (testCall){
					LOGGER.debug(new StringBuffer(logToken).append("Updated footWork = ").append(footWork));
				}

				idx = footWork.indexOf(mainMenuMap.getProperty(key));

				if (idx != -1){
					// Debug logging
					if (testCall){
						LOGGER.debug(new StringBuffer(logToken).append(" MainMenu Found at ").append("index = ").append(idx).append(" for Key ").append(mainMenuMap.getProperty(key)));
					}
				}
			}

			// Debug logging
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("Choices  = ")
						.append(choice1)
						.append("  ")
						.append(choice2)
						.append("  ")
						.append(choice3)
						.append("  ")
						.append(choice4)
						.append("  ")
						.append(choice5));
			}
		}

		// ------------------------------------------------------------
		//  If Main Menu Found then build the  XXX|XXX|XXX of the flow
		// ------------------------------------------------------------   
		// If we find a Main Menu in the footprint then we can process the call for the tbl_rpt_access_cnt
		if (mmFound){
			// Debug logging
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append(" footPrint = ").append(footPrint));
			}
			StringTokenizer st = new StringTokenizer(footPrint, "->");

			// Debug logging
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("StringTokenizer Length = ").append(st.countTokens()));
			}

			// Buffer to hold translation for logging
			String itm;
			String mmItm = null;
			while(st.hasMoreTokens()){	    	
				String item = st.nextToken();
				if (!item.equalsIgnoreCase("welcome") && item.indexOf(":") != -1){

					// Debug logging
					if (testCall){
						LOGGER.debug(new StringBuffer(logToken).append("st.nextToken() Raw = ").append(item));
					}

					itm = item.substring(0, item.indexOf(":")+1);

					// Debug logging
					if (testCall){
						LOGGER.debug(new StringBuffer(logToken).append("st.nextToken() indexed = ").append(itm));
					}

					mmItm = menuMap.getProperty(itm);
					if (mmItm != null) {
						if (stb == null){
							stb = new StringBuffer();
							stb.append(mmItm);
							lastMenu = mmItm;
						} else {
							stb.append("|").append(mmItm);
							lastMenu = mmItm;
						}
						if (testCall){
							LOGGER.debug(new StringBuffer(logToken).append("stb = ").append(stb));
						}
					}
				}
			}

			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("FINAL stb = ").append(stb));
			}
		}

		// -------------------------------------------------
		//  Determine the call termination status:  
		//  Values to the DB are::
		//      ivr_closed
		//      ivr_abandon
		//      xfer_success
		//      xfer_fail
		//ExitReason: VXMLAppError.BadFetch
		//**ExitReason: CallerExit.30009_PostPaidMainMenu
		//**ExitReason: Hangup.30009_PostPaidMainMenu
		//**ExitReason: XferSuccess
		//**ExitReason: XferException
		//**ExitReason: busy
		//**ExitReason: noanswer

		if (callExitReason != null ) {
			if (callExitReason.trim().startsWith("XferSuccess") || callExitReason.trim().startsWith("SUCCESS")) {
				xferYesNo = "Yes";
				callCompletion = "xfer_success";
			}else if (callExitReason.trim().startsWith("CallerExit") || callExitReason.trim().startsWith("Hangup")) {
				callCompletion = "ivr_closed";
			}else if (callExitReason.trim().startsWith("XferException") || 
					callExitReason.trim().startsWith("busy") ||
					callExitReason.trim().startsWith("noanswer")|| 
					callExitReason.trim().startsWith("FAILURE")) {
				callCompletion = "xfer_fail";
			}else {
				callCompletion = "ivr_abandon";
			}
		}

		//  Call Start Date & Time
		Date ssReportCallStart = (Date) session.getAttribute("ssReportCallStart"); 
		//  Call End Date & Time
		Date ssReportCallEnd = null; 
		//  Date and time when this call was transferred
		Date ssReportCallEndXfer = null; 
		// Call Duration in seconds
		long callDuration = 0;
		
		if (callExitReason != null ) {
			if (callExitReason.trim().startsWith("XferSuccess")) {
				//  Retrieve Session Data For Reporting
				//  Date and time when this call was transferred
				ssReportCallEndXfer = (Date) session.getAttribute("ssReportCallEndXfer"); 
				// Call Duration in seconds
				callDuration = (ssReportCallEndXfer.getTime() - ssReportCallStart.getTime()) / 1000;			
			} else {
				//  Retrieve Session Data For Reporting
				//  Call End Date & Time
				ssReportCallEnd = (Date) session.getAttribute("ssReportCallEnd"); 
				// Call Duration in seconds
				callDuration = (ssReportCallEnd.getTime() - ssReportCallStart.getTime()) / 1000;		
			}
		}

		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("callExitReason = ").append(callExitReason)
					.append("  callCompletion = ").append(callCompletion)
					.append("  callDuration = ").append(callDuration)
					.append("  xferYesNo = ").append(xferYesNo));
		}

		// If Xfer was a success then increment the daily barred count in TBL_CDAY_BARRED
		if ( (callCompletion != null) && (callCompletion.equals("xfer_success")) ){
			String ckBarDBRC = null;
			try {
				CheckBarred  chkBarred = new CheckBarred();

				session.setAttribute("barredCmd","increment");

				chkBarred.doGet(req, resp);

				ckBarDBRC = (String)session.getAttribute("DBRC");

			} catch(Exception e){
				LOGGER.warn(new StringBuffer(logToken).append(" - Problem working with check barred: ").append(e.getMessage()));
				e.printStackTrace();
			}	
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("CheckBarred INCREMENT dbrc = ").append(ckBarDBRC));
			}
		}
		
		//
		// If there is a session with the CSSServer then drop
		//
		String cssSessionExists = (String) session.getAttribute("cssSessionExists");
		if ( (cssSessionExists != null) && (cssSessionExists.equalsIgnoreCase("true")) ){
		try {		  		    
			CSSServer cSrv = new CSSServer();
			session.setAttribute("CSSCommand", "CLSS");
			cSrv.doGet(req, resp);
		  }catch(Exception e){
				LOGGER.warn(new StringBuffer(logToken).append(" - Problem working with CSSServer: ").append(e.getMessage()));
				e.printStackTrace();
			}	
		  if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("CSSServer dbrc = ").append(session.getAttribute("DBRC")));
		  }
		}
		// -------------------------------------------------
		//  Do we create an entry in the tbl_rpt_access_cnt
		// -------------------------------------------------   
		// If we have found a Main Menu in the footprint then we can process the call for the tbl_rpt_access_cnt

		String mobile = null;
		String landline = null;
		String msisdn = null;
		String lang = null;	
		Circle circ = null;
		String reportJNDIName = null;
		String dbrc = null;
		int RC = -1;


		if (mmFound) { // insert report data in DB

			String custType = null;
			String complaintFlag = null;
			int smsCount = 0;

			try {
				mobile = customer.getMobile();
				// MSISDN is mobile #
				msisdn = mobile;
				landline = customer.getLandlineNumber();
				if (landline == null) {
					landline = msisdn; // Type A or B caller
				}

				lang = (String) session.getAttribute("LANG");
				// Adjust Language value for the database  if not ENG or HIN then set to LOCAL
				if (!lang.equals("ENG")  &&  !lang.equals("HIN")){
					lang = "LOCAL";
				}


				circ = (Circle) session.getAttribute("circle");

				reportJNDIName = circ.getReportJNDIName();

				// custType - Prepaid or Postpaid ?
				custType = customer.getDbCType();

				if ( (complaintCall != null) && (complaintCall.equalsIgnoreCase("true")) ){
					complaintFlag =  "yes";
				} else {
					complaintFlag =  "no";
				}

//				smsFlag = customer.getSmsSent();
				smsCount = customer.getSmsCount();

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" Got all attributes"));
					LOGGER.debug(new StringBuffer(logToken).append(" mobile#: ").append(mobile));
					LOGGER.debug(new StringBuffer(logToken).append(" callid: ").append(callid));
				}
			} catch (Exception e) {
				dbrc = "F_C";
				LOGGER.error(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e));
				e.printStackTrace();
			}

			// Need to add a a record to the tbl_rpt_access_cnt
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - Attempting to insert record in TBL_RPT_ACCESS_CNT"));


			ReportAccessCountDAO rptAccessCntDAO = null;
			String msg = null;

			try {
				rptAccessCntDAO = new ReportAccessCountDAO(reportJNDIName, mobile, callid, testCall);
			} catch (SQLException sqle) {
				session.setAttribute("DBRC", "F_C");
				msg = sqle.getMessage();
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				DBXfer dbXfer = rptAccessCntDAO.insertRecord(callid, ssReportCallStart, ssReportCallEnd, 
						custType, msisdn, landline, lang, complaintFlag, smsCount, 
						choice1, choice2, choice3, choice4, choice5);
				dbrc = dbXfer.getDBRC();

				if (dbrc.equals("S")) {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Report Record inserted successfully in DB"));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Report Record NOT inserted in DB - Add entry into Error table"));
					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(dbXfer.getDBMsg());
				} 
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" ServiceFlag NOT retrieved from DB - Add entry into Error table").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
			session.setAttribute("DBRC", dbrc);	
		} else { // no need to insert data in DB
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - No MainMenu found, No records will be inserted in TBL_RPT_ACCESS_CNT"));
		}

		// -------------------------------------------------
		//  Do we create an entry in the tbl_rpt_access_cnt
		// -------------------------------------------------   
		// 

		//  Main Table    tbl_rpt_main field 'menus'


		//   1)Last Menu                  use   lastMenu
		//   2)Menu History    set  tbl_rpt_main.menus     Use  StringBuffer  stb
		//   3)Transfer flag             Use   String   xferYesNo
		//   4)Call Start Date & Time    use   Date class    ssReportCallStart
		//   5)Call End   Date & Time    use   Date class    ssReportCallEnd
		//   6) Category  (Silver, Gold, Bronze etc etc)      Use  customer.getVdn_category
		//   7)Mobile Number             use   customer.getMobile()
		//   8)Land Line Number          use   customer.getLandlineNumber()
		//   9)CallID                    Use  String  callid
		//  10)Call Duration             Use  Long    callDuration
		//  11)Call Completion           Use  Stirng  callCompletion
		//	12)UCID					 	 Use  String callid

		String lastOpt = null;
		String menuHistory = null;
		String category = null;
		String ctype = null;
		String accNum = null;
		String contractNum = null;
		StringBuffer stbActv = null;
		StringBuffer stbDeactv = null;
		String tempStr = "";
		String activated = null;
		String deactivated = null;
		

		try {
			mobile = customer.getMobile();
			// MSISDN is mobile #
			msisdn = mobile;
			ctype = customer.getPrgcode();
			accNum = customer.getCustCode();
			contractNum = customer.getCoid();
			landline = customer.getLandlineNumber();
			if (landline == null) {
				landline = msisdn; // Type A or B caller
			}
//			lang = (String) session.getAttribute("LANG");

			circ = (Circle) session.getAttribute("circle");

			reportJNDIName = circ.getReportJNDIName();
			
			// build "activated" and "deactivated" strings for table
			tempStr = "DC_BIR";
			if (customer.getServiceFlag_DCBIR().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCBIR().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_HA";
			if (customer.getServiceFlag_DCHA().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCHA().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_IB";
			if (customer.getServiceFlag_DCIB().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCIB().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_IR";
			if (customer.getServiceFlag_DCIR().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCIR().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_NR";
			if (customer.getServiceFlag_DCNR().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCNR().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_ISD";
			if (customer.getServiceFlag_DCISD().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCISD().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_PH";
			if (customer.getServiceFlag_DCPH().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCPH().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DC_STD";
			if (customer.getServiceFlag_DCSTD().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCSTD().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			tempStr = "DUP_BILL";
			if (customer.getServiceFlag_DCDB().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCDB().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}

			tempStr = "LANG_CHG";
			if (customer.getServiceFlag_DCLC().equals("A")) {
				if (stbActv == null){
					stbActv = new StringBuffer();
					stbActv.append(tempStr);
				} else {
					stbActv.append("|").append(tempStr);
				}
			} else if (customer.getServiceFlag_DCLC().equals("D")) {
				if (stbDeactv == null){
					stbDeactv = new StringBuffer();
					stbDeactv.append(tempStr);
				} else {
					stbDeactv.append("|").append(tempStr);
				}
			}
			
			if (stbActv != null) {
				activated = new String(stbActv);
			} else {
				activated = "";
			}
			
			if (stbDeactv != null) {
				deactivated = new String(stbDeactv);
			} else {
				deactivated = "";
			}

			if (mmFound) {
				if (lastMenu != null) {
					lastOpt = lastMenu;
				} else {
					lastOpt = "";
				}
				if (stb != null) {
					menuHistory = new String(stb);
				} else {
					menuHistory = "";
				}
			} else {
				lastOpt = "";
				menuHistory = "";
			}
			category = customer.getVdn_category();

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" Got all attributes"));
				LOGGER.debug(new StringBuffer(logToken).append(" mobile#: ").append(mobile));
				LOGGER.debug(new StringBuffer(logToken).append(" callid: ").append(callid));
				LOGGER.debug(new StringBuffer(logToken).append(" activated: ").append(activated));
				LOGGER.debug(new StringBuffer(logToken).append(" deactivated: ").append(deactivated));
			}
		} catch (Exception e) {
			dbrc = "F_C";
			LOGGER.error(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e));
			e.printStackTrace();
		}

		// Need to add a a record to the tbl_rpt_main
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" - Attempting to insert record in TBL_RPT_MAIN"));

		ReportMainDAO rptMainDAO = null;
		String msg = null;

		try {
			rptMainDAO = new ReportMainDAO(reportJNDIName, mobile, callid, testCall);
		} catch (SQLException sqle) {
			session.setAttribute("DBRC", "F_C");
			msg = sqle.getMessage();
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB: ").append(sqle.getMessage()));
			sqle.printStackTrace();
			return;
		}

		try {
			
			DBXfer dbXfer = rptMainDAO.insertRecord(ssReportCallStart, ssReportCallEnd, msisdn, 
					landline, category, menuHistory, lastOpt, lang, xferYesNo, callid, callDuration,
					callCompletion, callExitReason, ctype, activated, deactivated);

			dbrc = dbXfer.getDBRC();

			if (dbrc.equals("S")) {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Report Record inserted successfully in DB"));
			} else {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Report Record NOT inserted in DB - Add entry into Error table"));
				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(dbXfer.getDBMsg());
			}
		} catch (Exception e) {
			dbrc = "F_C";
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" ServiceFlag NOT retrieved from DB - Add entry into Error table").append(e.getMessage()));
			e.printStackTrace();

			//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			RC = rptErrorDAO.insertRecord(e.getMessage());
		}
		session.setAttribute("DBRC", dbrc);

		// -------------------------------------------------
		//  Handler Completion
		// -------------------------------------------------   
		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("Call Start Time = ").append(ssReportCallStart.toString()));
			LOGGER.debug(new StringBuffer(logToken).append("Call End Time = ").append(ssReportCallEnd.toString()));
			LOGGER.debug(new StringBuffer(logToken).append("Call Duration = ").append(callDuration));
			LOGGER.debug(new StringBuffer(logToken).append("Menu History = ").append(stb));
			LOGGER.debug(new StringBuffer(logToken).append("Menu Last Menu = ").append(lastMenu));
			LOGGER.debug(new StringBuffer(logToken).append("Mobile Number = ").append(customer.getMobile()));
			LOGGER.debug(new StringBuffer(logToken).append("LandLine Number = ").append(customer.getLandlineNumber()));
			LOGGER.debug(new StringBuffer(logToken).append("Complaint Call = ").append(complaintCall));
			LOGGER.debug(new StringBuffer(logToken).append("Call Type = ").append(customer.getDbCType()));
			LOGGER.debug(new StringBuffer(logToken).append("Transfer Flag = ").append(xferYesNo));
			LOGGER.debug(new StringBuffer(logToken).append("Call Coompletion = ").append(callCompletion));
			LOGGER.debug(new StringBuffer(logToken).append("VDN TranType = ").append(customer.getTran_type()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting CleanupHandler"));
		}


		return;
	}
}
