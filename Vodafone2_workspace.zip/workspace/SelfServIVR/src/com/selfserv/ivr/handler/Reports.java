package com.selfserv.ivr.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;

/**
 * Servlet implementation class for Servlet: Reports
 *
 */
 public class Reports extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	private static Logger LOGGER = Logger.getLogger(Reports.class);
	
	public Reports() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 HttpSession session = req.getSession(true);  // get session from Servlet request, created if not existed yet
		 String backendDBAccess = "false";
		 Properties callProp = null;
		 String initCustType = null;
		 Customer customer = null;
		 String circle = null;
		 String centralJNDIName = null;
		 String localJNDIName = null;

		 String callid = (String) session.getAttribute("callid");
		 
		 customer = (Customer)session.getAttribute("customer");

		 boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

			//create the log Token for later use, use StringBuffer to reduce number
			// of String objects
		 String logToken = new StringBuffer("[").append(callid).append("]").toString();

		 try{
			 Circle circ = (Circle)session.getAttribute("circle");	
			 localJNDIName = circ.getLocalJNDIName();				
			 circle = circ.getCircle();								//0001, 0002, ....,0023
			 initCustType = circ.getDnisType();						//TypeA, TypeB, pr TypeC
			 
			 callProp = (Properties) session.getAttribute("callProp");
			 backendDBAccess = callProp.getProperty("backendDBAccess");
			 centralJNDIName = callProp.getProperty("centralJNDIName");
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append("] - Got all attributes from the session"));
				 LOGGER.debug(new StringBuffer(logToken).append(", callProp: ").append(callProp));
			 }
		 }catch(Exception e){
				LOGGER.warn(new StringBuffer().append("[CustomerType::doGet()] [").append(callid).append("] - Problem retreiving attributes from the session: ").append(e));
		 }

		 if (backendDBAccess.equals("false")){//No DB ****** DUMMY dbCType ******
			 session.setAttribute("DBRC", "S");
			 return;
		 }else{//Querying the DB's
		 }

	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req,resp);
	}   	  	    
}