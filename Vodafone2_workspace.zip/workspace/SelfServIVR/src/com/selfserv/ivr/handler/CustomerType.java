package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.IVRCallDetailsXfer;
import com.selfserv.ivr.selfservdao.central.IVRCallDetailsDAO;
import com.selfserv.ivr.selfservdao.central.IVRMainDAO;
import com.selfserv.ivr.selfservdao.central.IVRMainXfer;

import com.selfserv.ivr.selfservdao.local.CTYPEDAO;
import com.selfserv.ivr.selfservdao.local.CTYPEXfer;
import com.selfserv.ivr.selfservdao.local.TablePrefDAO;
import com.selfserv.ivr.selfservdao.local.TablePrefXfer;

/**
 * CustomerType servlet will lookup 2 databases with the following scenarios:
 * 		A. If TypeA caller, lookup LDB, first, and update the following
 * 			1. customer.dbCType = CTYPE.TBL_CTYPE.CTYPE
 * 			2. customer.firstTimeCaller with value in TBL_CTYPE.FLAG
 * 			3. customer.prefLang = TBL_PREF.PREF_LANG
 * 				if preferred language not retreived, leave DBRC null
 * 			4. customer.mobile = session.ANI (the IVR already sends the ANI as a 10 digit number)
 * 			5. customer.vdn_category = TBL_CTYPE.VDN_CATEGORY
 * 			6. customer.callerFound
 * 			7. session.DBRC = "S" - success
 *						   "F_NF" - failed (query), record not found
 *						   "F_C"  - failed, critical error (i.e. DB down)
 * 	
 * 		B. If TypeB caller, lookup the LDB first (as for TypeA), if not found look up CDB and update the following
 * 			1. customer.dbCType, by doing the following
 * 					a. retrieve pgname from CDB, using the following stored procedures
 * 						i. IVR_Main
 * 						ii. ivr_call_details
 * 					b. customer.dbCType = lookup programName property with pgname as a key
 * 			2. customer.mobile=session.ANI
 * 			3. customer.callerFound
 * 			4. session.DBRC= "S" - success
 *						   "F_NF" - failed (query), record not found
 *						   "F_C"  - failed, critical error (i.e. DB down)
 *		
 *		C. If customer TypeA, or TypeB was not found in either DB's, set the following:
 *			1. if circle.getDnisType().equals("TypeA"), translate TypeA=PREPAID
 *				customer.dbCtype = "PREPAID"
 *			2. if circle.getDnisType().equals("TypeB"), translate TypeB=POSTPAID
 *				customer.dbCtype = "POSTPAID"
 *
 *		D. If TypeC caller and inroaming
 *				treat like TypeA, except that if no record is found, do not do the translation 
 *			
 *		E. If TypeC caller and not inroamer
 *				do LDB lookup, handle like TypeA: 
 *					- lookup Local DB (LDB) first, then Central DB (CDB) if the LDB is not available/record not found
					- if customer was not found in both DB's don't do a translation like TypeA->PREPAID.
					- just return F_NF

 */	

 public class CustomerType extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(CustomerType.class);
		
 	public CustomerType() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		 HttpSession session;  					// get session from Servlet request, created if not existed yet
		 Properties callProp = null;			// properties key-value pair
		 String centralJNDIName = null;			// JNDI name for central DB
		 String localJNDIName = null;			// JNDI name for local DB
		 String callid = null;					// call ID 
		 Customer customer = null;				// customer class 
		 String mobile = null;					// mobile number
		 String initCustType = null;			// initial customer type: TypeA, TypeB, TypeC
		 Circle circ = null;					// circle clsss that gets populated from the properties file
		 String dbrc = null;					// DB return code
		 String circle = null;					// Circle name 0001.....0023
		 boolean testCall = false;
		 String logToken = null;

		 session = req.getSession(true);  // get session from Servlet request, created if not existed yet
		 //circ = (Circle)session.getAttribute("circle");
		 callid = (String) session.getAttribute("callid");
		 mobile = (String) session.getAttribute("mobileNumber");

		 testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

			//create the log Token for later use, use StringBuffer to reduce number
			// of String objects
		 if (testCall) {
			 logToken = new StringBuffer("[").append(callid).append("]").toString();
			 
	//		 LOGGER.info(new StringBuffer(logToken).append(" - ********************************************"));
			 LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered CustomerType servlet *******"));
	//		 LOGGER.info(new StringBuffer(logToken).append(" - ********************************************"));
		 }

		 try{
			 customer = (Customer)session.getAttribute("customer");
			 
			 circ = (Circle)session.getAttribute("circle");			//circle class
			 circle = circ.getCircle();								//0001, 0002, ....,0023
			 localJNDIName = circ.getLocalJNDIName();				
			 initCustType = circ.getDnisType();						//TypeA, TypeB, TypeC
			 
			 callProp = (Properties) session.getAttribute("callProp");
			 centralJNDIName = callProp.getProperty("centralJNDIName");
			 if(testCall){
				 LOGGER.info(new StringBuffer(logToken).append(" - Got all attributes from session!"));
				 LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(mobile));
				 LOGGER.debug(new StringBuffer(logToken).append(" - initCustType=").append(initCustType));
				 LOGGER.debug(new StringBuffer(logToken).append(" - localJNDIName=").append(localJNDIName));
				 LOGGER.debug(new StringBuffer(logToken).append(" - centralJNDIName=").append(centralJNDIName));
			 }
		 }catch(Exception e){
			LOGGER.error(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e));
			session.setAttribute("DBRC", "F_C");	
		 }
		 
		 //if (backendDBAccess.equals("false")){						//No DB ****** DUMMY dbCType ******
		 if (callProp.getProperty("dBhandlerCustomerType").equals("false")){//No DB ****** DUMMY barred flag ******
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerCustomerType=true => using backend"));
			 }
			 customer.setDbCType("PREPAID");
			 customer.setFirstTimeCallerFlag("N");
			 customer.setCallerFound("Y");
			 customer.setInroamerFlag("N");
			 customer.setMobile(mobile);
			 customer.setPrefLang("ENG");
			 customer.setVdn_category("GOLD_NEW");
			 
			 session.setAttribute("customer", customer);
			 session.setAttribute("DBRC", "S");
			 return;
		 }else{
			 	customer.setMobile(mobile);
			 	//Querying the DB's
			 	//TypeA/PREPAID: Lookup Local DB (LDB) first, then Central DB (CDB) if the LDB is not available/record not found
				 if (initCustType.equals("TypeA")){
					 
					 dbrc = queryLDB(req, customer, callid, mobile, localJNDIName, session, testCall, logToken);	//access LDB

					 if (testCall) {
						 LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered TypeA/PREPAID"));
						 LOGGER.debug(new StringBuffer(logToken).append(" - 1. Accessing LDB"));
						 LOGGER.debug(new StringBuffer(logToken).append(" - DBRC = ").append(dbrc));
					 }

					if (!dbrc.equals("S")){
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(" - 2. Accessing CDB"));
						}
				 		dbrc = queryCDB(req, customer, callid, mobile, centralJNDIName, circ, session, testCall, logToken);				//access CDB
					 	if (!dbrc.equals("S")){
					 		//translate the DNISType property into a customer type:
					 		customer.setDbCType("PREPAID");  //TypeA -> PREPAID
							session.setAttribute("customer", customer);
							if (testCall) {
					 			LOGGER.debug(new StringBuffer(logToken).append(" - 3. Set dbCtype=DNISType=TypeA"));
								LOGGER.debug(new StringBuffer(logToken).append(" - dbCType=").append("Translated dbCType: TypeA->PREPAID"));
							}
						 }
					} else if (customer.getDbCType().equals("POSTPAID")) {  // Prepiad customer calling from PostPaid phone
							dbrc = queryCDB(req, customer, callid, mobile, centralJNDIName, circ, session, testCall, logToken);
							session.setAttribute("VDN",circ.getDefVDNTypeB());
							session.setAttribute("ctiVDN",circ.getDefVDNTypeB());
					}
					session.setAttribute("DBRC", dbrc);	
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TypeA"));
					}
				 }//TypeA
				
				 
				 
				 //TypeB
		 		//POSTPAID: Lookup Local DB (LDB) first, then Central DB (CDB)
				 if (initCustType.equals("TypeB")){
					 if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - WIN customer type: TypeB/POSTPAID"));
						LOGGER.debug(new StringBuffer(logToken).append(" - Accessing LDB first"));
					 }
					dbrc = queryLDB(req, customer, callid, mobile, localJNDIName, session, testCall, logToken);		//access LDB
					String ldbDbrc = dbrc;
//				 	if (!dbrc.equals("S")){
			 		if (testCall) {
			 			LOGGER.debug(new StringBuffer(logToken).append(" - Accessing CDB next"));
			 		}
			 		//	Accessing CDB because a LDB match was not found (i.e. DB not available, record not found, or other error)
			 		dbrc = queryCDB(req, customer, callid, mobile, centralJNDIName, circ, session, testCall, logToken);	//access CDB
				 	// return success if customer is found in either LDB or CDB
			 		if (ldbDbrc.equals("S") || dbrc.equals("S")) {
				 		session.setAttribute("DBRC", "S");
				 		customer.setCallerFound("Y");
				 	} else {
				 		//translate the DNISType property into a customer type:
				 		//TypeB -> POSTPAID
					 	customer.setDbCType("POSTPAID");
						session.setAttribute("customer", customer);
					}	
//				 	}
				 }//TypeB
			
				 
				 //TypeC, not inroamer
				 //do LDB lookup, handle like TypeA: 
				 //Lookup Local DB (LDB) first, then Central DB (CDB) if the LDB is not available/record not found
				 if (initCustType.equals("TypeC") && customer.getInroamerFlag().equals("N")){
					 if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Customer WIN received type=TypeC, not inroamer"));
						LOGGER.debug(new StringBuffer(logToken).append(" - Accessing LDB first"));
					 }
				 	dbrc = queryLDB(req, customer, callid, mobile, localJNDIName, session, testCall, logToken);					//access LDB 
				 	if (!dbrc.equals("S")){
				 		if (testCall) {
				 			LOGGER.debug(new StringBuffer(logToken).append(" - Accessing CDB next"));
				 		}
				 		dbrc = queryCDB(req, customer, callid, mobile, centralJNDIName, circ, session, testCall, logToken);				//access CDB
				 	}
				 	
				 	//if not found in both DB's don't do a translation like TypeA->PREPAID.
				 	//just return F_NF
				 	if (!dbrc.equals("S")){ 
				 		session.setAttribute("DBRC", "F_NF");
				 	}
				 	if (testCall) {
				 		LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting TypeC - not inroamer"));
				 	}
				 }//TypeC not inroamer
				 
				 //TypeC, inroamer
				 if (initCustType.equals("TypeC") && customer.getInroamerFlag().equals("Y")){
					 /* Only access CDB to get prgname and set: 	
					 										ctype, 
					 										customerFound="Y", 
					 										mobile, 
					 										prefLang, 
					 	If prgname is not found, set DBRC=F_NF
					 */
					 if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Accessing CDB next"));
					 }
				 	 dbrc = queryCDB(req, customer, callid, mobile, centralJNDIName, circ, session, testCall, logToken);				//access CDB
				 	
				 	 if (dbrc.equals("S")) {
				 		 if (customer.getDbCType().equals("POSTPAID")) {
				 			 customer.setVdn_category("POSTROAM");
				 			if (testCall) {
								LOGGER.debug(new StringBuffer(logToken).append(" - Set VDN Category to POSTROAM"));
							}
				 		 } else {
				 			customer.setVdn_category("PREROAM");
				 			if (testCall) {
								LOGGER.debug(new StringBuffer(logToken).append(" - Set VDN Category to PREROAM"));
							}
				 		 }
				 	 }
				 }//TypeC, inroamer	 	

				 if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
					LOGGER.debug(new StringBuffer(logToken).append(" - whichDB=").append(customer.getWhichDB()));
					LOGGER.debug(new StringBuffer(logToken).append(" - dbCType=").append(customer.getDbCType()));
					LOGGER.debug(new StringBuffer(logToken).append(" - prgcode=").append(customer.getPrgcode()));
					LOGGER.debug(new StringBuffer(logToken).append(" - callerFound=").append(customer.getCallerFound()));
					LOGGER.debug(new StringBuffer(logToken).append(" - firstTimeCaller=").append(customer.getFirstTimeCallerFlag()));
					LOGGER.debug(new StringBuffer(logToken).append(" - inroamerFlag=").append(customer.getInroamerFlag()));					
					LOGGER.debug(new StringBuffer(logToken).append(" - vdn_category=").append(customer.getVdn_category()));
					LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(customer.getMobile()));
					LOGGER.debug(new StringBuffer(logToken).append(" - langPref=").append(customer.getPrefLang()));
					LOGGER.debug(new StringBuffer(logToken).append(" - DBRC=").append(session.getAttribute("DBRC")));
				 }
			}//else
			
		 if (testCall)
			 LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting CustomerType servlet"));
		 }//doGet
	
	
	public String queryLDB(HttpServletRequest req, Customer customer, String callid, String mobile, String localJNDIName, HttpSession session, boolean testCall, String logToken){
		CTYPEDAO ctypeDAO = null;
		CTYPEXfer ctypeXfer = null;
		TablePrefDAO tablePrefDAO = null;
		TablePrefXfer tbXfer = null;
		
		// String dbCType = null;
		// String callerFound = null;
		// String vdn_category = null;
		// String firstTimeCaller = null;
		// String langPref = null;
		String dbrc = null;
		
		try {
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered queryLDB()"));
			}
			//Get values from TBL_CTYPE
			ctypeDAO = new CTYPEDAO(localJNDIName, mobile, callid, testCall);
			if (ctypeDAO!=null){//connected OK to the DB
				 ctypeXfer = ctypeDAO.findRecord(mobile); 
				 if (ctypeXfer!=null){//
					 dbrc = ctypeXfer.getDBRC();
					 
					 if (dbrc.equals("S")){
						 customer.setDbCType(ctypeXfer.getCtype());
						 customer.setCallerFound(ctypeXfer.getCallerFound());
						 customer.setFirstTimeCallerFlag(ctypeXfer.getFirstTimeCaller());	
						 //customer.setMobile(mobile);
						 customer.setVdn_category(ctypeXfer.getVdn_category());
						 customer.setWhichDB("L");
						 customer.setPrgcode(ctypeXfer.getPgmcode());
						 customer.setGprs_Flag(ctypeXfer.getGprs_Flag());
						 
						 if (testCall){
							 LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(mobile));
							 LOGGER.debug(new StringBuffer(logToken).append(" - prgcode=").append(customer.getPrgcode()));
							 LOGGER.debug(new StringBuffer(logToken).append(" - ctype=").append(customer.getDbCType()));
							 LOGGER.debug(new StringBuffer(logToken).append(" - vdn_category=").append(customer.getVdn_category()));
							 LOGGER.debug(new StringBuffer(logToken).append(" - firstTimeCaller=").append(customer.getFirstTimeCallerFlag()));
							 LOGGER.debug(new StringBuffer(logToken).append(" - gprsFlag=").append(customer.getGprs_Flag()));
						 }
					 }	 
					 dbrc = ctypeXfer.getDBRC();
				 }else{
					 customer.setCallerFound("N");
					 dbrc="F_NF";
					 session.setAttribute("DBRC",dbrc);
					 return dbrc;
				 }
			}else{
				customer.setCallerFound("N");
				dbrc="F_C";
				session.setAttribute("DBRC",dbrc);
				return dbrc;
			}
		}catch(SQLException e){
			dbrc="F_C";
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught when accessing the LDB: " + e.getMessage()));
			//e.printStackTrace();
			return dbrc;
		}
		
		 //Get the language preference  
		String langPref = null;
		try{
			//Get language preference from TBL_PREF
			tablePrefDAO = new TablePrefDAO(localJNDIName,mobile,callid, testCall);
			if (tablePrefDAO!=null){//connected OK to DB
				tbXfer = tablePrefDAO.findRecord(mobile);
				if (tbXfer!=null){
					// no need to set DBRC as not critical if cannot get language preference; call can continue without language preference
					langPref = tbXfer.getLanguagePref();
					customer.setPrefLang(langPref);
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - languagePreference=").append(customer.getPrefLang()));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - languagePreference not set"));
				}
			}
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception at getting TablePref information.  Exception: ").append(e.getMessage()));
		} 
						
		session.setAttribute("customer", customer);
		session.setAttribute("DBRC", dbrc);

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting queryLDB"));
		}
		return dbrc;
	}//queryLDB()
	

	private String queryCDB(HttpServletRequest req, Customer customer, String callid, String mobile, String centralJNDIName, Circle circ, HttpSession session, boolean testCall, String logToken){
		
		String dbrc = null;
		int coid = 0;
		String circle = circ.getCircle();
		
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Entered queryCDB()"));
		}
		 
		 IVRMainDAO ivrMainDAO = null;
		 ivrMainDAO = new IVRMainDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());											//-------------Central DB Access						
		 IVRMainXfer ivrMainXfer = ivrMainDAO.executeSP(circle,mobile);//-------------Query Stored Procedure IVR_Main
		 
		 dbrc = ivrMainXfer.getDBRC();
		 if (dbrc.equals("S")) {
			 coid = ivrMainXfer.getCoid();
			 CustomerDetails.setCustomerDetails(customer, ivrMainXfer, null);
			 customer.setIvrMainCalled(true);
			 
			 IVRCallDetailsDAO ivrCallDetailsDAO = new IVRCallDetailsDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());	
			 IVRCallDetailsXfer callDetailsXfer = ivrCallDetailsDAO.executeSP(circle, ivrMainXfer.getCoid(), ivrMainXfer.getCust_id());  //Query Stored Procedure ivr_call_details

			 dbrc = callDetailsXfer.getDBRC();
			 	 
			 //dbrc="F_NF";		//Sibyl: uncomment this line if you want to test the F_NF scenario with the CDB
			 
			 if (dbrc.equals("S")){															//-------------Lookup programName properties
				 String pgcode = callDetailsXfer.getPgcode();
				 String cust_code = callDetailsXfer.getCust_code();
				 String pgname = callDetailsXfer.getPgname();
				 String ctype = null;
		
				 if (testCall) {
					 LOGGER.debug(new StringBuffer(logToken).append(" prgcode: ").append(pgcode)
									.append(" cust_code: ").append(cust_code).append(" - ContractID: ").append(coid));
				 }
				 
				 CustomerDetails.setCustomerDetails(customer, null, callDetailsXfer);

				 customer.setIvrCallDetailsCalled(true);
				 
				 Properties globalProp = null;																			//Get the customer type from mapping of the program name in the programName properties file
				 if (pgname!= null) {
					 globalProp = (Properties) session.getServletContext().getAttribute("programNameProp");
					 if (globalProp!=null){
						 ctype = globalProp.getProperty(pgname.substring(0,2).toLowerCase());	
						 if (ctype==null){
							 ctype = "POSTPAID";
						 }
						 if (testCall) {
							 LOGGER.debug(new StringBuffer(logToken).append(" - Looking up programName property file"));
							 LOGGER.debug(new StringBuffer(logToken).append(" - Lookup: programName: "+pgname+" -> dbCtype: "+ctype));
						 }
						 
						 customer.setDbCType(ctype);
						 customer.setCallerFound("Y");			
						 //customer.setMobile(mobile);
						 customer.setWhichDB("C");
					 }
				 }
				
				 if (globalProp==null || pgname ==null){										//Problem with programName property file lookup
					 dbrc="F_NF";
					 customer.setMobile(mobile);
					 customer.setCallerFound("N");
				 }
			 }else{																			//Customer not found or couldn't be retreived from CDB
				 customer.setMobile(mobile);
				 customer.setCallerFound("N");
			 }
		 } else {
			 dbrc="F_NF";
			 customer.setMobile(mobile);
			 customer.setCallerFound("N");
		 }
		 session.setAttribute("customer", customer);
		 session.setAttribute("DBRC", dbrc);
		
		 if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Session and customer settings from CDB:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - coid=").append(customer.getCoid()));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC=").append(dbrc));
		
			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting queryCDB()"));
		 }
	
		return dbrc;		 
	}//queryCDB
}//CustomerType