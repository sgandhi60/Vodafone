/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.TableSeriesDAO;
import com.selfserv.ivr.selfservdao.local.TableSeriesXfer;

/**
 * @author Ciprian Agapi
 * This handler will return the INROAMER_FLAG from  LDB
 * IN: session.ANI
 * OUT: customer.inroamerFlag
 *      customer.mobile
 *      DBRC: S, F_NF, F_C
 */
public class TableSeries extends HttpServlet implements Servlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(TableSeries.class);
	//DataBase Return Code(s) S=Success; F_NF=Failed, Record Not Found, F_C=Critical (DB down)

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession(true);  // get session from Servlet request, created if not existed yet


		String callid = (String) session.getAttribute("callid");
		String mobile = (String) session.getAttribute("mobileNumber");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("]").toString();

		String initCustType = null;
		Circle circ = null;
		Properties callProp = null;
		String localJNDIName = null;
		Customer customer = null;
		TableSeriesXfer tableSeriesXfer = null;
		String dbrc = null;

		try{
			customer = (Customer)session.getAttribute("customer");
			circ = (Circle)session.getAttribute("circle");			//circle class
			localJNDIName = circ.getLocalJNDIName();	
			initCustType = circ.getDnisType();						//TypeA, TypeB, TypeC

			callProp = (Properties) session.getAttribute("callProp");

//			LOGGER.info(new StringBuffer(logToken).append(" - ***********************************"));
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered TableSeries handler"));
//			LOGGER.info(new StringBuffer(logToken).append(" - ***********************************"));
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - localJNDIName=").append(localJNDIName));
				LOGGER.debug(new StringBuffer(logToken).append(" - initCustType=").append(initCustType));
			}
			//LOGGER.debug(new StringBuffer(logToken).append(" - backendDBAccess=").append(backendDBAccess));
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			dbrc = "F_C";
			//session.setAttribute("DBRC", "F_C");	
		}
		//if (backendDBAccess.equals("false")){//No DB ****** DUMMY barred flag ******
		if (callProp.getProperty("dBhandlerTableSeries").equals("false")){//No DB ****** DUMMY barred flag ******
			customer.setInroamerFlag("Y");
			customer.setBirthFlag("N");
			customer.setTableSeriesCalled(true);
			dbrc = "S";
		}else{	 
			//LOGGER.warn(new StringBuffer(logToken).append(" - Customer WIN received type = TypeC"));
			if (customer.isTableSeriesCalled()) {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Table Series already called; no table lookup"));
				}
				dbrc = "S";
			} else {
				try {
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Table Series not called before; performing table lookup"));
					}
					TableSeriesDAO tableSeriesDAO = new TableSeriesDAO(circ.getLocalJNDIName(), mobile, callid, testCall);
					tableSeriesXfer = tableSeriesDAO.findRecord(mobile);
					dbrc = tableSeriesXfer.getDBRC();
					if (dbrc.equals("S")){
						customer.setInroamerFlag(tableSeriesXfer.getInroamerFlag());
						customer.setBirthFlag(tableSeriesXfer.getBirthFlag());
						customer.setTableSeriesCalled(true);
						if (tableSeriesXfer.getInroamerFlag().equalsIgnoreCase("Y")) {
							circ.setCircle(tableSeriesXfer.getCircleCode());
						}
					}
					//session.setAttribute("DBRC", dbrc);
				} catch (SQLException e) {
					LOGGER.warn(new StringBuffer(logToken).append(" - Exception caught attempting to instantiate tableSeriesDAO. ").append(e.getMessage()));
					dbrc = "F_C";
				}
			}
		}//else
		
		session.setAttribute("DBRC", dbrc);
		session.setAttribute("customer", customer);
		session.setAttribute("circle", circ);
		
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - inroamerFlag=").append(customer.getInroamerFlag()));
			LOGGER.debug(new StringBuffer(logToken).append(" - birthFlag=").append(customer.getBirthFlag()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC=").append(session.getAttribute("DBRC")));		 
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting TableSeries handler"));
		}
	}//doGet()
}
