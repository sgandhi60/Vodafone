/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.VASLogDAO;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class VASlog extends HttpServlet implements Servlet{

	private static Logger LOGGER = Logger.getLogger(VASlog.class);


	public VASlog() {
		super();
	}   	


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering VASlog"));

		Properties callProp = null;			// properties key-value pair
		String localJNDIName = null;			// JNDI name for Local DB
		String reportJNDIName = null;			// JNDI name for Report DB
		Customer customer = null;
		Circle circ = null;
		String mobile = null;					// mobile number
		String landline = null;
		String custType = null;
		String vasService = null;				// vas service
		String vasServiceReq = null;			// vas service Req - A for Activate, D for Deactivateaction
		String reqDate = null;					// Req Date as YYYYMMDD
		String dbrc = null;
		int RC = -1;

		try{
			customer = (Customer)session.getAttribute("customer");
			if ( customer != null ) {
				mobile = customer.getMobile();
				landline = customer.getLandlineNumber();
				// custType - Postpaid
				custType = customer.getDbCType();
			}

			if (session != null) {
				callProp = (Properties) session.getAttribute("callProp");
				circ = (Circle) session.getAttribute("circle");
				vasService = (String) session.getAttribute("vasService");
				vasServiceReq = (String) session.getAttribute("serviceAction");
//				reqDate = (String) session.getAttribute("TODAY");
			}

			if (circ != null) {
				localJNDIName = circ.getLocalJNDIName();
				reportJNDIName = circ.getReportJNDIName();
			}

			Calendar calNow = Calendar.getInstance();
			Date nowDate = calNow.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			reqDate = formatter.format(nowDate);

		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - landline: ").append(landline));
			LOGGER.debug(new StringBuffer(logToken).append(" - custType: ").append(custType));
			LOGGER.debug(new StringBuffer(logToken).append(" - vasService: ").append(vasService));
			LOGGER.debug(new StringBuffer(logToken).append(" - vasServiceReq: ").append(vasServiceReq));
			LOGGER.debug(new StringBuffer(logToken).append(" - reqDate: ").append(reqDate));
		}

		if (callProp.getProperty("dBhandlerVASlog").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerVASlog=false => using No backend"));

			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerVASlog=true => Attempting insert record in TBL_VASLOG"));

			VASLogDAO vasLogDAO = null;

			//insert record in TBL_VASLOG		
			try {
				vasLogDAO = new VASLogDAO(reportJNDIName, mobile, callid, testCall);
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to TBL_VASLOG: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				int result = vasLogDAO.insertRecord(landline, mobile, custType, vasService, vasServiceReq, reqDate);
				if (result == 1){//the record was inserted in the DB
					session.setAttribute("DBRC", "S");
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Record successfully inserted in TBL_VASLOG "));
				}else{
					session.setAttribute("DBRC", "F_C");
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error inserting record in TBL_VASLOG - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord("Error inserting record in TBL_VASLOG");
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Exception inserting record in TBL_VASLOG - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}

			session.setAttribute("DBRC", dbrc);		
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting VASLog"));
		}

		return;
	}


}
