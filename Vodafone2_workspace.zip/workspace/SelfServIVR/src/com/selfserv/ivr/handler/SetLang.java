/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;

import org.apache.log4j.Logger;
import com.ibm.ivr.framework.utilities.Common;
/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Move will move currencyVarB to currencyVarA
 * 
 *   Add, Subtract and Multiply will folloe the format
 * 
 *      currencyVarA = currencyVarB  '+' | '-' | '*' currencyVarC
 */
public class SetLang extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(SetLang.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering SetLang"));		 	

		// Get swession variables	
		String audioSkeleton = (String) session.getAttribute("audioSkeleton");
		String audioDir = audioSkeleton;
		String audioUtilsDir = audioDir+"/utils";

		// Log the sttributes
		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("LANG = "+session.getAttribute("LANG")));
			LOGGER.debug(new StringBuffer(logToken).append("audioSkeleton = "+audioSkeleton));
		}

		// Construct the new language root path
		try {
			// See if directory name has a variable reference. Supports one $var at this time
			int idx = audioDir.indexOf("$");
			if (idx != -1){
				String work = audioDir.substring(idx);
				int idx1 = work.indexOf("/");
				if (idx1 != -1){
					work.substring(0,idx1);					
				}
				String workResult = (String) evaluate(req, work);
				String workReplace = "["+work.substring(0,1)+"]"+work.substring(1);

				audioDir = audioDir.replaceFirst(workReplace, workResult);
				session.setAttribute("audioDir", audioDir);
				audioUtilsDir = audioDir+"/utils";
				session.setAttribute("audioUtilsDir", audioUtilsDir);

			}
		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken).append(e.getMessage()));
		}		


		// Set session variable for reply


		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("Active audioDir = "+audioDir));
			LOGGER.debug(new StringBuffer(logToken).append("Active audioUtilsDir = "+audioUtilsDir));
			LOGGER.info(new StringBuffer(logToken).append("Exiting SetLang"));
		}
		return;
	}
	/**
	 * Evaluate the string as literal string or session variable
	 * 
	 * @param var
	 *            literal string or session variable (starting with $)
	 * @return the value of session variable or literal string, null if not
	 *         found in session
	 * @throws Exception
	 */
	//Vodafone Added this method for processing audio directory content
	private Object evaluate(HttpServletRequest req, String var) throws Exception {
		HttpSession session = req.getSession();
		Object value = null;

		if (var != null && var.startsWith("$")) {
			value = Common.getSessionValue(var.substring(1), session);
			if (value == null){
				throw new JspException("session variable " + var.substring(1)
						+ " is not available at menu: ");
			}
			else
				return value;
		} else {
			return var;
		}
	}
	
}
