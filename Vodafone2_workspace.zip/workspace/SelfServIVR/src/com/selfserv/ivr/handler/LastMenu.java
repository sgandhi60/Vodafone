package com.selfserv.ivr.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Customer;

public class LastMenu extends HttpServlet implements Servlet{
	
	private static final long serialVersionUID = 1L;
	
	private static Logger LOGGER = Logger.getLogger(BirthDayCheck.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		// Get the menuMainMap property information
		Properties menuMap = (Properties) session.getServletContext().getAttribute("menuMap");
		
		// Get the menuMainMap property information
		Properties lastMenu = (Properties) session.getServletContext().getAttribute("lastMenu");

		
		StringBuffer fp = (StringBuffer) session.getAttribute("callRoute");
				
		String LastMenuMark = null;
		String LastMenuValue = null;
		String worker = null;
			
		if (testCall){
			LOGGER.info(new StringBuffer(logToken).append("Entering LastMenu"));
		}

		if (menuMap != null && fp != null && lastMenu != null){
			try{
				String footPrint = fp.toString();
				StringTokenizer st = new StringTokenizer(footPrint, "->");
				
			    while(st.hasMoreTokens()){
			    	
			    	String item = st.nextToken();
			    	
			    	if (!item.equalsIgnoreCase("welcome")){
			    		if (item.indexOf(":")!= -1){
			    			worker = menuMap.getProperty(item.substring(0,(item.indexOf(":")+1)));
			    			if (worker != null)
			    				LastMenuMark = worker;
			    		}
			    	}
			    }
				
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append(ex.getMessage()));
				// Update session with result
				LastMenuValue = null;
				session.setAttribute("LastMenuValue", LastMenuValue);
				return;
			}
		}

		if(LastMenuMark != null){
			LastMenuValue = lastMenu.getProperty(LastMenuMark);
		}
		// Update session with result
		session.setAttribute("LastMenuValue", LastMenuValue);
		
		if (testCall){
			LOGGER.info(new StringBuffer(logToken).append("LastMenuMark = ").append(LastMenuMark).append("   LastMenuValue = ").append(LastMenuValue));
			LOGGER.info(new StringBuffer(logToken).append("Exiting LastMenu"));
		}
		return;
	}
}
