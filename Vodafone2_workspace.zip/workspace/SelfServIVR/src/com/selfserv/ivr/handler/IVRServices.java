/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.data.HandlerHelper;
import com.selfserv.ivr.selfservdao.central.IVRServicesDAO;
import com.selfserv.ivr.selfservdao.central.IVRSvcsXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.TableSncode2DAO;
import com.selfserv.ivr.selfservdao.local.TableSncode2Xfer;


/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class IVRServices extends HttpServlet implements Servlet{

	private static Logger LOGGER = Logger.getLogger(IVRServices.class);

	
 	public IVRServices() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering IVRServices"));

		Properties callProp = null;			// properties key-value pair
		Customer customer = null;
		Circle circ = null;
		String circle = null;					// Circle name 0001.....0023
		String mobile = null;					// mobile number
		String coId = null;						// contract id
		String localJNDIName = null;			// JNDI name for local DB
		String reportJNDIName = null;			// JNDI name for report DB
		String centralJNDIName = null;			// JNDI name for central DB
		HandlerHelper helper = null;
		
		try{
			customer = (Customer)session.getAttribute("customer");

			mobile = customer.getMobile();
			coId = customer.getCoid();

			callProp = (Properties) session.getAttribute("callProp");
			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			localJNDIName = circ.getLocalJNDIName();
			reportJNDIName = circ.getReportJNDIName();
			centralJNDIName = callProp.getProperty("centralJNDIName");

			
			// instantiate helper class object and initialize it
			helper = new HandlerHelper();
			
			if (helper != null) {
				helper.setCallid(callid);
				helper.setCallProp(callProp);
				helper.setCirc(circ);
				helper.setCircle(circle);
				helper.setLocalJNDIName(localJNDIName);
				helper.setReportJNDIName(reportJNDIName);
				helper.setCentralJNDIName(centralJNDIName);
				helper.setLogToken(logToken);
				helper.setMobile(mobile);
				helper.setSession(session);
				helper.setTestCall(testCall);
				helper.setCoId(coId);
		}
			
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - contract Id: ").append(coId));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
		}

		if (callProp.getProperty("dBhandlerIVRServices").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerIVRServices=false => using No backend"));

			customer.setServiceID_DCBIR("d");
			customer.setServiceID_DCHA("d");
			customer.setServiceID_DCIR("d");
			customer.setServiceID_DCISD("d");
			customer.setServiceID_DCNR("d");
			customer.setServiceID_DCPH("d");
			customer.setServiceID_DCSTD("d");
			customer.setServiceID_DCIB("d");
			customer.setServiceID_DCBIR_code("????");
			customer.setServiceID_DCHA_code("2137");
			customer.setServiceID_DCIR_code("24");
			customer.setServiceID_DCISD_code("15");
			customer.setServiceID_DCNR_code("25");
			customer.setServiceID_DCPH_code("2199");
			customer.setServiceID_DCSTD_code("14");
			customer.setServiceID_DCIB_code("99");

			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerIVRServices=true => Attempting work for SNCodes"));

			// get service key and service code from TBL_SNCODE2 for all the records
			// and build Properties object for ServiceCode to ServiceKey mapping
			Properties sncProps = performSncodesLookup(helper);
			
			// get service_key and service_code from IVR_SERVICES SP
			// and build Properties object
			Properties servicesProp = retrieveServices(helper, circ);

		}//else callProp

		session.setAttribute("customer", customer);

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCBIR: ").append(customer.getServiceID_DCBIR()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCHA: ").append(customer.getServiceID_DCHA()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCIR: ").append(customer.getServiceID_DCIR()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCISD: ").append(customer.getServiceID_DCISD()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCNR: ").append(customer.getServiceID_DCNR()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCPH: ").append(customer.getServiceID_DCPH()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCSTD: ").append(customer.getServiceID_DCSTD()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCIB: ").append(customer.getServiceID_DCIB()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCBIR_Code: ").append(customer.getServiceID_DCBIR_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCHA_Code: ").append(customer.getServiceID_DCHA_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCIR_Code: ").append(customer.getServiceID_DCIR_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCISD_Code: ").append(customer.getServiceID_DCISD_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCNR_Code: ").append(customer.getServiceID_DCNR_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCPH_Code: ").append(customer.getServiceID_DCPH_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCSTD_Code: ").append(customer.getServiceID_DCSTD_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceID_DCIB_Code: ").append(customer.getServiceID_DCIB_code()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting IVRServices"));
		}


		return;
	}


	private Properties performSncodesLookup(HandlerHelper helper) {

		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String localJNDIName = null;
		String reportJNDIName = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			localJNDIName = helper.getLocalJNDIName();
			reportJNDIName = helper.getReportJNDIName();
		}

		// get birthdate from TBL_GEN for this mobile
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" Entered performSncodesLookup - Attempting to lookup TBL_SNCODE2"));

		String dbrc = null;
		int RC = -1;
		Properties code2Keys = null;   // returned to handler's calling method
		Properties key2Codes = null;   // uses only here
		TableSncode2Xfer tblSncXfer = null;

		TableSncode2DAO tblSncode2DAO = null;
		try {
			tblSncode2DAO = new TableSncode2DAO(localJNDIName, mobile, callid, testCall);
		} catch (SQLException sqle) {
			dbrc = "F_C";
			session.setAttribute("DBRC", dbrc);
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_SNCODE2: ").append(sqle.getMessage()));
			sqle.printStackTrace();
			return code2Keys;
		}

		Customer customer = (Customer) session.getAttribute("customer");		
		try { // retrieve all records
			tblSncXfer = tblSncode2DAO.findRecords();
			dbrc = tblSncXfer.getDBRC();
			
			if (dbrc.equals("S")){
				code2Keys = tblSncXfer.getCodeKeyProp();
				
				key2Codes = tblSncXfer.getKeyCodeProp();
				Enumeration en = key2Codes.keys();
				String svcKey = null;
				String svcCode = null;
				
				if (customer != null) {
					while (en.hasMoreElements()) {
						svcKey = (String) en.nextElement();
						svcCode = key2Codes.getProperty(svcKey);

						if (svcKey != null) {
							if (svcKey.equals("DC_STD")) {
								customer.setServiceID_DCSTD_code(svcCode);
							} else if (svcKey.equals("DC_ISD")) {
								customer.setServiceID_DCISD_code(svcCode);
							} else if (svcKey.equals("DC_HA")) {
								customer.setServiceID_DCHA_code(svcCode);
							} else if (svcKey.equals("DC_PH")) {
								customer.setServiceID_DCPH_code(svcCode);
							} else if (svcKey.equals("DC_IR")) {
								customer.setServiceID_DCIR_code(svcCode);
							} else if (svcKey.equals("DC_NR")) {
								customer.setServiceID_DCNR_code(svcCode);
							} else if (svcKey.equals("DC_BIR")) {
								customer.setServiceID_DCBIR_code(svcCode);
							} else if (svcKey.equals("DC_IB")) {
								customer.setServiceID_DCIB_code(svcCode);
//							} else {
//								LOGGER.error(new StringBuffer(logToken).
//											append(" Invalid Service Key from SNCODE2 table - SvcKey= ").append(svcKey));
							}
//						} else {
//							LOGGER.error(new StringBuffer(logToken).append(" - NULL Service Key from SNCODE2 table: ").append(svcKey));
						} //(svcKey != null
					} // while
				
					if (svcKey != null) {
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" SNCodes retrieved successfully "));
					}
				} // customer != null
				
			} else {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving Sncodes from DB - Add entry into Error table"));

	     		//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			    RC = rptErrorDAO.insertRecord(tblSncXfer.getDBMsg());
			}
		} catch (Exception e) {
			dbrc = "F_C";
//			session.setAttribute("DBRC", "F_C");
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" Sncodes NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
			e.printStackTrace();

     		//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
		    RC = rptErrorDAO.insertRecord(e.getMessage());
		}

		session.setAttribute("DBRC", dbrc);
		session.setAttribute("code2keys", code2Keys);
		session.setAttribute("customer", customer);

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" Exiting performSncodesLookup"));

		return code2Keys;
		
	} //performSncodeLookup


	private Properties retrieveServices(HandlerHelper helper, Circle circ) {
		
		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String reportJNDIName = null;
		String centralJNDIName = null;
		String circle = null;
		String coid = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			circle = helper.getCircle();
			coid = helper.getCoId();
			reportJNDIName = helper.getReportJNDIName();
			centralJNDIName = helper.getCentralJNDIName();
		}
		
		// get service_key and service_code from TBL_SNCODE2
		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append("Entered retrieveServices - Attempting to lookup IVR_SERVICES SP"));

		String dbrc = null;
		int RC = -1;
		String ivrSvcs = null;
		IVRSvcsXfer ivrSvcsXfer = null;
		Properties svcsProp = null;
		Properties code2Keys = null;

		IVRServicesDAO ivrSvcsDAO = null;

		try {
			ivrSvcsDAO = new IVRServicesDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());
		} catch (SQLException sqle) {
			dbrc = "F_C";
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB: ").append(sqle.getMessage()));
			sqle.printStackTrace();
//			return  svcsProp;
		}
		int iCoId = -1;
		if ( (coid != null) && (coid.length() !=0) ) {
			iCoId = new Integer(coid).intValue();
		}
		Customer customer = (Customer) session.getAttribute("customer");		
		try {
			ivrSvcsXfer = ivrSvcsDAO.executeSP(circle, iCoId);
			dbrc = ivrSvcsXfer.getDBRC();

			if (dbrc.equals("S")){
				// get serviceCodes to ServiceKey mapped properties object from session
				code2Keys = (Properties) session.getAttribute("code2keys");
				Enumeration en = code2Keys.keys();
				
				ivrSvcs =  ivrSvcsXfer.getServices();
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Services retrieved successfully - Services= ").append(ivrSvcs));
				
				// build Properties object from services 
				// services is formatted as -  "1|a,3|a,5|a,7|d,8|a,9|a,10|a,11|a,14|d,15|a,24|a�"
				svcsProp = new Properties();
				String svcId = null;
				String svcFlag = null;
				String svcKey = null;
				int index = -1;
				
				if ( (ivrSvcs != null) && (ivrSvcs.length() != 0) ) {
					StringTokenizer st = new StringTokenizer(ivrSvcs, ",");
					while (st.hasMoreElements()) {
						String svcToken = st.nextToken().trim();
						if ( (svcToken != null) && (svcToken.length() != 0)  ) {
							index = svcToken.indexOf("|");
							if (index != -1) {
								svcId = svcToken.substring(0, index);
								svcFlag = svcToken.substring(index+1);
								svcsProp.put(svcId, svcFlag);	
								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(" svcId= ").append(svcId).append(" svcFlag= ").append(svcFlag));

								if (svcId != null) {
									svcKey = code2Keys.getProperty(svcId);
								} else {
									LOGGER.error(new StringBuffer(logToken).append(" - NULL Service Id: ").append(svcId));
								}

								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(" svcKey= ").append(svcKey));

								if (svcKey != null) {
									if (svcKey.equals("DC_STD")) {
										customer.setServiceID_DCSTD(svcFlag);
									} else if (svcKey.equals("DC_ISD")) {
										customer.setServiceID_DCISD(svcFlag);
									} else if (svcKey.equals("DC_HA")) {
										customer.setServiceID_DCHA(svcFlag);
									} else if (svcKey.equals("DC_PH")) {
										customer.setServiceID_DCPH(svcFlag);
									} else if (svcKey.equals("DC_IR")) {
										customer.setServiceID_DCIR(svcFlag);
									} else if (svcKey.equals("DC_NR")) {
										customer.setServiceID_DCNR(svcFlag);
									} else if (svcKey.equals("DC_BIR")) {
										customer.setServiceID_DCBIR(svcFlag);
									} else if (svcKey.equals("DC_IB")) {
										customer.setServiceID_DCIB(svcFlag);
									}
								} //svcKey != null
							}
						}
					} // while
				}

				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" # of service pairs in properties object= ").append(svcsProp.size()));
			} else {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving Services from DB - Add entry into Error table"));

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(ivrSvcsXfer.getDBMsg());
			}
		} catch (Exception e) {
			dbrc = "F_C";
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" Services NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
			e.printStackTrace();

			//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			RC = rptErrorDAO.insertRecord(e.getMessage());
		}

		session.setAttribute("DBRC", dbrc);		
		session.setAttribute("customer", customer);
		
		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));

			LOGGER.debug(new StringBuffer(logToken).append("Exiting retrieveServices"));
		}

		return svcsProp;
		
	} //retrieveServices

	

}
