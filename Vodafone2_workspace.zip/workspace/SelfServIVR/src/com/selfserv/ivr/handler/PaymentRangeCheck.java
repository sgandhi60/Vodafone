/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.selfserv.ivr.data.Circle;
/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Function:
 *            Determine Determine if the CC payment offfered meets the Cirlce Min & Max requirements
 *            
 *            
 *            
 *   Inputs:
 *            This handler will used the following session variables:
 *            
 *                circle.getCcMinAmt()  
 *                circle.getCcMaxAmt()
 *                
 *   Outputs:
 *            This handler will set the following session variables:
 *            
 *               prcResult - true or false
 *                
 *         
 * 
 */
public class PaymentRangeCheck extends HttpServlet implements Servlet{
	
	private static final long serialVersionUID = 1L;
	
	private static Logger LOGGER = Logger.getLogger(PaymentRangeCheck.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering PaymentRangeCheck"));

		// Get Customer Class from Session
		Circle circle = (Circle) session.getAttribute("circle");

		// Output variable
		String prcResult = "true";

		// Set session variable for reply
		session.setAttribute("prcResult", prcResult);

		try {
			Float floatZero = Float.valueOf("0");
			Float minVal = Float.valueOf(circle.getCcMinAmt());
			Float maxVal = Float.valueOf(circle.getCcMaxAmt());
			Float payAmt = Float.valueOf((String)session.getAttribute("ccAmountEntered"));


			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("circle.getCcMinAmt() = ").append(circle.getCcMinAmt()));
				LOGGER.debug(new StringBuffer(logToken).append("circle.getCcMaxAmt() = ").append(circle.getCcMaxAmt()));
				LOGGER.debug(new StringBuffer(logToken).append("payAmt = ").append(payAmt));
			}       


			if (payAmt.equals(floatZero))
				prcResult = "false";
			else if (payAmt >= minVal && payAmt <= maxVal)
				prcResult = "true";
			else
				prcResult = "false";

		}catch(Exception ex){
			LOGGER.info(new StringBuffer(logToken).append(ex.getMessage()));
			session.setAttribute("prcResult", prcResult);
			return;  
		}
		
		session.setAttribute("prcResult", prcResult);
		
		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("prcResult = "+prcResult));
			LOGGER.info(new StringBuffer(logToken).append("Exiting PaymentRangeCheck"));
		}

		return;
	}
	

}
