/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.data.HandlerHelper;
import com.selfserv.ivr.selfservdao.central.IVRCallDetailsDAO;
import com.selfserv.ivr.selfservdao.central.IVRCallDetailsXfer;
import com.selfserv.ivr.selfservdao.central.IVRMainDAO;
import com.selfserv.ivr.selfservdao.central.IVRMainXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.TableBillDAO;
import com.selfserv.ivr.selfservdao.local.TableBillXfer;
import com.selfserv.ivr.selfservdao.local.TableGenDAO;
import com.selfserv.ivr.selfservdao.local.TableGenXfer;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class GetBillingInfo extends HttpServlet implements Servlet{

	private static final long serialVersionUID = 1L;

	private static Logger LOGGER = Logger.getLogger(GetBillingInfo.class);

 	public GetBillingInfo() {
		super();
	}   	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws ServletException, IOException {


		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" Entering GetBillingInfo"));

		Properties callProp = null;			// properties key-value pair
		String localJNDIName = null;		// JNDI name for Local DB
		String reportJNDIName = null;		// JNDI name for Report DB
		String centralJNDIName = null;		// JNDI name for Central DB
		Customer customer = null;
		Circle circ = null;
		String mobile = null;				// mobile number
		String circle = null;				// Circle name 0001.....0023		String dbrc = null;
		int RC = -1;
//		TableBillPymtXfer tblBillPymtXfer = null;
		HandlerHelper helper = null;
		String dbrc = null;						// DB return code

		try{
			customer = (Customer)session.getAttribute("customer");

			mobile = (String) customer.getMobile();
			callProp = (Properties) session.getAttribute("callProp");
			circ = (Circle) session.getAttribute("circle");
			localJNDIName = circ.getLocalJNDIName();
			reportJNDIName = circ.getReportJNDIName();
			circle = circ.getCircle();
			customer.getCustCode();

			centralJNDIName = callProp.getProperty("centralJNDIName");

			// instantiate helper class object and initialize it
			helper = new HandlerHelper();

			if (helper != null) {
				helper.setCallid(callid);
				helper.setLocalJNDIName(localJNDIName);
				helper.setReportJNDIName(reportJNDIName);
				helper.setCentralJNDIName(centralJNDIName);
				helper.setLogToken(logToken);
				helper.setMobile(mobile);
				helper.setSession(session);
				helper.setTestCall(testCall);
				helper.setCircle(circle);
			}
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
		}

		if (callProp.getProperty("dBhandlerGetBillingInfo").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetBillingInfo=false => using No backend"));

			customer.setBillCurrentOutstandingAmt(1212);
			customer.setBillPayableByDate("08012008");
			customer.setBillUnbilledAmt(989);
			customer.setBillLastPaymentAmt(1500);
			customer.setBillLastPaymentDate("07012008");
			customer.setBillCreditLimitAmt(100000);
			customer.setBillDepositRequiredAmt(100);
			customer.setBillBillingCycle("071508");
			customer.setBillBillEmail("ceo@vodafone.india.com");
			customer.setBillBillZipCode("400076");

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetBillingInfo=true => Attempting to retrieve call details"));
				LOGGER.debug(new StringBuffer(logToken).append(" - Accessing CDB first"));
			}

			// first query CDB, if no connection to CDB or customer not found in CDB,
			// then query LDB
			dbrc = queryCDB(customer, mobile, callid, circ, centralJNDIName, testCall, logToken);	//access CDB 

			if ( !dbrc.equals("S") ){

				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" - Accessing LDB next"));

				//	Accessing LDB because a CDB match was not found (i.e. DB not available, record not found, or other error)
				dbrc = queryLDB(helper, customer);		//access LDB
				if (!dbrc.equals("S")){
					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" - BillingInfo NOT retrieved succesffully from CDB or LDB"));
				}else {
					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" - BillingInfo retrieved succesffully"));
				}
			}

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer for Billing:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - coid=").append(customer.getCoid()));
			LOGGER.debug(new StringBuffer(logToken).append(" - cust_id=").append(customer.getCust_id()));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(customer.getMobile()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Current Outstanding Amount: ").append(customer.getBillCurrentOutstandingAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Payable By Date : ").append(customer.getBillPayableByDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Unbilled Amount: ").append(customer.getBillUnbilledAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Last Payment Amountt: ").append(customer.getBillLastPaymentAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Last Payment Date: ").append(customer.getBillLastPaymentDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Credit Limit Amount: ").append(customer.getBillCreditLimitAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Deposit Required Amount: ").append(customer.getBillDepositRequiredAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Billing Cycle: ").append(customer.getBillBillingCycle()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Bill Email: ").append(customer.getBillBillEmail()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Bill ZipCode: ").append(customer.getBillBillZipCode()));

			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting GetBillingInfo"));
		}


		return;
	}


	private String queryCDB(Customer customer, String mobile, String callid, Circle circ, String centralJNDIName, boolean testCall, String logToken){

		String circle = circ.getCircle();

		if (testCall) 
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered queryCDB()"));

		IVRMainDAO ivrMainDAO = null;
		IVRMainXfer ivrMainXfer = null;
		String dbrc = null;
		
		if (customer.isIvrMainCalled()) {
			
			dbrc = "S";
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" IVRMainDAO already called; not executing SP."));
			
		} else {

			try {
				ivrMainDAO = new IVRMainDAO(centralJNDIName, callid, mobile, testCall, circ.getSpPackageName());				//-------------Central DB Access						
				ivrMainXfer = ivrMainDAO.executeSP(circle,mobile);  				//-------------Query Stored Procedure IVR_Main
			} catch (Exception e) {
				ivrMainXfer.setDBRC("F_C");
				LOGGER.error(new StringBuffer(logToken).append(" - Error getting a connection to the CDB - IVRMain: "));
			}
	
			dbrc = ivrMainXfer.getDBRC();
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" DBRC from SP:IVRMain: ").append(dbrc));
			if (dbrc.equals("S")) {
				CustomerDetails.setCustomerDetails(customer, ivrMainXfer, null);
				customer.setIvrMainCalled(true);
			}
		}
		
		if (dbrc.equals("S")) {
			// proceed to get IVRCallDetails
			if (customer.isIvrCallDetailsCalled()) {
				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" IVRCallDetailsDAO already called; not executing SP."));
			} else {
				int coid = Integer.parseInt(customer.getCoid());
				int cust_id = Integer.parseInt(customer.getCust_id());
				IVRCallDetailsXfer callDetailsXfer = null;
	
				try {
					IVRCallDetailsDAO ivrCallDetailsDAO = new IVRCallDetailsDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());	
					callDetailsXfer = ivrCallDetailsDAO.executeSPForBilling(circle, coid, cust_id);  //Query Stored Procedure ivr_call_details
				} catch (Exception e) {
					callDetailsXfer.setDBRC("F_C");
					LOGGER.error(new StringBuffer(logToken).append(" - Error getting a connection to the CDB - IVRCallDetails: "));
				}
	
				dbrc = callDetailsXfer.getDBRC();
				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" DBRC from SP- IVRCallDetails: ").append(dbrc));
	
				if (dbrc.equals("S")){
					CustomerDetails.setCustomerDetails(customer, null, callDetailsXfer);
					customer.setIvrCallDetailsCalled(true);
				}
			}
		} else {																			//Customer not found or couldn't be retreived from CDB
			customer.setMobile(mobile);
			customer.setCallerFound("N");
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values from CDB and set in customer:"));

			LOGGER.debug(new StringBuffer(logToken).append(" - coid=").append(customer.getCoid()));
			LOGGER.debug(new StringBuffer(logToken).append(" - cust_id=").append(customer.getCust_id()));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(customer.getMobile()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Current Outstanding Amount: ").append(customer.getBillCurrentOutstandingAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Payable By Date : ").append(customer.getBillPayableByDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Unbilled Amount: ").append(customer.getBillUnbilledAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Last Payment Amountt: ").append(customer.getBillLastPaymentAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Last Payment Date: ").append(customer.getBillLastPaymentDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Credit Limit Amount: ").append(customer.getBillCreditLimitAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Deposit Required Amount: ").append(customer.getBillDepositRequiredAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Billing Cycle: ").append(customer.getBillBillingCycle()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Bill Email: ").append(customer.getBillBillEmail()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Bill ZipCode: ").append(customer.getBillBillZipCode()));

			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC=").append(dbrc));

			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting queryCDB()"));
		}

		return dbrc;		 
	}//queryCDB

	private String queryLDB(HandlerHelper helper, Customer customer){
		
		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String localJNDIName = null;
		String reportJNDIName = null;
		String circle = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			localJNDIName = helper.getLocalJNDIName();
			reportJNDIName = helper.getReportJNDIName();
			circle = helper.getCircle();
		}

		if (testCall) {
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered queryLDB()"));

			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
		}

		TableBillDAO tblBillDAO = null;
		TableBillXfer tblBillXfer = null;

		String dbrc = null;
		String msg = null;
		int RC = -1;

		try {
			tblBillDAO = new TableBillDAO(localJNDIName, mobile, callid, testCall);
		} catch (SQLException sqle) {
			dbrc = "F_C";
			session.setAttribute("DBRC", dbrc);
			msg = sqle.getMessage();
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_BILL: ").append(sqle.getMessage()));
			sqle.printStackTrace();
			return dbrc;
		}

		try {
			// get billingInfo from TBL_BILL
			tblBillXfer = tblBillDAO.findRecord(mobile);
			dbrc = tblBillXfer.getDBRC();

			String dueDate = null;
			String lastPymtDate = null;
			
			if (dbrc.equals("S")){			
				customer.setCust_id(Integer.toString(tblBillXfer.getCust_id()));
				customer.setCoid(tblBillXfer.getCoid());

				SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
				if (tblBillXfer.getDueDate() != null) {
					dueDate = formatter.format(tblBillXfer.getDueDate());
				}
				
				if (tblBillXfer.getLastPayDate() != null) {
					lastPymtDate = formatter.format(tblBillXfer.getLastPayDate());
				}
				
				customer.setBillCurrentOutstandingAmt(tblBillXfer.getCurOutStandAmt());
				customer.setBillPayableByDate(dueDate);
				customer.setBillUnbilledAmt(tblBillXfer.getUnBilledAmt());
				customer.setBillLastPaymentAmt(tblBillXfer.getLastpayment());;
				customer.setBillLastPaymentDate(lastPymtDate);
				customer.setBillCreditLimitAmt(tblBillXfer.getCreditLimit());
				customer.setBillBillingCycle(tblBillXfer.getBillCycle());

				// get email and pincode from TBL_GEN
				getEmailPinCode(helper, customer);

				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" BillingInfo retrieved successfully"));

			} else {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving BillingInfo from LDB - Add entry into Error table"));

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(tblBillXfer.getDBMsg());
			}
		} catch (Exception e) {
			dbrc = "F_C";
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" BillingInfo NOT retrieved from LDB - Add entry into Error table - ").append(e.getMessage()));
			e.printStackTrace();

			//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			RC = rptErrorDAO.insertRecord(e.getMessage());
		}

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values from LDB and set in customer:"));

			LOGGER.debug(new StringBuffer(logToken).append(" - coid=").append(customer.getCoid()));
			LOGGER.debug(new StringBuffer(logToken).append(" - cust_id=").append(customer.getCust_id()));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile=").append(customer.getMobile()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Current Outstanding Amount: ").append(customer.getBillCurrentOutstandingAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Payable By Date : ").append(customer.getBillPayableByDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Unbilled Amount: ").append(customer.getBillUnbilledAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Last Payment Amountt: ").append(customer.getBillLastPaymentAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Last Payment Date: ").append(customer.getBillLastPaymentDate()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Credit Limit Amount: ").append(customer.getBillCreditLimitAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Deposit Required Amount: ").append(customer.getBillDepositRequiredAmt()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Billing Cycle: ").append(customer.getBillBillingCycle()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Bill Email: ").append(customer.getBillBillEmail()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Bill ZipCode: ").append(customer.getBillBillZipCode()));

			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC=").append(dbrc));

			LOGGER.debug(new StringBuffer(logToken).append(" - ******* Exiting queryLDB"));
		}

		return dbrc;
	}//queryLDB()

	private void getEmailPinCode(HandlerHelper helper, Customer customer) {

		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String localJNDIName = null;
		String reportJNDIName = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			localJNDIName = helper.getLocalJNDIName();
			reportJNDIName = helper.getReportJNDIName();
		}
		
		String dbrc = null;
		int RC = -1;
		String msg = null;

		// get birthdate from TBL_GEN for this mobile
		if (testCall) 
			LOGGER.info(new StringBuffer(logToken).append(" Attempting to retrieve email and Pincode"));

		if (customer.isTableGenCalled()) {
			dbrc = "S";
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" TableGenDAO already called; not executing again."));
		} else {
			TableGenDAO tblGenDAO = null;

			try {
				tblGenDAO = new TableGenDAO(localJNDIName, mobile, callid, testCall);				
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				msg = sqle.getMessage();
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_GEN: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try { // retrieve email and pincode for this mobile #
				TableGenXfer tblGenXfer = tblGenDAO.findRecord(mobile);
				dbrc = tblGenXfer.getDBRC();

				if (dbrc.equals("S")){
					String pinCode = tblGenXfer.getPinCode();

					customer.setBillBillEmail(tblGenXfer.getEmail());
					if (pinCode != null) {
						customer.setBillBillZipCode(pinCode.substring(0, 6));
					} else {
						customer.setBillBillZipCode(null);
					}

					customer.setTitle(tblGenXfer.getTitle());
					customer.setFirstName(tblGenXfer.getFname());
					customer.setLastName(tblGenXfer.getLname());
					customer.setAddress1(tblGenXfer.getAddr1());
					customer.setAddress2(tblGenXfer.getAddr2());
					customer.setAddress3(tblGenXfer.getAddr3());
					customer.setCity(tblGenXfer.getCity());
					
//					customer.setPrgcode(tblGenXfer.getPrgcode());
					customer.setCustCode(tblGenXfer.getCustcode());
					customer.setCoid(tblGenXfer.getCoid());

					String birthDate = null;
					SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
					if (tblGenXfer.getBirthDate() != null) {
						birthDate = formatter.format(tblGenXfer.getBirthDate());
					}
					customer.setBirthDate(birthDate);			

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" data retrieved successfully "));
					
					customer.setTableGenCalled(true);

				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving data from DB - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(tblGenXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" BirthDate NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
		} // else
		session.setAttribute("DBRC", dbrc);
		return;

	} //getEmailPinCode


}
