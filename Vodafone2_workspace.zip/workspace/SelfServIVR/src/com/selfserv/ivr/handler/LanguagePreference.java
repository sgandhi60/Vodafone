package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.TablePrefDAO;

/**
 * Servlet implementation class for Servlet: PreferredLang
 *
 */
 public class LanguagePreference extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* 
     * Handler LanguagePreference - update the preferred language to dbLang in TBL_PREF and  customer.prefLang
		IN:  customer.mobile, session.dbLang
		OUT: session.DBRC
		OUT: customer.prefLang
	 */
	 
	private static Logger LOGGER = Logger.getLogger(LanguagePreference.class);
	
	public LanguagePreference() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Lookup LDB and then CDB
		 HttpSession session = req.getSession(true);  // get session from Servlet request, created if not existed yet
		 Properties callProp = null;
		 Customer customer = null;
		 String localJNDIName = null;
		 String dbLang = null;
		 
		 String callid = (String) session.getAttribute("callid");
		 
		 customer = (Customer)session.getAttribute("customer");
		 
		 String mobile = customer.getMobile();

		 boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

			//create the log Token for later use, use StringBuffer to reduce number
			// of String objects
		 String logToken = new StringBuffer("[").append(callid).append("]").toString();

		 try{
			 dbLang = (String) session.getAttribute("dbLang");
			 
			 
			 Circle circ = (Circle)session.getAttribute("circle");	
			 localJNDIName = circ.getLocalJNDIName();				
		 
			 callProp = (Properties) session.getAttribute("callProp");
			 
			 if (testCall) {
//				 LOGGER.info(new StringBuffer(logToken).append(" - **************************************************"));
				 LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered LanguagePreference Servlet *******"));
//				 LOGGER.info(new StringBuffer(logToken).append(" - **************************************************"));
				 LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
				 LOGGER.debug(new StringBuffer(logToken).append(" - prefLang: ").append(dbLang));
				 LOGGER.debug(new StringBuffer(logToken).append(" - callProp: ").append(", callProp: ").append(callProp));
			 }
		 } catch(Exception e){
				LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e));
		 }
		 
		 //if (backendDBAccess.equals("false")){//No DB ****** DUMMY dbCType ******
		 if (callProp.getProperty("dBhandlerLanguagePreference").equals("false")){//No DB ****** DUMMY dbCType ******
			 customer.setPrefLang(dbLang);
			 session.setAttribute("customer", customer);
			 session.setAttribute("DBRC", "S");
			 return;
		 }else{//Querying the DB's
			 try {
				TablePrefDAO tblPrefDAO = new TablePrefDAO(localJNDIName, mobile, callid, testCall);
				int result = 0;
				if (customer.getPrefLang() == null) {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - inserting language preference"));
					result = tblPrefDAO.insertRecord(mobile, dbLang, customer.getDbCType());
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" - updating language preference"));					
					result = tblPrefDAO.updateRecord(mobile, dbLang);
				}
				if (result>=1){//correct 
					 customer.setPrefLang(dbLang);
					 customer.setServiceFlag_DCLC("A");
					 session.setAttribute("customer", customer);
					 session.setAttribute("DBRC", "S");					
				}else{
					 session.setAttribute("DBRC", "F_C");										
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LOGGER.error(new StringBuffer(logToken).append("Exception caught: ").append(e.getMessage()));
				//e.printStackTrace();
			}
		 }
		 if (testCall) {
			 LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			 LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCLC: ").append(customer.getServiceFlag_DCLC()));
			 LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));

			 LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting LanguagePreference Servlet *******"));
		 }
	}//doGet() 	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}   	  	    
}