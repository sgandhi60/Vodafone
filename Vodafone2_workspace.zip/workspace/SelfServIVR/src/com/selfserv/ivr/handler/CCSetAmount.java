/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.selfserv.ivr.data.Customer;
import org.apache.log4j.Logger;

/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 * Move
 * 
 *      customer.cmDepositRequired
 *      
 * To     
 *      
 *      ccCallFromRoamingDepAmt 
 */
public class CCSetAmount extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(CCSetAmount.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering CCSetAmount"));

		// Get session variables	
		Customer customer = (Customer) session.getAttribute("customer");

		String ccCallFromRoamingDepAmt = null;

		ccCallFromRoamingDepAmt = String.valueOf(customer.getCmDepositRequired());

		// Set session variable for reply
		session.setAttribute("ccCallFromRoamingDepAmt", ccCallFromRoamingDepAmt);

		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("ccCallFromRoamingDepAmt = "+ccCallFromRoamingDepAmt));  
			LOGGER.info(new StringBuffer(logToken).append("Exiting CCSetAmount"));
		}

		return;
	}
}
