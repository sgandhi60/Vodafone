/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Move will move currencyVarB to currencyVarA
 * 
 *   Add, Subtract and Multiply will folloe the format
 * 
 *      currencyVarA = currencyVarB  '+' | '-' | '*' currencyVarC
 */
public class CLI extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(CLI.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering CLI"));

		// Get the ANI form the session	
		String ani = (String) session.getAttribute("ANI");
		String cliCmd = (String) session.getAttribute("cliCmd");

		// Log the sttributes
		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("ani = "+ani));
			LOGGER.debug(new StringBuffer(logToken).append("cliCmd = "+cliCmd));
		}

		String cliRc = "cliOK";     // Initialize to Success
		// Determin command to perform
		if (cliCmd.equals("aniExist")){
			if (ani == null){
				cliRc = "cliNoCli";   //  No CLI
			}else if (ani.length() < 10){
				cliRc = "cliNoCli";   //  No CLI
			} else{	
				String cliReturned = ani.substring((ani.length() - 10));
				session.setAttribute("cliReturned", cliReturned);
				if (testCall){
					LOGGER.debug(new StringBuffer(logToken).append("cliReturned = "+cliReturned));  
				}
			}
		}else if (cliCmd.equals("aniParse")){
			// Add logic here for aniParse
		}else{
			cliRc = "cliBadCmd";    // Set rc to 1 (Unrecognized cliCmd)
		}



		// Set session variable for reply
		session.setAttribute("cliRc", cliRc);

		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("cliRc = "+cliRc));  
			LOGGER.info(new StringBuffer(logToken).append("Exiting CLI"));
		}

		return;
	}
	

}
