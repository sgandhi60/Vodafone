/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.data.HandlerHelper;
import com.selfserv.ivr.selfservdao.central.GetMPinDAO;
import com.selfserv.ivr.selfservdao.central.MPinXfer;
import com.selfserv.ivr.selfservdao.local.LogreqDAO;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.VASLogDAO;
import com.selfserv.ivr.selfservdao.misc.CSSServerDAO;
import com.selfserv.ivr.selfservdao.misc.CSSServerReq;
import com.selfserv.ivr.selfservdao.misc.CSSServerResp;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class CSSServer extends HttpServlet implements Servlet{

	private static final String TRANSACTION = "BILLING INFO";

	private static Logger LOGGER = Logger.getLogger(CSSServer.class);

	private static final String BILL_THROUGH_MEDIA_EMAIL = "Email";
	private static final String BILL_THROUGH_MEDIA_COURIER = "Courier";
	private static final String TRANTYPE_DUPBILL_EMAIL = "DupBill Email";
	private static final String TRANTYPE_DUPBILL_COURIER = "DupBill Courier";

 	public CSSServer() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered CSSServer"));

		Customer customer = null;				// customer class 
		String mobile = null;					// mobile number
		Circle circ = null;						// circle clsss that gets populated from the properties file
		String circle = null;					// Circle name 0001.....0023
		String dbrc = null;						// DB return code
		Properties callProp = null;				// properties key-value pair
		String localJNDIName = null;			// JNDI name for local DB
		String reportJNDIName = null;			// JNDI name for report DB
		String media = null;					// media for Dup Bill - email or courier
		String month = null;
		String year = null;
		String landline = null;
		String pgmCode = null;
		String tranType = null;					// DupBill Email or DupBill Courier
		String mpin = null;
		String CSSCmd = null;
		String llTrue = null;
		boolean landLineFlag = false;
		HandlerHelper helper = null;

		try{
			callProp = (Properties) session.getAttribute("callProp");
			customer = (Customer)session.getAttribute("customer");

			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			CSSCmd = (String) session.getAttribute("CSSCommand");
			mpin = (String) session.getAttribute("mpin");
			llTrue = (String) session.getAttribute("llTrue");
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - CSSCmd: ").append(CSSCmd));
			
			if ( (CSSCmd != null) && (CSSCmd.length() == 6) ) {
				if (CSSCmd.substring(0,5).compareToIgnoreCase("DBILL") == 0 ) {
					month = ((String) session.getAttribute("Month"));
					year = ((String) session.getAttribute("Year"));
				}
			}

			localJNDIName = circ.getLocalJNDIName();
			reportJNDIName = circ.getReportJNDIName();
			mobile = customer.getMobile();
			pgmCode = customer.getPrgcode();
			landline = customer.getLandlineNumber();
			if (llTrue != null && llTrue.equals("yes")) {
				landLineFlag = true;
			} else {
				landLineFlag = false;
			}
			
			// instantiate helper class object and initialize it
			helper = new HandlerHelper();
			
			if (helper != null) {
				helper.setCallid(callid);
				helper.setCallProp(callProp);
				helper.setCirc(circ);
				helper.setCircle(circle);
				helper.setLandline(landline);
				helper.setLocalJNDIName(localJNDIName);
				helper.setReportJNDIName(reportJNDIName);
				helper.setLogToken(logToken);
				helper.setMedia(media);
				helper.setMobile(mobile);
				helper.setMonth(month);
				helper.setYear(year);
				helper.setPgmCode(pgmCode);
				helper.setSession(session);
				helper.setTestCall(testCall);
				helper.setTranType(tranType);
			}
			
			// get mpin from customer or SP IVR_MPIN
			if (mpin == null)
				mpin = retrieveMpin(helper, circ);

		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session and customer: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - CSSCmd: ").append(CSSCmd));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - mpin: ").append(mpin));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
			LOGGER.debug(new StringBuffer(logToken).append(" - pgmCode: ").append(pgmCode));
			LOGGER.debug(new StringBuffer(logToken).append(" - landLineNumber: ").append(landline));
			LOGGER.debug(new StringBuffer(logToken).append(" - landLineFlag: ").append(landLineFlag));
			LOGGER.debug(new StringBuffer(logToken).append(" - Month: ").append(month));
			LOGGER.debug(new StringBuffer(logToken).append(" - Year: ").append(year));
		}

		if (callProp.getProperty("dBhandlerCSSServer").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerCSSServer=false => using No backend"));

			if ( (CSSCmd != null) && (CSSCmd.length() != 0) ) {
				if (CSSCmd.compareToIgnoreCase("CRSS") == 0 ) {
					session.setAttribute("cssSessionExists", "true");
				} else if (CSSCmd.compareToIgnoreCase("CLSS") == 0 ) {
					session.setAttribute("cssSessionExists", "false");
				}
			}
			customer.setMpin("12345678");

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerCSSServer=true => Attempting to work with CSSServer"));

			CSSServerReq cssReq = null;
			CSSServerResp cssResp = null;
			String cssRespMsg = null;
			CSSServerDAO cssDao = null;
			int RC = -1;
			String url = null;
			String uid = null;
			String pwd = null;
			String cTimeout = null;
			String sTimeout = null;

			try {
				// prepare req object
				cssReq = new CSSServerReq();

				if (cssReq != null) {
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - CSSReq Object is NOT null"));
					}
					cssReq.setMobileNumber(mobile);
					cssReq.setCircleCode(circle);
					cssReq.setMpin(mpin);
					cssReq.setLandline(landLineFlag);
					cssReq.setLandlineNumber(landline);
					cssReq.setProgramCode(pgmCode);
					cssReq.setTransaction(TRANSACTION);   // set to "BILLING INFO"
					cssReq.setYear(year);
					cssReq.setMonth(month);
				}
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - CSSReq Object set successfully"));
				}

				// get configurable fields from global.properties
				Properties globalProp = (Properties) session.getServletContext().getAttribute("globalProp");

				if (globalProp != null) {
					url = (String) globalProp.getProperty("cssserver.url");
					uid = (String) globalProp.getProperty("cssserver.userid");
					pwd = (String) globalProp.getProperty("cssserver.password");
					cTimeout = (String) globalProp.getProperty("cssserver.ConnectionTimeout");
					sTimeout = (String) globalProp.getProperty("cssserver.SocketTimeout");
				}
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - URL: ").append(url));
					LOGGER.debug(new StringBuffer(logToken).append(" - UID: ").append(uid));
					LOGGER.debug(new StringBuffer(logToken).append(" - PWD: ").append(pwd));
					LOGGER.debug(new StringBuffer(logToken).append(" - Socket Timeout: ").append(sTimeout));
					LOGGER.debug(new StringBuffer(logToken).append(" - Connection Timeout: ").append(cTimeout));
					LOGGER.debug(new StringBuffer(logToken).append(" - cssSessionExists: ").append((String)session.getAttribute("cssSessionExists")));
					LOGGER.debug(new StringBuffer(logToken).append(" - cssDao: ").append((CSSServerDAO)session.getAttribute("cssDao")));
				}

				// check whether cssDao object is in session or not
				String cssSessExists = (String)session.getAttribute("cssSessionExists");
				if ( ( (cssSessExists != null) && (cssSessExists.equalsIgnoreCase("true")) ) && 
					 ((CSSServerDAO)session.getAttribute("cssDao") != null) ) {
					cssDao = (CSSServerDAO)session.getAttribute("cssDao");
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" If- cssDao: ").append(cssDao));
				} else {
					cssDao = new CSSServerDAO(reportJNDIName, mobile, callid, url, uid, pwd, cTimeout, sTimeout);
//					cssDao = new CSSServerDAO(reportJNDIName, mobile, callid,, url, uid, pwd, cTimeout, sTimeout, testCall);
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" else - cssDao: ").append(cssDao));
				}
//				} catch (SQLException sqle) {
			} catch (Exception e) {
				dbrc = "F_C";
				session.setAttribute("DBRC",dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB: ").append(e.getMessage()));
				e.printStackTrace();
			}
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - CSSServerDAO created; ").append(cssDao));

			try {
				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" - About to invoke CSSServerDAO method with CSSCmd: ").append(CSSCmd));
				if ( (CSSCmd != null) && (CSSCmd.length() != 0) ) {
					if (CSSCmd.compareToIgnoreCase("CRSS") == 0 ) {
						if (testCall) 
							LOGGER.debug(new StringBuffer(logToken).append(" - About to invoke CSSServerDAO:createSession method with CSSCmd: ").append(CSSCmd));
						cssResp = cssDao.createSession(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("DBILLE") == 0) {
						cssReq.setBillThrough(BILL_THROUGH_MEDIA_EMAIL);
						cssResp = cssDao.duplicateBill(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("DBILLC") == 0) {
						cssReq.setBillThrough(BILL_THROUGH_MEDIA_COURIER);
						cssResp = cssDao.duplicateBill(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("AMPIN") == 0 ) {
						cssResp = cssDao.createMpin(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("CMPIN") == 0 ) {
						cssResp = cssDao.changeMpin(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("AIB") == 0 ) {
						cssResp = cssDao.activateIBill(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("DIB") == 0 ) {
						if (testCall) 
							LOGGER.debug(new StringBuffer(logToken).append(" - About to invoke CSSServerDAO:deactivateIBill method with CSSCmd: ").append(CSSCmd));
						cssResp = cssDao.deactivateIBill(cssReq);
					} else if (CSSCmd.compareToIgnoreCase("CLSS") == 0 ) {
						cssResp = cssDao.dropSession(cssReq);
					}
				}

				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" - cssResp: ").append(cssResp));

					if (cssResp == null) {
					RC = -1;
					cssRespMsg = " - INVALID ACTION - ";

					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken)
						.append("CSSCommand= ").append(CSSCmd).append(" CSSRespMsg= ").append(cssRespMsg));
					}
				} else {
					RC = cssResp.getCode();
					cssRespMsg = cssResp.getMessage();

					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken)
						.append("CSSCommand= ").append(CSSCmd)
						.append(" CSS Server Response Code: " ).append(RC)
						.append(" CSS Server Response Msg: " ).append(cssRespMsg));
					}
				}

				if (RC == 0) {
					dbrc = "S";
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" CSSServer process ended successfully "));

					if (CSSCmd.compareToIgnoreCase("CRSS") == 0 ) {
						session.setAttribute("cssSessionExists", "true");
						session.setAttribute("cssDao", cssDao);
					} else if (CSSCmd.compareToIgnoreCase("DBILLE") == 0) {
						helper.setTranType(TRANTYPE_DUPBILL_EMAIL);
						helper.setMedia(BILL_THROUGH_MEDIA_EMAIL);
						// insert record into TBL_LOGREQ
						insertForDupBill(helper);
					} else if (CSSCmd.compareToIgnoreCase("DBILLC") == 0 ) {
						helper.setTranType(TRANTYPE_DUPBILL_COURIER);
						helper.setMedia(BILL_THROUGH_MEDIA_COURIER);
						// insert record into TBL_LOGREQ
						insertForDupBill(helper);
					} else if (CSSCmd.compareToIgnoreCase("AIB") == 0 ) {
						// insert record into TBL_VASLOG
						insertForItemizedBill(helper);
					} else if (CSSCmd.compareToIgnoreCase("DIB") == 0 ) {
						// insert record into TBL_VASLOG
						insertForItemizedBill(helper);
					} else if (CSSCmd.compareToIgnoreCase("CLSS") == 0 ) {
						session.setAttribute("cssSessionExists", "false");
						session.removeAttribute("cssDao");
					}
				} else if (RC == 999) { //Timeout or ...
					dbrc = "F_C";
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" CSSServer process ended with Timeout "));
					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(cssRespMsg);
				} else {
					dbrc = "F_NF";
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" CSSServer process ended with Not Found "));
					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(cssRespMsg);
				}
			} catch(Exception e) {
				dbrc = "F_C";
				LOGGER.error(new StringBuffer(logToken).append(" CSSServer process ended with Exception - ").append(e.getMessage()));
				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				if (cssRespMsg == null) 
					cssRespMsg = e.getMessage();
				RC = rptErrorDAO.insertRecord(cssRespMsg);
			}


			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - MPin in customer: ").append(customer.getMpin()));
			LOGGER.debug(new StringBuffer(logToken).append(" - MPin in session: ").append((String) session.getAttribute("mpin")));
			LOGGER.debug(new StringBuffer(logToken).append(" - cssSessionExists: ").append((String)session.getAttribute("cssSessionExists")));
			LOGGER.debug(new StringBuffer(logToken).append(" - cssDao: ").append((CSSServerDAO)session.getAttribute("cssDao")));
			LOGGER.debug(new StringBuffer(logToken).append(" - CSSCommand: ").append((String)session.getAttribute("CSSCommand")));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCDB: ").append(customer.getServiceFlag_DCDB()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting CSSServer"));
		}


		return;
	}
	

	private String retrieveMpin(HandlerHelper helper, Circle circ) {
		
		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		Properties callProp = null;
		String mobile = null;
		String callid = null;
		String circle = null;
		String reportJNDIName = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			callProp = helper.getCallProp();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			circle = helper.getCircle();
			reportJNDIName = helper.getReportJNDIName();
		}

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entered CSSSErver:retrieveMPIN() - Attempting to retrieve MPIN"));

		String dbrc = null;
		int RC = -1;
		String centralJNDIName = null;
		MPinXfer mpinXfer = null;
		String mPin = null;

		Customer customer = (Customer) session.getAttribute("customer");		
		// get mpin from IVR_MPIN SP
	 	GetMPinDAO mPinDAO = null;

		if (customer != null)
			mPin = customer.getMpin();
		
		if ( (mPin != null) && (mPin.length() != 0) ) {
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" MPin retrieved successfully - customer.mpin= ").append(mPin));
			}
			return mPin;
		} else {
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" MPin does not exist in Customer object - Get it from SP IVR_MPIN"));
			}
			

			try {
				centralJNDIName = callProp.getProperty("centralJNDIName");
				mPinDAO = new GetMPinDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return mPin;
			}

			try {
				//msisdn = mobile
				mpinXfer = mPinDAO.executeSP(circle, mobile);
				dbrc = mpinXfer.getDBRC();

				if (dbrc.equals("S")){
					mPin =  mpinXfer.getMPin();
					customer.setMpin(mPin);

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" MPin retrieved successfully - customer.mpin= ").append(mPin));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving MPIN from DB - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(mpinXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" MPin NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

	     		//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			    RC = rptErrorDAO.insertRecord(e.getMessage());
			}

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);		
		}
		
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("exiting CSSSErver:retrieveMpin() "));
		return mPin;
		
	} //retrieveMpin


	private void insertForDupBill(HandlerHelper helper) {

		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String localJNDIName = null;
		String reportJNDIName = null;
		String media = null;
		String landline = null;
		String pgmCode = null;
		String tranType = null;
		String month = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			localJNDIName = helper.getLocalJNDIName();
			reportJNDIName = helper.getReportJNDIName();
			media = helper.getMedia();
			landline = helper.getLandline();
			pgmCode = helper.getPgmCode();
			tranType = helper.getTranType();
			month = helper.getMonth();			
		}

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entered CSSSErver:insertForDupBill() - Attempting to insert record"));
		
		String dbrc = null;
		int RC = -1;
		String email = "N";
		String custCode = null;
		String coId = null;

		LogreqDAO logreqDAO = null;
		
		//insert record in TBL_LOGREQ		
		try {
			logreqDAO = new LogreqDAO(reportJNDIName, mobile, callid, testCall);
		} catch (SQLException sqle) {
//		} catch (Exception e) {
			dbrc = "F_C";
			session.setAttribute("DBRC", dbrc);
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to TBL_LOGREQ: ").append(sqle.getMessage()));
			sqle.printStackTrace();
			return;
		}

		try {
			Customer customer = (Customer) session.getAttribute("customer");
			if (customer != null) {
				customer.setServiceFlag_DCDB("A");
				custCode = customer.getCustCode();
				coId = customer.getCoid();
				if ((media!=null) && (media.equalsIgnoreCase(BILL_THROUGH_MEDIA_EMAIL))) 
					email = customer.getBillBillEmail();
			}


			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - CSSServer:insertForDupBill() - Got all attributes from the session"));
				LOGGER.debug(new StringBuffer(logToken).append(" - pgmCode: ").append(pgmCode));
				LOGGER.debug(new StringBuffer(logToken).append(" - custCode#: ").append(custCode));
				LOGGER.debug(new StringBuffer(logToken).append(" - coId: ").append(coId));
				LOGGER.debug(new StringBuffer(logToken).append(" - landline: ").append(landline));
				LOGGER.debug(new StringBuffer(logToken).append(" - tranType: ").append(tranType));
			}

			int rc = logreqDAO.insertRecordForDupBill(landline, pgmCode, media, email, tranType, month, custCode, coId);
			if (rc == 1){//the SMS message was inserted in the DB
				session.setAttribute("DBRC", "S");
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Record successfully inserted in TBL_LOGREQ "));
			}else{
				session.setAttribute("DBRC", "F_C");
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Error inserting record in TBL_LOGREQ - Add entry into Error table"));

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord("Error inserting record in TBL_LOGREQ");
			}
		} catch (Exception e) {
			dbrc = "F_C";
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" Exception inserting record in TBL_LOGREQ - Add entry into Error table - ").append(e.getMessage()));
			e.printStackTrace();

			//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			RC = rptErrorDAO.insertRecord(e.getMessage());
		}

		session.setAttribute("DBRC", dbrc);		

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("exiting CSSSErver:insertForDupBill() "));
		return;

	} //insertForDupBill

	private void insertForItemizedBill(HandlerHelper helper) {
		
		String logToken = null;
		boolean testCall = false;
		HttpSession session = null;
		String mobile = null;
		String callid = null;
		String localJNDIName = null;
		String reportJNDIName = null;
		String landline = null;

		if (helper != null) {
			logToken = helper.getLogToken();
			testCall = helper.isTestCall();
			session = helper.getSession();
			mobile = helper.getMobile();
			callid = helper.getCallid();
			localJNDIName = helper.getLocalJNDIName();
			reportJNDIName = helper.getReportJNDIName();
			landline = helper.getLandline();
		}

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entered CSSSErver:insertForItemizedBill() - Attempting to insert record"));

		String dbrc = null;
		int RC = -1;
		String custType = null;
		String vasService = null;
		String vasServiceReq = null;
		String reqDate = null;
		
		//insert record in TBL_VASLOG		
		VASLogDAO vasLogDAO = null;

		try {
			vasLogDAO = new VASLogDAO(reportJNDIName, mobile, callid, testCall);
		} catch (SQLException sqle) {
//			} catch (Exception e) {
			dbrc = "F_C";
			session.setAttribute("DBRC", dbrc);
			LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to TBL_LOGREQ: ").append(sqle.getMessage()));
			sqle.printStackTrace();
			return;
		}

		try {
			Customer customer = (Customer) session.getAttribute("customer");
			if (customer != null) {
				custType = customer.getDbCType();
			}

			if (session != null) {
				vasService = (String) session.getAttribute("vasService");
				vasServiceReq = (String) session.getAttribute("serviceAction");
//				reqDate = (String) session.getAttribute("TODAY");
			}
			

			Calendar calNow = Calendar.getInstance();
			Date nowDate = calNow.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
			reqDate = formatter.format(nowDate);

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
				LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
				LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
				LOGGER.debug(new StringBuffer(logToken).append(" - landline: ").append(landline));
				LOGGER.debug(new StringBuffer(logToken).append(" - custType: ").append(custType));
				LOGGER.debug(new StringBuffer(logToken).append(" - vasService: ").append(vasService));
				LOGGER.debug(new StringBuffer(logToken).append(" - vasServiceReq: ").append(vasServiceReq));
				LOGGER.debug(new StringBuffer(logToken).append(" - reqDate: ").append(reqDate));
			}

			int result = vasLogDAO.insertRecord(landline, mobile, custType, vasService, vasServiceReq, reqDate);
			if (result == 1){//the record was inserted in the DB
				session.setAttribute("DBRC", "S");
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Record successfully inserted in TBL_VASLOG "));
			}else{
				session.setAttribute("DBRC", "F_C");
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" Error inserting record in TBL_VASLOG - Add entry into Error table"));

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord("Error inserting record in TBL_VASLOG");
			}
		} catch (Exception e) {
			dbrc = "F_C";
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" Exception inserting record in TBL_VASLOG - Add entry into Error table - ").append(e.getMessage()));
			e.printStackTrace();

			//enter exception in the TBL_RPT_ERROR table
			ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
			RC = rptErrorDAO.insertRecord(e.getMessage());
		}

		session.setAttribute("DBRC", dbrc);		

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append(" exiting CSSSErver:insertForItemizedBill() "));
		}
		return;

	} //insertForItemizedBill

}
