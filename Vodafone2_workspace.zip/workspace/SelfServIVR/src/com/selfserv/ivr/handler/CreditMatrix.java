/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.CreditMatrixDAO;
import com.selfserv.ivr.selfservdao.central.CreditMatrixXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class CreditMatrix extends HttpServlet implements Servlet{
	
	private static Logger LOGGER = Logger.getLogger(CreditMatrix.class);

	
 	public CreditMatrix() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering CreditMatrix"));

		Properties callProp = null;			// properties key-value pair
		String centralJNDIName = null;			// JNDI name for Central DB
		String reportJNDIName = null;		    // JNDI name for Report DB
		Customer customer = null;
		Circle circ = null;
		String circle = null;					// Circle name 0001.....0023
		String mobile = null;					// mobile number
		String coId = null;					// contract id
		String custId = null;
		String pgmName = null;				   	// Program Name
		String serv_cd = null;			
		int RC = -1;
		CreditMatrixXfer cmXfer = null;
		String dbrc = null;
		String sAllowed = null;
		float depRequired = 0;
		String creditType = null;

		try{
			customer = (Customer)session.getAttribute("customer");

			mobile = customer.getMobile();
			coId = customer.getCoid();
			custId= customer.getCust_id();
			pgmName = customer.getPrgname();

			callProp = (Properties) session.getAttribute("callProp");
			serv_cd = (String) session.getAttribute("cmservCd");
			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			centralJNDIName = callProp.getProperty("centralJNDIName");
			reportJNDIName = circ.getReportJNDIName();
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - Circle ID: ").append(circle));
			LOGGER.debug(new StringBuffer(logToken).append(" - cust ID: ").append(custId));
			LOGGER.debug(new StringBuffer(logToken).append(" - Contract ID: ").append(coId));
			LOGGER.debug(new StringBuffer(logToken).append(" - Program Name: ").append(pgmName));
			LOGGER.debug(new StringBuffer(logToken).append(" - serv_cd: ").append(serv_cd));
		}

		if (callProp.getProperty("dBhandlerCreditMatrix").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerCreditMatrix=false => using No backend"));

			customer.setCmServiceAllowed("N");
			customer.setCmDepositRequired(100);
			customer.setCreditType("HR");

			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerCreditMatrix=true => Attempting to connect SP IVR_CREDIT_MATRIX"));

			CreditMatrixDAO cmDAO = null;

			try {
				cmDAO = new CreditMatrixDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}
			
			int iCustId = -1;
			if ( (custId != null) && (custId.length() != 0 ) ) {
				iCustId = new Integer(custId).intValue();
			}
			int iCoId = -1;
			if ( (coId != null) && (coId.length() != 0 ) ) {
				iCoId = new Integer(coId).intValue();
			}

			try {
				cmXfer = cmDAO.executeSP(circle, iCustId, iCoId, pgmName, serv_cd);
				dbrc = cmXfer.getDBRC();

				if (dbrc.equals("S")){
					sAllowed =  cmXfer.getSvcAllowed();
					depRequired = cmXfer.getDepReqd();
					creditType = cmXfer.getCreditType();
					
					customer.setCmServiceAllowed(sAllowed);
					customer.setCmDepositRequired(depRequired);
					customer.setCreditType(creditType);
					customer.setCreditMatrixCalled(true);
					
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Credit MAtrix retrieval successful - Service Allowed= ").append(sAllowed));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error while communicating with SP IVR_CREDIT_MATRIX - Add entry into Error table "));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(cmXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" MPin NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);		
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer for Crdit Matrix:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Service Allowed: ").append(customer.getCmServiceAllowed()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Deposit Required: ").append(customer.getCmDepositRequired()));
			LOGGER.debug(new StringBuffer(logToken).append(" - Credit Type: ").append(customer.getCreditType()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting CreditMatrix"));
		}


		return;
	}
	

}
