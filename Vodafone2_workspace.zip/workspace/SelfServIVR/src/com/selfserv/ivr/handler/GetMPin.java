/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.GetMPinDAO;
import com.selfserv.ivr.selfservdao.central.MPinXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;


/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class GetMPin extends HttpServlet implements Servlet{
	
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(GetMPin.class);

	
 	public GetMPin() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		// create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering GetMPin"));

		Properties callProp = null; // properties key-value pair
		String centralJNDIName = null;
		String reportJNDIName = null; // JNDI name for Repport DB
		Customer customer = null;
		Circle circ = null;
		String circle = null; // Circle name 0001.....0023
		String mobile = null; // mobile number
		String msisdn = null;
		String mpin = null;
		int RC = -1;
		MPinXfer mpinXfer = null;
		String dbrc = null;

		try {
			customer = (Customer) session.getAttribute("customer");

			mobile = (String) customer.getMobile();
			msisdn = mobile;
			callProp = (Properties) session.getAttribute("callProp");
			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			reportJNDIName = circ.getReportJNDIName();
			centralJNDIName = callProp.getProperty("centralJNDIName");
		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - msisdn: ").append(msisdn));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
		}

		if (callProp.getProperty("dBhandlerGetMPin").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetMPin=false => using No backend"));

			customer.setMpin("12345678");

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetMPin=true => Attempting to retrieve MPIN"));

			GetMPinDAO mPinDAO = null;
			String msg = null;

			try {
				mPinDAO = new GetMPinDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				msg = sqle.getMessage();
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				mpinXfer = mPinDAO.executeSP(circle, msisdn);
				dbrc = mpinXfer.getDBRC();

				if (dbrc.equals("S")){
					mpin =  mpinXfer.getMPin();
					customer.setMpin(mpin);
//					session.setAttribute("customer", customer);

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" MPin retrieved successfully - customer.mpin= ").append(mpin));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving MPIN from DB - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(mpinXfer.getDBMsg());
				}
//				session.setAttribute("DBRC", dbrc);		
			} catch (Exception e) {
				session.setAttribute("DBRC", "F_C");
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" MPin NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);		
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - MPin: ").append(customer.getMpin()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting GetMPin"));
		}

		return;
	}
	

}
