package com.selfserv.ivr.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.SIMLossDAO;

/**
 * Servlet implementation class for Servlet: SIMLoss
 *
 */
 public class SIMLoss extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	 
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*
	  * IN: customer.mobile
	  * 	customer.landLine
	  * 	customer.dbCType
	  * 
	  * OUT: DBRC
	  */
		private static Logger LOGGER = Logger.getLogger(SIMLoss.class);
		public SIMLoss() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Lookup LDB
		 HttpSession session = req.getSession(true);  // get session from Servlet request, created if not existed yet
		 Properties callProp = null;
		 Customer customer = null;
		 String reportJNDIName = null;
		 String landline = null;
		 
		 String callid = (String) session.getAttribute("callid");
		 String mobile = (String) session.getAttribute("mobileNumber");

		 boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

			//create the log Token for later use, use StringBuffer to reduce number
			// of String objects
		 String logToken = new StringBuffer("[").append(callid).append("]").toString();

		 try{
			 customer = (Customer)session.getAttribute("customer");
			 
			 landline = customer.getLandlineNumber();
			 Circle circ = (Circle)session.getAttribute("circle");	
			 reportJNDIName = circ.getReportJNDIName();				
		 
			 callProp = (Properties) session.getAttribute("callProp");
			 if (testCall) {
//				 LOGGER.info(new StringBuffer(logToken).append(" - ***************************************"));
				 LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered SIMLoss Servlet *******"));
//				 LOGGER.info(new StringBuffer(logToken).append(" - ***************************************"));
				 LOGGER.debug(new StringBuffer(logToken).append(" Got all attributes from the session"));
				 LOGGER.debug(new StringBuffer(logToken).append(" mobile#: ").append(mobile));
				 LOGGER.debug(new StringBuffer(logToken).append(" callid: ").append(callid));
			 }
		 }catch(Exception e){
			 LOGGER.error(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e));
		 }
		 
		 //if (backendDBAccess.equals("false")){//No DB ****** DUMMY Data ******
		 if (callProp.getProperty("dBhandlerSIMLoss").equals("false")){//No DB ****** DUMMY barred flag ******
		 	 session.setAttribute("DBRC", "S");
//			 return;
		 }else{//Querying the DB's
			 if (testCall) {
				 LOGGER.debug(new StringBuffer(logToken).append(" - Attempting to insert record in TBL_SIMLOSS"));
			 }
			int RC = 0;
			SIMLossDAO simLossDAO = new SIMLossDAO(reportJNDIName, mobile, callid, testCall);
			RC = simLossDAO.insertRecord(landline, customer.getDbCType());
			if (RC>0){
				session.setAttribute("DBRC", "S");
			}else{
				session.setAttribute("DBRC", "F_C");						
			}
//			return;
		 }
		 if (testCall)
			 LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting SIMLoss Servlet *******"));
		 return;
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}   	  	    
}