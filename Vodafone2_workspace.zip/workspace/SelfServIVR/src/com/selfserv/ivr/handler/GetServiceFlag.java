/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.ServiceFlagDAO;
import com.selfserv.ivr.selfservdao.local.ServiceFlagXfer;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class GetServiceFlag extends HttpServlet implements Servlet{
	
	private static Logger LOGGER = Logger.getLogger(GetServiceFlag.class);

	
 	public GetServiceFlag() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering GetServiceFlag"));

		Properties callProp = null;			// properties key-value pair
		String localJNDIName = null;			// JNDI name for Local DB
		String reportJNDIName = null;			// JNDI name for Report DB
		Customer customer = null;
		Circle circ = null;
		String circle = null;					// Circle name 0001.....0023
		String mobile = null;					// mobile number
		String pgmName = null;					// Program Name = CUSTSEG
		String svcFlag = null;
		ServiceFlagXfer svcFlagXfer = null;
		String dbrc = null;
		int RC = -1;

		try{
			customer = (Customer) session.getAttribute("customer");

			mobile = customer.getMobile();
			// Program Name = CUSTSEG
			pgmName = customer.getPrgname();

			callProp = (Properties) session.getAttribute("callProp");
			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			localJNDIName = circ.getLocalJNDIName();
			reportJNDIName = circ.getReportJNDIName();
		} catch(Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - Program Name: ").append(pgmName));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
		}

		if (callProp.getProperty("dBhandlerGetServiceFlag").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetServiceFlag=false => using No backend"));

			customer.setServiceFlag("N");

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", "S");
		} else {
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerGetServiceFlag=true => Attempting to retrieve serviceflag"));

			ServiceFlagDAO svcFlagDAO = null;

			try {
				svcFlagDAO = new ServiceFlagDAO(localJNDIName, mobile, callid, testCall);
			} catch (SQLException sqle) {
				dbrc = "F_C";
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_OPTALD: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				svcFlagXfer = svcFlagDAO.findRecord(circle, pgmName);
				dbrc = svcFlagXfer.getDBRC();

				if (dbrc.equals("S")){
					svcFlag = svcFlagXfer.getServiceFlag();
					customer.setServiceFlag(svcFlag);			

					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" ServiceFlag retrieved successfully - ServiceFlag: ").append(svcFlag));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving ServiceFlag from DB - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(svcFlagXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" ServiceFlag NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
			session.setAttribute("DBRC", dbrc);
			session.setAttribute("customer", customer);
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Service Flag: ").append(customer.getServiceFlag()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));
			LOGGER.info(new StringBuffer(logToken).append("Exiting GetServiceFlag"));
		}


		return;
	}
	

}
