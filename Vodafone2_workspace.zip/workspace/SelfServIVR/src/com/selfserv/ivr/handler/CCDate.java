/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.selfserv.ivr.data.Customer;
/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Function:
 *            
 *            
 *            
 *   Inputs:
 *           
 *                
 *   Outputs:
 *            
 *         
 * 
 */
public class CCDate extends HttpServlet implements Servlet{

	private static final long serialVersionUID = 1L;

	private static Logger LOGGER = Logger.getLogger(CCDate.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering CCDate"));

		// Get  Session vriables
		String ccExpDateEntered = (String) session.getAttribute("ccExpDateEntered");


		// Output variable(s)
		String ccExpDateValid = "false";


		String newDate = null;		
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
		formatter.setLenient(false);

		int maxDay = 0;

		newDate = "01" + ccExpDateEntered.substring(0, 2) + "20" + ccExpDateEntered.substring(2);

		try{
			//Get current date
			Date tdy = new Date(); 

			//Format CC base date which verifies that the input is valid
			Date ccDate = formatter.parse(newDate);

			Calendar cal = Calendar.getInstance();			
			cal.setTime(ccDate);

			//Get last day of month
			maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

			// Reconstruct CC date with last day of month
			newDate = String.valueOf(maxDay) + ccExpDateEntered.substring(0, 2) + "20" + ccExpDateEntered.substring(2);
			ccDate = formatter.parse(newDate);

			if (ccDate.after(tdy)){
				ccExpDateValid = "true";
			}else{
				ccExpDateValid = "false";
			}

		}
		catch(Exception ex){
			LOGGER.error(new StringBuffer(logToken).append(ex.getMessage()));
			session.setAttribute("ccExpDateValid", "false");
			return;
		}

		// Set session variable for reply
		session.setAttribute("ccExpDateValid", ccExpDateValid);


		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("newDate = "+newDate));
			LOGGER.debug(new StringBuffer(logToken).append("ccExpDateValid = "+ccExpDateValid));
			LOGGER.info(new StringBuffer(logToken).append("Exiting CCDate"));
		}

		return;
	}


}
