package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.LogreqDAO;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.SMSProDAO;
import com.selfserv.ivr.selfservdao.local.SMSProXfer;
import com.selfserv.ivr.selfservdao.local.SMSShopsDAO;
import com.selfserv.ivr.selfservdao.local.SMSShopsXfer;
import com.selfserv.ivr.selfservdao.local.TableGenDAO;
import com.selfserv.ivr.selfservdao.local.TableGenXfer;

/**
 * This servlet will insert one or more SMS messages in table TBL_LOGREQ for transmission to a caller
 * The SMS messages differ, depending where in the callflow the caller was.
 * 
 * The lookup for the SMS message is in 2 tables, depending on the session variable smsCmd as follows:
 * 
 * 	Session vars IN:
		 			session.smsCmd = postal - lookup smsPin (6digits) in SMS_SHOPS
		 					 		 cached - lookup DESCRIPTION in TBL_SMS_PRO with session.smsKey
		 			session.smsKey = key dependent on where the caller is in the callflow; used to do the lookup in TBL_SMS_PRO
		 		OUT:
		 			return DBRC = "F_C", or "S" only!

 * 
 * Servlet implementation class for calling XML:
 *    <Choice dtmf="@digits6" targetType="submenu"  
         dest="smsCmd:postal; smsPin:$digits6" 
         handler="com.selfserv.ivr.handler.SMS"  
            targetName="20039_CheckPinCodeSMSRc"/>  
 *
 */
 public class SMS extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(SMS.class);

	 /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SMS() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		/*
		 */

		HttpSession session = req.getSession(true);  // get session from Servlet request, created if not existed yet
		Properties callProp = null;
		Customer customer = null;
		String circle = null;
		String localJNDIName = null;
		String reportJNDIName = null;
		SMSShopsXfer smsShopsXfer = null;
		String smsKey = null;
		String smsCmd = null;

		String callid = (String) session.getAttribute("callid");
		
		customer = (Customer)session.getAttribute("customer");
		String mobile = customer.getMobile();

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("]").toString();

		try{
			smsCmd = (String) session.getAttribute("smsCmd");
			smsKey = (String) session.getAttribute("smsKey");
			

			Circle circ = (Circle)session.getAttribute("circle");	
			localJNDIName = circ.getLocalJNDIName();				
			reportJNDIName = circ.getReportJNDIName();				
			circle = circ.getCircle();								//0001, 0002, ....,0023

			callProp = (Properties) session.getAttribute("callProp");
		}catch(Exception e){
			LOGGER.warn(new StringBuffer("[").append(callid).append("][").append(mobile).append("]").append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}

		if (testCall) {
//			LOGGER.info(new StringBuffer(logToken).append(" - ***************************"));
			LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered SMS Servlet"));
//			LOGGER.info(new StringBuffer(logToken).append(" - ***************************"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - smsKey: ").append(smsKey));
			LOGGER.debug(new StringBuffer(logToken).append(" - smsCmd: ").append(smsCmd));
		}

		if (callProp.getProperty("dBhandlerSMS").equals("false")){//No DB ****** DUMMY barred flag ******
			session.setAttribute("DBRC", "S");
			return;
		}else{//Querying the LDB

			/*
			 * Postal - SMS_SHOPS
			 */
			if (smsCmd.equals("postal")){
				//Lookup smsPin in table SMS_SHOPS
				String smsPin = (String)session.getAttribute("smsPin");
				int smsMsgs = 0;
				try {
					SMSShopsDAO smsShopsDAO = new SMSShopsDAO(localJNDIName, mobile, callid, testCall);
					smsShopsXfer = smsShopsDAO.findRecord(smsPin);
					smsMsgs = smsShopsXfer.getTotalCenters();

				}catch (SQLException e) {
					LOGGER.error(new StringBuffer(logToken).append(" - Exception caught attempting to get SMS_SHOPS data - " + e.getMessage()));
				}

				if (smsShopsXfer.getDBRC().equals("S")){
//					customer.setSmsSent("yes");
//					if(customer.getPrgcode()==null || customer.getCustCode()==null || customer.getCoid()==null){						
					try {
						getTblGenInfo(callid, customer, mobile, localJNDIName, testCall, logToken);
					} catch (SQLException e) {
						LOGGER.error(new StringBuffer(logToken).append(" - Exception caught when attempting to get information from TBL_GEN: "+ e.getMessage()));
						session.setAttribute("DBRC", "F_C");
						return;
					}
					session.setAttribute("customer", customer);
//					}//if

					String prgcode = customer.getPrgcode();
					String custCode = customer.getCustCode();
					String coid = customer.getCoid();
					String landline = customer.getLandlineNumber();
					String trantype = (String) session.getAttribute("smsTranType"); //more verbose description of smsKey
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" prgcode: ").append(prgcode)
								.append(" cust_code: ").append(custCode).append(" - ContractID: ").append(coid));
					}

					//insert the messages retrieved from SMS_SHOPS into TBL_LOGREQ
					LogreqDAO logreqDAO = null;
					try {
						logreqDAO = new LogreqDAO(reportJNDIName, mobile, callid, testCall);
					} catch (SQLException sqle) {
						session.setAttribute("DBRC", "F_C");
						LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to TBL_LOGREQ: ").append(sqle.getMessage()));
						sqle.printStackTrace();
						return;
					}

					int rc = 0;
					for (int i=0;i<smsMsgs;i++){
						rc = logreqDAO.insertRecord(landline, prgcode, trantype, smsShopsXfer.getSmsMsg(i), custCode, coid);
					}

					if (rc > 0){//at lease one SMS message was inserted in the LDB
						//update smsCounter by # of SMS messages sent
						int totalSMSs = customer.getSmsCount();
						totalSMSs += smsMsgs;
						customer.setSmsCount(totalSMSs);

						session.setAttribute("DBRC", "S");
						session.setAttribute("customer", customer);
					}else{
						session.setAttribute("DBRC", "F_C");
					}
				}else if (smsShopsXfer.getDBRC().equals("F_NF")){ // no record found
					session.setAttribute("DBRC", "F_NF");
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - No record found in TBL_SMS_SHOPS"));
					}
				}else{//any other DB failure
					session.setAttribute("DBRC", "F_C");
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Exception caught when accessing TBL_SMS_SHOPS"));
					}
				}
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Returning from SMS servlet (postal)"));
				}
				return;
			}//postal


			/*
			 * Cached - TBL_SMS_PRO
			 */
			if (smsCmd.equals("cached")){
				String smsPropName = "smsProps"+circle;
				Properties smsProps = (Properties) session.getServletContext().getAttribute(smsPropName);

				if (smsProps==null){//if the SMS Table does not exist, load it
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - SMSPro table is not cached in the servletContext.  Caching now: JNDI=" + localJNDIName + ", smsProps="+smsPropName));
					}
					smsProps = loadSMSProTable(callid, mobile, localJNDIName,session,smsPropName, testCall, logToken);					
				}

				//check properties date
				//if the timestamp difference is > 24h => refresh the properties in the servletContext from the LDB

				String lastUpdate = smsProps.getProperty("Timestamp");

				Calendar now = Calendar.getInstance();

				long diffMs = now.getTimeInMillis() - Long.parseLong(lastUpdate);
				long diffDays =  diffMs/(24*60*60*1000);  // difference in days

				if (diffDays>1){
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - SMSPro table from servletContext is stale. Replacing it now..."));
					}
					smsProps = loadSMSProTable(callid, mobile, localJNDIName,session, smsPropName, testCall, logToken);							
				}else{
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Accessing cached SMS_PRO properties from the servletContext"));
					}
				}

				//work with the cached properties
				String smsMsg = smsProps.getProperty(smsKey);
				if (testCall) 
					LOGGER.debug(new StringBuffer(logToken).append(" - smsMsg: ").append(smsMsg));

//				if(customer.getPrgcode()==null || customer.getCustCode()==null || customer.getCoid()==null){
				if (!customer.isIvrCallDetailsCalled()) {
					try {
						getTblGenInfo(callid, customer, mobile, localJNDIName, testCall, logToken);
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
				session.setAttribute("customer", customer);
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" - Updated customer with TBL_GEN data"));
				}
//				}	

				String prgcode = customer.getPrgcode();
				String custCode = customer.getCustCode();
				String coid = customer.getCoid();
				String landline = customer.getLandlineNumber();
				String trantype = (String) session.getAttribute("smsTranType"); //more verbose description of smsKey

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(" prgcode: ").append(prgcode)
							.append(" cust_code: ").append(custCode).append(" - ContractID: ").append(coid));
				}

				//insert the messages retrieved from SMS_SHOPS into TBL_LOGREQ
				LogreqDAO logreqDAO = null;
				try {
					logreqDAO = new LogreqDAO(reportJNDIName, mobile, callid, testCall);
				} catch (SQLException sqle) {
					session.setAttribute("DBRC", "F_C");
					LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to TBL_LOGREQ: ").append(sqle.getMessage()));
					sqle.printStackTrace();
					return;
				}

				int rc = logreqDAO.insertRecord(landline, prgcode, trantype, smsMsg, custCode, coid);
				if (rc == 1){//the SMS message was inserted in the DB
					//update smsCounter by # of SMS messages sent
					int totalSMSs = customer.getSmsCount();
					totalSMSs++;
					customer.setSmsCount(totalSMSs);

//					customer.setSmsSent("yes");
					session.setAttribute("DBRC", "S");
					session.setAttribute("customer", customer);
				}else{
					session.setAttribute("DBRC", "F_C");
				}
				if (testCall)
					LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting SMS servlet (cached)"));
				return;
			}//cached
		}//backendAccess==true
	}//doGet()

	private void getTblGenInfo(String callid, Customer customer, String mobile, String localJNDIName, boolean testCall, String logToken) throws SQLException {
		if (testCall) 
			LOGGER.debug(new StringBuffer(logToken).append(" - Accessing TBL_GEN information"));

		if (customer.isTableGenCalled()) {
			if (testCall) 
				LOGGER.debug(new StringBuffer(logToken).append(" TableGenDAO already called; not executing again."));
		} else {
			TableGenXfer tableGenXfer = null;
			
			//retrieve required data from TBL_GEN, and set the customer properties
			try{
				TableGenDAO tableGenDAO = new TableGenDAO (localJNDIName, mobile, callid, testCall);
				tableGenXfer = tableGenDAO.findRecord(mobile);
			}catch(Exception e){
				LOGGER.error(new StringBuffer(logToken).append(" - Exception caught when attempting to retrieve TBL_GEN data: " + e.getMessage()));
			}
			
//			customer.setPrgcode(tableGenXfer.getPrgcode());
			customer.setCustCode(tableGenXfer.getCustcode());
			customer.setCoid(tableGenXfer.getCoid());

			customer.setBillBillEmail(tableGenXfer.getEmail());
			String pinCode = tableGenXfer.getPinCode();
			if (pinCode != null) {
				customer.setBillBillZipCode(pinCode.substring(0, 6));
			} else {
				customer.setBillBillZipCode(null);
			}

			customer.setTitle(tableGenXfer.getTitle());
			customer.setFirstName(tableGenXfer.getFname());
			customer.setLastName(tableGenXfer.getLname());
			customer.setAddress1(tableGenXfer.getAddr1());
			customer.setAddress2(tableGenXfer.getAddr2());
			customer.setAddress3(tableGenXfer.getAddr3());
			customer.setCity(tableGenXfer.getCity());

			String birthDate = null;
			SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
			if (tableGenXfer.getBirthDate() != null) {
				birthDate = formatter.format(tableGenXfer.getBirthDate());
			}
			customer.setBirthDate(birthDate);			

			customer.setTableGenCalled(true);
		} // else
	}

	private Properties loadSMSProTable(String callid, String mobile, String localJNDIName, HttpSession session, String smsPropName, boolean testCall, String logToken) {
		SMSProXfer smsProXfer = null;

		Properties smsProps;

		try {
			SMSProDAO smsProDAO = new SMSProDAO(localJNDIName, mobile, callid, testCall);
			smsProXfer = smsProDAO.findRecord();								//getting the cached SMS_PRO table
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception caught accessing SMSProDAO: " + e.getMessage()));
		}
		
		Calendar now = Calendar.getInstance();
		Properties props = smsProXfer.getSmsPro();
		props.setProperty("Timestamp", Long.toString(now.getTimeInMillis()));
		
		//replace the property in the servlet context
		session.getServletContext().setAttribute(smsPropName, props);	
		smsProps = props;
		return smsProps;
	}


	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}   	  	    
}