/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.selfserv.ivr.data.Customer;
/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Function:
 *            Determine what type of birthday greeting should be played
 *            based on the date value stored in the Customer class in the 
 *            field birthDate.  (customet.getBirthDate())
 *            
 *   Inputs:
 *            This handler will used the following session variables:
 *            
 *                customet.getBirthDate()  Valid Birthdate formatted DDMMYYYY
 *                
 *   Outputs:
 *            This handler will set the following session variables:
 *            
 *                bDayGreeting - Result of the birth date check.  Possible Values:
 *                
 *                   advanced =  DOB - 3 days
 *                   birthday =  DOB
 *                   belated  =  DOB + 2 days
 *                   none     =  Not in range, or internal error
 *         
 * 
 */
public class BirthDayCheck extends HttpServlet implements Servlet{
	
	private static final long serialVersionUID = 1L;
	
	private static Logger LOGGER = Logger.getLogger(BirthDayCheck.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering BirthDayCheck"));

		// Get Customer Class from Session
		Customer customer = (Customer) session.getAttribute("customer");

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append("customer.getBirthDate() = ").append(customer.getBirthDate()));


		// Output variable
		String bDayGreeting = "none";

		//  Add Birthday logic here 
		//Get current date
		Date todayDate = new Date();
		Date birthdayToCheck = new Date();
		try{		
			//
			// Get Calendar instance of todays date so we can grab the year
			// Build the Birth Date using the callers birth day and month then add on todays year
			//
			Calendar todayDateCal = Calendar.getInstance();			
			todayDateCal.setTime(todayDate);
			todayDateCal.set(Calendar.HOUR, 0);
			todayDateCal.set(Calendar.MINUTE, 0);
			todayDateCal.set(Calendar.SECOND, 0);
			todayDateCal.set(Calendar.MILLISECOND, 0);

			String builtBirthDate = customer.getBirthDate().substring(0, 4) + String.valueOf(todayDateCal.get(Calendar.YEAR));

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append("builtBirthDate = ").append(builtBirthDate));

			//
			// Setup formatter and Date for newly constructed birth date string
			//
			SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
			formatter.setLenient(false);

			birthdayToCheck =  formatter.parse(builtBirthDate);

			Calendar birthdayToCheckCal = Calendar.getInstance();
			birthdayToCheckCal.setTime(birthdayToCheck);

			//
			// Build a calendar based on the new birth date constructed in birthdayToCheck
			// Set the constructed birthdate and subtract 4 
			//  The Calendar compare logic is a bit odd for .before and .after ..   Need to use - 4

			Calendar earlyDateCal = Calendar.getInstance();			
			earlyDateCal.setTime(todayDate);				
			earlyDateCal.add(Calendar.DAY_OF_MONTH, - 4);

			//
			// Build a calendar based on the new birth date constructed in birthdayToCheck
			// Set the constructed birthdate and subtract + 3
			//  The Calendar compare logic is a bit odd for .before and .after ..   Need to use + 3

			Calendar lateDateCal = Calendar.getInstance();			
			lateDateCal.setTime(todayDate);				
			lateDateCal.add(Calendar.DAY_OF_MONTH, + 2);

			//
			// Using the 3 Calendar instances determine the state of the birthdate
			// 
			//  todayDateCal birthdayToCheckCal     earlyDateCal    lateDateCal

			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("todayDateCal = ").append(todayDateCal.getTime()));
				LOGGER.debug(new StringBuffer(logToken).append("birthdayToCheckCal = ").append(birthdayToCheckCal.getTime()));
				LOGGER.debug(new StringBuffer(logToken).append("earlyDateCal = ").append(earlyDateCal.getTime()));
				LOGGER.debug(new StringBuffer(logToken).append("lateDateCal = ").append(lateDateCal.getTime()));
			}

			//
			// Determine where Birtday falls
			//

// 			if (birthdayToCheckCal.equals(todayDateCal)){
			if ( (birthdayToCheckCal.get(Calendar.MONTH) == todayDateCal.get(Calendar.MONTH)) && 
						(birthdayToCheckCal.get(Calendar.DAY_OF_MONTH) == todayDateCal.get(Calendar.DAY_OF_MONTH)) ) {
						bDayGreeting = "birthday";
			}else if (birthdayToCheckCal.before(todayDateCal) && birthdayToCheckCal.after(earlyDateCal)){
				bDayGreeting = "belated";
			}else if (birthdayToCheckCal.after(todayDateCal) && birthdayToCheckCal.before(lateDateCal)){
				bDayGreeting = "advanced";
			}

		}catch(Exception ex){
			LOGGER.error(new StringBuffer(logToken).append(ex.getMessage()));
			session.setAttribute("bDayGreeting", bDayGreeting);
			return;
		}


		// Set session variable for reply
		session.setAttribute("bDayGreeting", bDayGreeting);

		if (testCall){
			LOGGER.debug(new StringBuffer(logToken).append("bDayGreeting = "+bDayGreeting));
			LOGGER.info(new StringBuffer(logToken).append("Exiting BirthDayCheck"));
		}

		return;
	}
	

}
