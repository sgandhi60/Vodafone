/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * @author Mirt
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 *  This module will  move , Add, Subtract and Multiply
 * 
 *   Move will move currencyVarB to currencyVarA
 * 
 *   Add, Subtract and Multiply will folloe the format
 * 
 *      currencyVarA = currencyVarB  '+' | '-' | '*' currencyVarC
 */
public class FootPrint extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger(FootPrint.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	                                      throws ServletException, IOException {
						
		// get session from Servlet request, created if not existed yet
		 HttpSession session = req.getSession(true);
		  
		 String callid = (String) session.getAttribute("callid");

		 boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

			//create the log Token for later use, use StringBuffer to reduce number
			// of String objects
		 String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering FootPrint"));
		 		
		  // Get the footPrint from the session	
		  String footPrint = (String) session.getAttribute("footPrint");
		  String printToAdd = (String) session.getAttribute("printToAdd");

		 // Log the sttributes
		 if (testCall){
			 LOGGER.debug(new StringBuffer(logToken).append("printToAdd = "+printToAdd));
		 }
		 
       // Concatenate comma separated printToAdd to the running footprint
		 
		 if (footPrint == null){
			 footPrint = printToAdd;
		 }else{
			 footPrint = footPrint + "," + printToAdd;
		 }
		 
       // Set session variable for reply
       session.setAttribute("footPrint", footPrint);
       
 	  if (testCall){
 		LOGGER.debug(new StringBuffer(logToken).append("Updated footPrint = "+footPrint));  
		LOGGER.debug(new StringBuffer(logToken).append("Exiting footPrint"));
 	  }
      return;
   }
	
}
