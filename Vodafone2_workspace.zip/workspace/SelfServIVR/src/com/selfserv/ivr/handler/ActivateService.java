/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.ActSvcXfer;
import com.selfserv.ivr.selfservdao.central.ActivateSvcDAO;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class ActivateService extends HttpServlet implements Servlet{
	
	private static Logger LOGGER = Logger.getLogger(ActivateService.class);

	
 	public ActivateService() {
		super();
	}   	
	
 	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering ActivateService"));

		Properties callProp = null;				// properties key-value pair
		String centralJNDIName = null;			// JNDI name for Central DB
		String reportJNDIName = null;		    // JNDI name for Report DB
		Customer customer = null;
		Circle circ = null;
		String circle = null;					// Circle name 0001.....0023
		String mobile = null;					// mobile number
		String msisdn = null;
		String serviceKey = null;				// service key
		String serviceAction = null;			// service action
		String code = null;						// service code
		String v_r = "V";
		int RC = -1;
		ActSvcXfer actSvcXfer = null;
		String dbrc = null;
		String status = null;

		try{
			customer = (Customer)session.getAttribute("customer");

			mobile = customer.getMobile();
			msisdn = mobile;

			callProp = (Properties) session.getAttribute("callProp");
			serviceKey = (String) session.getAttribute("serviceKey");
			serviceAction = (String) session.getAttribute("serviceAction");

			if (serviceAction != null) {
				serviceAction = serviceAction.toLowerCase();
			}

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" serviceKey= ").append(serviceKey).append(" serviceAction= ").append(serviceAction));
			if (serviceKey != null) {
				if (serviceKey.equals("DC_BIR")) {
					code = customer.getServiceID_DCBIR_code();
				} else if (serviceKey.equals("DC_HA")) {
					code = customer.getServiceID_DCHA_code();
				} else if (serviceKey.equals("DC_IR")) {
					code = customer.getServiceID_DCIR_code();
				} else if (serviceKey.equals("DC_ISD")) {
					code = customer.getServiceID_DCISD_code();
				} else if (serviceKey.equals("DC_NR")) {
					code = customer.getServiceID_DCNR_code();
				} else if (serviceKey.equals("DC_PH")) {
					code = customer.getServiceID_DCPH_code();
				} else if (serviceKey.equals("DC_STD")) {
					code = customer.getServiceID_DCSTD_code();
				} else if (serviceKey.equals("DC_IB")) {
					code = customer.getServiceID_DCIB_code();
//				} else  
//					LOGGER.error(new StringBuffer(logToken).append(" - Invalid Service Key: ").append(serviceKey));
				}
//			} else {
//				LOGGER.error(new StringBuffer(logToken).append(" - Null Service Key: ").append(serviceKey));
			}
			
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" code= ").append(code));
			circ = (Circle) session.getAttribute("circle");
			circle = circ.getCircle();

			centralJNDIName = callProp.getProperty("centralJNDIName");
			reportJNDIName = circ.getReportJNDIName();
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - msisdn: ").append(msisdn));
			LOGGER.debug(new StringBuffer(logToken).append(" - serviceKey: ").append(serviceKey));
			LOGGER.debug(new StringBuffer(logToken).append(" - serviceAction: ").append(serviceAction));
			LOGGER.debug(new StringBuffer(logToken).append(" - code: ").append(code));
			LOGGER.debug(new StringBuffer(logToken).append(" - circle ID: ").append(circle));
			LOGGER.debug(new StringBuffer(logToken).append(" - v_r: ").append(v_r));
		}

		if (callProp.getProperty("dBhandlerActivateService").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerActivateService=false => using No backend"));
/*
			if (serviceKey != null) {
				if (serviceKey.equals("DC_BIR")) {
					customer.setServiceID_DCBIR(serviceAction);
				} else if (serviceKey.equals("DC_HA")) {
					customer.setServiceID_DCHA(serviceAction);
				} else if (serviceKey.equals("DC_IR")) {
					customer.setServiceID_DCIR(serviceAction);
				} else if (serviceKey.equals("DC_ISD")) {
					customer.setServiceID_DCISD(serviceAction);
				} else if (serviceKey.equals("DC_NR")) {
					customer.setServiceID_DCNR(serviceAction);
				} else if (serviceKey.equals("DC_PH")) {
					customer.setServiceID_DCPH(serviceAction);
				} else if (serviceKey.equals("DC_STD")) {
					customer.setServiceID_DCSTD(serviceAction);
				} else if (serviceKey.equals("DC_IB")) {
					customer.setServiceID_DCIB(serviceAction);
				}
//				else  
//					LOGGER.error(new StringBuffer(logToken).append(" - Invalid Service Key: ").append(serviceKey));

				session.setAttribute("customer", customer);
//			} else { 
//				LOGGER.error(new StringBuffer(logToken).append(" - NULL Service Key: ").append(serviceKey));
			}
*/
			session.setAttribute("DBRC", "S");
			
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerActivateService=true => Attempting to connect SP IVR_SR_CREATION"));

			ActivateSvcDAO actSvcDAO = null;

			try {
				actSvcDAO = new ActivateSvcDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}
			int iCode = -1;
			if ( (code != null) && (code.length() != 0)) {
				iCode = new Integer(code).intValue();
			}
			try {
				actSvcXfer = actSvcDAO.executeSP(circle, msisdn, iCode, serviceAction, v_r);
				dbrc = actSvcXfer.getDBRC();

				if (dbrc.equals("S")){
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Service Created successfully"));
/*					
					if (status != null) {
						status = status.toLowerCase();
					}
*/
					if (serviceKey != null) {
						if (serviceKey.equals("DC_BIR")) {
							customer.setServiceFlag_DCBIR(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_HA")) {
							customer.setServiceFlag_DCHA(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_IR")) {
							customer.setServiceFlag_DCIR(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_ISD")) {
							customer.setServiceFlag_DCISD(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_NR")) {
							customer.setServiceFlag_DCNR(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_PH")) {
							customer.setServiceFlag_DCPH(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_STD")) {
							customer.setServiceFlag_DCSTD(serviceAction.toUpperCase());
						} else if (serviceKey.equals("DC_IB")) {
							customer.setServiceFlag_DCIB(serviceAction.toUpperCase());
						} 
//						else   
//							LOGGER.error(new StringBuffer(logToken).append(" - Invalid Service Key: ").append(serviceKey));

//					} else {
//						LOGGER.error(new StringBuffer(logToken).append(" - Null Service Key: ").append(serviceKey));
					}
					
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error while communicating with SP IVR_SR_CREATION - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(actSvcXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				LOGGER.error(new StringBuffer(logToken).append(" Exception caught while communicating with DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}

			session.setAttribute("customer", customer);
			session.setAttribute("DBRC", dbrc);		
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - Service creation request is sent"));

			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCBIR: ").append(customer.getServiceFlag_DCBIR()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCHA: ").append(customer.getServiceFlag_DCHA()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCIR: ").append(customer.getServiceFlag_DCIR()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCISD: ").append(customer.getServiceFlag_DCISD()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCNR: ").append(customer.getServiceFlag_DCNR()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCPH: ").append(customer.getServiceFlag_DCPH()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCSTD: ").append(customer.getServiceFlag_DCSTD()));
			LOGGER.debug(new StringBuffer(logToken).append(" - ServiceFlag_DCIB: ").append(customer.getServiceFlag_DCIB()));
			LOGGER.debug(new StringBuffer(logToken).append(" - DBRC: ").append((String)session.getAttribute("DBRC")));

			LOGGER.info(new StringBuffer(logToken).append("Exiting ActivateService"));
		}

		return;
	}
	

}
