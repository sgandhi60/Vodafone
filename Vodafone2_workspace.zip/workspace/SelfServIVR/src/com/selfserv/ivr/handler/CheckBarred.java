/*
 * Created on Apr 5, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.BarredXfer;
import com.selfserv.ivr.selfservdao.local.BarredDAO;
import com.selfserv.ivr.selfservdao.local.CDayBarredDAO;

/**
 * This handler:
 * 	- will either return the barred status of the caller or will update the daily barred count
 *  - will check only the local database (LDB)
 * 
 *  Logic overview:
 	Check first the session "barredCmd"
 		If session.barredCmd == LOOKUP
			If tbl_barred "Y"
				set customer.barred = "Y"
				return
			else //i.e tbl_barred "N"
				if cday_barred > circle.maxTransfer
				set Customer.barred = "Y"
				return

		If session.barredCmd == INCREMENT
			bump cday_barred count
			update the DB
			return
			
		DataBase Return Code(s) S=Success; F_NF=Failed, Record Not Found, F_C=Failed, Critical (DB down)			
 */
		public class CheckBarred extends HttpServlet implements Servlet{
			private static final long serialVersionUID = 1L;
			private static Logger LOGGER = Logger.getLogger(CheckBarred.class);

			

			public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {				
				HttpSession session;  								// get session from Servlet request, created if not existed yet
				Properties callProp = null;			   				// properties key-value pair
				//private String centralJNDIName = null;			// JNDI name for central DB
				String localJNDIName = null;						// JNDI name for local DB
				Customer customer = null;							// customer class 
				String initCustType = null;							// initial customer type: TypeA, TypeB, TypeC
				Circle circ = null;									// circle clsss that gets populated from the properties file
				//private String dbrc = null;						// DB return code
				String barredCmd=null;

				BarredDAO barredDAO = null;
				BarredXfer bXfer = null;
				CDayBarredDAO cDayBarredDAO = null;

				session = req.getSession(true);  // get session from Servlet request, created if not existed yet
				customer = (Customer)session.getAttribute("customer");				
				String callid = (String) session.getAttribute("callid");
				
				//String mobile = (String) session.getAttribute("");
                String mobile = customer.getMobile();
				
				boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

				//create the log Token for later use, use StringBuffer to reduce number
				// of String objects
				String logToken = new StringBuffer("[").append(callid).append("]").toString();

				try{
				
					circ = (Circle)session.getAttribute("circle");			//circle class

					localJNDIName = circ.getLocalJNDIName();	
					initCustType = circ.getDnisType();						//TypeA, TypeB, TypeC

					callProp = (Properties) session.getAttribute("callProp");
					barredCmd = (String) session.getAttribute("barredCmd");


					if (testCall) {	
//						LOGGER.info(new StringBuffer(logToken).append(" - ***********************************"));
						LOGGER.info(new StringBuffer(logToken).append(" - ******* Entered CheckBarred servlet"));
//						LOGGER.info(new StringBuffer(logToken).append(" - ***********************************"));
						LOGGER.debug(new StringBuffer(logToken).append(" - localJNDIName=").append(localJNDIName));
						LOGGER.debug(new StringBuffer(logToken).append(" - initCustType=").append(initCustType));
						LOGGER.debug(new StringBuffer(logToken).append(" - session.barredCmd=").append(session.getAttribute("barredCmd")));
					}
				}catch(Exception e){
					LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
					session.setAttribute("DBRC", "F_C");
					return;
				}

				//if (backendDBAccess.equals("false")){//No DB ****** DUMMY barred flag ******
				if (callProp.getProperty("dBhandlerCustomerBarred").equals("false")){//No DB ****** DUMMY barred flag ******
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Using dummy data!"));
					}
					customer.setBarredFlag("N");
					session.setAttribute("customer", customer);
					session.setAttribute("DBRC", "S");
				}else{
					String dbrc = null;
					try{ 
						//Perform record lookup*/
						if (barredCmd.equalsIgnoreCase("LOOKUP")){
							if (testCall) {
								LOGGER.debug(new StringBuffer(logToken).append(" - barredCmd=LOOKUP"));
							}
							barredDAO = new BarredDAO(localJNDIName, mobile, callid, testCall);
							bXfer = barredDAO.findRecord(mobile);
							String barred = null;
							dbrc = bXfer.getDBRC();
							if (bXfer != null && dbrc.equals("S")){//found a match in the DB
								barred = bXfer.getBarred();
								if (testCall) {
									LOGGER.debug(new StringBuffer(logToken).append(" - barred=").append(barred));
								}
								if (barred.equals("Y")){	//Customer is barred
									customer.setBarredFlag(barred); 
								}
							}
							// if customer is not barred check tbl_cday_barred
							if (customer.getBarredFlag() != null && customer.getBarredFlag().equals("N")) {
								//Customer is not barred in the TBL_BARRED, and must be verified in TBL_CDAY_BARRED
								if (testCall) {
									LOGGER.debug(new StringBuffer(logToken).append(" -  caller must be verified in cday_barred table"));
								}
								cDayBarredDAO = new CDayBarredDAO(localJNDIName, mobile, callid, testCall);

								bXfer = cDayBarredDAO.findRecord();
								
								if (bXfer != null) {
									dbrc = bXfer.getDBRC();
									if (dbrc.equals("S")){//found a match in the LDB
										int dailyCount = bXfer.getCdayCount();
										if (dailyCount >= Integer.parseInt(circ.getMaxTransfer())){
											customer.setBarredFlag("Y");													  //Customer has exceeded allowed CCE Xfers
										}else{
											customer.setBarredFlag("N");													  //Customer is not barred
										}
										customer.setDailyXfers(Integer.toString(bXfer.getCdayCount()));
									} else{
										customer.setDailyXfers("0");
									}
								} else {
									dbrc = "F_NF";
								}
							}
						} else {
							if (testCall) {
								LOGGER.debug(new StringBuffer(logToken).append(" - Barred status was not updated from TBL_BARRED"));
							}
						}


						//Increment the daily count					    	 
						if (barredCmd.equalsIgnoreCase("INCREMENT")){		
							int result = 0;

							cDayBarredDAO = new CDayBarredDAO(localJNDIName, mobile, callid, testCall);
							bXfer = cDayBarredDAO.findRecord();

							//BarredXfer barredXfer = null;
							//int dailyCount = Integer.parseInt(customer.getDailyXfers());			//Caching: The daily xfers should have been cached already in the customer class from a previous barredCmd="LOOKUP",			    	 	

							if (bXfer==null || bXfer.getCdayCount()==0){//insert
								//dailyXfersCount = bXfer.getCdayCount();
								if (testCall) {
									LOGGER.debug(new StringBuffer(logToken).append(" - No transfers for today => inserting record"));
								}

								if (cDayBarredDAO!=null){
									cDayBarredDAO.insertRecord(mobile);
								}
							}else{//update
								int dailyXfersCount = bXfer.getCdayCount();
								if (testCall) {
									LOGGER.debug(new StringBuffer(logToken).append(" - Incrementing daily count to: ").append(dailyXfersCount++));
								}
								cDayBarredDAO = new CDayBarredDAO(localJNDIName, mobile, callid, testCall);
								result = cDayBarredDAO.updateRecord(dailyXfersCount);
								customer.setDailyXfers(Integer.toString(dailyXfersCount));

								if (result==1){
									dbrc = "S";
								}
								if (result==0){//no record was found => insert record
									//dbrc = "F_NF";
								}
								if (result==-1){
									dbrc="F_C";
								}
								customer.setDailyXfers(Integer.toString(dailyXfersCount));
							}
						}	

					}catch(Exception e){

						LOGGER.error(new StringBuffer(logToken).append(" - Exception caught in CheckBarred: ").append(e.getMessage()));
						session.setAttribute("DBRC","F_C");
						e.printStackTrace();
					}

					session.setAttribute("customer", customer);							 
					session.setAttribute("DBRC", dbrc);

					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(" - Set in session:"));
						LOGGER.debug(new StringBuffer(logToken).append(" - customer.barred=").append(customer.getBarredFlag()));
						LOGGER.debug(new StringBuffer(logToken).append(" - customer.dailyXfers=").append(customer.getDailyXfers()));						 
						LOGGER.debug(new StringBuffer(logToken).append(" - session.DBRC=").append(dbrc));						 
					}
				}
				if (testCall)
					LOGGER.info(new StringBuffer(logToken).append(" - ******* Exiting CheckBarred servlet"));
				return;
			}
		}