/*
 * Created on July 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.selfserv.ivr.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.VDNDAO;
import com.selfserv.ivr.selfservdao.local.VDNXfer;

/**
 * @author Shailesh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 */
public class VDN extends HttpServlet implements Servlet{

	private static Logger LOGGER = Logger.getLogger(VDN.class);


	public VDN() {
		super();
	}   	


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}   	

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("Entering VDN"));

		Properties callProp = null;			// properties key-value pair
		String localJNDIName = null;			// JNDI name for Local DB
		String reportJNDIName = null;			// JNDI name for Report DB
		Customer customer = null;
		Circle circ = null;
		String mobile = null;					// mobile number
		String custType = null;
		String tranType = null;				
		String category = null;			
		String vdn = null;
		VDNXfer vdnXfer = null;
		String lang = null;					
		String dbrc = null;
		int RC = -1;

		try{
			customer = (Customer)session.getAttribute("customer");
			if ( customer != null) {
				mobile = customer.getMobile();
				custType = customer.getDbCType();
				category = customer.getVdn_category();
				tranType = customer.getTran_type(); 
			}

			if (session != null) {
				lang =  (String) session.getAttribute("LANG");
				if (lang != null) {
					if ( (lang.equalsIgnoreCase("ENG")) || (lang.equalsIgnoreCase("HIN")) ) {
					} else {
						lang ="LOCAL";
					}
				}
				callProp = (Properties) session.getAttribute("callProp");
				circ = (Circle) session.getAttribute("circle");
			}

			if (circ != null) {
				localJNDIName = circ.getLocalJNDIName();
				reportJNDIName = circ.getReportJNDIName();
			}
		}catch(Exception e){
			LOGGER.warn(new StringBuffer(logToken).append(" - Problem retreiving attributes from the session: ").append(e.getMessage()));
			e.printStackTrace();
		}	

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Got all attributes from the session"));
			LOGGER.debug(new StringBuffer(logToken).append(" - callid: ").append(callid));
			LOGGER.debug(new StringBuffer(logToken).append(" - mobile#: ").append(mobile));
			LOGGER.debug(new StringBuffer(logToken).append(" - custType: ").append(custType));
			LOGGER.debug(new StringBuffer(logToken).append(" - lang: ").append(lang));
			LOGGER.debug(new StringBuffer(logToken).append(" - category: ").append(category));
			LOGGER.debug(new StringBuffer(logToken).append(" - tranType: ").append(tranType));
		}

		if (callProp.getProperty("dBhandlerVDN").equals("false")){//No DB ****** DUMMY barred flag ******
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerVDN=false => using No backend"));

			customer.setVdnRoutePoint("6707");

			session.setAttribute("customer", customer);
			session.setAttribute("VDN", "6707");
			session.setAttribute("DBRC", "S");
		} else {		
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(" - dBhandlerVDN=true => Attempting to retrieve VDN Route Point"));

			VDNDAO vdnDAO = null;

			try {
				vdnDAO = new VDNDAO(localJNDIName, mobile, callid, testCall);
			} catch (SQLException sqle) {
				dbrc = "F_C";
				session.setAttribute("DBRC", dbrc);
				LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_VDN: ").append(sqle.getMessage()));
				sqle.printStackTrace();
				return;
			}

			try {
				vdnXfer = vdnDAO.findRecord(custType, tranType, lang, category);
				dbrc = vdnXfer.getDBRC();

				if (dbrc.equals("S")){
					vdn = vdnXfer.getVdnRoutePoint();
					customer.setVdnRoutePoint(vdn);		

					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" VDN retrieved successfully - VDN: ").append(vdn));
				} else {
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving VDN from DB - Add entry into Error table"));

					//enter exception in the TBL_RPT_ERROR table
					ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
					RC = rptErrorDAO.insertRecord(vdnXfer.getDBMsg());
				}
			} catch (Exception e) {
				dbrc = "F_C";
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(" VDN NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
				e.printStackTrace();

				//enter exception in the TBL_RPT_ERROR table
				ReportErrorDAO rptErrorDAO = new ReportErrorDAO(reportJNDIName, mobile, callid, testCall);
				RC = rptErrorDAO.insertRecord(e.getMessage());
			}
			session.setAttribute("DBRC", dbrc);
			session.setAttribute("customer", customer);
			session.setAttribute("VDN", vdn);
		}//else callProp

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(" - Values in session.customer:"));
			LOGGER.debug(new StringBuffer(logToken).append(" - VDN Route Point: ").append(customer.getVdnRoutePoint()));
			LOGGER.info(new StringBuffer(logToken).append("Exiting VDN"));
		}


		return;
	}


}
