/**
 * <copyright>
 * </copyright>
 *
 * $Id: CallRoutingTypeImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.ClosedAudioType;
import com.ibm.ivr.framework.model.DefaultRoutingType;
import com.ibm.ivr.framework.model.EventHandlersType;
import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.HolidayAudioType;
import com.ibm.ivr.framework.model.IntroAudioType;
import com.ibm.ivr.framework.model.MenuOperatorType;
import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.OperatorType;
import com.ibm.ivr.framework.model.OutroAudioType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.model.TransferAudioType;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Call Routing Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getIntroAudio <em>Intro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getOutroAudio <em>Outro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getHolidayAudio <em>Holiday Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getClosedAudio <em>Closed Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getTransferAudio <em>Transfer Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getOperator <em>Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getMenuOperator <em>Menu Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getEvents <em>Events</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getEventHandlers <em>Event Handlers</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getDefaultRouting <em>Default Routing</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getSubMenu <em>Sub Menu</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getAudioDir <em>Audio Dir</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getCallProperties <em>Call Properties</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getCleanupHandler <em>Cleanup Handler</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getCommon <em>Common</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getFileVersion <em>File Version</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getMain <em>Main</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getReleaseVersion <em>Release Version</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getStart <em>Start</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl#getStartMode <em>Start Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CallRoutingTypeImpl extends EDataObjectImpl implements CallRoutingType
{
  /**
   * The cached value of the '{@link #getIntroAudio() <em>Intro Audio</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIntroAudio()
   * @generated
   * @ordered
   */
  protected EList introAudio = null;

  /**
   * The cached value of the '{@link #getOutroAudio() <em>Outro Audio</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutroAudio()
   * @generated
   * @ordered
   */
  protected EList outroAudio = null;

  /**
   * The cached value of the '{@link #getHolidayAudio() <em>Holiday Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHolidayAudio()
   * @generated
   * @ordered
   */
  protected HolidayAudioType holidayAudio = null;

  /**
   * The cached value of the '{@link #getClosedAudio() <em>Closed Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getClosedAudio()
   * @generated
   * @ordered
   */
  protected ClosedAudioType closedAudio = null;

  /**
   * The cached value of the '{@link #getTransferAudio() <em>Transfer Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTransferAudio()
   * @generated
   * @ordered
   */
  protected TransferAudioType transferAudio = null;

  /**
   * The cached value of the '{@link #getOperator() <em>Operator</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOperator()
   * @generated
   * @ordered
   */
  protected OperatorType operator = null;

  /**
   * The cached value of the '{@link #getMenuOperator() <em>Menu Operator</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMenuOperator()
   * @generated
   * @ordered
   */
  protected EList menuOperator = null;

  /**
   * The cached value of the '{@link #getEvents() <em>Events</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEvents()
   * @generated
   * @ordered
   */
  protected EventsType events = null;

  /**
   * The cached value of the '{@link #getEventHandlers() <em>Event Handlers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEventHandlers()
   * @generated
   * @ordered
   */
  protected EventHandlersType eventHandlers = null;

  /**
   * The cached value of the '{@link #getDefaultRouting() <em>Default Routing</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDefaultRouting()
   * @generated
   * @ordered
   */
  protected EList defaultRouting = null;

  /**
   * The cached value of the '{@link #getSubMenu() <em>Sub Menu</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSubMenu()
   * @generated
   * @ordered
   */
  protected EList subMenu = null;

  /**
   * The default value of the '{@link #getAudioDir() <em>Audio Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAudioDir()
   * @generated
   * @ordered
   */
  protected static final String AUDIO_DIR_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getAudioDir() <em>Audio Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAudioDir()
   * @generated
   * @ordered
   */
  protected String audioDir = AUDIO_DIR_EDEFAULT;

  /**
   * The default value of the '{@link #getCallProperties() <em>Call Properties</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCallProperties()
   * @generated
   * @ordered
   */
  protected static final String CALL_PROPERTIES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCallProperties() <em>Call Properties</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCallProperties()
   * @generated
   * @ordered
   */
  protected String callProperties = CALL_PROPERTIES_EDEFAULT;

  /**
   * The default value of the '{@link #getCleanupHandler() <em>Cleanup Handler</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCleanupHandler()
   * @generated
   * @ordered
   */
  protected static final String CLEANUP_HANDLER_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCleanupHandler() <em>Cleanup Handler</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCleanupHandler()
   * @generated
   * @ordered
   */
  protected String cleanupHandler = CLEANUP_HANDLER_EDEFAULT;

  /**
   * The default value of the '{@link #getCommon() <em>Common</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCommon()
   * @generated
   * @ordered
   */
  protected static final String COMMON_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCommon() <em>Common</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCommon()
   * @generated
   * @ordered
   */
  protected String common = COMMON_EDEFAULT;

  /**
   * The default value of the '{@link #getFileVersion() <em>File Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFileVersion()
   * @generated
   * @ordered
   */
  protected static final String FILE_VERSION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getFileVersion() <em>File Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFileVersion()
   * @generated
   * @ordered
   */
  protected String fileVersion = FILE_VERSION_EDEFAULT;

  /**
   * The default value of the '{@link #getMain() <em>Main</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMain()
   * @generated
   * @ordered
   */
  protected static final String MAIN_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getMain() <em>Main</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMain()
   * @generated
   * @ordered
   */
  protected String main = MAIN_EDEFAULT;

  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getReleaseVersion() <em>Release Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReleaseVersion()
   * @generated
   * @ordered
   */
  protected static final String RELEASE_VERSION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getReleaseVersion() <em>Release Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReleaseVersion()
   * @generated
   * @ordered
   */
  protected String releaseVersion = RELEASE_VERSION_EDEFAULT;

  /**
   * The default value of the '{@link #getStart() <em>Start</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStart()
   * @generated
   * @ordered
   */
  protected static final String START_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getStart() <em>Start</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStart()
   * @generated
   * @ordered
   */
  protected String start = START_EDEFAULT;

  /**
   * The default value of the '{@link #getStartMode() <em>Start Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStartMode()
   * @generated
   * @ordered
   */
  protected static final String START_MODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getStartMode() <em>Start Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStartMode()
   * @generated
   * @ordered
   */
  protected String startMode = START_MODE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CallRoutingTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getCallRoutingType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getIntroAudio()
  {
    if (introAudio == null)
    {
      introAudio = new EObjectContainmentEList(IntroAudioType.class, this, ModelPackage.CALL_ROUTING_TYPE__INTRO_AUDIO);
    }
    return introAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getOutroAudio()
  {
    if (outroAudio == null)
    {
      outroAudio = new EObjectContainmentEList(OutroAudioType.class, this, ModelPackage.CALL_ROUTING_TYPE__OUTRO_AUDIO);
    }
    return outroAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HolidayAudioType getHolidayAudio()
  {
    return holidayAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHolidayAudio(HolidayAudioType newHolidayAudio, NotificationChain msgs)
  {
    HolidayAudioType oldHolidayAudio = holidayAudio;
    holidayAudio = newHolidayAudio;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO, oldHolidayAudio, newHolidayAudio);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHolidayAudio(HolidayAudioType newHolidayAudio)
  {
    if (newHolidayAudio != holidayAudio)
    {
      NotificationChain msgs = null;
      if (holidayAudio != null)
        msgs = ((InternalEObject)holidayAudio).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO, null, msgs);
      if (newHolidayAudio != null)
        msgs = ((InternalEObject)newHolidayAudio).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO, null, msgs);
      msgs = basicSetHolidayAudio(newHolidayAudio, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO, newHolidayAudio, newHolidayAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ClosedAudioType getClosedAudio()
  {
    return closedAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetClosedAudio(ClosedAudioType newClosedAudio, NotificationChain msgs)
  {
    ClosedAudioType oldClosedAudio = closedAudio;
    closedAudio = newClosedAudio;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO, oldClosedAudio, newClosedAudio);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setClosedAudio(ClosedAudioType newClosedAudio)
  {
    if (newClosedAudio != closedAudio)
    {
      NotificationChain msgs = null;
      if (closedAudio != null)
        msgs = ((InternalEObject)closedAudio).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO, null, msgs);
      if (newClosedAudio != null)
        msgs = ((InternalEObject)newClosedAudio).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO, null, msgs);
      msgs = basicSetClosedAudio(newClosedAudio, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO, newClosedAudio, newClosedAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransferAudioType getTransferAudio()
  {
    return transferAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTransferAudio(TransferAudioType newTransferAudio, NotificationChain msgs)
  {
    TransferAudioType oldTransferAudio = transferAudio;
    transferAudio = newTransferAudio;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO, oldTransferAudio, newTransferAudio);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransferAudio(TransferAudioType newTransferAudio)
  {
    if (newTransferAudio != transferAudio)
    {
      NotificationChain msgs = null;
      if (transferAudio != null)
        msgs = ((InternalEObject)transferAudio).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO, null, msgs);
      if (newTransferAudio != null)
        msgs = ((InternalEObject)newTransferAudio).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO, null, msgs);
      msgs = basicSetTransferAudio(newTransferAudio, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO, newTransferAudio, newTransferAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OperatorType getOperator()
  {
    return operator;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOperator(OperatorType newOperator, NotificationChain msgs)
  {
    OperatorType oldOperator = operator;
    operator = newOperator;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__OPERATOR, oldOperator, newOperator);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOperator(OperatorType newOperator)
  {
    if (newOperator != operator)
    {
      NotificationChain msgs = null;
      if (operator != null)
        msgs = ((InternalEObject)operator).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__OPERATOR, null, msgs);
      if (newOperator != null)
        msgs = ((InternalEObject)newOperator).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__OPERATOR, null, msgs);
      msgs = basicSetOperator(newOperator, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__OPERATOR, newOperator, newOperator));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getMenuOperator()
  {
    if (menuOperator == null)
    {
      menuOperator = new EObjectContainmentEList(MenuOperatorType.class, this, ModelPackage.CALL_ROUTING_TYPE__MENU_OPERATOR);
    }
    return menuOperator;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventsType getEvents()
  {
    return events;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEvents(EventsType newEvents, NotificationChain msgs)
  {
    EventsType oldEvents = events;
    events = newEvents;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__EVENTS, oldEvents, newEvents);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEvents(EventsType newEvents)
  {
    if (newEvents != events)
    {
      NotificationChain msgs = null;
      if (events != null)
        msgs = ((InternalEObject)events).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__EVENTS, null, msgs);
      if (newEvents != null)
        msgs = ((InternalEObject)newEvents).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__EVENTS, null, msgs);
      msgs = basicSetEvents(newEvents, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__EVENTS, newEvents, newEvents));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventHandlersType getEventHandlers()
  {
    return eventHandlers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEventHandlers(EventHandlersType newEventHandlers, NotificationChain msgs)
  {
    EventHandlersType oldEventHandlers = eventHandlers;
    eventHandlers = newEventHandlers;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS, oldEventHandlers, newEventHandlers);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEventHandlers(EventHandlersType newEventHandlers)
  {
    if (newEventHandlers != eventHandlers)
    {
      NotificationChain msgs = null;
      if (eventHandlers != null)
        msgs = ((InternalEObject)eventHandlers).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS, null, msgs);
      if (newEventHandlers != null)
        msgs = ((InternalEObject)newEventHandlers).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS, null, msgs);
      msgs = basicSetEventHandlers(newEventHandlers, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS, newEventHandlers, newEventHandlers));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getDefaultRouting()
  {
    if (defaultRouting == null)
    {
      defaultRouting = new EObjectContainmentEList(DefaultRoutingType.class, this, ModelPackage.CALL_ROUTING_TYPE__DEFAULT_ROUTING);
    }
    return defaultRouting;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getSubMenu()
  {
    if (subMenu == null)
    {
      subMenu = new EObjectContainmentEList(SubMenuType.class, this, ModelPackage.CALL_ROUTING_TYPE__SUB_MENU);
    }
    return subMenu;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getAudioDir()
  {
    return audioDir;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAudioDir(String newAudioDir)
  {
    String oldAudioDir = audioDir;
    audioDir = newAudioDir;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__AUDIO_DIR, oldAudioDir, audioDir));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCallProperties()
  {
    return callProperties;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCallProperties(String newCallProperties)
  {
    String oldCallProperties = callProperties;
    callProperties = newCallProperties;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__CALL_PROPERTIES, oldCallProperties, callProperties));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCleanupHandler()
  {
    return cleanupHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCleanupHandler(String newCleanupHandler)
  {
    String oldCleanupHandler = cleanupHandler;
    cleanupHandler = newCleanupHandler;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__CLEANUP_HANDLER, oldCleanupHandler, cleanupHandler));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCommon()
  {
    return common;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCommon(String newCommon)
  {
    String oldCommon = common;
    common = newCommon;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__COMMON, oldCommon, common));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getFileVersion()
  {
    return fileVersion;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFileVersion(String newFileVersion)
  {
    String oldFileVersion = fileVersion;
    fileVersion = newFileVersion;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__FILE_VERSION, oldFileVersion, fileVersion));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getMain()
  {
    return main;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMain(String newMain)
  {
    String oldMain = main;
    main = newMain;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__MAIN, oldMain, main));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getReleaseVersion()
  {
    return releaseVersion;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setReleaseVersion(String newReleaseVersion)
  {
    String oldReleaseVersion = releaseVersion;
    releaseVersion = newReleaseVersion;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__RELEASE_VERSION, oldReleaseVersion, releaseVersion));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getStart()
  {
    return start;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStart(String newStart)
  {
    String oldStart = start;
    start = newStart;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__START, oldStart, start));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getStartMode()
  {
    return startMode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStartMode(String newStartMode)
  {
    String oldStartMode = startMode;
    startMode = newStartMode;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.CALL_ROUTING_TYPE__START_MODE, oldStartMode, startMode));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs)
  {
    if (featureID >= 0)
    {
      switch (eDerivedStructuralFeatureID(featureID, baseClass))
      {
        case ModelPackage.CALL_ROUTING_TYPE__INTRO_AUDIO:
          return ((InternalEList)getIntroAudio()).basicRemove(otherEnd, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__OUTRO_AUDIO:
          return ((InternalEList)getOutroAudio()).basicRemove(otherEnd, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO:
          return basicSetHolidayAudio(null, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO:
          return basicSetClosedAudio(null, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO:
          return basicSetTransferAudio(null, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__OPERATOR:
          return basicSetOperator(null, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__MENU_OPERATOR:
          return ((InternalEList)getMenuOperator()).basicRemove(otherEnd, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__EVENTS:
          return basicSetEvents(null, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS:
          return basicSetEventHandlers(null, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__DEFAULT_ROUTING:
          return ((InternalEList)getDefaultRouting()).basicRemove(otherEnd, msgs);
        case ModelPackage.CALL_ROUTING_TYPE__SUB_MENU:
          return ((InternalEList)getSubMenu()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.CALL_ROUTING_TYPE__INTRO_AUDIO:
        return getIntroAudio();
      case ModelPackage.CALL_ROUTING_TYPE__OUTRO_AUDIO:
        return getOutroAudio();
      case ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO:
        return getHolidayAudio();
      case ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO:
        return getClosedAudio();
      case ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO:
        return getTransferAudio();
      case ModelPackage.CALL_ROUTING_TYPE__OPERATOR:
        return getOperator();
      case ModelPackage.CALL_ROUTING_TYPE__MENU_OPERATOR:
        return getMenuOperator();
      case ModelPackage.CALL_ROUTING_TYPE__EVENTS:
        return getEvents();
      case ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS:
        return getEventHandlers();
      case ModelPackage.CALL_ROUTING_TYPE__DEFAULT_ROUTING:
        return getDefaultRouting();
      case ModelPackage.CALL_ROUTING_TYPE__SUB_MENU:
        return getSubMenu();
      case ModelPackage.CALL_ROUTING_TYPE__AUDIO_DIR:
        return getAudioDir();
      case ModelPackage.CALL_ROUTING_TYPE__CALL_PROPERTIES:
        return getCallProperties();
      case ModelPackage.CALL_ROUTING_TYPE__CLEANUP_HANDLER:
        return getCleanupHandler();
      case ModelPackage.CALL_ROUTING_TYPE__COMMON:
        return getCommon();
      case ModelPackage.CALL_ROUTING_TYPE__FILE_VERSION:
        return getFileVersion();
      case ModelPackage.CALL_ROUTING_TYPE__MAIN:
        return getMain();
      case ModelPackage.CALL_ROUTING_TYPE__NAME:
        return getName();
      case ModelPackage.CALL_ROUTING_TYPE__RELEASE_VERSION:
        return getReleaseVersion();
      case ModelPackage.CALL_ROUTING_TYPE__START:
        return getStart();
      case ModelPackage.CALL_ROUTING_TYPE__START_MODE:
        return getStartMode();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.CALL_ROUTING_TYPE__INTRO_AUDIO:
        getIntroAudio().clear();
        getIntroAudio().addAll((Collection)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__OUTRO_AUDIO:
        getOutroAudio().clear();
        getOutroAudio().addAll((Collection)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO:
        setHolidayAudio((HolidayAudioType)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO:
        setClosedAudio((ClosedAudioType)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO:
        setTransferAudio((TransferAudioType)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__OPERATOR:
        setOperator((OperatorType)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__MENU_OPERATOR:
        getMenuOperator().clear();
        getMenuOperator().addAll((Collection)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__EVENTS:
        setEvents((EventsType)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS:
        setEventHandlers((EventHandlersType)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__DEFAULT_ROUTING:
        getDefaultRouting().clear();
        getDefaultRouting().addAll((Collection)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__SUB_MENU:
        getSubMenu().clear();
        getSubMenu().addAll((Collection)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__AUDIO_DIR:
        setAudioDir((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__CALL_PROPERTIES:
        setCallProperties((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__CLEANUP_HANDLER:
        setCleanupHandler((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__COMMON:
        setCommon((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__FILE_VERSION:
        setFileVersion((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__MAIN:
        setMain((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__NAME:
        setName((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__RELEASE_VERSION:
        setReleaseVersion((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__START:
        setStart((String)newValue);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__START_MODE:
        setStartMode((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.CALL_ROUTING_TYPE__INTRO_AUDIO:
        getIntroAudio().clear();
        return;
      case ModelPackage.CALL_ROUTING_TYPE__OUTRO_AUDIO:
        getOutroAudio().clear();
        return;
      case ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO:
        setHolidayAudio((HolidayAudioType)null);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO:
        setClosedAudio((ClosedAudioType)null);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO:
        setTransferAudio((TransferAudioType)null);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__OPERATOR:
        setOperator((OperatorType)null);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__MENU_OPERATOR:
        getMenuOperator().clear();
        return;
      case ModelPackage.CALL_ROUTING_TYPE__EVENTS:
        setEvents((EventsType)null);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS:
        setEventHandlers((EventHandlersType)null);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__DEFAULT_ROUTING:
        getDefaultRouting().clear();
        return;
      case ModelPackage.CALL_ROUTING_TYPE__SUB_MENU:
        getSubMenu().clear();
        return;
      case ModelPackage.CALL_ROUTING_TYPE__AUDIO_DIR:
        setAudioDir(AUDIO_DIR_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__CALL_PROPERTIES:
        setCallProperties(CALL_PROPERTIES_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__CLEANUP_HANDLER:
        setCleanupHandler(CLEANUP_HANDLER_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__COMMON:
        setCommon(COMMON_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__FILE_VERSION:
        setFileVersion(FILE_VERSION_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__MAIN:
        setMain(MAIN_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__RELEASE_VERSION:
        setReleaseVersion(RELEASE_VERSION_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__START:
        setStart(START_EDEFAULT);
        return;
      case ModelPackage.CALL_ROUTING_TYPE__START_MODE:
        setStartMode(START_MODE_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.CALL_ROUTING_TYPE__INTRO_AUDIO:
        return introAudio != null && !introAudio.isEmpty();
      case ModelPackage.CALL_ROUTING_TYPE__OUTRO_AUDIO:
        return outroAudio != null && !outroAudio.isEmpty();
      case ModelPackage.CALL_ROUTING_TYPE__HOLIDAY_AUDIO:
        return holidayAudio != null;
      case ModelPackage.CALL_ROUTING_TYPE__CLOSED_AUDIO:
        return closedAudio != null;
      case ModelPackage.CALL_ROUTING_TYPE__TRANSFER_AUDIO:
        return transferAudio != null;
      case ModelPackage.CALL_ROUTING_TYPE__OPERATOR:
        return operator != null;
      case ModelPackage.CALL_ROUTING_TYPE__MENU_OPERATOR:
        return menuOperator != null && !menuOperator.isEmpty();
      case ModelPackage.CALL_ROUTING_TYPE__EVENTS:
        return events != null;
      case ModelPackage.CALL_ROUTING_TYPE__EVENT_HANDLERS:
        return eventHandlers != null;
      case ModelPackage.CALL_ROUTING_TYPE__DEFAULT_ROUTING:
        return defaultRouting != null && !defaultRouting.isEmpty();
      case ModelPackage.CALL_ROUTING_TYPE__SUB_MENU:
        return subMenu != null && !subMenu.isEmpty();
      case ModelPackage.CALL_ROUTING_TYPE__AUDIO_DIR:
        return AUDIO_DIR_EDEFAULT == null ? audioDir != null : !AUDIO_DIR_EDEFAULT.equals(audioDir);
      case ModelPackage.CALL_ROUTING_TYPE__CALL_PROPERTIES:
        return CALL_PROPERTIES_EDEFAULT == null ? callProperties != null : !CALL_PROPERTIES_EDEFAULT.equals(callProperties);
      case ModelPackage.CALL_ROUTING_TYPE__CLEANUP_HANDLER:
        return CLEANUP_HANDLER_EDEFAULT == null ? cleanupHandler != null : !CLEANUP_HANDLER_EDEFAULT.equals(cleanupHandler);
      case ModelPackage.CALL_ROUTING_TYPE__COMMON:
        return COMMON_EDEFAULT == null ? common != null : !COMMON_EDEFAULT.equals(common);
      case ModelPackage.CALL_ROUTING_TYPE__FILE_VERSION:
        return FILE_VERSION_EDEFAULT == null ? fileVersion != null : !FILE_VERSION_EDEFAULT.equals(fileVersion);
      case ModelPackage.CALL_ROUTING_TYPE__MAIN:
        return MAIN_EDEFAULT == null ? main != null : !MAIN_EDEFAULT.equals(main);
      case ModelPackage.CALL_ROUTING_TYPE__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ModelPackage.CALL_ROUTING_TYPE__RELEASE_VERSION:
        return RELEASE_VERSION_EDEFAULT == null ? releaseVersion != null : !RELEASE_VERSION_EDEFAULT.equals(releaseVersion);
      case ModelPackage.CALL_ROUTING_TYPE__START:
        return START_EDEFAULT == null ? start != null : !START_EDEFAULT.equals(start);
      case ModelPackage.CALL_ROUTING_TYPE__START_MODE:
        return START_MODE_EDEFAULT == null ? startMode != null : !START_MODE_EDEFAULT.equals(startMode);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (audioDir: ");
    result.append(audioDir);
    result.append(", callProperties: ");
    result.append(callProperties);
    result.append(", cleanupHandler: ");
    result.append(cleanupHandler);
    result.append(", common: ");
    result.append(common);
    result.append(", fileVersion: ");
    result.append(fileVersion);
    result.append(", main: ");
    result.append(main);
    result.append(", name: ");
    result.append(name);
    result.append(", releaseVersion: ");
    result.append(releaseVersion);
    result.append(", start: ");
    result.append(start);
    result.append(", startMode: ");
    result.append(startMode);
    result.append(')');
    return result.toString();
  }

} //CallRoutingTypeImpl
