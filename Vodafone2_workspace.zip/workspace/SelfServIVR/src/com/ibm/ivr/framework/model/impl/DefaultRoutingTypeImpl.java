/**
 * <copyright>
 * </copyright>
 *
 * $Id: DefaultRoutingTypeImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.DefaultRoutingType;
import com.ibm.ivr.framework.model.ModelPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Default Routing Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DefaultRoutingTypeImpl#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DefaultRoutingTypeImpl#getAlternative <em>Alternative</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DefaultRoutingTypeImpl#getDnis <em>Dnis</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DefaultRoutingTypeImpl extends EDataObjectImpl implements DefaultRoutingType
{
  /**
   * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected static final String VALUE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected String value = VALUE_EDEFAULT;

  /**
   * The default value of the '{@link #getAlternative() <em>Alternative</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlternative()
   * @generated
   * @ordered
   */
  protected static final String ALTERNATIVE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getAlternative() <em>Alternative</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlternative()
   * @generated
   * @ordered
   */
  protected String alternative = ALTERNATIVE_EDEFAULT;

  /**
   * The default value of the '{@link #getDnis() <em>Dnis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDnis()
   * @generated
   * @ordered
   */
  protected static final String DNIS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDnis() <em>Dnis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDnis()
   * @generated
   * @ordered
   */
  protected String dnis = DNIS_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected DefaultRoutingTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getDefaultRoutingType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValue(String newValue)
  {
    String oldValue = value;
    value = newValue;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.DEFAULT_ROUTING_TYPE__VALUE, oldValue, value));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getAlternative()
  {
    return alternative;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlternative(String newAlternative)
  {
    String oldAlternative = alternative;
    alternative = newAlternative;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.DEFAULT_ROUTING_TYPE__ALTERNATIVE, oldAlternative, alternative));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDnis()
  {
    return dnis;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDnis(String newDnis)
  {
    String oldDnis = dnis;
    dnis = newDnis;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.DEFAULT_ROUTING_TYPE__DNIS, oldDnis, dnis));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DEFAULT_ROUTING_TYPE__VALUE:
        return getValue();
      case ModelPackage.DEFAULT_ROUTING_TYPE__ALTERNATIVE:
        return getAlternative();
      case ModelPackage.DEFAULT_ROUTING_TYPE__DNIS:
        return getDnis();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DEFAULT_ROUTING_TYPE__VALUE:
        setValue((String)newValue);
        return;
      case ModelPackage.DEFAULT_ROUTING_TYPE__ALTERNATIVE:
        setAlternative((String)newValue);
        return;
      case ModelPackage.DEFAULT_ROUTING_TYPE__DNIS:
        setDnis((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DEFAULT_ROUTING_TYPE__VALUE:
        setValue(VALUE_EDEFAULT);
        return;
      case ModelPackage.DEFAULT_ROUTING_TYPE__ALTERNATIVE:
        setAlternative(ALTERNATIVE_EDEFAULT);
        return;
      case ModelPackage.DEFAULT_ROUTING_TYPE__DNIS:
        setDnis(DNIS_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DEFAULT_ROUTING_TYPE__VALUE:
        return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
      case ModelPackage.DEFAULT_ROUTING_TYPE__ALTERNATIVE:
        return ALTERNATIVE_EDEFAULT == null ? alternative != null : !ALTERNATIVE_EDEFAULT.equals(alternative);
      case ModelPackage.DEFAULT_ROUTING_TYPE__DNIS:
        return DNIS_EDEFAULT == null ? dnis != null : !DNIS_EDEFAULT.equals(dnis);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (value: ");
    result.append(value);
    result.append(", alternative: ");
    result.append(alternative);
    result.append(", dnis: ");
    result.append(dnis);
    result.append(')');
    return result.toString();
  }

} //DefaultRoutingTypeImpl
