package com.ibm.ivr.framework.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.MenuDefaultType;
import com.ibm.ivr.framework.model.OutroAudioType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.utilities.AudioHelper;
import com.ibm.ivr.framework.utilities.CallRouteStats;
import com.ibm.ivr.framework.utilities.Common;
import com.ibm.ivr.framework.utilities.Reporter;

/**
 * The ExitServlet logs the exit reason of the call in the log file
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2004-06-01: initial version
 * <p>
 * 2004-06-23: Shailesh Gandhi - Added support for "audioDir" and "outroAudio"
 * <p>
 * 2007-03-09: 
 * 
 * @author Fang Wang
 * @version 2007-03-09
 *  
 */
public class ExitServlet extends HttpServlet implements Servlet {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(ExitServlet.class);

	/**
	 * The regular service method
	 * 
	 * @param HttpServletRequest -
	 *            Servlet Request object
	 * @param HttpServletResponse -
	 *            Servlet Response object
	 * 
	 * @return void
	 * @throws ServletException,
	 *             IOException
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		// get session from Servlet request
		HttpSession session = req.getSession(false);

		InputStream is = null;
		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();

		String callid = (String) session.getAttribute("callid");

		boolean testCall = false;
		if (session.getAttribute("testCall") != null)
			testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce
		// number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();
		

		if (testCall)
			LOGGER.info(new StringBuffer(logToken)
				.append("Entering ExitServlet..."));

		
		String result1 = (String)req.getParameter("RESULT1");
		if ( (result1 != null) && (result1.equalsIgnoreCase("FAILURE")) ) {
			LOGGER.error(new StringBuffer(logToken).append("Result1: ").append(result1)
					.append(" Result2: ").append((String)req.getParameter("RESULT2"))
					.append(" Result3: ").append((String)req.getParameter("RESULT3"))
					.append(" Result4: ").append((String)req.getParameter("RESULT4"))
					.append(" Result5: ").append((String)req.getParameter("RESULT5"))
					.append(" Result6: ").append((String)req.getParameter("RESULT6")));
		} else {
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("Result1: ").append(result1)
						.append(" Result2: ").append((String)req.getParameter("RESULT2"))
						.append(" Result3: ").append((String)req.getParameter("RESULT3"))
						.append(" Result4: ").append((String)req.getParameter("RESULT4"))
						.append(" Result5: ").append((String)req.getParameter("RESULT5"))
						.append(" Result6: ").append((String)req.getParameter("RESULT6")));
			}
		}
		String nextPage = null;
		
//		boolean forwardToEndCall = false;
		
		String ctiEnabled = (String)session.getAttribute("ctiEnabled");

		if ( (ctiEnabled != null) && (ctiEnabled.equalsIgnoreCase("Y")) ) {
			if ( (result1 != null) && (result1.equalsIgnoreCase("SUCCESS")) ) {
			     String result6 = ((String)req.getParameter("RESULT6"));
			     String result4 = ((String)req.getParameter("RESULT4"));
			     if ( (result6 != null) && result6.indexOf("NotifyCallStart") != -1){
			    	 LOGGER.error(new StringBuffer(logToken).append("Call Start Failure, Xfer Successful:: ")
			    	            .append("Result1: ").append(result1)
								.append(" Result2: ").append((String)req.getParameter("RESULT2"))
								.append(" Result3: ").append((String)req.getParameter("RESULT3"))
								.append(" Result4: ").append((String)req.getParameter("RESULT4"))
								.append(" Result5: ").append((String)req.getParameter("RESULT5"))
								.append(" Result6: ").append((String)req.getParameter("RESULT6"))); 
			     }else{
				     if ( (result4 != null) && result4.indexOf("DEFAULTVDN Xfer Successful:: ") != -1){
				    	 LOGGER.error(new StringBuffer(logToken).append("Default VDN used for transfer:: ")
				    	            .append("Result1: ").append(result1)
									.append(" Result2: ").append((String)req.getParameter("RESULT2"))
									.append(" Result3: ").append((String)req.getParameter("RESULT3"))
									.append(" Result4: ").append((String)req.getParameter("RESULT4"))
									.append(" Result5: ").append((String)req.getParameter("RESULT5"))
									.append(" Result6: ").append((String)req.getParameter("RESULT6"))); 
				     }			    	 
			     }			     
			}
	}

//		String endCallReturnFlag = (String)session.getAttribute("endCallReturnFlag");
//		if (testCall) 
//			LOGGER.debug("endCallReturnFlag: " + endCallReturnFlag);

//		if ( (ctiEnabled != null) && (ctiEnabled.equalsIgnoreCase("Y")) ) {
//			if ( (endCallReturnFlag == null))
//				forwardToEndCall = true;
//		}
	
//		if (forwardToEndCall) {
			
			// Mirt:  Added logging flag to pass into EndCall.jsv
			//        If testCall
			//            Set ctiLogFlag to "true"
			//         else
			//            Set ctiLogFlag to "false"
			
//			if (testCall)
//				req.setAttribute("ctiLogFlag", "true");
//			else
//				req.setAttribute("ctiLogFlag", "false");
			
			
			//save all the params
//			req.setAttribute("exitReason", req.getParameter("exitReason"));
//			req.setAttribute(" dest", req.getParameter("dest"));
//			req.setAttribute(" mode", req.getParameter("mode"));
//			req.setAttribute(" counter", req.getParameter("counter"));
//			req.setAttribute(" selection", req.getParameter("selection"));
//			req.setAttribute(" audio", req.getParameter("audio"));
//			req.setAttribute(" newAppLink", req.getParameter("newAppLink"));

//			if (testCall) {
//				LOGGER.info(new StringBuffer(logToken)
//					.append("exitReason: ").append(req.getParameter("exitReason"))
//					.append(" dest: ").append(req.getParameter("dest"))
//					.append(" mode: ").append(req.getParameter("mode"))
//					.append(" counter: ").append(req.getParameter("counter"))
//					.append(" selection: ").append(req.getParameter("selection"))
//					.append(" audio: ").append(req.getParameter("audio"))
//					.append(" newAppLink: ").append(req.getParameter("newAppLink")));
//			}

//			nextPage = "/jsp/" + getInitParameter("endCallPage");
			
//			session.setAttribute("endCallReturnFlag", "true");

//			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);

//			if (testCall) {
//				LOGGER.info(new StringBuffer(logToken).append(
//						"Leaving ExitServlet... nextPage: ").append(nextPage));
//			}

//			dispatch.forward(req, resp);
//		} else {
//			if ( (result1 != null) && (result1.equalsIgnoreCase("FAILURE")) ) {
//				LOGGER.error(new StringBuffer(logToken).append("Result1: ").append(result1)
//						.append(" Result2: ").append((String)req.getParameter("RESULT2")));
//			} else {
//				if (testCall) {
//					LOGGER.debug(new StringBuffer(logToken).append("Result1: ").append(result1)
//							.append(" Result2: ").append((String)req.getParameter("RESULT2")));
//				}
//			}

			if (testCall) {
				LOGGER.info(new StringBuffer(logToken)
					.append("exitReason2: ").append(req.getParameter("exitReason"))
					.append(" dest2: ").append(req.getParameter("dest"))
					.append(" mode2: ").append(req.getParameter("mode"))
					.append(" counter2: ").append(req.getParameter("counter"))
					.append(" selection2: ").append(req.getParameter("selection"))
					.append(" audio2: ").append(req.getParameter("audio"))
					.append(" newAppLink2: ").append(req.getParameter("newAppLink")));
			}

			//set log4j Nested Debug Context
			if (NDC.getDepth() == 0)
				NDC.push((String)this.getServletContext().getAttribute("hostName"));
			
			//	get request parameters
			String reason = (String) req.getParameter("exitReason");
			if (reason == null) reason = (String) req.getParameter("dest");
			// in case the reason was not set, use the version saved in the session by transfer servlet
			if (reason == null) reason = (String) session.getAttribute("reason");
			
			String mode = (String) req.getParameter("mode");

			//********************************* BEGIN TEST TOOL TESTING HOOK
			// ********************
			SubMenuType testdata = ((SubMenuType) req.getSession().getAttribute(
					"testdata"));
			if (reason == null && testdata != null) {
				List menuDefaults = testdata.getMenuDefault();
				for (int i = 0; i < menuDefaults.size(); i++) {
					MenuDefaultType md = (MenuDefaultType) menuDefaults.get(i);
					reason = md.getTargetName();
					mode = "DTMF";
					break;
				}
			}
			//********************************* END TEST TOOL TESTING HOOK
			// ********************

			String currentPos = (String) session.getAttribute("currentPos");		
			String appName = null;
			CallRoutingType iCallRouting = (CallRoutingType) session
					.getAttribute("iCallRouting");
			if (iCallRouting != null)
				appName = iCallRouting.getName();

			String dnis = (String) session.getAttribute("DNIS");
			String ani = (String) session.getAttribute("ANI");


			if (mode == null)
				mode = (String) session.getAttribute("mode");

			//get the reporter
			Reporter reporter = (Reporter) this.getServletContext().getAttribute(
					"reporter");
			//contains GVP call id for VAR reporter
			String gvpCallId = (String) session.getAttribute("gvpCallId");

			//set/increment the counter for the parameter if submitted
			String counter = (String) req.getParameter("counter");
			if (counter != null && counter.length() != 0) {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"increment counter: ").append(counter));
				}
				String[] counters = counter.split(",");
				for (int i = 0; i < counters.length; i++) {
					String c = counters[i].trim();
					if (c.length() != 0) {
						reporter.callEvent(gvpCallId, appName, c);
					}
				}
			}

			String selection = (String) req.getParameter("selection");

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("mode: ").append(
						mode));
			}

			// build and log the call Route info
			StringBuffer callRoute = (StringBuffer) session
					.getAttribute("callRoute");
			if (callRoute == null)
				callRoute = new StringBuffer();
			SubMenuType subMenu = ((SubMenuType) session.getAttribute("iSubMenu"));

			// this is only logged when subMenu has atttribute markPosition set
			// not as "false", when the attribute is not specified, default as
			// "true"
			// it will be logged no matter what if this is test call
			if (subMenu != null) {
				String markPosition = subMenu.getMarkPosition();
				if (markPosition == null)
					markPosition = Common.TRUE;
				if (!markPosition.equalsIgnoreCase(Common.FALSE) || testCall) {
					if (selection != null) {
						int index = selection.indexOf(Common.COLON);
						if (index != -1) {
							selection = selection.substring(index + 1).replaceAll(
									" ", "");
						}
					}

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(
								"selection: ").append(selection));

					if ((selection != null) && (selection.length() != 0)) {
						callRoute.append(selection);
						if (mode.equalsIgnoreCase(Common.SPEECH))
							callRoute.append(Common.SPEECH_MODE);
						else if (mode.equalsIgnoreCase(Common.DTMF))
							callRoute.append(Common.DTMF_MODE);
						else if (mode.equalsIgnoreCase(Common.HYBRID))
							callRoute.append(Common.HYBRID_MODE);
					}
				}
			}
			if ((reason.indexOf("Hungup") != -1)
					|| (reason.indexOf("Hangup") != -1)) {
				String selfhelpComplete = (String) session
						.getAttribute("selfhelpComplete");
				if ((selfhelpComplete != null)
						&& (selfhelpComplete.equalsIgnoreCase("true"))) {
					reason = (String) session.getAttribute("selfhelpStatus");
				} else {
					//if hangup occurred after transfer started (interacted with URS), log it
					//as HangupAfterTransfer
					if (session.getAttribute("postTransfer") != null)
						reason = reason + "AfterTransfer";
					
					//if the current menu indicates hangup is an expected behavior,
					// set hangup exitreason into CallerExit
					if (subMenu != null && subMenu.getHangup() != null
							&& subMenu.getHangup().equalsIgnoreCase("callerexit"))
						reason = "CallerExit";

					if (currentPos != null) {
						reason = reason + "." + currentPos;
					}
				}

				// build and save the call Route
				callRoute.append(Common.SEPARATOR).append(Common.HUP);
			}

			if (reason.equalsIgnoreCase("CallerExit")) {
				if (currentPos != null) {
					reason = reason + "." + currentPos;
				}
				String selfhelpComplete = (String) session
						.getAttribute("selfhelpComplete");
				if ((selfhelpComplete != null)
						&& (selfhelpComplete.equalsIgnoreCase("true"))) {
					reason = (String) session.getAttribute("selfhelpStatus");
				}
			}

			if (reason.equalsIgnoreCase("Operator")) {
				if (currentPos != null) {
					reason = reason + "." + currentPos;
					//FWQ: don't know why need this, leave it our for now
					//int index = currentPos.indexOf('_');
					//if (index != -1) {
					//	reason = reason + "." + currentPos.substring(0, index);
					//} else {
					//	reason = reason + "." + currentPos;
					//}
				}

				// build and save the call Route
				callRoute.append(Common.SEPARATOR).append(Common.OPERATOR);
			}

			if ( reason.equalsIgnoreCase("Default")
					|| reason.equalsIgnoreCase("InputError")
					|| reason.equalsIgnoreCase("NoInput")
					|| reason.equalsIgnoreCase("NoMatch")) {
				if (currentPos != null) {
					reason = reason + "." + currentPos;
				}
			}

			if (reason.indexOf("Error") != -1) {

				// build and save the call Route
				callRoute.append(Common.SEPARATOR).append(Common.ERROR);
				if (session.getAttribute("errorLogged") == null)
					LOGGER.error(new StringBuffer(logToken).append("ExitReason: ")
						.append(reason));
			}

			// log the statistics
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("ExitReason: ")
						.append(reason));
				LOGGER.debug(new StringBuffer(logToken).append("callRoute: ")
						.append(callRoute));
			}

			try {
				// since session will be destroyed , retrieve outroAudio and
				// audioDir from session
				// and store in request to use later
				//get audio filename for transfer
				String audio = req.getParameter("audio");
				String audioDir = null;
				if (audio == null || audio.length() == 0) {
					if (iCallRouting != null) {
						List outroAudios = iCallRouting.getOutroAudio();
						String oaFile = "";
						String oaFileTTS = "";
						OutroAudioType oaDefault = null;
						for (int i = 0; i < outroAudios.size(); i++) {
							OutroAudioType oa = (OutroAudioType) outroAudios.get(i);
							if (oa.getDnis() == null) {
								oaDefault = oa;
							} else {
								if (oa.getDnis().indexOf(dnis) != -1) {
									oaFile = oa.getValue();
									oaFileTTS = oa.getTts();
									break;
								}
							}
						}
						if (oaFile.length() == 0 && oaDefault != null) {//no
							// matching
							// dnis
							// is found on
							// OutroAudio
							oaFile = oaDefault.getValue();
							oaFileTTS = oaDefault.getTts();
						}

						// Vodafone: Changed where the audio dir is retrieved from
						//audioDir = iCallRouting.getAudioDir();
						audioDir = (String) session.getAttribute("audioDir");
						req.setAttribute("audioDir", audioDir);
						AudioHelper audioHelper = new AudioHelper(oaFile);
						audioHelper.setTTS(oaFileTTS);
						req.setAttribute("iAudioHelper", audioHelper);
					}
				}

				//retrieve ANI and put in request to be used by NewApp.jsv
				req.setAttribute("ANI", ani);
				if (iCallRouting != null)
					req.setAttribute("appName", iCallRouting.getName());
				req.setAttribute("TNT", session.getAttribute("TNT"));

				
	            // Check Alternate Reporting attribute for additional report inforamtion.
				String altReport = (String) this.getServletContext().getAttribute("altReport");
				if(altReport.equals("true")){
					Date ssReportCallEnd = new Date();
					session.setAttribute("ssReportCallEnd",ssReportCallEnd);				
				}
				
				//Store constructed reason into session for use by Cleanup Handler
				session.setAttribute("callExitReason", reason);
				
				//final cleanup
				if (iCallRouting != null) {
					String handler = iCallRouting.getCleanupHandler();

					try {
						if (handler != null && handler.length() > 0) {
							// Get the classloader for loading resources and classes
							// Use the context classloader to search the servlet
							// path,
							// not the
							// servlet container path
							ClassLoader classloader = Thread.currentThread()
									.getContextClassLoader();
							Servlet servlet = (Servlet) classloader.loadClass(
									handler).newInstance();

							//Calling service should call doGet to be called
							servlet.service(req, resp);
						}
					} catch (Exception e) {
						//throw new RuntimeException(e);
						LOGGER.error(new StringBuffer(logToken).append("Exception From CleanupHandler: "));
						e.printStackTrace();
					}
				}
				//destroy session
				session.invalidate();
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"session with id ").append(session.getId()).append(" destroyed successfully"));
				}

			} catch (Exception ex) {
				ex.printStackTrace();
				LOGGER.error(new StringBuffer(logToken)
						.append("failed to cleanup the session "));
			} finally {
				//if exit reason is AppError, send email alert
				//no need to send since it is controlled in log4j.properties now
				//if (reason.indexOf("AppError") != -1) {
				//	Properties prop = (Properties) this.getServletContext()
				//			.getAttribute("globalProp");
				//	new EmailAlert((String) prop.get("emailSender"), (String) prop
				//			.get("emailRecipient"), reason + " in "
				//			+ req.getContextPath() + " on callid " + callid,
				//			(String) prop.get("SMTP"));
				//}

				//log the statistics
/*				if (gvpCallId !=  null && reporter.isCallStarted(gvpCallId))
					reporter.callEnd(gvpCallId, appName, reason, mode);

				if (testCall) {
					LOGGER.info(new StringBuffer(logToken).append(
							"Current number of concurrent sessions: ").append(
							reporter.getNumOfSessions()));
				}

				//log the CallRoute statistics
				CallRouteStats.logStats(callid, appName, callRoute.toString());

				String newAppLink = req.getParameter("newAppLink");
				
				if (newAppLink != null) {
					nextPage = "/jsp/" + getInitParameter("newAppPage");
				} else {
					nextPage = "/jsp/" + getInitParameter("exitPage");
				}
*/
				//log the CallRoute statistics
				CallRouteStats.logStats(callid, appName, callRoute.toString());
				nextPage = "/jsp/" + getInitParameter("exitPage");

				RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);

				if (testCall) {
					LOGGER.info(new StringBuffer(logToken).append(
							"Leaving ExitServlet... nextPage: ").append(nextPage));
				}

				dispatch.forward(req, resp);
			}
			NDC.remove();
			
		//}
	} 
}