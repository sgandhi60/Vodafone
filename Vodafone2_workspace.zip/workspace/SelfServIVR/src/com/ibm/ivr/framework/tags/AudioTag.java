package com.ibm.ivr.framework.tags;

import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.ibm.ivr.framework.model.AudioType;
import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.utilities.Common;

/**
 * The Audio custom tag
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-11: 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-11
 *  
 */
public class AudioTag extends TagSupport {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(AudioTag.class);

	private String tts = "";

	private String src = "";

	private String dir = "";

	private int index = -1;

	private String listCount = null;

	private String caching = null;

	private String fetchtimeout = null;

	public void setSrc(String _src) {
		this.src = _src;
	}

	public String getSrc() {
		return this.src;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int _index) {
		index = _index;
	}

	public void setListCount(String _listCount) {
		this.src = _listCount;
	}

	public String getListCount() {
		return this.listCount;
	}

	public void setCaching(String _caching) {
		this.caching = _caching;
	}

	public String getCaching() {
		return this.caching;
	}

	public void setFetchtimeout(String _fetchtimeout) {
		this.fetchtimeout = _fetchtimeout;
	}

	public String getFetchtimeout() {
		return this.fetchtimeout;
	}

	public int doStartTag() throws JspException {
		StringBuffer audiotag = new StringBuffer();

		HttpSession session = pageContext.getSession();
		CallRoutingType iCallRouting = (CallRoutingType) session
				.getAttribute("iCallRouting");
		SubMenuType iSubMenu = (SubMenuType) session.getAttribute("iSubMenu");

		// Vodafone: Changed where the audio dir is retrieved from
		//audioDir = iCallRouting.getAudioDir();
		String audioDir = (String) session.getAttribute("audioDir");
		
		//Vodafone If Audiodir starts with $ then strip off $ and get session value(s) 
		
		String audioUtilsDir = audioDir + "/utils";

		// get global properties
		Properties globalProp = (Properties) session.getServletContext()
				.getAttribute("globalProp");

		String audioFileExtension = globalProp
				.getProperty("audioFileExtension");

		// find audio file root location
		String audioRoot = globalProp.getProperty("audioFileRoot");
		String localAudioRoot = ((HttpServletRequest) pageContext.getRequest())
				.getContextPath();
		boolean localAudio = false;

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (src == null)
			src = " ";

		if (index != -1) {
			AudioType audio = (AudioType) iSubMenu.getAudio().get(index);
			//check the cond of the Audio, if false, no need to continue
			String cond = audio.getCond();
			boolean condResult = true;
			if (cond != null && cond.length() != 0) {
				condResult = Common
						.conditionsMatch(cond, session, logToken);
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"AudioTag cond: [" + cond).append(
							"] evaluated as: ").append(condResult));
				if (!condResult) return SKIP_BODY;
			}
			
			src = audio.getValue();
			tts = audio.getTts();
			listCount = audio.getListCount();
			caching = audio.getCaching();
			fetchtimeout = audio.getFetchtimeout();
			dir = audio.getDir();
		}

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append("AudioTag src: "
					+ src));
			LOGGER.debug(new StringBuffer(logToken).append("AudioTag tts: "
					+ tts));
		}

		int count = 1;
		if (listCount != null) {
			try {
				if (listCount.startsWith("$")) {
					count = ((Integer) Common.getSessionValue(listCount
							.substring(1), session)).intValue();
				} else
					count = Integer.parseInt(listCount);
			} catch (NumberFormatException nfe) {
				LOGGER.error(new StringBuffer(logToken).append("listCount: " + listCount
						+ " is not an integer"));
				throw new JspException("listCount: " + listCount
						+ " is not an integer");
			}
		}

		String srcStr = null;

		//replace tab character to reduce the number of segments
		src = src.replaceAll("\\t", "");
		String[] segments = src.split("\\s");

		boolean ttsEmbedded = src.indexOf(("[")) >= 0;
		for (int j = 0; j < count; j++) {
			boolean firstAudio = true;

			for (int i = 0; i < segments.length; i++) {
				//reset audioDir
				// Vodafone: Changed source of audioDir
				// audioDir = iCallRouting.getAudioDir();
				audioDir = (String)session.getAttribute("audioDir");
				localAudio = false;

				srcStr = segments[i].trim();
				// If this is a tts segment, just dump the TTS
				if (srcStr.length() > 0 && srcStr.matches("\\[\\(\\S+\\)\\]")) {
					audiotag.append(
							transformTTS(srcStr.substring(2,
									srcStr.length() - 2), j)).append("\n");
					ttsEmbedded = true;
					continue;
				}
				// If this is a session variable, translate into list of audio
				// file names first
				if (srcStr.length() > 0 && srcStr.matches("\\(\\S+\\)")) {
					int index = srcStr.indexOf(":recording");
					if (index >= 0) {
						audiotag.append(
								"<audio expr=\""
										+ srcStr.trim().substring(1, index)
										+ "\"/>").append("\n");
						continue;
					}

					//set audioDir to utils sub dir
					if (srcStr.indexOf(":local") > 0) {
						localAudio = true;
					}else if  (srcStr.endsWith("file)")) {
						audioDir = (String) session.getAttribute("audioDir");
					}
					else
						audioDir = audioUtilsDir;

					try {						
						srcStr = transformAudio(srcStr.substring(1, srcStr.length() - 1), j, audioFileExtension);
					} catch (Exception e) {
						LOGGER.error(new StringBuffer(logToken).append("Exception caught when formatting variable from text to audio: ").append(e.getMessage()));
						throw new JspException(
								"Exception caught when formatting variable from text to audio: "
										+ e.getMessage());
					}
				}
				StringTokenizer st = new StringTokenizer(srcStr);
				while (st.hasMoreTokens()) {
					String wavFile = st.nextToken().trim();
					if (wavFile.endsWith(audioFileExtension)) {
						if (localAudio)
							audiotag.append("<audio src=\"").append(
									localAudioRoot).append("/audio/").append("/").append(wavFile)
									.append("\"");

						else {
							if (wavFile.startsWith("http"))
								audiotag.append("<audio src=\"").append(wavFile).append("\"");								
							else
								audiotag.append("<audio src=\"").append(audioRoot)
									.append("/audio/").append(audioDir).append(
									"/").append(wavFile).append("\"");
						}

						if (caching != null) {
							audiotag.append(" caching=\"").append(caching)
									.append("\"");
						}
						int timeoutvalue = 0;
						if (fetchtimeout != null) {
							try {
								timeoutvalue = Integer.parseInt(fetchtimeout);
								audiotag.append(" fetchtimeout=\"").append(
										timeoutvalue).append("\"");
							} catch (Exception ex) {
								;
							}
						}

						// If we have TTS and this is the first audio segment -
						// and the TTS is not embedded in the audio segments
						if (session.getServletContext().getInitParameter("ttsEnabled").equalsIgnoreCase(Common.TRUE) && tts != null && firstAudio && !ttsEmbedded) {
							audiotag.append(" >").append(transformTTS(tts, j))
									.append("</audio>\n");
						} else
							audiotag.append(" />\n");
						firstAudio = false;
					} else {
						audiotag.append(wavFile).append("\n");
					}
				}
			}
		}

		if (testCall)
			LOGGER.trace(new StringBuffer(logToken).append("AudioTag content: "
					+ audiotag.toString()));

		try {
			pageContext.getOut().print(audiotag.toString());
		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken).append("AudioTag Error: ").append(e.getMessage()));
			e.printStackTrace();
		}
		return SKIP_BODY;
	}

	private String transformTTS(String tts, int index) {
		HttpSession session = pageContext.getSession();
		StringBuffer result = new StringBuffer();
		String[] segments = tts.split("\\(|\\)");
		for (int i = 0; i < segments.length; i++) {
			String varName = segments[i].split(":")[0].trim();

			String varType = segments[i].indexOf(":") >= 0 ? segments[i]
					.substring(segments[i].indexOf(":") + 1).trim() : "string";

			//if recording type, the variable is VXML variable not session
			// varaible
			if (varType.equals("recording")) {
				result.append("<audio expr=\"" + varName + "\"/>");
				continue;
			}

			Object varValue = null;
			if (varName.endsWith("#")) {
				varValue = Common.getSessionValueFromArray(varName.substring(0,
						varName.length() - 1), session, index);
			} else {
				varValue = Common.getSessionValue(varName, session);
			}

			if (varValue == null) {
				result.append((i > 0 ? " " : "") + segments[i]);
				continue;
			}

			if (varType.equals("string")) {
				result.append((i > 0 ? " " : "")).append(varValue);
			} else {
				result.append((i > 0 ? " " : "")).append(
						"<prosody rate=\"-20%\"><say-as interpret-as=\"")
						.append(varType).append("\">");
				result.append(varValue);
				result.append("</say-as></prosody>");
			}
		}
		return (result.toString());
	}

	private String transformAudio(String src, int index, String extension)
			throws Exception {
		HttpSession session = pageContext.getSession();
		StringBuffer result = new StringBuffer();
		String varName = src.split(":")[0].trim();

		Object varValue = null;

		if (varName.endsWith("#")) {
			varValue = Common.getSessionValueFromArray(varName.substring(0,
					varName.length() - 1), session, index);
		} else {
			varValue = Common.getSessionValue(varName, session);
		}

		if (LOGGER.isTraceEnabled())
			LOGGER.trace(new StringBuffer("session var ").append(
				varName).append("=").append(varValue));

		//convert object to String for generating the audio files
		String varStr = null;
		if (varValue == null) {//if not exist in session, ignore the field
			//varStr = varName;
			varStr = Common.EMPTYSTRING;
			return varStr;
		} else {
			varStr = varValue.toString().trim();
		}

		String varType = src.indexOf(":") >= 0 ? src
				.substring(src.indexOf(":") + 1) : "string";
								
		if (varType.equalsIgnoreCase("wavfile")
				|| varType.equalsIgnoreCase("localwavfile")) {
			result.append(varStr.replace(' ', '-')).append(".wav");
		} else if (varType.equalsIgnoreCase("aufile")
				|| varType.equalsIgnoreCase("localaufile")) {
			result.append(varStr.replace(' ', '-')).append(".au");
		} else if (varType.equalsIgnoreCase("voxfile")
				|| varType.equalsIgnoreCase("localvoxfile")) {
			result.append(varStr.replace(' ', '-')).append(".vox");
		} else if (varType.equalsIgnoreCase("letters")) {
			for (int i = 0; i < varStr.length(); i++) {
				//alpha audio files are lower case
				char c = varStr.toLowerCase().charAt(i);
				if (c == ' ') {
					//result.append("<break time=\"1s\"/>").append(Common.SPACE);
					result.append("1secSilence").append(extension).append(Common.SPACE);
				}
				else if (c == '@') {
					result.append("At").append(extension)
					.append(Common.SPACE);
				}
				else if (c == '.') {
						result.append("Dot").append(extension)
						.append(Common.SPACE);	
				}
				else if (c == '*') {
						result.append("Star").append(extension)
						.append(Common.SPACE);	
				}
				else if (c == '#') {
						result.append("Pound").append(extension)
						.append(Common.SPACE);	
				} else {
					result.append(c).append(extension)
							.append(Common.SPACE);
				}
			}
		} else if (varType.equalsIgnoreCase("digits")) {
			for (int i = 0; i < varStr.length(); i++) {
				char c = varStr.charAt(i);
				if (c == ' ') {
					//result.append("<break time=\"1s\"/>").append(Common.SPACE);
					result.append("1secSilence").append(extension).append(Common.SPACE);
				} else {
					result.append(c).append(extension).append(Common.SPACE);
				}
			}
		} else if (varType.equalsIgnoreCase("phone")) {
			int dc = 0;
			boolean pauseInserted = false;
			//result.append("AreaCode").append(extension).append(Common.SPACE);
			for (int i = 0; i < varStr.length(); i++) {
				char c = varStr.charAt(i);
				if (c == ' ') {
					//result.append("<break time=\"1s\"/>").append(Common.SPACE);
					result.append("1secSilence").append(extension).append(Common.SPACE);
					dc = 0;
					pauseInserted = false;
					//result.append("AreaCode").append(extension).append(Common.SPACE);
				} else if (c == '-') {
					//result.append("<break time=\"0.5s\"/>").append(Common.SPACE);
					result.append("500msSilence").append(extension).append(Common.SPACE);
					pauseInserted = true;
				} else {
					if ((dc == 3 || dc == 6) && !pauseInserted) {
						//result.append("<break time=\"0.5s\"/>").append(Common.SPACE);
						result.append("500msSilence").append(extension).append(Common.SPACE);
					}
					result.append(c).append(extension).append(Common.SPACE);
					dc++;
					pauseInserted = false;
				}
			}
		} else if (varType.equalsIgnoreCase("HHMMDD")) {
			int h = Integer.parseInt(varStr.substring(0, 2));
			result.append(Common.NUMBER[h]).append(extension).append(
					Common.SPACE);
			int m = Integer.parseInt(varStr.substring(2, 4));
			if (m > 0) {
				if (m < 10)
					result.append("oh").append(extension).append(Common.SPACE);
				result.append(Common.NUMBER[m]).append(extension).append(
						Common.SPACE);
			}
			result.append(varStr.substring(4, 6).toUpperCase()).append(
					extension).append(Common.SPACE);
		} else if (varType.equalsIgnoreCase("HHMM")) {
			String designator = "AM";
			int h = Integer.parseInt(varStr.substring(0, 2));
			if (h == 0)
				h = 12;
			else if (h == 12)
				designator = "PM";
			else if (h > 12) {
				h = h - 12;
				designator = "PM";
			}
			result.append(Common.NUMBER[h]).append(extension).append(
					Common.SPACE);
			int m = Integer.parseInt(varStr.substring(2, 4));
			if (m > 0) {
				if (m < 10)
					result.append("oh").append(extension).append(Common.SPACE);
				result.append(Common.NUMBER[m]).append(extension).append(
						Common.SPACE);
			}
			result.append(designator).append(extension).append(Common.SPACE);
		} else if (varType.equalsIgnoreCase("MMDDYYYY")) {
			int m = Integer.parseInt(varStr.substring(0, 2));
			result.append(Common.MONTHS[m]).append(extension).append(
					Common.SPACE);
			int d = Integer.parseInt(varStr.substring(2, 4));
			result.append(Common.DATE[d]).append(extension)
					.append(Common.SPACE);
			int y = Integer.parseInt(varStr.substring(4, 8));
			if (y == 2000) {
				result.append("two-thousand").append(extension).append(
						Common.SPACE);
			}
			else if (y > 2000) {
				result.append("two-thousand").append(extension).append(
						Common.SPACE);
				int t = y - 2000;
				//result.append(Common.NUMBER[t]).append(extension).append(Common.SPACE);
				result.append(Common.EMPTYSTRING + t).append(extension).append(Common.SPACE);
			} else {
				int h = y / 100;
				int t = y - h * 100;
				result.append(Common.NUMBER[h]).append(extension).append(
						Common.SPACE);
				result.append(Common.NUMBER[t]).append(extension).append(
						Common.SPACE);
			}

		} else if (varType.equalsIgnoreCase("DDMMYYYY")) {
			
			// For ENG the DD portion is played a 25th, 1st, 2nd, 3rd etc etc
			// For ALL other languages the DD is played as a number 25, 1, 2, 3, etc etc
			// This is not controlled thru logic but thru the contents of the audio files.   The file may be
			// named twenty-fifth but the contents can be 25 or 25th depending on the language recording.
			
			int d = Integer.parseInt(varStr.substring(0, 2));
						
			result.append(Common.DATE[d]).append(extension)
					.append(Common.SPACE);
			
			int m = Integer.parseInt(varStr.substring(2, 4));
			
			result.append(Common.MONTHS[m]).append(extension).append(
								Common.SPACE);
									
			int y = Integer.parseInt(varStr.substring(4, 8));
									
			if (y == 2000) {
				result.append("two").append(extension).append(
						Common.SPACE).append("thousand")
					      .append(extension)
					      .append(Common.SPACE);
			}
			else if (y > 2000) {
				result.append("two").append(extension).append(
						Common.SPACE).append("thousand")
					      .append(extension)
					      .append(Common.SPACE);
				int t = y - 2000;
				//result.append(Common.NUMBER[t]).append(extension).append(Common.SPACE);
				result.append(Common.EMPTYSTRING + t).append(extension).append(Common.SPACE);
			} else {
				int h = y / 100;
				int t = y - h * 100;
				result.append(Common.NUMBER[h]).append(extension).append(
						Common.SPACE);
				result.append(Common.NUMBER[t]).append(extension).append(
						Common.SPACE);
			}	
						
		}else if (varType.equalsIgnoreCase("MMYY")) {
			int m = Integer.parseInt(varStr.substring(0, 2));
			
			result.append(Common.MONTHS[m]).append(extension).append(
								Common.SPACE);
				
			// Prepend 20 for the year
			int y = Integer.parseInt("20"+varStr.substring(2, 4));

			if (y == 2000) {
				
				result.append("two").append(extension).append(
						Common.SPACE).append("thousand")
					      .append(extension)
					      .append(Common.SPACE);
			}
			else if (y > 2000) {
				result.append("two").append(extension).append(
						Common.SPACE).append("thousand")
					      .append(extension)
					      .append(Common.SPACE);
				int t = y - 2000;
				//result.append(Common.NUMBER[t]).append(extension).append(Common.SPACE);
				result.append(Common.NUMBER[t]).append(extension).append(Common.SPACE);
			} else {
				int h = y / 100;
				int t = y - h * 100;
				result.append(Common.NUMBER[h]).append(extension).append(
						Common.SPACE);
				result.append(Common.NUMBER[t]).append(extension).append(
						Common.SPACE);
			}			
		}else if (varType.equalsIgnoreCase("MM")) {
			int m = Integer.parseInt(varStr);
			
			result.append(Common.MONTHS[m]).append(extension).append(
								Common.SPACE);
										
		}else if (varType.equalsIgnoreCase("currency")) {
			if (LOGGER.isTraceEnabled())
				LOGGER.info("varStr: " + varStr);
			
			//trim off the leading minus sign assuming the credit audio is handled outside
			if (varStr.startsWith("-")) varStr = varStr.substring(1);
			
			int dollar = 0;
			index = varStr.indexOf(".");
			if (index >= 0)
				dollar = Integer.parseInt(varStr.substring(0, index));
			else
				dollar = Integer.parseInt(varStr);

			int s = dollar / 1000;
			int h = (dollar - s * 1000) / 100;
			int t = dollar - s * 1000 - h * 100;
			
			if (LOGGER.isTraceEnabled())
				LOGGER.info("s: " + s + " h: " + h + " t:" + t);
			
			if (s >= 10){
				int ss = s / 100;
				int hh = s - ss * 100;
				if (ss != 0){//if over 100K
					result.append(Common.NUMBER[ss]).append("-hundred").append(
							extension).append(Common.SPACE);
					if (hh == 0)
						result.append("thousand").append(extension).append(Common.SPACE);
				}
				if (hh != 0)
					result.append(Common.NUMBER[hh]).append("-thousand").append(
						extension).append(Common.SPACE);
				
				if (t == 0 && h == 0)
					result.append("dollars").append(extension).append(Common.SPACE);
			}
			else if (s != 0) {
				if (t == 0 && h == 0)
					result.append(Common.NUMBER[s]).append("-thousand-dollars")
							.append(extension).append(Common.SPACE);
				else
					result.append(Common.NUMBER[s]).append("-thousand").append(
							extension).append(Common.SPACE);
			}
			
			if (h != 0) {
				if (t == 0)
					result.append(Common.NUMBER[h]).append("-hundred-dollars")
							.append(extension).append(Common.SPACE);
				else {
					result.append(Common.NUMBER[h]).append("-hundred").append(
							extension).append(Common.SPACE);
				}
			}
			if (t != 0) {
				if (s == 0 && h == 0 && t == 1)
					result.append(Common.NUMBER[t]).append("-dollar").append(
							extension).append(Common.SPACE);
				else
					result.append(Common.NUMBER[t]).append("-dollars").append(
							extension).append(Common.SPACE);
			}
			else {
				if (s == 0 && h == 0)
					result.append(Common.NUMBER[t]).append("-dollars").append(
						extension).append(Common.SPACE);
			}

			if (index >= 0) {
				String temp = varStr.substring(index + 1);
				int cent = 0;
				int subcent = 0;
				if (temp.length() == 1)
					cent = Integer.parseInt(temp + "0");
				else if (temp.length() == 2)
					cent = Integer.parseInt(temp);
				else {
					cent = Integer.parseInt(temp.substring(0, 2));
					subcent = Integer.parseInt(temp.substring(2, 3));
				}
				
				if (LOGGER.isTraceEnabled())
					LOGGER.info("cent: " + cent + " subcent: " + subcent);
				
				if (subcent == 0) {
					result.append("and-");

					if (cent != 1)
						result.append(Common.NUMBER[cent]).append("-cents")
								.append(extension).append(Common.SPACE);
					else
						result.append(Common.NUMBER[cent]).append("-cent")
								.append(extension).append(Common.SPACE);
				} else {
					result.append(Common.NUMBER[cent]).append(extension)
							.append(Common.SPACE);
					result.append("point").append(extension).append(
							Common.SPACE);
					result.append(Common.NUMBER[subcent]).append(extension)
							.append(Common.SPACE);
					result.append("cents").append(extension).append(
							Common.SPACE);
				}
			}
		} else if (varType.equalsIgnoreCase("number")) {
			int number = 0;
			//
			index = varStr.indexOf(".");
			if (index >= 0)
				number = Integer.parseInt(varStr.substring(0, index));
			else
				number = Integer.parseInt(varStr);

			int s = number / 1000;
			int h = (number - s * 1000) / 100;
			int t = number - s * 1000 - h * 100;
			if (s != 0) {
				result.append(Common.NUMBER[s]).append("-thousand").append(
						extension).append(Common.SPACE);
			}
			if (h != 0) {
				result.append(Common.NUMBER[h]).append("-hundred").append(
						extension).append(Common.SPACE);
			}
			if (t != 0) {
				if (s != 0 || h != 0)
					result.append("and").append(extension).append(Common.SPACE);
				result.append(Common.NUMBER[t]).append(extension).append(
						Common.SPACE);
			}
			else
			{
				if (s == 0 && h == 0)
					result.append(Common.NUMBER[t]).append(extension).append(
						Common.SPACE);
			}

		} else if (varType.equalsIgnoreCase("rupee") ||
				          varType.equalsIgnoreCase("rupeewhole")) {
			int number = 0;
			
			// Adjust varString is needed to avoid exception			
			if (varStr.startsWith("."))
				varStr = "0"+varStr;
			if (varStr.endsWith("."))
				varStr = varStr+"0";
			
			// Locate the decimal point, if any
			index = varStr.indexOf(".");
			if (index >= 0)
				number = Integer.parseInt(varStr.substring(0, index));
			else
				number = Integer.parseInt(varStr);

			// Get lacs    Ex:   2149128   results in m = 21 lacs
			int m = number / 100000;
			
			// Get Thousands Ex: 2149128   results in 49  Thousand
			int s = (number - m * 100000) / 1000;
			
			// Get Hundreds  Ex: 2149128  results in 1  hundred
			int h = (number - ((m * 100000) +(s * 1000))) / 100;
			
			// Get 10's and 1's as a whole #.    Ex: 2149128  Results in 28
			int t = (number - ((m * 100000) +(s * 1000) + (h * 100)));

			
			// --------------------------------------------------------------------------
			// Need to break rupee support by language.
			// ENG lang does not have audio for #'s like TwentySeven, ThirtyFour etc etc
			//     so we need to play twenty.wav + seven.wav for ENG only to resolve this.
	        // --------------------------------------------------------------------------
			
			String playLang = (String)session.getAttribute("LANG");
			
				if (playLang.equals("ENG")){

				    //  Need to beak m into smaller parts
				    int k = m;
				    int l = 0;
				    if (m >= 20 ){
				    	k = (m / 10) * 10;    //  For Ex; (28 / 10) * 10 = 20				    	
				    	l = m % 10;           //  For Ex:  28 % 10 = 8
				    }

				    //  Need to beak s into smaller parts
				    int a = s;
				    int b = 0;
				    if (s >= 20 ){
				    	a = (s / 10) * 10;    //  For Ex; (28 / 10) * 10 = 20				    	
				    	b = s % 10;           //  For Ex:  28 % 10 = 8
				    }
					
				    //  Need to beak t into smaller parts
				    int r = t;
				    int v = 0;
				    if (t >= 20 ){
				    	r = (t / 10) * 10;    //  For Ex; (28 / 10) * 10 = 20				    	
				    	v = t % 10;           //  For Ex:  28 % 10 = 8
				    }
					
					//  Add in Rupee Audio that is always played:   rupees.wav
					result.append("rupees").append(extension).append(Common.SPACE);
													
					if (m != 0) {
						
						if (k == 1 && l == 0){
							result.append(Common.NUMBER[k])
						      .append(extension)
						      .append(Common.SPACE)
						      .append("lac")
						      .append(extension)
						      .append(Common.SPACE);					
						}else{						
							if (k > 1){
							result.append(Common.NUMBER[k])
							      .append(extension)
							      .append(Common.SPACE);
							}
							
							if (l > 0){
							result.append(Common.NUMBER[l])
							      .append(extension)
							      .append(Common.SPACE);
							}
							
							// Append lacs
							result.append("lacs")
						      .append(extension)
						      .append(Common.SPACE);
						}
					}
					
					if (s != 0) {
						if (a != 0){
							result.append(Common.NUMBER[a])
						      .append(extension)
						      .append(Common.SPACE);
						}
						if (b != 0){
							result.append(Common.NUMBER[b])
						      .append(extension)
						      .append(Common.SPACE);
						}

						result.append("thousand")
						      .append(extension)
						      .append(Common.SPACE);
					}
		
					if (h != 0) {
						result.append(Common.NUMBER[h])
					      .append(extension)
					      .append(Common.SPACE)
					      .append("hundred")
					      .append(extension)
					      .append(Common.SPACE);
					}
					
					// 
					if (t != 0) {
						// Play r portion
						if (r != 0) {
							result.append(Common.NUMBER[r])
						      .append(extension)
						      .append(Common.SPACE);
						}
						
						// Play v portion
						if (v != 0) {
							result.append(Common.NUMBER[v])
						      .append(extension)
						      .append(Common.SPACE);
						}
					}
					
					
					//  If m, s, h, t are zero then add in zero.wav 
					if (m == 0  &&  s == 0 && h == 0 && t == 0){
						result.append(Common.NUMBER[0]).append(extension);						
					}
					
					
					// See if there are Piasa to deal with
					if (!varType.equalsIgnoreCase("rupeewhole")) {
						if (index >= 0) {
							String temp = varStr.substring(index + 1);
							int cent = 0;
							int subcent = 0;
							if (temp.length() == 1)
								cent = Integer.parseInt(temp + "0");
							else if (temp.length() == 2)
								cent = Integer.parseInt(temp);
							
							
							if (LOGGER.isTraceEnabled())
								LOGGER.info("cent: " + cent + " subcent: " + subcent);
							
							if (cent != 0) {
								if (cent > 1){
									int e = cent;
									int f = 0;
								    //  Need to beak cent into smaller parts
									if (cent >= 20){
								      e = (cent / 10) * 10;    //  For Ex; (28 / 10) * 10 = 20
								      f = cent % 10;           //  For Ex:  28 % 10 = 8
									}
								    // Append initial portion to play
								    result.append(Common.SPACE)
								      .append("and")
							          .append(extension)
							          .append(Common.SPACE);
								    
								    // If there are 10's to play
								    if (e != 0){
								    	result.append(Common.NUMBER[e])
								      	  .append(extension)
								          .append(Common.SPACE);
								    }
								    // If there are 1's to play
								    if (f != 0){
								    	result.append(Common.NUMBER[f])
								      	  .append(extension)
								          .append(Common.SPACE);
								    }
	
								   result.append("paise")
							      	     .append(extension)
							    	     .append(Common.SPACE);
								}else{
									result.append(Common.SPACE)
									   .append("and")
							          .append(extension)
							          .append(Common.SPACE)
							          .append(Common.NUMBER[cent])
							      	  .append(extension)
							          .append(Common.SPACE)				      	  
							      	  .append("paisa")
							      	  .append(extension)
							    	  .append(Common.SPACE);						
								}
							}else{
									result.append(Common.SPACE)
									  .append("and")
							          .append(extension)
							          .append(Common.SPACE)
							          .append(Common.NUMBER[cent])
							      	  .append(extension)
							          .append(Common.SPACE)				      	  
							      	  .append("paise")
							      	  .append(extension)
							    	  .append(Common.SPACE);						
							}
						}else{
								result.append(Common.SPACE)
								  .append("and")
						          .append(extension)
						          .append(Common.SPACE)
						          .append(Common.NUMBER[0])
						      	  .append(extension)
						          .append(Common.SPACE)				      	  
						      	  .append("paise")
						      	  .append(extension)
						    	  .append(Common.SPACE);						
						}
			    	}
                   // End If ENG
		       	}  else if (playLang.equals("HIN") || playLang.equals("Gujarati")){
					
					//  Add in Rupee Audio that is always played:   rupees.wav
					result.append("rupees").append(extension).append(Common.SPACE);
					
								
					if (m != 0) {
						if (m > 1){
						result.append(Common.NUMBER[m])
						      .append(extension)
						      .append(Common.SPACE)
						      .append("lacs")
						      .append(extension)
						      .append(Common.SPACE);
						}else{
							result.append(Common.NUMBER[m])
						      .append(extension)
						      .append(Common.SPACE)
						      .append("lac")
						      .append(extension)
						      .append(Common.SPACE);					
						}
					}
					if (s != 0) {
						result.append(Common.NUMBER[s])
						      .append(extension)
						      .append(Common.SPACE)
						      .append("thousand")
						      .append(extension)
						      .append(Common.SPACE);
					}
		
					if (h != 0) {
						result.append(Common.NUMBER[h])
					      .append(extension)
					      .append(Common.SPACE)
					      .append("hundred")
					      .append(extension)
					      .append(Common.SPACE);
					}
					if (t != 0) {
						result.append(Common.NUMBER[t])
					      .append(extension)
					      .append(Common.SPACE);
					}
					
					//  If m, s, h, t are zero then add in zero.wav 
					if (m == 0  &&  s == 0 && h == 0 && t == 0){
						result.append(Common.NUMBER[0]).append(extension);						
					}
					
					if (!varType.equalsIgnoreCase("rupeewhole")) {
						// See if there are Piasa to deal with
						if (index >= 0) {
							String temp = varStr.substring(index + 1);
							int cent = 0;
							int subcent = 0;
							if (temp.length() == 1)
								cent = Integer.parseInt(temp + "0");
							else if (temp.length() == 2)
								cent = Integer.parseInt(temp);
							
							
							if (LOGGER.isTraceEnabled())
								LOGGER.info("cent: " + cent + " subcent: " + subcent);
							
							if (cent != 0) {
								if (cent > 1){
								result.append(Common.SPACE)
								      .append("and")
							          .append(extension)
							          .append(Common.SPACE)
							          .append(Common.NUMBER[cent])
							      	  .append(extension)
							          .append(Common.SPACE)				      	  
							      	  .append("paise")
							      	  .append(extension)
							    	  .append(Common.SPACE);
								}else{
									result.append(Common.SPACE)
									   .append("and")
							          .append(extension)
							          .append(Common.SPACE)
							          .append(Common.NUMBER[cent])
							      	  .append(extension)
							          .append(Common.SPACE)				      	  
							      	  .append("paisa")
							      	  .append(extension)
							    	  .append(Common.SPACE);						
								}
							}else{
									result.append(Common.SPACE)
									  .append("and")
							          .append(extension)
							          .append(Common.SPACE)
							          .append(Common.NUMBER[cent])
							      	  .append(extension)
							          .append(Common.SPACE)				      	  
							      	  .append("paise")
							      	  .append(extension)
							    	  .append(Common.SPACE);						
							}
						}else{
								result.append(Common.SPACE)
								  .append("and")
						          .append(extension)
						          .append(Common.SPACE)
						          .append(Common.NUMBER[0])
						      	  .append(extension)
						          .append(Common.SPACE)				      	  
						      	  .append("paise")
						      	  .append(extension)
						    	  .append(Common.SPACE);						
						}
				}
              //	 End If HIN
			} else if  (playLang.equals("Punjabi") ||
						playLang.equals("Marathi") ||
						playLang.equals("Assamese") ||
						playLang.equals("Oriya") ||
						playLang.equals("Tamil") ||
						playLang.equals("Malayalam") ||
						playLang.equals("Telugu") ||
						playLang.equals("Kannada") ||
						playLang.equals("Bengali")){
				//  playLang is not ENG and not HIN	
				//  Languages that will follow this logic:
				//     Punjabi
				//     Guajarati
				//     Marathi
				//     Assamese
				//     Bengali
				//     Oriya
				//     Tamil 
				//     Malayalam
				//     Telugu 
				//     Kannada
															
				if (m != 0) {
					if (m > 1){
					result.append(Common.NUMBER[m])
					      .append(extension)
					      .append(Common.SPACE)
					      .append("lacs")
					      .append(extension)
					      .append(Common.SPACE);
					}else{
						result.append(Common.NUMBER[m])
					      .append(extension)
					      .append(Common.SPACE)
					      .append("lac")
					      .append(extension)
					      .append(Common.SPACE);					
					}
				}
				if (s != 0) {
					result.append(Common.NUMBER[s])
					      .append(extension)
					      .append(Common.SPACE)
					      .append("thousand")
					      .append(extension)
					      .append(Common.SPACE);
				}
	
				if (h != 0) {
					result.append(Common.NUMBER[h])
				          .append(extension)
				          .append(Common.SPACE)
				          .append("hundred")
				          .append(extension)
				          .append(Common.SPACE);
				}
				if (t != 0) {
					result.append(Common.NUMBER[t])
				          .append(extension)
				          .append(Common.SPACE);
				}
				
				//  If m, s, h, t are zero then add in zero.wav 
				if (m == 0  &&  s == 0 && h == 0 && t == 0){
					result.append(Common.NUMBER[0])
					      .append(extension)
					      .append(Common.SPACE);						
				}
				
				//  Add in Rupee Audio that is always played:   rupees.wav
				result.append("rupees").append(extension).append(Common.SPACE);
				
				if (!varType.equalsIgnoreCase("rupeewhole")) {
					// See if there are Piasa to deal with
					if (index >= 0) {
						String temp = varStr.substring(index + 1);
						int cent = 0;
						int subcent = 0;
						if (temp.length() == 1)
							cent = Integer.parseInt(temp + "0");
						else if (temp.length() == 2)
							cent = Integer.parseInt(temp);
						
						
						if (LOGGER.isTraceEnabled())
							LOGGER.info("cent: " + cent + " subcent: " + subcent);
						
						if (cent != 0) {
							if (cent > 1){
							result.append(Common.SPACE)
							      .append("and")
						          .append(extension)
						          .append(Common.SPACE)
						          .append(Common.NUMBER[cent])
						      	  .append(extension)
						          .append(Common.SPACE)				      	  
						      	  .append("paise")
						      	  .append(extension)
						    	  .append(Common.SPACE);
							}else{
								result.append(Common.SPACE)
								      .append("and")
						              .append(extension)
						              .append(Common.SPACE)
						              .append(Common.NUMBER[cent])
						      	      .append(extension)
						              .append(Common.SPACE)				      	  
						      	      .append("paisa")
						      	      .append(extension)
						    	      .append(Common.SPACE);						
							}
						}else{
								result.append(Common.SPACE)
								      .append("and")
						              .append(extension)
						              .append(Common.SPACE)
						              .append(Common.NUMBER[cent])
						      	      .append(extension)
						              .append(Common.SPACE)				      	  
						      	      .append("paise")
						          	  .append(extension)
						    	      .append(Common.SPACE);						
						}
					}else{
							result.append(Common.SPACE)
							  .append("and")
					          .append(extension)
					          .append(Common.SPACE)
					          .append(Common.NUMBER[0])
					      	  .append(extension)
					          .append(Common.SPACE)				      	  
					      	  .append("paise")
					      	  .append(extension)
					    	  .append(Common.SPACE);						
					}
			  }
		   }  else	{
				throw new Exception(playLang
						+ " is not a supported audio language.");
			}		
		}else{
			throw new Exception(varType
					+ " is not supported audio format type.");
		}
		return (result.toString());
	}

	public int doEndTag() {
		return EVAL_PAGE;
	}

	/**
	 * @param tts
	 *            The tts to set.
	 */
	public void setTts(String tts) {
		this.tts = tts;
	}

	/**
	 * @return Returns the tts.
	 */
	public String getTts() {
		return tts;
	}
}
