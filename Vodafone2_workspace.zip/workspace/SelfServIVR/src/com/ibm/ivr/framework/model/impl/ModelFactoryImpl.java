/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelFactoryImpl.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModelFactoryImpl extends EFactoryImpl implements ModelFactory
{
  /**
   * Creates and instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModelFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case ModelPackage.AUDIO_CONFIRM_TYPE: return (EObject)createAudioConfirmType();
      case ModelPackage.AUDIO_TYPE: return (EObject)createAudioType();
      case ModelPackage.CALL_ROUTING_TYPE: return (EObject)createCallRoutingType();
      case ModelPackage.CHOICE_TYPE: return (EObject)createChoiceType();
      case ModelPackage.CLOSED_AUDIO_TYPE: return (EObject)createClosedAudioType();
      case ModelPackage.DEFAULT_ROUTING_TYPE: return (EObject)createDefaultRoutingType();
      case ModelPackage.DOCUMENT_ROOT: return (EObject)createDocumentRoot();
      case ModelPackage.EVENT_HANDLERS_TYPE: return (EObject)createEventHandlersType();
      case ModelPackage.EVENTS_TYPE: return (EObject)createEventsType();
      case ModelPackage.GRAMMAR_TYPE: return (EObject)createGrammarType();
      case ModelPackage.HANGUP_TYPE: return (EObject)createHangupType();
      case ModelPackage.HELP_TYPE: return (EObject)createHelpType();
      case ModelPackage.HOLIDAY_AUDIO_TYPE: return (EObject)createHolidayAudioType();
      case ModelPackage.INPUT_ERROR_TYPE: return (EObject)createInputErrorType();
      case ModelPackage.INTRO_AUDIO_TYPE: return (EObject)createIntroAudioType();
      case ModelPackage.MENU_DEFAULT_TYPE: return (EObject)createMenuDefaultType();
      case ModelPackage.MENU_OPERATOR_TYPE: return (EObject)createMenuOperatorType();
      case ModelPackage.NO_INPUT_TYPE: return (EObject)createNoInputType();
      case ModelPackage.NO_MATCH_TYPE: return (EObject)createNoMatchType();
      case ModelPackage.OPERATOR_TYPE: return (EObject)createOperatorType();
      case ModelPackage.OUTRO_AUDIO_TYPE: return (EObject)createOutroAudioType();
      case ModelPackage.SUB_MENU_TYPE: return (EObject)createSubMenuType();
      case ModelPackage.TRANSFER_AUDIO_TYPE: return (EObject)createTransferAudioType();
      case ModelPackage.TRANSFER_TYPE: return (EObject)createTransferType();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AudioConfirmType createAudioConfirmType()
  {
    AudioConfirmTypeImpl audioConfirmType = new AudioConfirmTypeImpl();
    return audioConfirmType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AudioType createAudioType()
  {
    AudioTypeImpl audioType = new AudioTypeImpl();
    return audioType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CallRoutingType createCallRoutingType()
  {
    CallRoutingTypeImpl callRoutingType = new CallRoutingTypeImpl();
    return callRoutingType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ChoiceType createChoiceType()
  {
    ChoiceTypeImpl choiceType = new ChoiceTypeImpl();
    return choiceType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ClosedAudioType createClosedAudioType()
  {
    ClosedAudioTypeImpl closedAudioType = new ClosedAudioTypeImpl();
    return closedAudioType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DefaultRoutingType createDefaultRoutingType()
  {
    DefaultRoutingTypeImpl defaultRoutingType = new DefaultRoutingTypeImpl();
    return defaultRoutingType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DocumentRoot createDocumentRoot()
  {
    DocumentRootImpl documentRoot = new DocumentRootImpl();
    return documentRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventHandlersType createEventHandlersType()
  {
    EventHandlersTypeImpl eventHandlersType = new EventHandlersTypeImpl();
    return eventHandlersType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventsType createEventsType()
  {
    EventsTypeImpl eventsType = new EventsTypeImpl();
    return eventsType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GrammarType createGrammarType()
  {
    GrammarTypeImpl grammarType = new GrammarTypeImpl();
    return grammarType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HangupType createHangupType()
  {
    HangupTypeImpl hangupType = new HangupTypeImpl();
    return hangupType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HelpType createHelpType()
  {
    HelpTypeImpl helpType = new HelpTypeImpl();
    return helpType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HolidayAudioType createHolidayAudioType()
  {
    HolidayAudioTypeImpl holidayAudioType = new HolidayAudioTypeImpl();
    return holidayAudioType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputErrorType createInputErrorType()
  {
    InputErrorTypeImpl inputErrorType = new InputErrorTypeImpl();
    return inputErrorType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IntroAudioType createIntroAudioType()
  {
    IntroAudioTypeImpl introAudioType = new IntroAudioTypeImpl();
    return introAudioType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MenuDefaultType createMenuDefaultType()
  {
    MenuDefaultTypeImpl menuDefaultType = new MenuDefaultTypeImpl();
    return menuDefaultType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MenuOperatorType createMenuOperatorType()
  {
    MenuOperatorTypeImpl menuOperatorType = new MenuOperatorTypeImpl();
    return menuOperatorType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NoInputType createNoInputType()
  {
    NoInputTypeImpl noInputType = new NoInputTypeImpl();
    return noInputType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NoMatchType createNoMatchType()
  {
    NoMatchTypeImpl noMatchType = new NoMatchTypeImpl();
    return noMatchType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OperatorType createOperatorType()
  {
    OperatorTypeImpl operatorType = new OperatorTypeImpl();
    return operatorType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutroAudioType createOutroAudioType()
  {
    OutroAudioTypeImpl outroAudioType = new OutroAudioTypeImpl();
    return outroAudioType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SubMenuType createSubMenuType()
  {
    SubMenuTypeImpl subMenuType = new SubMenuTypeImpl();
    return subMenuType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransferAudioType createTransferAudioType()
  {
    TransferAudioTypeImpl transferAudioType = new TransferAudioTypeImpl();
    return transferAudioType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransferType createTransferType()
  {
    TransferTypeImpl transferType = new TransferTypeImpl();
    return transferType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModelPackage getModelPackage()
  {
    return (ModelPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  public static ModelPackage getPackage()
  {
    return ModelPackage.eINSTANCE;
  }

} //ModelFactoryImpl
