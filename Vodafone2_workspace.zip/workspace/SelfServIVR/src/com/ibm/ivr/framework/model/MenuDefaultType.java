/**
 * <copyright>
 * </copyright>
 *
 * $Id: MenuDefaultType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Menu Default Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getCond <em>Cond</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getCounter <em>Counter</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getDest <em>Dest</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getDestType <em>Dest Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getDnis <em>Dnis</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getHandler <em>Handler</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetAudio <em>Target Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetMode <em>Target Mode</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetName <em>Target Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetType <em>Target Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuDefaultType#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType()
 * @model 
 * @generated
 */
public interface MenuDefaultType
{
  /**
   * Returns the value of the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cond</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cond</em>' attribute.
   * @see #setCond(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_Cond()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCond();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getCond <em>Cond</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Cond</em>' attribute.
   * @see #getCond()
   * @generated
   */
  void setCond(String value);

  /**
   * Returns the value of the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Counter</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Counter</em>' attribute.
   * @see #setCounter(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_Counter()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCounter();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getCounter <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Counter</em>' attribute.
   * @see #getCounter()
   * @generated
   */
  void setCounter(String value);

  /**
   * Returns the value of the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dest</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dest</em>' attribute.
   * @see #setDest(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_Dest()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDest();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getDest <em>Dest</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dest</em>' attribute.
   * @see #getDest()
   * @generated
   */
  void setDest(String value);

  /**
   * Returns the value of the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dest Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dest Type</em>' attribute.
   * @see #setDestType(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_DestType()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDestType();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getDestType <em>Dest Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dest Type</em>' attribute.
   * @see #getDestType()
   * @generated
   */
  void setDestType(String value);

  /**
   * Returns the value of the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dnis</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dnis</em>' attribute.
   * @see #setDnis(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_Dnis()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDnis();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getDnis <em>Dnis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dnis</em>' attribute.
   * @see #getDnis()
   * @generated
   */
  void setDnis(String value);

  /**
   * Returns the value of the '<em><b>Handler</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Handler</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Handler</em>' attribute.
   * @see #setHandler(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_Handler()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getHandler();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getHandler <em>Handler</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Handler</em>' attribute.
   * @see #getHandler()
   * @generated
   */
  void setHandler(String value);

  /**
   * Returns the value of the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Audio</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Audio</em>' attribute.
   * @see #setTargetAudio(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_TargetAudio()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetAudio <em>Target Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Audio</em>' attribute.
   * @see #getTargetAudio()
   * @generated
   */
  void setTargetAudio(String value);

  /**
   * Returns the value of the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Mode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Mode</em>' attribute.
   * @see #setTargetMode(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_TargetMode()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetMode();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetMode <em>Target Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Mode</em>' attribute.
   * @see #getTargetMode()
   * @generated
   */
  void setTargetMode(String value);

  /**
   * Returns the value of the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Name</em>' attribute.
   * @see #setTargetName(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_TargetName()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetName();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetName <em>Target Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Name</em>' attribute.
   * @see #getTargetName()
   * @generated
   */
  void setTargetName(String value);

  /**
   * Returns the value of the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Type</em>' attribute.
   * @see #setTargetType(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_TargetType()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetType();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetType <em>Target Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Type</em>' attribute.
   * @see #getTargetType()
   * @generated
   */
  void setTargetType(String value);

  /**
   * Returns the value of the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tts</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tts</em>' attribute.
   * @see #setTts(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuDefaultType_Tts()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTts();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTts <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tts</em>' attribute.
   * @see #getTts()
   * @generated
   */
  void setTts(String value);

} // MenuDefaultType
