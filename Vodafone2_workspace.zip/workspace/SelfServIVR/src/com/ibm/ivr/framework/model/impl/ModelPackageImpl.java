/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelPackageImpl.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.AudioConfirmType;
import com.ibm.ivr.framework.model.AudioType;
import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.ChoiceType;
import com.ibm.ivr.framework.model.ClosedAudioType;
import com.ibm.ivr.framework.model.DefaultRoutingType;
import com.ibm.ivr.framework.model.DocumentRoot;
import com.ibm.ivr.framework.model.EventHandlersType;
import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.GrammarType;
import com.ibm.ivr.framework.model.HangupType;
import com.ibm.ivr.framework.model.HelpType;
import com.ibm.ivr.framework.model.HolidayAudioType;
import com.ibm.ivr.framework.model.InputErrorType;
import com.ibm.ivr.framework.model.IntroAudioType;
import com.ibm.ivr.framework.model.MenuDefaultType;
import com.ibm.ivr.framework.model.MenuOperatorType;
import com.ibm.ivr.framework.model.ModelFactory;
import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.NoInputType;
import com.ibm.ivr.framework.model.NoMatchType;
import com.ibm.ivr.framework.model.OperatorType;
import com.ibm.ivr.framework.model.OutroAudioType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.model.TransferAudioType;
import com.ibm.ivr.framework.model.TransferType;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import org.eclipse.emf.ecore.xml.type.impl.XMLTypePackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModelPackageImpl extends EPackageImpl implements ModelPackage
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass audioConfirmTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass audioTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass callRoutingTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass choiceTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass closedAudioTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass defaultRoutingTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass documentRootEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventHandlersTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eventsTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass grammarTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hangupTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass helpTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass holidayAudioTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputErrorTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass introAudioTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass menuDefaultTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass menuOperatorTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass noInputTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass noMatchTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass operatorTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outroAudioTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass subMenuTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass transferAudioTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass transferTypeEClass = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.ibm.ivr.framework.model.ModelPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private ModelPackageImpl()
  {
    super(eNS_URI, ModelFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this
   * model, and for any others upon which it depends.  Simple
   * dependencies are satisfied by calling this method on all
   * dependent packages before doing anything else.  This method drives
   * initialization for interdependent packages directly, in parallel
   * with this package, itself.
   * <p>Of this package and its interdependencies, all packages which
   * have not yet been registered by their URI values are first created
   * and registered.  The packages are then initialized in two steps:
   * meta-model objects for all of the packages are created before any
   * are initialized, since one package's meta-model objects may refer to
   * those of another.
   * <p>Invocation of this method will not affect any packages that have
   * already been initialized.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static ModelPackage init()
  {
    if (isInited) return (ModelPackage)EPackage.Registry.INSTANCE.getEPackage(ModelPackage.eNS_URI);

    // Obtain or create and register package
    ModelPackageImpl theModelPackage = (ModelPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof ModelPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new ModelPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    XMLTypePackageImpl.init();

    // Create package meta-data objects
    theModelPackage.createPackageContents();

    // Initialize created meta-data
    theModelPackage.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theModelPackage.freeze();

    return theModelPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAudioConfirmType()
  {
    return audioConfirmTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioConfirmType_Value()
  {
    return (EAttribute)audioConfirmTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioConfirmType_Caching()
  {
    return (EAttribute)audioConfirmTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioConfirmType_Dir()
  {
    return (EAttribute)audioConfirmTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioConfirmType_Fetchtimeout()
  {
    return (EAttribute)audioConfirmTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioConfirmType_ListCount()
  {
    return (EAttribute)audioConfirmTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioConfirmType_Tts()
  {
    return (EAttribute)audioConfirmTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAudioType()
  {
    return audioTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_Value()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_Caching()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_Cond()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_Dir()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_Fetchtimeout()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_ListCount()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudioType_Tts()
  {
    return (EAttribute)audioTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getCallRoutingType()
  {
    return callRoutingTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_IntroAudio()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_OutroAudio()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_HolidayAudio()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_ClosedAudio()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_TransferAudio()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_Operator()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_MenuOperator()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_Events()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_EventHandlers()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_DefaultRouting()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCallRoutingType_SubMenu()
  {
    return (EReference)callRoutingTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_AudioDir()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_CallProperties()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_CleanupHandler()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_Common()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_FileVersion()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_Main()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_Name()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_ReleaseVersion()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_Start()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCallRoutingType_StartMode()
  {
    return (EAttribute)callRoutingTypeEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getChoiceType()
  {
    return choiceTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Annot()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Cond()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Counter()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Dest()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_DestType()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Dtmf()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Handler()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Speech()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_TargetAudio()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_TargetMode()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_TargetName()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_TargetType()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getChoiceType_Tts()
  {
    return (EAttribute)choiceTypeEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getClosedAudioType()
  {
    return closedAudioTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getClosedAudioType_Value()
  {
    return (EAttribute)closedAudioTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getClosedAudioType_Caching()
  {
    return (EAttribute)closedAudioTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getClosedAudioType_Dir()
  {
    return (EAttribute)closedAudioTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getClosedAudioType_Fetchtimeout()
  {
    return (EAttribute)closedAudioTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getClosedAudioType_Terminate()
  {
    return (EAttribute)closedAudioTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getClosedAudioType_Tts()
  {
    return (EAttribute)closedAudioTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDefaultRoutingType()
  {
    return defaultRoutingTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDefaultRoutingType_Value()
  {
    return (EAttribute)defaultRoutingTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDefaultRoutingType_Alternative()
  {
    return (EAttribute)defaultRoutingTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDefaultRoutingType_Dnis()
  {
    return (EAttribute)defaultRoutingTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDocumentRoot()
  {
    return documentRootEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDocumentRoot_Mixed()
  {
    return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_XMLNSPrefixMap()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_XSISchemaLocation()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Audio()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_AudioConfirm()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_CallRouting()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Choice()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_ClosedAudio()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_DefaultRouting()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_EventHandlers()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Events()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Grammar()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Hangup()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Help()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_HolidayAudio()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_InputError()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_IntroAudio()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_MenuDefault()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_MenuOperator()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_NoInput()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_NoMatch()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Operator()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_OutroAudio()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(22);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_SubMenu()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(23);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_Transfer()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(24);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDocumentRoot_TransferAudio()
  {
    return (EReference)documentRootEClass.getEStructuralFeatures().get(25);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventHandlersType()
  {
    return eventHandlersTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventHandlersType_InputError()
  {
    return (EReference)eventHandlersTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventHandlersType_NoInput()
  {
    return (EReference)eventHandlersTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventHandlersType_NoMatch()
  {
    return (EReference)eventHandlersTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventHandlersType_Help()
  {
    return (EReference)eventHandlersTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEventsType()
  {
    return eventsTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventsType_Hangup()
  {
    return (EReference)eventsTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEventsType_Transfer()
  {
    return (EReference)eventsTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGrammarType()
  {
    return grammarTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGrammarType_Value()
  {
    return (EAttribute)grammarTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGrammarType_Type()
  {
    return (EAttribute)grammarTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHangupType()
  {
    return hangupTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHangupType_Cond()
  {
    return (EAttribute)hangupTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHangupType_Counter()
  {
    return (EAttribute)hangupTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHelpType()
  {
    return helpTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Value()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Cond()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Count()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Counter()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Dest()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_DestType()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Reprompt()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_TargetAudio()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_TargetMode()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_TargetName()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_TargetType()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHelpType_Tts()
  {
    return (EAttribute)helpTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHolidayAudioType()
  {
    return holidayAudioTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHolidayAudioType_Value()
  {
    return (EAttribute)holidayAudioTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHolidayAudioType_Caching()
  {
    return (EAttribute)holidayAudioTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHolidayAudioType_Dir()
  {
    return (EAttribute)holidayAudioTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHolidayAudioType_Fetchtimeout()
  {
    return (EAttribute)holidayAudioTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHolidayAudioType_Terminate()
  {
    return (EAttribute)holidayAudioTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHolidayAudioType_Tts()
  {
    return (EAttribute)holidayAudioTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputErrorType()
  {
    return inputErrorTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Value()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Cond()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Count()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Counter()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Dest()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_DestType()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Event()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Reprompt()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_TargetAudio()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_TargetMode()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_TargetName()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_TargetType()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputErrorType_Tts()
  {
    return (EAttribute)inputErrorTypeEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIntroAudioType()
  {
    return introAudioTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIntroAudioType_Value()
  {
    return (EAttribute)introAudioTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIntroAudioType_Caching()
  {
    return (EAttribute)introAudioTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIntroAudioType_Dir()
  {
    return (EAttribute)introAudioTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIntroAudioType_Dnis()
  {
    return (EAttribute)introAudioTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIntroAudioType_Fetchtimeout()
  {
    return (EAttribute)introAudioTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIntroAudioType_Tts()
  {
    return (EAttribute)introAudioTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMenuDefaultType()
  {
    return menuDefaultTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_Cond()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_Counter()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_Dest()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_DestType()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_Dnis()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_Handler()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_TargetAudio()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_TargetMode()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_TargetName()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_TargetType()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuDefaultType_Tts()
  {
    return (EAttribute)menuDefaultTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMenuOperatorType()
  {
    return menuOperatorTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_Value()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_Cond()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_Counter()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_Dest()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_DestType()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_TargetAudio()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_TargetMode()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_TargetName()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_TargetType()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMenuOperatorType_Tts()
  {
    return (EAttribute)menuOperatorTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getNoInputType()
  {
    return noInputTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Value()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Cond()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Count()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Counter()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Dest()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_DestType()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Reprompt()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_TargetAudio()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_TargetMode()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_TargetName()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_TargetType()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoInputType_Tts()
  {
    return (EAttribute)noInputTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getNoMatchType()
  {
    return noMatchTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Value()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Cond()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Count()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Counter()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Dest()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_DestType()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Reprompt()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_TargetAudio()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_TargetMode()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_TargetName()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_TargetType()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getNoMatchType_Tts()
  {
    return (EAttribute)noMatchTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOperatorType()
  {
    return operatorTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOperatorType_Value()
  {
    return (EAttribute)operatorTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOperatorType_Dnis()
  {
    return (EAttribute)operatorTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutroAudioType()
  {
    return outroAudioTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutroAudioType_Value()
  {
    return (EAttribute)outroAudioTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutroAudioType_Caching()
  {
    return (EAttribute)outroAudioTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutroAudioType_Dir()
  {
    return (EAttribute)outroAudioTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutroAudioType_Dnis()
  {
    return (EAttribute)outroAudioTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutroAudioType_Fetchtimeout()
  {
    return (EAttribute)outroAudioTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutroAudioType_Tts()
  {
    return (EAttribute)outroAudioTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSubMenuType()
  {
    return subMenuTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_Audio()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_AudioConfirm()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_Grammar()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_Choice()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_MenuOperator()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_MenuDefault()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_InputError()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_NoInput()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_NoMatch()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_Help()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSubMenuType_Events()
  {
    return (EReference)subMenuTypeEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_ClearDTMFBuffer()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Counter()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_EndCall()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Hangup()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_MarkPosition()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Maxretries()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Mode()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Name()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_RecordingConfirmation()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Repeat()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Retry()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Set()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(22);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Type()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(23);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Vxml()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(24);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSubMenuType_Wait()
  {
    return (EAttribute)subMenuTypeEClass.getEStructuralFeatures().get(25);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTransferAudioType()
  {
    return transferAudioTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTransferAudioType_Value()
  {
    return (EAttribute)transferAudioTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTransferAudioType_Tts()
  {
    return (EAttribute)transferAudioTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTransferType()
  {
    return transferTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTransferType_Cond()
  {
    return (EAttribute)transferTypeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTransferType_Counter()
  {
    return (EAttribute)transferTypeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModelFactory getModelFactory()
  {
    return (ModelFactory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents()
  {
    if (isCreated) return;
    isCreated = true;

    // Create classes and their features
    audioConfirmTypeEClass = createEClass(AUDIO_CONFIRM_TYPE);
    createEAttribute(audioConfirmTypeEClass, AUDIO_CONFIRM_TYPE__VALUE);
    createEAttribute(audioConfirmTypeEClass, AUDIO_CONFIRM_TYPE__CACHING);
    createEAttribute(audioConfirmTypeEClass, AUDIO_CONFIRM_TYPE__DIR);
    createEAttribute(audioConfirmTypeEClass, AUDIO_CONFIRM_TYPE__FETCHTIMEOUT);
    createEAttribute(audioConfirmTypeEClass, AUDIO_CONFIRM_TYPE__LIST_COUNT);
    createEAttribute(audioConfirmTypeEClass, AUDIO_CONFIRM_TYPE__TTS);

    audioTypeEClass = createEClass(AUDIO_TYPE);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__VALUE);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__CACHING);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__COND);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__DIR);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__FETCHTIMEOUT);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__LIST_COUNT);
    createEAttribute(audioTypeEClass, AUDIO_TYPE__TTS);

    callRoutingTypeEClass = createEClass(CALL_ROUTING_TYPE);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__INTRO_AUDIO);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__OUTRO_AUDIO);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__HOLIDAY_AUDIO);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__CLOSED_AUDIO);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__TRANSFER_AUDIO);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__OPERATOR);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__MENU_OPERATOR);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__EVENTS);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__EVENT_HANDLERS);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__DEFAULT_ROUTING);
    createEReference(callRoutingTypeEClass, CALL_ROUTING_TYPE__SUB_MENU);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__AUDIO_DIR);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__CALL_PROPERTIES);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__CLEANUP_HANDLER);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__COMMON);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__FILE_VERSION);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__MAIN);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__NAME);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__RELEASE_VERSION);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__START);
    createEAttribute(callRoutingTypeEClass, CALL_ROUTING_TYPE__START_MODE);

    choiceTypeEClass = createEClass(CHOICE_TYPE);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__ANNOT);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__COND);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__COUNTER);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__DEST);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__DEST_TYPE);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__DTMF);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__HANDLER);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__SPEECH);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__TARGET_AUDIO);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__TARGET_MODE);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__TARGET_NAME);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__TARGET_TYPE);
    createEAttribute(choiceTypeEClass, CHOICE_TYPE__TTS);

    closedAudioTypeEClass = createEClass(CLOSED_AUDIO_TYPE);
    createEAttribute(closedAudioTypeEClass, CLOSED_AUDIO_TYPE__VALUE);
    createEAttribute(closedAudioTypeEClass, CLOSED_AUDIO_TYPE__CACHING);
    createEAttribute(closedAudioTypeEClass, CLOSED_AUDIO_TYPE__DIR);
    createEAttribute(closedAudioTypeEClass, CLOSED_AUDIO_TYPE__FETCHTIMEOUT);
    createEAttribute(closedAudioTypeEClass, CLOSED_AUDIO_TYPE__TERMINATE);
    createEAttribute(closedAudioTypeEClass, CLOSED_AUDIO_TYPE__TTS);

    defaultRoutingTypeEClass = createEClass(DEFAULT_ROUTING_TYPE);
    createEAttribute(defaultRoutingTypeEClass, DEFAULT_ROUTING_TYPE__VALUE);
    createEAttribute(defaultRoutingTypeEClass, DEFAULT_ROUTING_TYPE__ALTERNATIVE);
    createEAttribute(defaultRoutingTypeEClass, DEFAULT_ROUTING_TYPE__DNIS);

    documentRootEClass = createEClass(DOCUMENT_ROOT);
    createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
    createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
    createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
    createEReference(documentRootEClass, DOCUMENT_ROOT__AUDIO);
    createEReference(documentRootEClass, DOCUMENT_ROOT__AUDIO_CONFIRM);
    createEReference(documentRootEClass, DOCUMENT_ROOT__CALL_ROUTING);
    createEReference(documentRootEClass, DOCUMENT_ROOT__CHOICE);
    createEReference(documentRootEClass, DOCUMENT_ROOT__CLOSED_AUDIO);
    createEReference(documentRootEClass, DOCUMENT_ROOT__DEFAULT_ROUTING);
    createEReference(documentRootEClass, DOCUMENT_ROOT__EVENT_HANDLERS);
    createEReference(documentRootEClass, DOCUMENT_ROOT__EVENTS);
    createEReference(documentRootEClass, DOCUMENT_ROOT__GRAMMAR);
    createEReference(documentRootEClass, DOCUMENT_ROOT__HANGUP);
    createEReference(documentRootEClass, DOCUMENT_ROOT__HELP);
    createEReference(documentRootEClass, DOCUMENT_ROOT__HOLIDAY_AUDIO);
    createEReference(documentRootEClass, DOCUMENT_ROOT__INPUT_ERROR);
    createEReference(documentRootEClass, DOCUMENT_ROOT__INTRO_AUDIO);
    createEReference(documentRootEClass, DOCUMENT_ROOT__MENU_DEFAULT);
    createEReference(documentRootEClass, DOCUMENT_ROOT__MENU_OPERATOR);
    createEReference(documentRootEClass, DOCUMENT_ROOT__NO_INPUT);
    createEReference(documentRootEClass, DOCUMENT_ROOT__NO_MATCH);
    createEReference(documentRootEClass, DOCUMENT_ROOT__OPERATOR);
    createEReference(documentRootEClass, DOCUMENT_ROOT__OUTRO_AUDIO);
    createEReference(documentRootEClass, DOCUMENT_ROOT__SUB_MENU);
    createEReference(documentRootEClass, DOCUMENT_ROOT__TRANSFER);
    createEReference(documentRootEClass, DOCUMENT_ROOT__TRANSFER_AUDIO);

    eventHandlersTypeEClass = createEClass(EVENT_HANDLERS_TYPE);
    createEReference(eventHandlersTypeEClass, EVENT_HANDLERS_TYPE__INPUT_ERROR);
    createEReference(eventHandlersTypeEClass, EVENT_HANDLERS_TYPE__NO_INPUT);
    createEReference(eventHandlersTypeEClass, EVENT_HANDLERS_TYPE__NO_MATCH);
    createEReference(eventHandlersTypeEClass, EVENT_HANDLERS_TYPE__HELP);

    eventsTypeEClass = createEClass(EVENTS_TYPE);
    createEReference(eventsTypeEClass, EVENTS_TYPE__HANGUP);
    createEReference(eventsTypeEClass, EVENTS_TYPE__TRANSFER);

    grammarTypeEClass = createEClass(GRAMMAR_TYPE);
    createEAttribute(grammarTypeEClass, GRAMMAR_TYPE__VALUE);
    createEAttribute(grammarTypeEClass, GRAMMAR_TYPE__TYPE);

    hangupTypeEClass = createEClass(HANGUP_TYPE);
    createEAttribute(hangupTypeEClass, HANGUP_TYPE__COND);
    createEAttribute(hangupTypeEClass, HANGUP_TYPE__COUNTER);

    helpTypeEClass = createEClass(HELP_TYPE);
    createEAttribute(helpTypeEClass, HELP_TYPE__VALUE);
    createEAttribute(helpTypeEClass, HELP_TYPE__COND);
    createEAttribute(helpTypeEClass, HELP_TYPE__COUNT);
    createEAttribute(helpTypeEClass, HELP_TYPE__COUNTER);
    createEAttribute(helpTypeEClass, HELP_TYPE__DEST);
    createEAttribute(helpTypeEClass, HELP_TYPE__DEST_TYPE);
    createEAttribute(helpTypeEClass, HELP_TYPE__REPROMPT);
    createEAttribute(helpTypeEClass, HELP_TYPE__TARGET_AUDIO);
    createEAttribute(helpTypeEClass, HELP_TYPE__TARGET_MODE);
    createEAttribute(helpTypeEClass, HELP_TYPE__TARGET_NAME);
    createEAttribute(helpTypeEClass, HELP_TYPE__TARGET_TYPE);
    createEAttribute(helpTypeEClass, HELP_TYPE__TTS);

    holidayAudioTypeEClass = createEClass(HOLIDAY_AUDIO_TYPE);
    createEAttribute(holidayAudioTypeEClass, HOLIDAY_AUDIO_TYPE__VALUE);
    createEAttribute(holidayAudioTypeEClass, HOLIDAY_AUDIO_TYPE__CACHING);
    createEAttribute(holidayAudioTypeEClass, HOLIDAY_AUDIO_TYPE__DIR);
    createEAttribute(holidayAudioTypeEClass, HOLIDAY_AUDIO_TYPE__FETCHTIMEOUT);
    createEAttribute(holidayAudioTypeEClass, HOLIDAY_AUDIO_TYPE__TERMINATE);
    createEAttribute(holidayAudioTypeEClass, HOLIDAY_AUDIO_TYPE__TTS);

    inputErrorTypeEClass = createEClass(INPUT_ERROR_TYPE);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__VALUE);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__COND);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__COUNT);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__COUNTER);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__DEST);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__DEST_TYPE);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__EVENT);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__REPROMPT);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__TARGET_AUDIO);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__TARGET_MODE);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__TARGET_NAME);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__TARGET_TYPE);
    createEAttribute(inputErrorTypeEClass, INPUT_ERROR_TYPE__TTS);

    introAudioTypeEClass = createEClass(INTRO_AUDIO_TYPE);
    createEAttribute(introAudioTypeEClass, INTRO_AUDIO_TYPE__VALUE);
    createEAttribute(introAudioTypeEClass, INTRO_AUDIO_TYPE__CACHING);
    createEAttribute(introAudioTypeEClass, INTRO_AUDIO_TYPE__DIR);
    createEAttribute(introAudioTypeEClass, INTRO_AUDIO_TYPE__DNIS);
    createEAttribute(introAudioTypeEClass, INTRO_AUDIO_TYPE__FETCHTIMEOUT);
    createEAttribute(introAudioTypeEClass, INTRO_AUDIO_TYPE__TTS);

    menuDefaultTypeEClass = createEClass(MENU_DEFAULT_TYPE);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__COND);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__COUNTER);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__DEST);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__DEST_TYPE);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__DNIS);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__HANDLER);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__TARGET_AUDIO);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__TARGET_MODE);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__TARGET_NAME);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__TARGET_TYPE);
    createEAttribute(menuDefaultTypeEClass, MENU_DEFAULT_TYPE__TTS);

    menuOperatorTypeEClass = createEClass(MENU_OPERATOR_TYPE);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__VALUE);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__COND);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__COUNTER);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__DEST);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__DEST_TYPE);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__TARGET_AUDIO);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__TARGET_MODE);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__TARGET_NAME);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__TARGET_TYPE);
    createEAttribute(menuOperatorTypeEClass, MENU_OPERATOR_TYPE__TTS);

    noInputTypeEClass = createEClass(NO_INPUT_TYPE);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__VALUE);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__COND);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__COUNT);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__COUNTER);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__DEST);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__DEST_TYPE);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__REPROMPT);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__TARGET_AUDIO);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__TARGET_MODE);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__TARGET_NAME);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__TARGET_TYPE);
    createEAttribute(noInputTypeEClass, NO_INPUT_TYPE__TTS);

    noMatchTypeEClass = createEClass(NO_MATCH_TYPE);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__VALUE);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__COND);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__COUNT);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__COUNTER);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__DEST);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__DEST_TYPE);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__REPROMPT);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__TARGET_AUDIO);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__TARGET_MODE);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__TARGET_NAME);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__TARGET_TYPE);
    createEAttribute(noMatchTypeEClass, NO_MATCH_TYPE__TTS);

    operatorTypeEClass = createEClass(OPERATOR_TYPE);
    createEAttribute(operatorTypeEClass, OPERATOR_TYPE__VALUE);
    createEAttribute(operatorTypeEClass, OPERATOR_TYPE__DNIS);

    outroAudioTypeEClass = createEClass(OUTRO_AUDIO_TYPE);
    createEAttribute(outroAudioTypeEClass, OUTRO_AUDIO_TYPE__VALUE);
    createEAttribute(outroAudioTypeEClass, OUTRO_AUDIO_TYPE__CACHING);
    createEAttribute(outroAudioTypeEClass, OUTRO_AUDIO_TYPE__DIR);
    createEAttribute(outroAudioTypeEClass, OUTRO_AUDIO_TYPE__DNIS);
    createEAttribute(outroAudioTypeEClass, OUTRO_AUDIO_TYPE__FETCHTIMEOUT);
    createEAttribute(outroAudioTypeEClass, OUTRO_AUDIO_TYPE__TTS);

    subMenuTypeEClass = createEClass(SUB_MENU_TYPE);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__AUDIO);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__AUDIO_CONFIRM);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__GRAMMAR);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__CHOICE);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__MENU_OPERATOR);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__MENU_DEFAULT);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__INPUT_ERROR);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__NO_INPUT);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__NO_MATCH);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__HELP);
    createEReference(subMenuTypeEClass, SUB_MENU_TYPE__EVENTS);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__CLEAR_DTMF_BUFFER);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__COUNTER);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__END_CALL);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__HANGUP);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__MARK_POSITION);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__MAXRETRIES);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__MODE);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__NAME);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__RECORDING_CONFIRMATION);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__REPEAT);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__RETRY);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__SET);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__TYPE);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__VXML);
    createEAttribute(subMenuTypeEClass, SUB_MENU_TYPE__WAIT);

    transferAudioTypeEClass = createEClass(TRANSFER_AUDIO_TYPE);
    createEAttribute(transferAudioTypeEClass, TRANSFER_AUDIO_TYPE__VALUE);
    createEAttribute(transferAudioTypeEClass, TRANSFER_AUDIO_TYPE__TTS);

    transferTypeEClass = createEClass(TRANSFER_TYPE);
    createEAttribute(transferTypeEClass, TRANSFER_TYPE__COND);
    createEAttribute(transferTypeEClass, TRANSFER_TYPE__COUNTER);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents()
  {
    if (isInitialized) return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    XMLTypePackageImpl theXMLTypePackage = (XMLTypePackageImpl)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

    // Add supertypes to classes

    // Initialize classes and features; add operations and parameters
    initEClass(audioConfirmTypeEClass, AudioConfirmType.class, "AudioConfirmType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getAudioConfirmType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, AudioConfirmType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioConfirmType_Caching(), theXMLTypePackage.getString(), "caching", null, 0, 1, AudioConfirmType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioConfirmType_Dir(), theXMLTypePackage.getString(), "dir", null, 0, 1, AudioConfirmType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioConfirmType_Fetchtimeout(), theXMLTypePackage.getString(), "fetchtimeout", null, 0, 1, AudioConfirmType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioConfirmType_ListCount(), theXMLTypePackage.getString(), "listCount", null, 0, 1, AudioConfirmType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioConfirmType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, AudioConfirmType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(audioTypeEClass, AudioType.class, "AudioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getAudioType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioType_Caching(), theXMLTypePackage.getString(), "caching", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioType_Dir(), theXMLTypePackage.getString(), "dir", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioType_Fetchtimeout(), theXMLTypePackage.getString(), "fetchtimeout", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioType_ListCount(), theXMLTypePackage.getString(), "listCount", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudioType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, AudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(callRoutingTypeEClass, CallRoutingType.class, "CallRoutingType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getCallRoutingType_IntroAudio(), this.getIntroAudioType(), null, "introAudio", null, 0, -1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_OutroAudio(), this.getOutroAudioType(), null, "outroAudio", null, 0, -1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_HolidayAudio(), this.getHolidayAudioType(), null, "holidayAudio", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_ClosedAudio(), this.getClosedAudioType(), null, "closedAudio", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_TransferAudio(), this.getTransferAudioType(), null, "transferAudio", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_Operator(), this.getOperatorType(), null, "operator", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_MenuOperator(), this.getMenuOperatorType(), null, "menuOperator", null, 0, -1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_Events(), this.getEventsType(), null, "events", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_EventHandlers(), this.getEventHandlersType(), null, "eventHandlers", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_DefaultRouting(), this.getDefaultRoutingType(), null, "defaultRouting", null, 0, -1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCallRoutingType_SubMenu(), this.getSubMenuType(), null, "subMenu", null, 1, -1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_AudioDir(), theXMLTypePackage.getString(), "audioDir", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_CallProperties(), theXMLTypePackage.getString(), "callProperties", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_CleanupHandler(), theXMLTypePackage.getString(), "cleanupHandler", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_Common(), theXMLTypePackage.getString(), "common", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_FileVersion(), theXMLTypePackage.getString(), "fileVersion", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_Main(), theXMLTypePackage.getString(), "main", null, 0, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_ReleaseVersion(), theXMLTypePackage.getString(), "releaseVersion", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_Start(), theXMLTypePackage.getString(), "start", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCallRoutingType_StartMode(), theXMLTypePackage.getString(), "startMode", null, 1, 1, CallRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(choiceTypeEClass, ChoiceType.class, "ChoiceType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getChoiceType_Annot(), theXMLTypePackage.getString(), "annot", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Dtmf(), theXMLTypePackage.getString(), "dtmf", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Handler(), theXMLTypePackage.getString(), "handler", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Speech(), theXMLTypePackage.getString(), "speech", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getChoiceType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, ChoiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(closedAudioTypeEClass, ClosedAudioType.class, "ClosedAudioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getClosedAudioType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, ClosedAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getClosedAudioType_Caching(), theXMLTypePackage.getString(), "caching", null, 0, 1, ClosedAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getClosedAudioType_Dir(), theXMLTypePackage.getString(), "dir", null, 0, 1, ClosedAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getClosedAudioType_Fetchtimeout(), theXMLTypePackage.getString(), "fetchtimeout", null, 0, 1, ClosedAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getClosedAudioType_Terminate(), theXMLTypePackage.getString(), "terminate", null, 0, 1, ClosedAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getClosedAudioType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, ClosedAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(defaultRoutingTypeEClass, DefaultRoutingType.class, "DefaultRoutingType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getDefaultRoutingType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, DefaultRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getDefaultRoutingType_Alternative(), theXMLTypePackage.getString(), "alternative", null, 0, 1, DefaultRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getDefaultRoutingType_Dnis(), theXMLTypePackage.getString(), "dnis", null, 0, 1, DefaultRoutingType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Audio(), this.getAudioType(), null, "audio", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_AudioConfirm(), this.getAudioConfirmType(), null, "audioConfirm", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_CallRouting(), this.getCallRoutingType(), null, "callRouting", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Choice(), this.getChoiceType(), null, "choice", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_ClosedAudio(), this.getClosedAudioType(), null, "closedAudio", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_DefaultRouting(), this.getDefaultRoutingType(), null, "defaultRouting", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_EventHandlers(), this.getEventHandlersType(), null, "eventHandlers", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Events(), this.getEventsType(), null, "events", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Grammar(), this.getGrammarType(), null, "grammar", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Hangup(), this.getHangupType(), null, "hangup", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Help(), this.getHelpType(), null, "help", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_HolidayAudio(), this.getHolidayAudioType(), null, "holidayAudio", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_InputError(), this.getInputErrorType(), null, "inputError", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_IntroAudio(), this.getIntroAudioType(), null, "introAudio", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_MenuDefault(), this.getMenuDefaultType(), null, "menuDefault", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_MenuOperator(), this.getMenuOperatorType(), null, "menuOperator", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_NoInput(), this.getNoInputType(), null, "noInput", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_NoMatch(), this.getNoMatchType(), null, "noMatch", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Operator(), this.getOperatorType(), null, "operator", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_OutroAudio(), this.getOutroAudioType(), null, "outroAudio", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_SubMenu(), this.getSubMenuType(), null, "subMenu", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_Transfer(), this.getTransferType(), null, "transfer", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
    initEReference(getDocumentRoot_TransferAudio(), this.getTransferAudioType(), null, "transferAudio", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

    initEClass(eventHandlersTypeEClass, EventHandlersType.class, "EventHandlersType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getEventHandlersType_InputError(), this.getInputErrorType(), null, "inputError", null, 0, -1, EventHandlersType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEventHandlersType_NoInput(), this.getNoInputType(), null, "noInput", null, 0, -1, EventHandlersType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEventHandlersType_NoMatch(), this.getNoMatchType(), null, "noMatch", null, 0, -1, EventHandlersType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEventHandlersType_Help(), this.getHelpType(), null, "help", null, 0, 1, EventHandlersType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(eventsTypeEClass, EventsType.class, "EventsType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getEventsType_Hangup(), this.getHangupType(), null, "hangup", null, 0, -1, EventsType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEventsType_Transfer(), this.getTransferType(), null, "transfer", null, 0, -1, EventsType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(grammarTypeEClass, GrammarType.class, "GrammarType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGrammarType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, GrammarType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGrammarType_Type(), theXMLTypePackage.getString(), "type", null, 0, 1, GrammarType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(hangupTypeEClass, HangupType.class, "HangupType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getHangupType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, HangupType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHangupType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, HangupType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(helpTypeEClass, HelpType.class, "HelpType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getHelpType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_Count(), theXMLTypePackage.getInt(), "count", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_Reprompt(), theXMLTypePackage.getString(), "reprompt", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHelpType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, HelpType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(holidayAudioTypeEClass, HolidayAudioType.class, "HolidayAudioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getHolidayAudioType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, HolidayAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHolidayAudioType_Caching(), theXMLTypePackage.getString(), "caching", null, 0, 1, HolidayAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHolidayAudioType_Dir(), theXMLTypePackage.getString(), "dir", null, 0, 1, HolidayAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHolidayAudioType_Fetchtimeout(), theXMLTypePackage.getString(), "fetchtimeout", null, 0, 1, HolidayAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHolidayAudioType_Terminate(), theXMLTypePackage.getString(), "terminate", null, 0, 1, HolidayAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHolidayAudioType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, HolidayAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputErrorTypeEClass, InputErrorType.class, "InputErrorType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getInputErrorType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Count(), theXMLTypePackage.getInt(), "count", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Event(), theXMLTypePackage.getString(), "event", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Reprompt(), theXMLTypePackage.getString(), "reprompt", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getInputErrorType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, InputErrorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(introAudioTypeEClass, IntroAudioType.class, "IntroAudioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getIntroAudioType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, IntroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIntroAudioType_Caching(), theXMLTypePackage.getString(), "caching", null, 0, 1, IntroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIntroAudioType_Dir(), theXMLTypePackage.getString(), "dir", null, 0, 1, IntroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIntroAudioType_Dnis(), theXMLTypePackage.getString(), "dnis", null, 0, 1, IntroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIntroAudioType_Fetchtimeout(), theXMLTypePackage.getString(), "fetchtimeout", null, 0, 1, IntroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIntroAudioType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, IntroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(menuDefaultTypeEClass, MenuDefaultType.class, "MenuDefaultType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMenuDefaultType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_Dnis(), theXMLTypePackage.getString(), "dnis", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_Handler(), theXMLTypePackage.getString(), "handler", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuDefaultType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, MenuDefaultType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(menuOperatorTypeEClass, MenuOperatorType.class, "MenuOperatorType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMenuOperatorType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMenuOperatorType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, MenuOperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(noInputTypeEClass, NoInputType.class, "NoInputType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getNoInputType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_Count(), theXMLTypePackage.getInt(), "count", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_Reprompt(), theXMLTypePackage.getString(), "reprompt", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoInputType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, NoInputType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(noMatchTypeEClass, NoMatchType.class, "NoMatchType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getNoMatchType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_Count(), theXMLTypePackage.getInt(), "count", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_Dest(), theXMLTypePackage.getString(), "dest", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_DestType(), theXMLTypePackage.getString(), "destType", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_Reprompt(), theXMLTypePackage.getString(), "reprompt", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_TargetAudio(), theXMLTypePackage.getString(), "targetAudio", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_TargetMode(), theXMLTypePackage.getString(), "targetMode", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_TargetName(), theXMLTypePackage.getString(), "targetName", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_TargetType(), theXMLTypePackage.getString(), "targetType", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getNoMatchType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, NoMatchType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(operatorTypeEClass, OperatorType.class, "OperatorType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getOperatorType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, OperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOperatorType_Dnis(), theXMLTypePackage.getString(), "dnis", null, 0, 1, OperatorType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outroAudioTypeEClass, OutroAudioType.class, "OutroAudioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getOutroAudioType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, OutroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOutroAudioType_Caching(), theXMLTypePackage.getString(), "caching", null, 0, 1, OutroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOutroAudioType_Dir(), theXMLTypePackage.getString(), "dir", null, 0, 1, OutroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOutroAudioType_Dnis(), theXMLTypePackage.getString(), "dnis", null, 0, 1, OutroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOutroAudioType_Fetchtimeout(), theXMLTypePackage.getString(), "fetchtimeout", null, 0, 1, OutroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOutroAudioType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, OutroAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(subMenuTypeEClass, SubMenuType.class, "SubMenuType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getSubMenuType_Audio(), this.getAudioType(), null, "audio", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_AudioConfirm(), this.getAudioConfirmType(), null, "audioConfirm", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_Grammar(), this.getGrammarType(), null, "grammar", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_Choice(), this.getChoiceType(), null, "choice", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_MenuOperator(), this.getMenuOperatorType(), null, "menuOperator", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_MenuDefault(), this.getMenuDefaultType(), null, "menuDefault", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_InputError(), this.getInputErrorType(), null, "inputError", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_NoInput(), this.getNoInputType(), null, "noInput", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_NoMatch(), this.getNoMatchType(), null, "noMatch", null, 0, -1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_Help(), this.getHelpType(), null, "help", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSubMenuType_Events(), this.getEventsType(), null, "events", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_ClearDTMFBuffer(), theXMLTypePackage.getString(), "clearDTMFBuffer", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_EndCall(), theXMLTypePackage.getString(), "endCall", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Hangup(), theXMLTypePackage.getString(), "hangup", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_MarkPosition(), theXMLTypePackage.getString(), "markPosition", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Maxretries(), theXMLTypePackage.getInt(), "maxretries", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Mode(), theXMLTypePackage.getString(), "mode", null, 1, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_RecordingConfirmation(), theXMLTypePackage.getString(), "recordingConfirmation", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Repeat(), theXMLTypePackage.getString(), "repeat", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Retry(), theXMLTypePackage.getString(), "retry", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Set(), theXMLTypePackage.getString(), "set", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Type(), theXMLTypePackage.getString(), "type", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Vxml(), theXMLTypePackage.getString(), "vxml", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSubMenuType_Wait(), theXMLTypePackage.getString(), "wait", null, 0, 1, SubMenuType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(transferAudioTypeEClass, TransferAudioType.class, "TransferAudioType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getTransferAudioType_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, TransferAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTransferAudioType_Tts(), theXMLTypePackage.getString(), "tts", null, 0, 1, TransferAudioType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(transferTypeEClass, TransferType.class, "TransferType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getTransferType_Cond(), theXMLTypePackage.getString(), "cond", null, 0, 1, TransferType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTransferType_Counter(), theXMLTypePackage.getString(), "counter", null, 0, 1, TransferType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    // Create resource
    createResource(eNS_URI);

    // Create annotations
    // http:///org/eclipse/emf/ecore/util/ExtendedMetaData
    createExtendedMetaDataAnnotations();
  }

  /**
   * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createExtendedMetaDataAnnotations()
  {
    String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
    addAnnotation
      (audioConfirmTypeEClass, 
       source, 
       new String[] 
       {
       "name", "AudioConfirm_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getAudioConfirmType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getAudioConfirmType_Caching(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "caching"
       });		
    addAnnotation
      (getAudioConfirmType_Dir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dir"
       });		
    addAnnotation
      (getAudioConfirmType_Fetchtimeout(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fetchtimeout"
       });		
    addAnnotation
      (getAudioConfirmType_ListCount(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "listCount"
       });		
    addAnnotation
      (getAudioConfirmType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (audioTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Audio_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getAudioType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getAudioType_Caching(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "caching"
       });		
    addAnnotation
      (getAudioType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getAudioType_Dir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dir"
       });		
    addAnnotation
      (getAudioType_Fetchtimeout(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fetchtimeout"
       });		
    addAnnotation
      (getAudioType_ListCount(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "listCount"
       });		
    addAnnotation
      (getAudioType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (callRoutingTypeEClass, 
       source, 
       new String[] 
       {
       "name", "CallRouting_._type",
       "kind", "elementOnly"
       });		
    addAnnotation
      (getCallRoutingType_IntroAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "IntroAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_OutroAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "OutroAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_HolidayAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "HolidayAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_ClosedAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "ClosedAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_TransferAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "TransferAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_Operator(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Operator",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_MenuOperator(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "MenuOperator",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_Events(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Events",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_EventHandlers(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "EventHandlers",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_DefaultRouting(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "DefaultRouting",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_SubMenu(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "SubMenu",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getCallRoutingType_AudioDir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "audioDir"
       });		
    addAnnotation
      (getCallRoutingType_CallProperties(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "callProperties"
       });		
    addAnnotation
      (getCallRoutingType_CleanupHandler(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cleanupHandler"
       });		
    addAnnotation
      (getCallRoutingType_Common(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "common"
       });		
    addAnnotation
      (getCallRoutingType_FileVersion(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fileVersion"
       });		
    addAnnotation
      (getCallRoutingType_Main(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "main"
       });		
    addAnnotation
      (getCallRoutingType_Name(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "name"
       });		
    addAnnotation
      (getCallRoutingType_ReleaseVersion(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "releaseVersion"
       });		
    addAnnotation
      (getCallRoutingType_Start(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "start"
       });		
    addAnnotation
      (getCallRoutingType_StartMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "startMode"
       });		
    addAnnotation
      (choiceTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Choice_._type",
       "kind", "empty"
       });		
    addAnnotation
      (getChoiceType_Annot(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "annot"
       });		
    addAnnotation
      (getChoiceType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getChoiceType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getChoiceType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getChoiceType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getChoiceType_Dtmf(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dtmf"
       });		
    addAnnotation
      (getChoiceType_Handler(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "handler"
       });		
    addAnnotation
      (getChoiceType_Speech(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "speech"
       });		
    addAnnotation
      (getChoiceType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getChoiceType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getChoiceType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getChoiceType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getChoiceType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (closedAudioTypeEClass, 
       source, 
       new String[] 
       {
       "name", "ClosedAudio_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getClosedAudioType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getClosedAudioType_Caching(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "caching"
       });		
    addAnnotation
      (getClosedAudioType_Dir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dir"
       });		
    addAnnotation
      (getClosedAudioType_Fetchtimeout(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fetchtimeout"
       });		
    addAnnotation
      (getClosedAudioType_Terminate(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "terminate"
       });		
    addAnnotation
      (getClosedAudioType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (defaultRoutingTypeEClass, 
       source, 
       new String[] 
       {
       "name", "DefaultRouting_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getDefaultRoutingType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getDefaultRoutingType_Alternative(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "alternative"
       });		
    addAnnotation
      (getDefaultRoutingType_Dnis(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dnis"
       });		
    addAnnotation
      (documentRootEClass, 
       source, 
       new String[] 
       {
       "name", "",
       "kind", "mixed"
       });		
    addAnnotation
      (getDocumentRoot_Mixed(), 
       source, 
       new String[] 
       {
       "kind", "elementWildcard",
       "name", ":mixed"
       });		
    addAnnotation
      (getDocumentRoot_XMLNSPrefixMap(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "xmlns:prefix"
       });		
    addAnnotation
      (getDocumentRoot_XSISchemaLocation(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "xsi:schemaLocation"
       });		
    addAnnotation
      (getDocumentRoot_Audio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Audio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_AudioConfirm(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "AudioConfirm",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_CallRouting(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "CallRouting",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Choice(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Choice",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_ClosedAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "ClosedAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_DefaultRouting(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "DefaultRouting",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_EventHandlers(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "EventHandlers",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Events(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Events",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Grammar(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Grammar",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Hangup(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Hangup",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Help(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Help",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_HolidayAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "HolidayAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_InputError(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "InputError",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_IntroAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "IntroAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_MenuDefault(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "MenuDefault",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_MenuOperator(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "MenuOperator",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_NoInput(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "NoInput",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_NoMatch(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "NoMatch",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Operator(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Operator",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_OutroAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "OutroAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_SubMenu(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "SubMenu",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_Transfer(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Transfer",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getDocumentRoot_TransferAudio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "TransferAudio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (eventHandlersTypeEClass, 
       source, 
       new String[] 
       {
       "name", "EventHandlers_._type",
       "kind", "elementOnly"
       });		
    addAnnotation
      (getEventHandlersType_InputError(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "InputError",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getEventHandlersType_NoInput(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "NoInput",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getEventHandlersType_NoMatch(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "NoMatch",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getEventHandlersType_Help(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Help",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (eventsTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Events_._type",
       "kind", "elementOnly"
       });		
    addAnnotation
      (getEventsType_Hangup(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Hangup",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getEventsType_Transfer(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Transfer",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (grammarTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Grammar_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getGrammarType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getGrammarType_Type(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "type"
       });		
    addAnnotation
      (hangupTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Hangup_._type",
       "kind", "empty"
       });		
    addAnnotation
      (getHangupType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getHangupType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (helpTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Help_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getHelpType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getHelpType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getHelpType_Count(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "count"
       });		
    addAnnotation
      (getHelpType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getHelpType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getHelpType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getHelpType_Reprompt(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "reprompt"
       });		
    addAnnotation
      (getHelpType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getHelpType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getHelpType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getHelpType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getHelpType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (holidayAudioTypeEClass, 
       source, 
       new String[] 
       {
       "name", "HolidayAudio_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getHolidayAudioType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getHolidayAudioType_Caching(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "caching"
       });		
    addAnnotation
      (getHolidayAudioType_Dir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dir"
       });		
    addAnnotation
      (getHolidayAudioType_Fetchtimeout(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fetchtimeout"
       });		
    addAnnotation
      (getHolidayAudioType_Terminate(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "terminate"
       });		
    addAnnotation
      (getHolidayAudioType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (inputErrorTypeEClass, 
       source, 
       new String[] 
       {
       "name", "InputError_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getInputErrorType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getInputErrorType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getInputErrorType_Count(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "count"
       });		
    addAnnotation
      (getInputErrorType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getInputErrorType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getInputErrorType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getInputErrorType_Event(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "event"
       });		
    addAnnotation
      (getInputErrorType_Reprompt(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "reprompt"
       });		
    addAnnotation
      (getInputErrorType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getInputErrorType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getInputErrorType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getInputErrorType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getInputErrorType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (introAudioTypeEClass, 
       source, 
       new String[] 
       {
       "name", "IntroAudio_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getIntroAudioType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getIntroAudioType_Caching(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "caching"
       });		
    addAnnotation
      (getIntroAudioType_Dir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dir"
       });		
    addAnnotation
      (getIntroAudioType_Dnis(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dnis"
       });		
    addAnnotation
      (getIntroAudioType_Fetchtimeout(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fetchtimeout"
       });		
    addAnnotation
      (getIntroAudioType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (menuDefaultTypeEClass, 
       source, 
       new String[] 
       {
       "name", "MenuDefault_._type",
       "kind", "empty"
       });		
    addAnnotation
      (getMenuDefaultType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getMenuDefaultType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getMenuDefaultType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getMenuDefaultType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getMenuDefaultType_Dnis(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dnis"
       });		
    addAnnotation
      (getMenuDefaultType_Handler(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "handler"
       });		
    addAnnotation
      (getMenuDefaultType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getMenuDefaultType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getMenuDefaultType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getMenuDefaultType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getMenuDefaultType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (menuOperatorTypeEClass, 
       source, 
       new String[] 
       {
       "name", "MenuOperator_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getMenuOperatorType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getMenuOperatorType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getMenuOperatorType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getMenuOperatorType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getMenuOperatorType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getMenuOperatorType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getMenuOperatorType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getMenuOperatorType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getMenuOperatorType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getMenuOperatorType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (noInputTypeEClass, 
       source, 
       new String[] 
       {
       "name", "NoInput_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getNoInputType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getNoInputType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getNoInputType_Count(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "count"
       });		
    addAnnotation
      (getNoInputType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getNoInputType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getNoInputType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getNoInputType_Reprompt(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "reprompt"
       });		
    addAnnotation
      (getNoInputType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getNoInputType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getNoInputType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getNoInputType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getNoInputType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (noMatchTypeEClass, 
       source, 
       new String[] 
       {
       "name", "NoMatch_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getNoMatchType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getNoMatchType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getNoMatchType_Count(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "count"
       });		
    addAnnotation
      (getNoMatchType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getNoMatchType_Dest(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dest"
       });		
    addAnnotation
      (getNoMatchType_DestType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "destType"
       });		
    addAnnotation
      (getNoMatchType_Reprompt(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "reprompt"
       });		
    addAnnotation
      (getNoMatchType_TargetAudio(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetAudio"
       });		
    addAnnotation
      (getNoMatchType_TargetMode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetMode"
       });		
    addAnnotation
      (getNoMatchType_TargetName(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetName"
       });		
    addAnnotation
      (getNoMatchType_TargetType(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "targetType"
       });		
    addAnnotation
      (getNoMatchType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (operatorTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Operator_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getOperatorType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getOperatorType_Dnis(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dnis"
       });		
    addAnnotation
      (outroAudioTypeEClass, 
       source, 
       new String[] 
       {
       "name", "OutroAudio_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getOutroAudioType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getOutroAudioType_Caching(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "caching"
       });		
    addAnnotation
      (getOutroAudioType_Dir(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dir"
       });		
    addAnnotation
      (getOutroAudioType_Dnis(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "dnis"
       });		
    addAnnotation
      (getOutroAudioType_Fetchtimeout(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "fetchtimeout"
       });		
    addAnnotation
      (getOutroAudioType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (subMenuTypeEClass, 
       source, 
       new String[] 
       {
       "name", "SubMenu_._type",
       "kind", "elementOnly"
       });		
    addAnnotation
      (getSubMenuType_Audio(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Audio",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_AudioConfirm(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "AudioConfirm",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_Grammar(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Grammar",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_Choice(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Choice",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_MenuOperator(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "MenuOperator",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_MenuDefault(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "MenuDefault",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_InputError(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "InputError",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_NoInput(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "NoInput",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_NoMatch(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "NoMatch",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_Help(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Help",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_Events(), 
       source, 
       new String[] 
       {
       "kind", "element",
       "name", "Events",
       "namespace", "##targetNamespace"
       });		
    addAnnotation
      (getSubMenuType_ClearDTMFBuffer(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "clearDTMFBuffer"
       });		
    addAnnotation
      (getSubMenuType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });		
    addAnnotation
      (getSubMenuType_EndCall(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "endCall"
       });		
    addAnnotation
      (getSubMenuType_Hangup(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "hangup"
       });		
    addAnnotation
      (getSubMenuType_MarkPosition(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "markPosition"
       });		
    addAnnotation
      (getSubMenuType_Maxretries(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "maxretries"
       });		
    addAnnotation
      (getSubMenuType_Mode(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "mode"
       });		
    addAnnotation
      (getSubMenuType_Name(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "name"
       });		
    addAnnotation
      (getSubMenuType_RecordingConfirmation(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "recordingConfirmation"
       });		
    addAnnotation
      (getSubMenuType_Repeat(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "repeat"
       });		
    addAnnotation
      (getSubMenuType_Retry(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "retry"
       });		
    addAnnotation
      (getSubMenuType_Set(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "set"
       });		
    addAnnotation
      (getSubMenuType_Type(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "type"
       });		
    addAnnotation
      (getSubMenuType_Vxml(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "vxml"
       });		
    addAnnotation
      (getSubMenuType_Wait(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "wait"
       });		
    addAnnotation
      (transferAudioTypeEClass, 
       source, 
       new String[] 
       {
       "name", "TransferAudio_._type",
       "kind", "simple"
       });		
    addAnnotation
      (getTransferAudioType_Value(), 
       source, 
       new String[] 
       {
       "name", ":0",
       "kind", "simple"
       });		
    addAnnotation
      (getTransferAudioType_Tts(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "tts"
       });		
    addAnnotation
      (transferTypeEClass, 
       source, 
       new String[] 
       {
       "name", "Transfer_._type",
       "kind", "empty"
       });		
    addAnnotation
      (getTransferType_Cond(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "cond"
       });		
    addAnnotation
      (getTransferType_Counter(), 
       source, 
       new String[] 
       {
       "kind", "attribute",
       "name", "counter"
       });
  }

} //ModelPackageImpl
