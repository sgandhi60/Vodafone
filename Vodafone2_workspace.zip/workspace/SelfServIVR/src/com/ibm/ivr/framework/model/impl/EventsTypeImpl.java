/**
 * <copyright>
 * </copyright>
 *
 * $Id: EventsTypeImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.HangupType;
import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.TransferType;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Events Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.EventsTypeImpl#getHangup <em>Hangup</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.EventsTypeImpl#getTransfer <em>Transfer</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EventsTypeImpl extends EDataObjectImpl implements EventsType
{
  /**
   * The cached value of the '{@link #getHangup() <em>Hangup</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHangup()
   * @generated
   * @ordered
   */
  protected EList hangup = null;

  /**
   * The cached value of the '{@link #getTransfer() <em>Transfer</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTransfer()
   * @generated
   * @ordered
   */
  protected EList transfer = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EventsTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getEventsType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getHangup()
  {
    if (hangup == null)
    {
      hangup = new EObjectContainmentEList(HangupType.class, this, ModelPackage.EVENTS_TYPE__HANGUP);
    }
    return hangup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getTransfer()
  {
    if (transfer == null)
    {
      transfer = new EObjectContainmentEList(TransferType.class, this, ModelPackage.EVENTS_TYPE__TRANSFER);
    }
    return transfer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs)
  {
    if (featureID >= 0)
    {
      switch (eDerivedStructuralFeatureID(featureID, baseClass))
      {
        case ModelPackage.EVENTS_TYPE__HANGUP:
          return ((InternalEList)getHangup()).basicRemove(otherEnd, msgs);
        case ModelPackage.EVENTS_TYPE__TRANSFER:
          return ((InternalEList)getTransfer()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENTS_TYPE__HANGUP:
        return getHangup();
      case ModelPackage.EVENTS_TYPE__TRANSFER:
        return getTransfer();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENTS_TYPE__HANGUP:
        getHangup().clear();
        getHangup().addAll((Collection)newValue);
        return;
      case ModelPackage.EVENTS_TYPE__TRANSFER:
        getTransfer().clear();
        getTransfer().addAll((Collection)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENTS_TYPE__HANGUP:
        getHangup().clear();
        return;
      case ModelPackage.EVENTS_TYPE__TRANSFER:
        getTransfer().clear();
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENTS_TYPE__HANGUP:
        return hangup != null && !hangup.isEmpty();
      case ModelPackage.EVENTS_TYPE__TRANSFER:
        return transfer != null && !transfer.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

} //EventsTypeImpl
