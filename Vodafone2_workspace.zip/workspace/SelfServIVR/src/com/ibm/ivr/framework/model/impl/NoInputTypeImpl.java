/**
 * <copyright>
 * </copyright>
 *
 * $Id: NoInputTypeImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.NoInputType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>No Input Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getCond <em>Cond</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getCount <em>Count</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getCounter <em>Counter</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getDest <em>Dest</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getDestType <em>Dest Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getReprompt <em>Reprompt</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getTargetAudio <em>Target Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getTargetMode <em>Target Mode</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getTargetName <em>Target Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getTargetType <em>Target Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NoInputTypeImpl extends EDataObjectImpl implements NoInputType
{
  /**
   * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected static final String VALUE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected String value = VALUE_EDEFAULT;

  /**
   * The default value of the '{@link #getCond() <em>Cond</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCond()
   * @generated
   * @ordered
   */
  protected static final String COND_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCond() <em>Cond</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCond()
   * @generated
   * @ordered
   */
  protected String cond = COND_EDEFAULT;

  /**
   * The default value of the '{@link #getCount() <em>Count</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCount()
   * @generated
   * @ordered
   */
  protected static final int COUNT_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getCount() <em>Count</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCount()
   * @generated
   * @ordered
   */
  protected int count = COUNT_EDEFAULT;

  /**
   * This is true if the Count attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean countESet = false;

  /**
   * The default value of the '{@link #getCounter() <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCounter()
   * @generated
   * @ordered
   */
  protected static final String COUNTER_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCounter() <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCounter()
   * @generated
   * @ordered
   */
  protected String counter = COUNTER_EDEFAULT;

  /**
   * The default value of the '{@link #getDest() <em>Dest</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDest()
   * @generated
   * @ordered
   */
  protected static final String DEST_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDest() <em>Dest</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDest()
   * @generated
   * @ordered
   */
  protected String dest = DEST_EDEFAULT;

  /**
   * The default value of the '{@link #getDestType() <em>Dest Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDestType()
   * @generated
   * @ordered
   */
  protected static final String DEST_TYPE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDestType() <em>Dest Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDestType()
   * @generated
   * @ordered
   */
  protected String destType = DEST_TYPE_EDEFAULT;

  /**
   * The default value of the '{@link #getReprompt() <em>Reprompt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReprompt()
   * @generated
   * @ordered
   */
  protected static final String REPROMPT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getReprompt() <em>Reprompt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReprompt()
   * @generated
   * @ordered
   */
  protected String reprompt = REPROMPT_EDEFAULT;

  /**
   * The default value of the '{@link #getTargetAudio() <em>Target Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetAudio()
   * @generated
   * @ordered
   */
  protected static final String TARGET_AUDIO_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTargetAudio() <em>Target Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetAudio()
   * @generated
   * @ordered
   */
  protected String targetAudio = TARGET_AUDIO_EDEFAULT;

  /**
   * The default value of the '{@link #getTargetMode() <em>Target Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetMode()
   * @generated
   * @ordered
   */
  protected static final String TARGET_MODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTargetMode() <em>Target Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetMode()
   * @generated
   * @ordered
   */
  protected String targetMode = TARGET_MODE_EDEFAULT;

  /**
   * The default value of the '{@link #getTargetName() <em>Target Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetName()
   * @generated
   * @ordered
   */
  protected static final String TARGET_NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTargetName() <em>Target Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetName()
   * @generated
   * @ordered
   */
  protected String targetName = TARGET_NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getTargetType() <em>Target Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetType()
   * @generated
   * @ordered
   */
  protected static final String TARGET_TYPE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTargetType() <em>Target Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetType()
   * @generated
   * @ordered
   */
  protected String targetType = TARGET_TYPE_EDEFAULT;

  /**
   * The default value of the '{@link #getTts() <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTts()
   * @generated
   * @ordered
   */
  protected static final String TTS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTts() <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTts()
   * @generated
   * @ordered
   */
  protected String tts = TTS_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected NoInputTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getNoInputType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValue(String newValue)
  {
    String oldValue = value;
    value = newValue;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__VALUE, oldValue, value));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCond()
  {
    return cond;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCond(String newCond)
  {
    String oldCond = cond;
    cond = newCond;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__COND, oldCond, cond));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getCount()
  {
    return count;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCount(int newCount)
  {
    int oldCount = count;
    count = newCount;
    boolean oldCountESet = countESet;
    countESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__COUNT, oldCount, count, !oldCountESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetCount()
  {
    int oldCount = count;
    boolean oldCountESet = countESet;
    count = COUNT_EDEFAULT;
    countESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, ModelPackage.NO_INPUT_TYPE__COUNT, oldCount, COUNT_EDEFAULT, oldCountESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetCount()
  {
    return countESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCounter()
  {
    return counter;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCounter(String newCounter)
  {
    String oldCounter = counter;
    counter = newCounter;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__COUNTER, oldCounter, counter));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDest()
  {
    return dest;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDest(String newDest)
  {
    String oldDest = dest;
    dest = newDest;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__DEST, oldDest, dest));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDestType()
  {
    return destType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDestType(String newDestType)
  {
    String oldDestType = destType;
    destType = newDestType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__DEST_TYPE, oldDestType, destType));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getReprompt()
  {
    return reprompt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setReprompt(String newReprompt)
  {
    String oldReprompt = reprompt;
    reprompt = newReprompt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__REPROMPT, oldReprompt, reprompt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTargetAudio()
  {
    return targetAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTargetAudio(String newTargetAudio)
  {
    String oldTargetAudio = targetAudio;
    targetAudio = newTargetAudio;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__TARGET_AUDIO, oldTargetAudio, targetAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTargetMode()
  {
    return targetMode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTargetMode(String newTargetMode)
  {
    String oldTargetMode = targetMode;
    targetMode = newTargetMode;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__TARGET_MODE, oldTargetMode, targetMode));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTargetName()
  {
    return targetName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTargetName(String newTargetName)
  {
    String oldTargetName = targetName;
    targetName = newTargetName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__TARGET_NAME, oldTargetName, targetName));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTargetType()
  {
    return targetType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTargetType(String newTargetType)
  {
    String oldTargetType = targetType;
    targetType = newTargetType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__TARGET_TYPE, oldTargetType, targetType));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTts()
  {
    return tts;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTts(String newTts)
  {
    String oldTts = tts;
    tts = newTts;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.NO_INPUT_TYPE__TTS, oldTts, tts));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.NO_INPUT_TYPE__VALUE:
        return getValue();
      case ModelPackage.NO_INPUT_TYPE__COND:
        return getCond();
      case ModelPackage.NO_INPUT_TYPE__COUNT:
        return new Integer(getCount());
      case ModelPackage.NO_INPUT_TYPE__COUNTER:
        return getCounter();
      case ModelPackage.NO_INPUT_TYPE__DEST:
        return getDest();
      case ModelPackage.NO_INPUT_TYPE__DEST_TYPE:
        return getDestType();
      case ModelPackage.NO_INPUT_TYPE__REPROMPT:
        return getReprompt();
      case ModelPackage.NO_INPUT_TYPE__TARGET_AUDIO:
        return getTargetAudio();
      case ModelPackage.NO_INPUT_TYPE__TARGET_MODE:
        return getTargetMode();
      case ModelPackage.NO_INPUT_TYPE__TARGET_NAME:
        return getTargetName();
      case ModelPackage.NO_INPUT_TYPE__TARGET_TYPE:
        return getTargetType();
      case ModelPackage.NO_INPUT_TYPE__TTS:
        return getTts();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.NO_INPUT_TYPE__VALUE:
        setValue((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__COND:
        setCond((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__COUNT:
        setCount(((Integer)newValue).intValue());
        return;
      case ModelPackage.NO_INPUT_TYPE__COUNTER:
        setCounter((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__DEST:
        setDest((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__DEST_TYPE:
        setDestType((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__REPROMPT:
        setReprompt((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_AUDIO:
        setTargetAudio((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_MODE:
        setTargetMode((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_NAME:
        setTargetName((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_TYPE:
        setTargetType((String)newValue);
        return;
      case ModelPackage.NO_INPUT_TYPE__TTS:
        setTts((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.NO_INPUT_TYPE__VALUE:
        setValue(VALUE_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__COND:
        setCond(COND_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__COUNT:
        unsetCount();
        return;
      case ModelPackage.NO_INPUT_TYPE__COUNTER:
        setCounter(COUNTER_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__DEST:
        setDest(DEST_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__DEST_TYPE:
        setDestType(DEST_TYPE_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__REPROMPT:
        setReprompt(REPROMPT_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_AUDIO:
        setTargetAudio(TARGET_AUDIO_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_MODE:
        setTargetMode(TARGET_MODE_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_NAME:
        setTargetName(TARGET_NAME_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__TARGET_TYPE:
        setTargetType(TARGET_TYPE_EDEFAULT);
        return;
      case ModelPackage.NO_INPUT_TYPE__TTS:
        setTts(TTS_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.NO_INPUT_TYPE__VALUE:
        return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
      case ModelPackage.NO_INPUT_TYPE__COND:
        return COND_EDEFAULT == null ? cond != null : !COND_EDEFAULT.equals(cond);
      case ModelPackage.NO_INPUT_TYPE__COUNT:
        return isSetCount();
      case ModelPackage.NO_INPUT_TYPE__COUNTER:
        return COUNTER_EDEFAULT == null ? counter != null : !COUNTER_EDEFAULT.equals(counter);
      case ModelPackage.NO_INPUT_TYPE__DEST:
        return DEST_EDEFAULT == null ? dest != null : !DEST_EDEFAULT.equals(dest);
      case ModelPackage.NO_INPUT_TYPE__DEST_TYPE:
        return DEST_TYPE_EDEFAULT == null ? destType != null : !DEST_TYPE_EDEFAULT.equals(destType);
      case ModelPackage.NO_INPUT_TYPE__REPROMPT:
        return REPROMPT_EDEFAULT == null ? reprompt != null : !REPROMPT_EDEFAULT.equals(reprompt);
      case ModelPackage.NO_INPUT_TYPE__TARGET_AUDIO:
        return TARGET_AUDIO_EDEFAULT == null ? targetAudio != null : !TARGET_AUDIO_EDEFAULT.equals(targetAudio);
      case ModelPackage.NO_INPUT_TYPE__TARGET_MODE:
        return TARGET_MODE_EDEFAULT == null ? targetMode != null : !TARGET_MODE_EDEFAULT.equals(targetMode);
      case ModelPackage.NO_INPUT_TYPE__TARGET_NAME:
        return TARGET_NAME_EDEFAULT == null ? targetName != null : !TARGET_NAME_EDEFAULT.equals(targetName);
      case ModelPackage.NO_INPUT_TYPE__TARGET_TYPE:
        return TARGET_TYPE_EDEFAULT == null ? targetType != null : !TARGET_TYPE_EDEFAULT.equals(targetType);
      case ModelPackage.NO_INPUT_TYPE__TTS:
        return TTS_EDEFAULT == null ? tts != null : !TTS_EDEFAULT.equals(tts);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (value: ");
    result.append(value);
    result.append(", cond: ");
    result.append(cond);
    result.append(", count: ");
    if (countESet) result.append(count); else result.append("<unset>");
    result.append(", counter: ");
    result.append(counter);
    result.append(", dest: ");
    result.append(dest);
    result.append(", destType: ");
    result.append(destType);
    result.append(", reprompt: ");
    result.append(reprompt);
    result.append(", targetAudio: ");
    result.append(targetAudio);
    result.append(", targetMode: ");
    result.append(targetMode);
    result.append(", targetName: ");
    result.append(targetName);
    result.append(", targetType: ");
    result.append(targetType);
    result.append(", tts: ");
    result.append(tts);
    result.append(')');
    return result.toString();
  }

} //NoInputTypeImpl
