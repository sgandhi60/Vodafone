/*
 * Created on Mar 7, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.ivr.framework.utilities;

import org.apache.log4j.Logger;

/**
 * The Java class to log messages into alarm log
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-05: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-07
 *  
 */
public class Alarm {

	/**
	 * The private log4j logger
	 */
	private static Logger logger = Logger.getLogger(Alarm.class);

	public static void error(String msg){
		logger.error(msg);
	}
	
	public static void fatal(String msg){
		logger.fatal(msg);
	}
	
	public static void warn(String msg) {
		logger.warn(msg);
	}
	
	public static void info(String msg) {
		logger.info(msg);
	}
}
