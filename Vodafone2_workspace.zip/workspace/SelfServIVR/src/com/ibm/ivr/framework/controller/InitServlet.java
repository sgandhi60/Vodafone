package com.ibm.ivr.framework.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.io.FileInputStream;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.apache.log4j.PropertyConfigurator;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.utilities.CallRoutingHelper;
import com.ibm.ivr.framework.utilities.Common;
import com.ibm.ivr.framework.utilities.Reporter;
import com.ibm.ivr.framework.utilities.StatsReporter;
import com.ibm.ivr.framework.utilities.VARReporter;


/**
 * The Java class holding the Servlet which does all the initialization work at
 * the start of the Web Application
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2004-06-01: initial version
 * <p>
 * 2007-03-05: 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-07
 *  
 */
public class InitServlet extends HttpServlet implements Servlet {

	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(InitServlet.class);

	/**
	 * init() method
	 * 
	 * @throws ServletException
	 * 
	 * @return void
	 */
	public void init() throws ServletException {

		boolean initSuccess = false;

		String hostName = null;
		
		String propertyFileRoot = null;
		String propertyPathFileName = getInitParameter("propertyFilePath");

		String file = getInitParameter("log4jConfigFile");

		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();


		//
        //  Get the property files root location
		//
		try{
		InputStream isPR = this.getServletContext().getResourceAsStream("/WEB-INF/classes/" + propertyPathFileName);
		Properties propPR = new Properties();
		propPR.load(isPR);
		propertyFileRoot = propPR.getProperty("propertyFileRoot");
		
		//System.out.println("Property File Root Resolved = "+propertyFileRoot);
		isPR.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw (new ServletException(
					"Unable to load propertyFileRoot"));			
		}
		
		//set host name in servlet context to be used in Logging the Error
		try {
			InetAddress thisIp = InetAddress.getLocalHost();
			hostName = thisIp.getHostName();
			this.getServletContext().setAttribute("hostName", hostName);

			//use MDC once it is confirmed working in log4j
			NDC.push(hostName);
		} catch (Exception e) {
			LOGGER.error("[init] failed to set hostName in servlet context: "
					+ e.getMessage());
		}

		// load log4jConfigFile properties
		// if the log4jConfigFile is not set, then no point in trying
		if (file != null) {
			//URL url = classLoader.getResource("/" + file);
			//URL url = null;
			//try {
				//url = this.getServletContext().getResource("/WEB-INF/classes/" + file);
				//System.out.println("Resource = "+propertyFileRoot + file);
				//url = new URL(propertyFileRoot + file);
				
				//System.out.println("URL = "+url.toString());
			//} catch (Exception ex) {
				//ex.printStackTrace();
				//LOGGER.fatal("{" + hostName
						//+ "} [init] malFormed URL for log4jConfigFile" + file);
				//throw (new ServletException("Null URL for log4jConfigFile"
						//+ file));
			//}
			// Make sure the logger directories are set up before
			// instantiating the logger
			try {
				//InputStream is = classLoader
				//		.getResourceAsStream("/" + file);
				//InputStream is = this.getServletContext().getResourceAsStream("/WEB-INF/classes/" + file);
				InputStream is = new FileInputStream(propertyFileRoot + file);
				
				Properties prop = new Properties();
				prop.load(is);
				is.close();
//				String logDir = prop.getProperty("log4j.appender.R1.File");
				String logDir = prop.getProperty("log4j.appender.R2.File");
				if (logDir != null) {
					File logDirFile = new File(logDir).getParentFile();
					logDirFile.mkdirs();
//					new File(logDirFile.getParent() + "/log").mkdirs();
//					new File(logDirFile.getParent() + "/alarm").mkdirs();
					LOGGER.info("[init] logdir" + logDirFile.toString() + " created successfully");
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER
						.fatal("[init] Unable to create dir(s) for Log4j log files");
				throw (new ServletException(
						"Unable to create dir(s) for Log4j log files"));
			}

			//PropertyConfigurator.configure(url);
			PropertyConfigurator.configure(propertyFileRoot + file);
			LOGGER.info("[init] log4j configured from " + propertyFileRoot + file);
			this.getServletContext().setAttribute("log4jConfig", propertyFileRoot + file);
		}

		LOGGER.info("[init] ********   InitServlet Initalization   ************");
		LOGGER.info("[init] propertyFileRoot =  " + propertyFileRoot);


		super.init();

		try {
			//load ivr mapping properties
			//InputStream is = classLoader.getResourceAsStream("/"
			//		+ getInitParameter("mappingFile"));
			InputStream is = new FileInputStream(propertyFileRoot + getInitParameter("mappingFile"));
			Properties prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("mappingProp", prop);
			LOGGER.info("[init] loading " + getInitParameter("mappingFile")
					+ " succeeded");
			is.close();
			
			// --------------------------------------------
			//load Program Name properties
			// Used to map the customer type when customer is located in central database
			// --------------------------------------------
			is = new FileInputStream(propertyFileRoot + getInitParameter("programNameFile"));
			prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("programNameProp", prop);
			LOGGER.info("[init] loading " + getInitParameter("programNameFile")
					+ " succeeded");
			is.close();
			
		    Enumeration e = prop.propertyNames();
		    String key = null;
		    while (e.hasMoreElements()) {
		      key = (String) e.nextElement();
		      //System.out.println(key + "=" + prop.getProperty(key));
		      LOGGER.info("[init] programNameFile Key = " + key+"  Value = "+ prop.getProperty(key));
		    }

			// --------------------------------------------
			//load MainMenuMap properties
			// Used to map the customer type when customer is located in central database
			// --------------------------------------------
			is = new FileInputStream(propertyFileRoot + getInitParameter("mainMenuMapFile"));
			prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("mainMenuMap", prop);
			LOGGER.info("[init] loading " + getInitParameter("mainMenuMapFile")
					+ " succeeded");
			is.close();
			
		     e = prop.propertyNames();

		    while (e.hasMoreElements()) {
		      key = (String) e.nextElement();
		      //System.out.println(key + "=" + prop.getProperty(key));
		      LOGGER.info("[init] mainMenuMap Key = " + key+"  Value = "+ prop.getProperty(key));
		    }

			// --------------------------------------------
			//load Lastmenu properties
			// Used to locate the last menu the caller was in before transfer
			// --------------------------------------------
			is = new FileInputStream(propertyFileRoot + getInitParameter("lastMenuFile"));
			prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("lastMenu", prop);
			LOGGER.info("[init] loading " + getInitParameter("lastMenuFile")
					+ " succeeded");
			is.close();
			
		     e = prop.propertyNames();

		    while (e.hasMoreElements()) {
		      key = (String) e.nextElement();
		      //System.out.println(key + "=" + prop.getProperty(key));
		      LOGGER.info("[init] lastMenu Key = " + key+"  Value = "+ prop.getProperty(key));
		    }

			// --------------------------------------------
			//load menuMap properties
			// Used to map the customer type when customer is located in central database
			// --------------------------------------------
			is = new FileInputStream(propertyFileRoot + getInitParameter("menuMapFile"));
			prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("menuMap", prop);
			LOGGER.info("[init] loading " + getInitParameter("menuMapFile")
					+ " succeeded");
			is.close();
			
		     e = prop.propertyNames();

		    while (e.hasMoreElements()) {
		      key = (String) e.nextElement();
		      //System.out.println(key + "=" + prop.getProperty(key));
		      LOGGER.info("[init] menuMap Key = " + key+"  Value = "+ prop.getProperty(key));
		    }
		    
			// --------------------------------------------
			// Load global properties
			// Used to map the customer type when customer is located in central database
			// --------------------------------------------
			is = new FileInputStream(propertyFileRoot + getInitParameter("globalConfigFile"));
			prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("globalProp", prop);
			String dateFormat = prop.getProperty("dateFormat");
			this.getServletContext().setAttribute("dateFormat", dateFormat);
			String altReport = prop.getProperty("altReport");
			this.getServletContext().setAttribute("altReport", altReport);			
			String timeFormat = prop.getProperty("timeFormat");
			this.getServletContext().setAttribute("timeFormat", timeFormat);
			String startTimeFormat = prop.getProperty("startTimeFormat");
			this.getServletContext().setAttribute("startTimeFormat",
					startTimeFormat);
			LOGGER.info("[init] loading "
					+ getInitParameter("globalConfigFile") + " succeeded");
			is.close();

			// --------------------------------------------
			// load call properties
			// --------------------------------------------
			is = new FileInputStream(propertyFileRoot + getInitParameter("callPropFile"));
			prop = new Properties();
			prop.load(is);
			this.getServletContext().setAttribute("callProp", prop);
			LOGGER.info("[init] loading " + getInitParameter("callPropFile")
					+ " succeeded");
			is.close();
		} catch (IOException ioe) {
			LOGGER.fatal("[init] Loading properties failed");
			throw new ServletException("InitServlet Configuration FAILED");
		}

		// Creating hashtables to hold DNIS to CallRouting class(es)
		Properties prop = (Properties) this.getServletContext().getAttribute(
				"mappingProp");
		Hashtable hs = new Hashtable();
		Hashtable iCRHelperHsahtable = new Hashtable();
		Hashtable XML2KeyTable = new Hashtable();

		// -----------------------
		// Added this section to avoid duplicate entries in the tables
		Enumeration en = prop.keys();
		CallRoutingType iCallRouting = null;
		CallRoutingHelper iCRHelper = null;
		while (en.hasMoreElements()) {
			String key = (String) en.nextElement();
			if (key.startsWith("callflow")) {
				String xmlFile = prop.getProperty(key);
				// parse the value found corresponding to key
				int index = xmlFile.indexOf("#");
				if (index != -1) {//extract the xml filename
					xmlFile = xmlFile.substring(0, index);
				}
				// verify xml and key in the table (table includes XMLs and
				// corresponding DNISs and Virtual DNISs to jump to other IVRs)
				if (!XML2KeyTable.containsKey(xmlFile)) {
					String dir = this.getServletContext().getRealPath(
							"/WEB-INF/CallRoutingConfig/");
					String fileURL = null;
					try {
						// Load the document
						fileURL = "file:///" + dir + xmlFile;
						iCallRouting = Common.loadXML(fileURL);
					} catch (Exception e) {
						throw (new ServletException(e.getMessage()));
					}
				      
					//try to load common xml if specified;
					String commonFiles = iCallRouting.getCommon();
					if (commonFiles != null) {
						String[] cFiles = commonFiles.split(",");
						for (int i = 0; i < cFiles.length; i++) {
							try {
								fileURL = "file:///" + dir + cFiles[i].trim();
								CallRoutingType callRoutingCommon = Common
										.loadXML(fileURL);
								//merge in SubMenus
								List submenus = iCallRouting.getSubMenu();
								submenus.addAll(callRoutingCommon.getSubMenu());
							} catch (Exception e) {
								e.printStackTrace();
								throw (new ServletException(e.getMessage()));
							}
						}
					}

					hs.put(key, iCallRouting);

					iCRHelper = new CallRoutingHelper(iCallRouting);
					iCRHelperHsahtable.put(key, iCRHelper);

					// add XML and key in the table (table includes XMLs and
					// corresponding DNISs and Virtual DNISs to jump to
					// other IVRs)
					XML2KeyTable.put(xmlFile, key);
					LOGGER.info("[init] Creating CallRouting Table entry for: "
							+ key + "=" + xmlFile);
				} else {
					String prevKey = (String) XML2KeyTable.get(xmlFile);
					iCallRouting = (CallRoutingType) hs.get(prevKey);
					hs.put(key, iCallRouting);
					LOGGER
							.info("[init] Cross Referencing CallRouting Table entry for: "
									+ key + " to " + prevKey + "=" + xmlFile);

					iCRHelper = (CallRoutingHelper) iCRHelperHsahtable
							.get(prevKey);
					iCRHelperHsahtable.put(key, iCRHelper);
				}
				//				}
			}
		}
		// -----------------------

		this.getServletContext().setAttribute("callRoutingHelperHash",
				iCRHelperHsahtable);
		this.getServletContext().setAttribute("callRoutingTable", hs);

		LOGGER.info("[init] callRoutingTable constructed successfully");

		prop = (Properties) this.getServletContext().getAttribute("globalProp");

		
		//Add Reporter handles
		// property not defined then will use the flatfile reporting
		String rName = prop.getProperty("ivr.reporter");
		Reporter reporter = null;
		if (rName != null && rName.equalsIgnoreCase("VARReporter"))
			reporter = new VARReporter(prop
					.getProperty("ivr.reporter.minCallDuration"), prop
					.getProperty("ivr.reporter.path"));
		else
			reporter = new StatsReporter();

		this.getServletContext().setAttribute("reporter", reporter);

		LOGGER.info("[init] reporter handle created in servlet context");

		LOGGER.info("[init] InitServlet initialized successfully");

		NDC.remove();
	}

	/**
	 * destroy() method
	 * 
	 * @return void
	 */
	public void destroy() {
		
		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC
					.push((String) this.getServletContext().getAttribute(
							"hostName"));
		
		LOGGER.error("[final] InitServlet destroyed successfully");

		NDC.remove();
	}
}
