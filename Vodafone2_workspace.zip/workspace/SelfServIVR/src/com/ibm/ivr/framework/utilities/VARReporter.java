/*
 * Created on Mar 16, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.ivr.framework.utilities;

import java.sql.Timestamp;
import java.util.Hashtable;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.log4j.Logger;

/**
 * @author fangwang
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class VARReporter implements Reporter {

	//define the private logger
	private static Logger LOGGER = Logger.getLogger(VARReporter.class);

	//define the static hashtable for holding the call information during the
	// call
	private static Hashtable callTable = new Hashtable();

	//minimum call duration in ms to treat the call as non-abandoned
	private long minCallDuration = 0L;

	//end point URL for VARAgent web service
	private String endpointURL = null;

	/*
	 * constructor
	 * 
	 * @param minCallDuration minimum call duration in s to treat the call as
	 * non-abandoned @param endpointURL end point URL for VARAgent web service
	 */
	public VARReporter(String minCallDuration, String endpointURL) {
		this.endpointURL = endpointURL;
		if (LOGGER.isTraceEnabled())
			LOGGER.debug("[init] endpointURL: " + endpointURL);

		try {
			this.minCallDuration = 1000 * Long.parseLong(minCallDuration);
		} catch (Exception e) {
			if (LOGGER.isTraceEnabled())
				LOGGER.debug("[init] minCallDuration is not valid: "
					+ e.getMessage());
		}
		if (LOGGER.isTraceEnabled())
			LOGGER.debug("[init] minCallDuration: " + minCallDuration + "s");
	}

	/**
	 * Used by IVR to report call start
	 * 
	 * @param ani
	 *            ani of the call
	 * @param dnis
	 *            dnis of the call
	 * @param sessionID
	 *            unique session id of the call
	 * @param appName
	 *            application reached by the call
	 */
	public void callStart(String ani, String dnis, String sessionID,
			String appName) {

		String logToken = new StringBuffer("[").append(sessionID).append("] ")
				.append("[").append(appName).append("]: ").toString();
		
		if (sessionID == null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("sessionID is null, returning..."));
			return;
		}

		if (callTable.get(sessionID) != null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("START event already sent, returning..."));
			return;
		}

		CallStats callStats = new CallStats(ani, dnis, sessionID, appName);

		// log call starting timestamp
		Timestamp curTS = new Timestamp((new java.util.Date()).getTime());
		callStats.setCallStartTime(curTS);

		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken).append("call started at: ")
				.append(curTS).append("; DNIS=").append(dnis).append("; ANI=")
				.append(ani));

		// form the call to VARAGENT webservice
		StringBuffer logData = new StringBuffer("EVENT=01");

		if (ani == null || ani.length() == 0)
			ani = "ANI";
		logData.append("&ANI=").append(ani);

		if (dnis == null || dnis.length() == 0)
			dnis = "DNIS";
		logData.append("&DNIS=").append(dnis);

		logData.append("&APPNAME=").append(appName);

		try {
			sendReportData(sessionID, appName, logData, callStats);
		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(e.getMessage()), e);
			return;
		}

		// Set into hashtable to indicate Start Event has been sent
		callTable.put(sessionID, callStats);

		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer(logToken)
				.append("sendCallStartReportData Succeeded"));
	}

	/**
	 * Used by IVR to report call end
	 * 
	 * @param sessionID
	 *            unique session id of the call
	 * @param appName
	 *            application reached by the call
	 * @param exitReason
	 *            the exit reason of the call
	 * @param mode
	 *            the ending mode of the call, DTMF/SPEECH/HYBRID
	 */
	public void callEnd(String sessionID, String appName, String exitReason,
			String mode) {

		String logToken = new StringBuffer("[").append(sessionID).append("] ")
		.append("[").append(appName).append("]: ").toString();
		
		if (sessionID == null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("sessionID is null, returning..."));
			return;
		}

		CallStats callStats = (CallStats) callTable.get(sessionID);

		Timestamp startTS = callStats.getCallStartTime();

		Timestamp curTS = new Timestamp((new java.util.Date()).getTime());

		long callDuration = curTS.getTime() - startTS.getTime();

		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken).append("call ended at: ")
				.append(curTS));

		StringBuffer sb = new StringBuffer(logToken);
		sb.append("status=").append(exitReason).append("; mode=").append(mode)
				.append("; duration=").append(callDuration / 1000).append("s");
		if (LOGGER.isTraceEnabled())
			LOGGER.info(sb);

		callTable.remove(sessionID);

		String endAction = "";
		String ivrResult = "";
		StringBuffer logData = new StringBuffer("EVENT=02");

		// set End Action
		if (callDuration < minCallDuration) {
			endAction = Common.END_ABANDONED;
		} else {
			if (exitReason.startsWith("CallerExit.") ||
					exitReason.startsWith("Hangup."))
					endAction = Common.END_NORMAL;
			else
				endAction = Common.END_TRANSFERRED;
		}
		logData.append("&END_ACTION=").append(endAction);

		// Set Result as perceived by the IVR application *******
		if (endAction.equals(Common.END_ABANDONED)
				|| exitReason.indexOf("Error") >= 0) {
			ivrResult = Common.END_FAILED;
		} else {
			ivrResult = Common.END_SUCCESS;
		}
		logData.append("&IVR_RESULT=").append(ivrResult);

		// Set Reason *******
		logData.append("&IVR_REASON=").append(exitReason);

		// Set IVR Note *******
		logData.append("&IVR_NOTE=None");

		try {
			sendReportData(sessionID, appName, logData, callStats);
		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(e.getMessage()), e);
			return;
		}

		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer(logToken)
				.append("sendCallEndReportData Succeeded"));
	}

	/**
	 * Used by IVR to report call events collectd at the end of the call
	 * 
	 * @param sessionID
	 *            unique session id of the call
	 * @param appName
	 *            application reached by the call
	 * @param eventMap
	 *            hashmap contains the event name and value pairs
	 */
	public void callEvent(String sessionID, String appName, String eventName) {

		if (eventName != null) eventName = eventName.trim();
		
		String logToken = new StringBuffer("[").append(sessionID).append("] ")
				.append("[").append(appName).append("]: ").toString();
		
		if (sessionID == null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("sessionID is null, returning..."));
			return;
		}

		CallStats callStats = (CallStats) callTable.get(sessionID);

		StringBuffer logData = null;

		if (eventName == null || eventName.length() == 0) {
			LOGGER.warn("Event name empty, skipping ...");
			return;
		}

		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken)
				.append("event: ").append(eventName));
		
		logData = new StringBuffer("EVENT=03");

		logData.append("&SUBCALLFLOW_ID=").append(eventName);
		logData.append("&SUBCALLFLOW_NAME=").append(eventName);
		logData.append("&PARENT_SCF_ID=0");

		try {
			sendReportData(sessionID, appName, logData, callStats);
		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(e
					.getMessage()), e);
			return;
		}

		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer(logToken)
				.append("sendSubcallflowStartEvent Succeeded"));

		//send subcallflow end event
		logData = new StringBuffer("EVENT=04");

		logData.append("&SUBCALLFLOW_ID=").append(eventName);
		logData.append("&SUBCALLFLOW_RESULT=").append("");
		logData.append("&SUBCALLFLOW_REASON=").append("1");
		logData.append("&SUBCALLFLOW_NOTE=None");
		logData.append("&PARENT_SCF_ID=0");
		logData.append("&LAST_SCF=0");

		try {
			sendReportData(sessionID, appName, logData, callStats);
		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken).append(e
					.getMessage()), e);
			return;
		}

		if (LOGGER.isTraceEnabled())
			LOGGER.debug(new StringBuffer(logToken)
				.append("sendSubcallflowEndEvent Succeeded"));
	}


	/*
	 * get the current number of concurrent sessions
	 * 
	 * @return the size of the callTable
	 */
	public int getNumOfSessions() {
		return callTable.size();
	}

	/*
	 * send the report data to VARagent webservice
	 * 
	 * @param sessionID unique session id of the call @param appID application
	 * reached by the call @param logData specific data to be sent @param
	 * callStats callStats object for the current call for updating the event
	 * SEQ
	 * 
	 * @throw Exception
	 */
	private void sendReportData(String sessionID, String appID,
			StringBuffer logData, CallStats callStats) throws Exception {
		String eventSeq = "";
		Object[] inputArray = new Object[1];

		String logToken = new StringBuffer("[").append(sessionID).append("] ")
				.append("[").append(appID).append("]: ").toString();

		// add type
		logData.append("&TYPE=PROFILE");

		// get session Id
		if (sessionID == null || sessionID.length() == 0) {
			throw new Exception("sessionID is empty");
		}
		logData.append("&CALL_ID=").append(sessionID);

		// get App Id
		if (appID == null || appID.length() == 0) {
			throw new Exception("appID is empty");
		}
		logData.append("&APPID=").append(appID);

		// add event sequence and incremet it
		int seq = callStats.getVarEventSeq();
		seq++;
		logData.append("&EVENT_SEQ=").append(seq);
		callStats.setVarEventSeq(seq);

		if (LOGGER.isTraceEnabled())
			LOGGER.debug((new StringBuffer(logToken))
				.append("logData to be sent: ").append(logData));

		inputArray[0] = logData.toString();
		try {
			Service service = new Service();
			Call call = (Call) service.createCall();
			call.setTargetEndpointAddress(new java.net.URL(endpointURL));
			call.setOperationName("log");
			call.addParameter("USERDATA", org.apache.axis.Constants.XSD_STRING,
					javax.xml.rpc.ParameterMode.IN);
			call.setReturnType(org.apache.axis.Constants.XSD_ANY);
			call.invoke(inputArray);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("call to VARAGENT webservice failed"
					+ e.getMessage());
		}
	}
	
	/**
	 * Used by IVR to check if callStart has been logged
	 * 
	 * @param sessionID	unique session id of the call
	 * @return true if already logged, false otherwise
	 */
	public boolean isCallStarted(String sessionID){
		return (callTable.get(sessionID) != null);
	}
}
