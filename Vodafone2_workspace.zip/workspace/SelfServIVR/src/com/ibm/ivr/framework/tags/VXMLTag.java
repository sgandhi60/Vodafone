package com.ibm.ivr.framework.tags;

import java.util.StringTokenizer;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;
import com.ibm.ivr.framework.utilities.Common;
/**
 * The VXML custom tag
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-11: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-11
 *  
 */
public class VXMLTag extends TagSupport {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(VXMLTag.class);

	private String properties = "";

	public void setProperties(String _properties) {
		this.properties = _properties;
	}

	public String getProperties() {
		return this.properties;
	}

	public int doStartTag() throws JspException {
		StringBuffer vxmltag = new StringBuffer();

		HttpSession session = pageContext.getSession();

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append("VXMLTag properties: "
					+ properties));
		
		String name = null;
		String value = null;
		StringTokenizer st = new StringTokenizer(properties, ";");
		while (st.hasMoreTokens()) {
			String var = st.nextToken();
			if (var != null) {
				int index = var.indexOf(":");
				if (index != -1) {
					name = var.substring(0, index).trim();
					value = var.substring(index + 1).trim();
					
					if (value.startsWith("$")){
					    value = (String) Common.getSessionValue(value.substring(1), session);	
					}
					
					vxmltag.append("<property name=\"").append(name).append("\" value=\"").append(value).append("\" />").append("\n");
				}
			}
		}
		if (testCall)
			LOGGER.trace(new StringBuffer(logToken).append("VXMLTag content: "
					+ vxmltag.toString()));
		
		try {
			pageContext.getOut().print(vxmltag.toString());
		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken).append("VXMLTag Error: ").append(e.getMessage()));
			e.printStackTrace();
		}
	
		return SKIP_BODY;
	}

	public int doEndTag() {
		return EVAL_PAGE;
	}

}
