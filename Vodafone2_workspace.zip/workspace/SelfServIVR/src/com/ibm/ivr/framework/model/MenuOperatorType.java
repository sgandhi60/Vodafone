/**
 * <copyright>
 * </copyright>
 *
 * $Id: MenuOperatorType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Menu Operator Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getCond <em>Cond</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getCounter <em>Counter</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getDest <em>Dest</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getDestType <em>Dest Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetAudio <em>Target Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetMode <em>Target Mode</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetName <em>Target Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetType <em>Target Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.MenuOperatorType#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType()
 * @model 
 * @generated
 */
public interface MenuOperatorType
{
  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute.
   * @see #setValue(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_Value()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getValue();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getValue <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' attribute.
   * @see #getValue()
   * @generated
   */
  void setValue(String value);

  /**
   * Returns the value of the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cond</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cond</em>' attribute.
   * @see #setCond(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_Cond()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCond();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getCond <em>Cond</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Cond</em>' attribute.
   * @see #getCond()
   * @generated
   */
  void setCond(String value);

  /**
   * Returns the value of the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Counter</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Counter</em>' attribute.
   * @see #setCounter(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_Counter()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCounter();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getCounter <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Counter</em>' attribute.
   * @see #getCounter()
   * @generated
   */
  void setCounter(String value);

  /**
   * Returns the value of the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dest</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dest</em>' attribute.
   * @see #setDest(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_Dest()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDest();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getDest <em>Dest</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dest</em>' attribute.
   * @see #getDest()
   * @generated
   */
  void setDest(String value);

  /**
   * Returns the value of the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dest Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dest Type</em>' attribute.
   * @see #setDestType(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_DestType()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDestType();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getDestType <em>Dest Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dest Type</em>' attribute.
   * @see #getDestType()
   * @generated
   */
  void setDestType(String value);

  /**
   * Returns the value of the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Audio</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Audio</em>' attribute.
   * @see #setTargetAudio(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_TargetAudio()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetAudio <em>Target Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Audio</em>' attribute.
   * @see #getTargetAudio()
   * @generated
   */
  void setTargetAudio(String value);

  /**
   * Returns the value of the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Mode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Mode</em>' attribute.
   * @see #setTargetMode(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_TargetMode()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetMode();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetMode <em>Target Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Mode</em>' attribute.
   * @see #getTargetMode()
   * @generated
   */
  void setTargetMode(String value);

  /**
   * Returns the value of the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Name</em>' attribute.
   * @see #setTargetName(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_TargetName()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetName();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetName <em>Target Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Name</em>' attribute.
   * @see #getTargetName()
   * @generated
   */
  void setTargetName(String value);

  /**
   * Returns the value of the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Type</em>' attribute.
   * @see #setTargetType(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_TargetType()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTargetType();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetType <em>Target Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target Type</em>' attribute.
   * @see #getTargetType()
   * @generated
   */
  void setTargetType(String value);

  /**
   * Returns the value of the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tts</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tts</em>' attribute.
   * @see #setTts(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getMenuOperatorType_Tts()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTts();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTts <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tts</em>' attribute.
   * @see #getTts()
   * @generated
   */
  void setTts(String value);

} // MenuOperatorType
