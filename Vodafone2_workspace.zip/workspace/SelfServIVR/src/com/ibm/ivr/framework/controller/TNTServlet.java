package com.ibm.ivr.framework.controller;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.DefaultRoutingType;
import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.TransferType;
import com.ibm.ivr.framework.utilities.Common;
import com.ibm.ivr.framework.utilities.Reporter;

/**
 * The TransferServlet decides attaches the call data to the call (if available)
 * and transfer the caller to the queue/route point
 * 
 * Revision history:
 * <p>
 * 2007-03-23:
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-21
 *  
 */
public class TNTServlet extends HttpServlet implements Servlet {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(TNTServlet.class);

	/**
	 * The regular service method as the controller to forward to next jsv page
	 * and/or error page in the case of exceptions
	 * 
	 * @param HttpServletRequest -
	 *            Servlet Request object
	 * @param HttpServletResponse -
	 *            Servlet Response object
	 * 
	 * @return void
	 * @throws ServletException,
	 *             IOException
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String callid = null;

		// get session from Servlet request
		HttpSession session = req.getSession(false);
		
		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC.push((String)this.getServletContext().getAttribute("hostName"));

		callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce
		// number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		LOGGER
				.info(new StringBuffer(logToken)
						.append("Entering TNTServlet..."));

		String TNT = (String) req.getAttribute("TNT");
		if (TNT == null) {
			TNT = req.getParameter("TNT");
			if (TNT != null)
				req.setAttribute("TNT", TNT);
		}

		String errorMessage = (String) req.getAttribute("errorMessage");
		if (errorMessage == null)
			errorMessage = req.getParameter("errorMessage");

		String exitReason = (String) req.getAttribute("exitReason");
		if (exitReason == null) {
			exitReason = req.getParameter("exitReason");
			if (exitReason != null)
				req.setAttribute("exitReason", exitReason);
		}

		if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append(
					"exitReason: ").append(exitReason));
		}

		//check the special counter associated with EventType only
		// when ready for TNT
		StringBuffer counterSB = new StringBuffer();
		CallRoutingType iCallRouting = (CallRoutingType) session
			.getAttribute("iCallRouting");
		if (iCallRouting != null) {
			EventsType events = iCallRouting.getEvents();

			if (events != null) {
				List transfers = events.getTransfer();
				if (transfers != null) {
					for (int i = 0; i < transfers.size(); i++) {
						TransferType transfer = (TransferType) transfers
								.get(i);
						String c = transfer.getCond();
						boolean result = true;
						if (c != null && c.length() != 0) {
							result = Common.conditionsMatch(c, session,
									logToken);
							if (testCall)
								LOGGER.trace(new StringBuffer(logToken)
										.append(
												"Events.Transfer cond: ["
														+ c).append(
												"] evaluated as: ")
										.append(result));
						}
						//only if cond is true or not specified
						if (result) {
							String ctr = transfer.getCounter();
							if (ctr != null && ctr.length() != 0) {
								counterSB.append(
										Common.evaluateCounterName(ctr,
												session)).append(",");
							}
						}
					}
				}
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"increment counter: ").append(counterSB));
				}

				//get the reporter
				Reporter reporter = (Reporter) this.getServletContext().getAttribute(
						"reporter");
				
				String appName = "UNKNOWN";
				appName = iCallRouting.getName();

				//contains GVP call id for VAR reporter
				String gvpCallId = (String) session.getAttribute("gvpCallId");
				
				String[] counters = counterSB.toString().split(",");
				for (int i = 0; i < counters.length; i++) {
					String c = counters[i].trim();
					if (c.length() != 0) {
						reporter.callEvent(gvpCallId, appName, c);
					}
				}
			}
		}

		String defaultRouting = (String) req.getAttribute("defaultRouting");
		if (defaultRouting == null) {
			defaultRouting = req.getParameter("defaultRouting");
			if (defaultRouting != null)
				req.setAttribute("defaultRouting", defaultRouting);
		} else { //coming from TransferServet Exception handling, no attach
				 // data has attempted
			if (defaultRouting.equalsIgnoreCase("true"))
				req.setAttribute("attachDataNeeded", "true");
		}

		try {
			// build and save the call Route info in session
			StringBuffer callRoute = (StringBuffer) session
					.getAttribute("callRoute");
			if (callRoute == null)
				callRoute = new StringBuffer();
			if (req.getAttribute("defaultRouting") != null)
				callRoute.append("->TNT:DefaultRouting");
			else
				callRoute.append("->TNT:RegularRouting");
			session.setAttribute("callRoute", callRoute);

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("callRoute: ")
						.append(callRoute));
			}

			String nextPage = null;
			String dnis = (String) session.getAttribute("DNIS");

			//if it is defaultRouting, need to find the default TNT number
			if (defaultRouting != null
					&& (defaultRouting.equalsIgnoreCase("true") || defaultRouting.equalsIgnoreCase("queuecall"))) {

				nextPage = "/jsp/" + getInitParameter("nextPage");

				LOGGER.warn(new StringBuffer(logToken).append(
						"Attempting default routing because : ").append(
						errorMessage));

				if (iCallRouting != null) {
					List dRoutings = iCallRouting.getDefaultRouting();
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(
								"DefaultRouting list found: ").append(!(dRoutings == null || dRoutings.size() == 0)));
					}
					if (dRoutings == null || dRoutings.size() == 0){
						Properties prop = (Properties)this.getServletContext().getAttribute("globalProp");
						TNT = prop.getProperty("TNT");
						nextPage = "/jsp/" + getInitParameter("nextPage");
						if (testCall)
							LOGGER.info(new StringBuffer(logToken).append(
								"Using TNT from global.properties: ").append(TNT));
					}
					else {
						nextPage = "/jsp/" + getInitParameter("errorPage");

						String iTNT = null;
						DefaultRoutingType drDefault = null;
						for (int i = 0; i < dRoutings.size(); i++) {
							DefaultRoutingType dRouting = (DefaultRoutingType) dRoutings
									.get(i);
							if (dRouting.getDnis() == null) {
								drDefault = dRouting;
							} else {
								if (dRouting.getDnis().indexOf(dnis) != -1) {
									drDefault = dRouting;
									break;
								}
							}
						}
						
						if (testCall) {
							LOGGER.debug(new StringBuffer(logToken).append(
									"matching DefaultRouting found: ").append(!(drDefault == null)));
						}
						
						if (drDefault != null) {
							//if alternative is not specified
							if (drDefault.getAlternative() == null
									|| drDefault.getAlternative().length() == 0)
								TNT = drDefault.getValue();
							else {//if alternative is specified, use round
								  // robin to find the right one to use
								Boolean defaultRoutingValue = (Boolean) this
										.getServletContext().getAttribute(
												"defaultRoutingValue");
								boolean value = true;
								synchronized (defaultRoutingValue) {
									value = defaultRoutingValue.booleanValue();
									if (value) {
										defaultRoutingValue = Boolean.FALSE;
										LOGGER
												.info(new StringBuffer(logToken)
														.append("Using DefaultRouting value "));
									} else {
										defaultRoutingValue = Boolean.TRUE;
										LOGGER
												.info(new StringBuffer(logToken)
														.append("Using DefaultRouting alernative attribute value "));
									}
									this.getServletContext().setAttribute("defaultRoutingValue", defaultRoutingValue);
								}
								if (value)
									TNT = drDefault.getValue();
								else
									TNT = drDefault.getAlternative();
							}
							if (TNT != null && TNT.length() > 0) {
								TNT = TNT.replaceAll("-", "");
								if (TNT.startsWith("*8")) TNT = TNT.substring(2);
								nextPage = "/jsp/"
										+ getInitParameter("nextPage");
							}
						}
					}
				} else {
					Properties prop = (Properties)this.getServletContext().getAttribute("globalProp");
					TNT = prop.getProperty("TNT");
					nextPage = "/jsp/" + getInitParameter("nextPage");
				}
			}
			else{
				if (TNT != null && TNT.length() > 0) {
					TNT = TNT.replaceAll("-", "");
					if (TNT.startsWith("*8")) TNT = TNT.substring(2);
					nextPage = "/jsp/"
							+ getInitParameter("nextPage");
				}
			}

			req.setAttribute("TNT", TNT);
			if (testCall)
				LOGGER.info(new StringBuffer(logToken).append("transfer to TNT : ")
					.append(TNT));

			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving TNTServlet... nextPage: ").append(nextPage));
			}
			dispatch.forward(req, resp);

		} catch (Exception ex) {
			ex.printStackTrace();
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(ex.getMessage()), ex);
			session.setAttribute("errorLogged", new Boolean(true));
			
			String nextPage = "/jsp/"
					+ (getInitParameter("errorPage") == null ? "TNTError.jsv"
							: getInitParameter("errorPage"));

			req.setAttribute("lastError", ex.toString());
			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving TNTServlet... nextPage: ").append(nextPage));
			}
			dispatch.forward(req, resp);
		}
		NDC.remove();
	}
}
