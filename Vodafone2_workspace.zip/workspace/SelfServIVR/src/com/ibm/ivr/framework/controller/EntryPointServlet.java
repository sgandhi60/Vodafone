package com.ibm.ivr.framework.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.TimeZone;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;


import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.utilities.CallRoutingHelper;
import com.ibm.ivr.framework.utilities.Common;
import com.ibm.ivr.framework.utilities.Reporter;

import com.selfserv.ivr.data.*;
import java.util.Date;
/**
 * The EntryPointServlet decides which application to invoke; it also put into
 * the session of the information needed by other servlets in the application,
 * i.e., callid, locale and an iCallRouting instance if CallRouting application
 * is going to be invoked.
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2004-06-01: initial version
 * <p>
 * 
 * 2007-03-08: 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-08
 *  
 */
public class EntryPointServlet extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;	
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(EntryPointServlet.class);

	/**
	 * The regular service method as the controller to forward to different
	 * servlets and/or error page in the case of exceptions
	 * 
	 * @param HttpServletRequest -
	 *            Servlet Request object
	 * @param HttpServletResponse -
	 *            Servlet Response object
	 * 
	 * @return void
	 * @throws ServletException,
	 *             IOException
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);
		
		// Store into session the Circle and DefaultDNIS passed in for the EntryPointServlet URL.
		// Thses values should be passed from the definition found in WVR default.cff
		
		if (session.getAttribute("circleParm") == null){
			session.setAttribute("circleParm", req.getParameter("circleParm"));
			session.setAttribute("defaultDNIS", req.getParameter("defaultDNIS"));
		}

		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC.push((String) this.getServletContext().getAttribute("hostName"));

		//	get request attributes, if not there then parameters
		String dnis = (String) req.getAttribute("DNIS");
		
		if (dnis == null){
			dnis = (String) req.getParameter("DNIS");
			if (dnis != null){
			  if (dnis.startsWith("tel:"))
				dnis = dnis.substring(4);
			}
		}		

		if (dnis == null) {
			if (((String) this.getServletContext().getInitParameter(
					"ivrPlatform")).equalsIgnoreCase("GVP"))
				dnis = (String) req.getParameter("DID");
		}
		
		//FWQ // If the DNIS was not provided, check the choice variable
		// provided by the test tool
		if (dnis == null)
			dnis = (String) req.getParameter("choice");

		//	get request attributes, if not there then parameters
		String ani = (String) req.getAttribute("ANI");
		

		if (ani == null){
			ani = (String) req.getParameter("ANI");
			if (ani != null){
			   if (ani.startsWith("tel:"))
				 ani = ani.substring(4);
			}
		}

		String callid = (String) req.getAttribute("CALLID");
		
		if (callid == null)
			callid = (String) req.getParameter("CALLID");


		if (callid == null) {
			if (((String) this.getServletContext().getInitParameter(
					"ivrPlatform")).equalsIgnoreCase("GVP"))
				callid = (String) req.getParameter("SESSIONID");
		}

        		
		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken).append(
				"Entering EntryPointServlet with context ").append(
				req.getContextPath()).append("  DNIS = ").append(dnis));

		boolean testCall = false;

		//Part 1 of 3
		//POST routing after getting routing information from URS.    Ths is determined by looking for queueCall in the session.
		try {
			if (((String) this.getServletContext().getInitParameter("ctiEnabled")).equalsIgnoreCase("TRUE")) {

				String queueCall = (String) session.getAttribute("queueCall");
				//   Return form the URS.   If True.
				if (queueCall != null && queueCall.equalsIgnoreCase("DONE")) {
					String routeRequest = req.getParameter("routeRequest");
					//if after return from URS, data hasn't been retrieved
					
					if (routeRequest == null
							|| !routeRequest.equalsIgnoreCase("DONE")) {   //   Get the attach data  First in post route
						String nextPage = "/jsp/"
								+ getInitParameter("postRoutingPage");
						RequestDispatcher dispatch = req
								.getRequestDispatcher(nextPage);
						dispatch.forward(req, resp);
						return;
					}//if data has been retrieved after returning from URS
					else {  // 2nd call in the post route
						session.removeAttribute("queueCall");    // Remove var to turn logic off.
						//any hang up occurred in the flow from here on, will be logged as HangupAfterTransfer
						session.setAttribute("postTransfer","true");

						String ivrTarget = req.getParameter("IVRTarget");
						if (LOGGER.isTraceEnabled())
							LOGGER.info(new StringBuffer(logToken).append(
							"IVRTarget: ").append(ivrTarget));
						session.setAttribute("IVRTarget",
								ivrTarget == null ? "" : ivrTarget);

						String ivrTargetLocation = req
								.getParameter("IVRTargetLocation");
						if (LOGGER.isTraceEnabled())
							LOGGER.info(new StringBuffer(logToken).append(
							"IVRTargetLocation: ").append(ivrTargetLocation));
						session.setAttribute("IVRTargetLocation",
								ivrTargetLocation == null ? ""
										: ivrTargetLocation);

						String msgId = req.getParameter("MSGID");
						if (LOGGER.isTraceEnabled())
							LOGGER.info(new StringBuffer(logToken).append(
							"MSGID: ").append(msgId));
						session.setAttribute("MSGID", msgId == null ? ""
								: msgId);

						String postRoutingEntry = req.getParameter("PostRoutingEntry");
						if (LOGGER.isTraceEnabled())
							LOGGER.info(new StringBuffer(logToken).append(
							"PostRoutingEntry: ").append(postRoutingEntry));
						session.setAttribute("PostRoutingEntry", postRoutingEntry == null ? ""
								: postRoutingEntry);
						
						String wdStartTime = req.getParameter("WeekdayStartTime");
						if (LOGGER.isTraceEnabled())
							LOGGER.info(new StringBuffer(logToken).append(
							"WeekdayStartTime: ").append(wdStartTime));
						session.setAttribute("WeekdayStartTime", wdStartTime == null ? ""
								: wdStartTime);
						
						String wdEndTime = req.getParameter("WeekdayEndTime");
						if (LOGGER.isTraceEnabled())
							LOGGER.info(new StringBuffer(logToken).append(
							"WeekdayEndTime: ").append(wdEndTime));
						session.setAttribute("WeekdayEndTime", wdEndTime == null ? ""
								: wdEndTime);
						
						//if more IVR flow is needed after routing completed
						//if (postRoutingEntry != null && postRoutingEntry.trim().length() > 0 && ivrTarget != null && ivrTarget.trim().length() < 10 && ivrTarget.trim().length() > 0) {
                        //  Logic to determine next subMenu to go to inside our XML
						if (postRoutingEntry != null && postRoutingEntry.trim().length() > 0) {
							testCall = ((Boolean) session
									.getAttribute("testCall")).booleanValue();
							CallRoutingType iCallRouting = (CallRoutingType) session
									.getAttribute("iCallRouting");

							// Check properties to find the start menu
							Properties prop = (Properties) this.getServletContext()
									.getAttribute("mappingProp");

							// extract value for this DNIS from ivrmapping
							// properties
							// for called IVR apps, this value will be in
							// xxxx.xml#xxxmenu.dtmf format
							String callFlow = prop.getProperty("callflow."
									+ postRoutingEntry);
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(
										"callFlow ").append(callFlow));

							// if DNIS not defined in the ivrmapping.properties
							if (callFlow == null) {
								throw new Exception(
										"DNIS "	+ postRoutingEntry
												+ " not defined in the ivrmapping.properties");
							}

							// parse the value found corresponding to key to
							// determine the start
							// menu/mode
							String xmlFile = null;
							String menuMode = null;
							String menu = null;
							String mode = null;
							int index = callFlow.indexOf("#");
							if (index != -1) {
								xmlFile = callFlow.substring(0, index);
								menuMode = callFlow.substring(index + 1);
								index = menuMode.indexOf(".");
								if (index != -1) {
									menu = menuMode.substring(0, index);
									mode = menuMode.substring(index + 1);
								}
							}

							if (menu == null) {
								menu = (String) iCallRouting.getStart();
								mode = (String) iCallRouting.getStartMode();
							}
							session.setAttribute("entryMenu", menu);
							//set the mode in session
							session.setAttribute("mode", mode);

							RequestDispatcher dispatch = req
									.getRequestDispatcher("/CallRoutingServlet");
							dispatch.forward(req, resp);
							return;

						} else {//if no more IVR flow after routing is done
							//req.setAttribute("routeRequest", "DONE");
							RequestDispatcher dispatch = req
									.getRequestDispatcher("/TransferServlet");
							dispatch.forward(req, resp);
							return;
						}
					}
				}
			}

			//  Part 2 of 3 First thing execute when new call.
			//do not need to do all these checking if testCall has been set in
			// the session
			if (session.getAttribute("testCall") == null) {
				if (((String) this.getServletContext().getInitParameter(
						"ctiEnabled")).equalsIgnoreCase("TRUE")) {

					
					String ctiStartDone = (String) req.getParameter("ctiStartDone");
					//if CTI enabled but ctiStart operation hasn't been done,
					// send
					// back the ctiStart page
					if (ctiStartDone == null
							|| !ctiStartDone.equalsIgnoreCase("true")) {
						//save the intial value to compare later if need to be
						// replaced
						if (dnis != null) {
							session.setAttribute("DNIS", dnis);
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"DNIS from IVR: ").append(dnis));
						}
						if (ani != null) {
							session.setAttribute("ANI", ani);
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"ANI from IVR: ").append(ani));
						}
						if (callid != null) {
							session.setAttribute("callid", callid);
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"CALLID from IVR: ").append(callid));
						}
						// First page to execute.  To get GVP_ANI  and IVR_DNIS from the link
						//  Will set ctiStartPage true
						String nextPage = "/jsp/"
								+ getInitParameter("ctiStartPage");
						RequestDispatcher dispatch = req
								.getRequestDispatcher(nextPage);
						dispatch.forward(req, resp);
						return;
					} else {
						//otherwise, use the submitted new value to replace the
						// ones in the session
						//  Was it set bu the ctiStartPage then use it .. 
						if (dnis != null && dnis.length() != 0) {
							session.setAttribute("DNIS", dnis);
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"DNIS from CTI: ").append(dnis));
						} else
							dnis = (String) session.getAttribute("DNIS");

						if (ani != null && ani.length() != 0) {
							session.setAttribute("ANI", ani);
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"ANI from CTI: ").append(ani));
						} else
							ani = (String) session.getAttribute("ANI");

						if (callid != null && callid.length() != 0) {
							session.setAttribute("callid", callid);
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"CALLID from CTI: ").append(callid));
						} else
							callid = (String) session.getAttribute("callid");

						String connectionID = req.getParameter("connectionID");
						if (connectionID != null && connectionID.length() > 0)
							session.setAttribute("connectionID", connectionID);
					}

				} else {
					// First time invocation if DNIS is not submitted, e.g., WVR
					// platform when browser is recycled at the end of the
					// previous
					// call
					
					//  Check the vxmlStartDone and if true then put ANI & DNIS into session.
					
					//  Add logic similar to above when vxmlStartDone is null and TRUE.
					//   No need to check if DNIS, ANI, CallID are null .. 
					
					String vxmlStartDone = (String) req.getParameter("vxmlStartDone");
					
					if (vxmlStartDone == null) {
						String nextPage = "/jsp/"
								+ getInitParameter("vxmlStartPage");
						RequestDispatcher dispatch = req
								.getRequestDispatcher(nextPage);
						dispatch.forward(req, resp);
						return;
					}
				}
			}

			
			
			
			// Check global.properties to see if this call should be treated
			// as test call

						
            if (callid == null){
            	UUID uid = UUID.randomUUID();
            	callid = uid.toString();
            	// Generate the call ID but don't place in session
            }

			Properties globalProp = (Properties) this.getServletContext()
					.getAttribute("globalProp");
			String testDNIS = (String) globalProp.get("testDNIS");
			if (session.getAttribute("testCall") == null) {//if first time in
				if (testDNIS != null && testDNIS.indexOf(dnis) != -1) {
				
					testCall = true;
					session.setAttribute("testCall", Boolean.valueOf(testCall));
					session.setAttribute("gvpCallId", callid);
					
										
					//callid = "TEST" + dnis + "-" + callid;
					// Removed dnis from TEST callid to control length
					callid = "TEST" + "-" + callid;
					
					session.setAttribute("callid", callid);
					//send the firstPage to collect DNIS/ANI
					String nextPage = "/jsp/" + getInitParameter("firstPage");
					RequestDispatcher dispatch = req
							.getRequestDispatcher(nextPage);
					dispatch.forward(req, resp);
					return;
				} else {
					// Logic to force test call status for additional logging
					String testDNISforce = (String) globalProp.get("testDNISforce");
					if (testDNISforce.equalsIgnoreCase("true")){
						testCall = true;
     				}
					session.setAttribute("gvpCallId", callid);
					session.setAttribute("testCall", Boolean.valueOf(testCall));
					session.setAttribute("callid", callid);
				}
			} else {//2nd time in after the caller entered DNIS manually
				
				testCall = ((Boolean) session.getAttribute("testCall"))
						.booleanValue();
				callid = (String) session.getAttribute("callid");
			}

//			if (callid == null)
//				callid = (String) session.getAttribute("callid");			
			
			//create the log Token for later use, use StringBuffer to reduce
			// number
			// of String objects
			logToken = new StringBuffer("[").append(callid).append("] ")
					.toString();

			// set current position of caller as "EntryPoint" in the session for
			// later use
			// to log at Hangup time for statistic report
			String currentPos = "EntryPoint";
			session.setAttribute("currentPos", currentPos);

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append("CurrentPos: ")
						.append(currentPos));

			// Valid Application DNIS
			//contains GVP call id for VAR reporter
			String gvpCallId = (String) session.getAttribute("gvpCallId");

			//set current date in the session
			String dateFormat = (String) this.getServletContext().getAttribute(
					"dateFormat");
			SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
			
			String timeZone = ((Properties)this.getServletContext().getAttribute("globalProp")).getProperty("timeZone");
			TimeZone tz = TimeZone.getTimeZone(timeZone);
			formatter.setTimeZone(tz);
			Calendar calNow = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
			
			String date = formatter.format(calNow.getTime());
			session.setAttribute("TODAY", date);
			if (testCall)
				LOGGER.trace(new StringBuffer(logToken).append(
						"TODAY: ").append(date));
			
			
			
			//String shiftStr = (String) globalProp.get("transactionDateShift");
			//int shift = 0;
			//try {
				//shift = Integer.parseInt(shiftStr);
			//}catch(Exception ex){
				//if (testCall)
					//LOGGER.debug(new StringBuffer(logToken).append(
							//"transactionDateShift: ").append(ex.getMessage()));
			//}
			
			//calNow.add(Calendar.DATE, shift);
			//date = formatter.format(calNow.getTime());
			//session.setAttribute("TRANSACTIONDATE", date);
			//if (testCall)
				//LOGGER.trace(new StringBuffer(logToken).append(
					//	"TRANSACTIONDATE: ").append(date));

			
			//set call start time in the session
			String startTimeFormat = (String) this.getServletContext()
					.getAttribute("startTimeFormat");
			if (startTimeFormat != null) {
				formatter = new SimpleDateFormat(startTimeFormat);
				formatter.setTimeZone(tz);
				calNow = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
				String startTime = formatter.format(calNow.getTime());
				session.setAttribute("startTime", startTime);
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"startTime to be sent to backend: ").append(
							startTime));
			}

			// Check properties to search Hash Table for CallRouting class
			Properties prop = (Properties) this.getServletContext()
					.getAttribute("mappingProp");
			if (testCall)
				LOGGER.trace(new StringBuffer(logToken)
						.append("after mappingproperties"));

			Hashtable hs = (Hashtable) this.getServletContext().getAttribute(
					"callRoutingTable");
			if (testCall)
				LOGGER.trace(new StringBuffer(logToken)
						.append("after callRoutingTable"));
			
			//  MIRT:  Added logic in the event a NULL DNIS arrives to the App.
			//  Set DNIS and dnis is null
			//
			if (dnis == null || dnis.length() == 0){
			   session.setAttribute("DNIS", session.getAttribute("defaultDNIS"));
			   dnis = (String) session.getAttribute("DNIS");
			   LOGGER.warn(new StringBuffer(logToken).append("DEFAULT DNIS override used, dnis was null.  Now set to ")
					                                 .append(dnis));
			}

			// extract value for this DNIS from ivrmapping properties
			// for called IVR apps, this value will be in
			// xxxx.xml#xxxmenu.dtmf format
			String callFlow = prop.getProperty("callflow." + dnis);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append("callFlow ")
						.append(callFlow));

			// if DNIS not defined in the ivrmapping.properties
			if (callFlow == null) {
				   session.setAttribute("DNIS", session.getAttribute("defaultDNIS"));
				   String dnisOld = dnis;
				   dnis = (String) session.getAttribute("DNIS");
				   LOGGER.warn(new StringBuffer(logToken).append("DEFAULT DNIS override used, dnis was ")
						                                 .append(dnisOld)
						                                 .append("  now set to ")
						                                 .append(dnis));
				   callFlow = prop.getProperty("callflow." + dnis);
				   if (callFlow == null) {
						throw new Exception("defaultDNIS " + dnis
								+ " not defined in the ivrmapping.properties");
				   }
			}
			CallRoutingType iCallRouting = (CallRoutingType) hs.get("callflow."
					+ dnis);

			Hashtable iCRHelperHashtable = (Hashtable) this.getServletContext()
					.getAttribute("callRoutingHelperHash");

			CallRoutingHelper iCRHelper = (CallRoutingHelper) iCRHelperHashtable
					.get("callflow." + dnis);

			if (testCall)
				LOGGER.info(new StringBuffer(logToken).append(
					iCallRouting.getName())
					.append(" Application to be started"));

			
			
			// log call starting timestamp
			Reporter reporter = (Reporter) this.getServletContext()
					.getAttribute("reporter");
			reporter.callStart(ani, dnis, gvpCallId, iCallRouting.getName());

            // Check Alternate Reporting attribute for additional report inforamtion.
			String altReport = (String) this.getServletContext().getAttribute("altReport");
			if(altReport.equals("true")){
				Date ssReportCallStart = new Date();
				session.setAttribute("ssReportCallStart",ssReportCallStart);				
			}
			
			
			//To be used by the rest of application
			session.setAttribute("iCallRouting", iCallRouting);
			session.setAttribute("iCRHelper", iCRHelper);
			HashMap attachedData = new HashMap();
			session.setAttribute("attachedData", attachedData);

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken)
						.append("Set iCallRouting in the session"));

			// store DNIS in session
			// Mirt :: Maybe we can review
			session.setAttribute("DNIS", dnis);
			session.setAttribute("ANI", ani);

			// set default TNT number in the session, to be passed to
			// staticVXMLPage
			prop = (Properties) this.getServletContext().getAttribute(
					"globalProp");
			String tnt = prop.getProperty("TNT." + dnis);
			if (tnt == null)
				tnt = prop.getProperty("TNT");
			session.setAttribute("TNT", tnt);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"default TNT to be used in staticVXMLPage: ").append(
						tnt));
			
			// Vodafone::  Added this section to construct the audio and audio utils directory.  Place in session
			
			// Vodafone:: Load Circle based information into session			
			Properties callProp = (Properties) this.getServletContext().getAttribute("callProp");
			session.setAttribute("callProp", callProp);
			// Get circle ref based on DNIS
//			String Circ = (String)callProp.getProperty("circleDNIS."+dnis);
			
			// Shailesh - HotKey support
			// Get circle ref from URL request
			String Circ = (String) session.getAttribute("circleParm");
			
			if (testCall){
				LOGGER.trace(new StringBuffer(logToken).append("circleParm = "+Circ));
			}

			// extract values of HotkeyDNIS and HotKeyDNISType for this circle from call properties
			
			// Mirt:  No need ot override dnis here
			//dnis = callProp.getProperty("circleHotKeyDNIS." + Circ);
									
			// Create class to hold circle specific information
			Circle circle = new Circle();
			
			circle.setCircle(Circ);
			circle.setCircleName((String)callProp.getProperty("circleName."+Circ));

			circle.setHotKeyDNIS((String)callProp.getProperty("circleHotKeyDNIS."+Circ));
			circle.setHotKeyType((String)callProp.getProperty("circleHotKeyType."+Circ));

			circle.setGprsFlag((String)callProp.getProperty("circleGPRS."+Circ));
			
			circle.setCtiEnabledFlag((String)callProp.getProperty("circleCTIEnabled."+Circ));
			circle.setCtiSwitch((String)callProp.getProperty("circleCTISwitch."+Circ));
			circle.setCdtType((String)callProp.getProperty("circleCdtType."+Circ));

			circle.setSpPackageName((String)callProp.getProperty("spPackageName."+Circ));

			circle.setCcMinAmt((String)callProp.getProperty("ccMinAmt."+Circ));
			circle.setCcMaxAmt((String)callProp.getProperty("ccMaxAmt."+Circ));
			
			circle.setTransferCharge((String)callProp.getProperty("transferCharge."+Circ));
			circle.setComplaintMenuActivePre((String)callProp.getProperty("complaintMenuActivePre."+Circ));
			circle.setComplaintMenuActivePost((String)callProp.getProperty("complaintMenuActivePost."+Circ));
			circle.setMaxTransfer((String)callProp.getProperty("maxTransfer."+Circ));
			circle.setLocalLanguage((String)callProp.getProperty("localLanguage."+Circ));
			circle.setDefaultLanguage((String)callProp.getProperty("defaultLanguage."+Circ));
			circle.setLocalJNDIName((String)callProp.getProperty("localJNDIName."+Circ));
			circle.setReportJNDIName((String)callProp.getProperty("reportJNDIName."+Circ));
			
			// Mirt:  Set call type based on whether this is a HotKey call or not.
			if (dnis.equals(circle.getHotKeyDNIS())){
				circle.setDnisType(circle.getHotKeyType());
			}else{
			    circle.setDnisType((String)callProp.getProperty("dnisType."+dnis));
			}
			
			// Get To Continue Conditional choices and Langs
			circle.setToContinueChoice1((String)callProp.getProperty("toContinueChoice1."+Circ));
			circle.setToContinueChoice2((String)callProp.getProperty("toContinueChoice2."+Circ));
			circle.setToContinueChoice3((String)callProp.getProperty("toContinueChoice3."+Circ));

			circle.setToContinueChoice1Lang((String)callProp.getProperty("toContinueChoice1Lang."+Circ));
			circle.setToContinueChoice2Lang((String)callProp.getProperty("toContinueChoice2Lang."+Circ));
			circle.setToContinueChoice3Lang((String)callProp.getProperty("toContinueChoice3Lang."+Circ));
			
			// Get To Set Conditional choices and Langs
			circle.setToSetChoice1((String)callProp.getProperty("toSetChoice1."+Circ));
			circle.setToSetChoice2((String)callProp.getProperty("toSetChoice2."+Circ));
			circle.setToSetChoice3((String)callProp.getProperty("toSetChoice3."+Circ));

			circle.setToSetChoice1Lang((String)callProp.getProperty("toSetChoice1Lang."+Circ));
			circle.setToSetChoice2Lang((String)callProp.getProperty("toSetChoice2Lang."+Circ));
			circle.setToSetChoice3Lang((String)callProp.getProperty("toSetChoice3Lang."+Circ));
			
			circle.setDefVDNTypeA((String)callProp.getProperty("circleDefaultVDNTypeA."+Circ));
			circle.setDefVDNTypeB((String)callProp.getProperty("circleDefaultVDNTypeB."+Circ));
			circle.setDefVDNTypeC((String)callProp.getProperty("circleDefaultVDNTypeC."+Circ));
			circle.setDefVDNTypeD((String)callProp.getProperty("circleDefaultVDNTypeD."+Circ));
			
			circle.setDefVdnGPRS((String)callProp.getProperty("circleDefaultVDNTypeD."+Circ));
			
			// Set circle into session
			session.setAttribute("circle", circle);
			
			session.setAttribute("LANG",circle.getDefaultLanguage());
			session.setAttribute("ctiSwitch", circle.getCtiSwitch());
			session.setAttribute("cdtType", circle.getCdtType());
			session.setAttribute("ctiEnabled", circle.getCtiEnabledFlag());
			
			// Log debug messages
			if (testCall){
				LOGGER.trace(new StringBuffer(logToken).append("Circle = "+Circ));
				LOGGER.trace(new StringBuffer(logToken).append("circle.CircleName = "+circle.getCircleName()));
				
				LOGGER.trace(new StringBuffer(logToken).append("circle.HotKeyDNIS = "+circle.getHotKeyDNIS()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.HotKeyType = "+circle.getHotKeyType()));

				LOGGER.trace(new StringBuffer(logToken).append("circle.gprsFlag = "+circle.getGprsFlag()));

				LOGGER.trace(new StringBuffer(logToken).append("circle.CTIEnabledFlag = "+circle.getCtiEnabledFlag()));

				LOGGER.trace(new StringBuffer(logToken).append("circle.spPackageName = "+circle.getSpPackageName()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.ccMinAmt = "+circle.getCcMinAmt()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.ccMaxAmt = "+circle.getCcMaxAmt()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.TransferCharge = "+circle.getTransferCharge()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.complaintMenuActivePre = "+circle.getComplaintMenuActivePre()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.complaintMenuActivePost = "+circle.getComplaintMenuActivePost()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.MaxTransfer = "+circle.getMaxTransfer()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.LocalLanguage = "+circle.getLocalLanguage()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.DefaultLanguage = "+circle.getDefaultLanguage()));				
				LOGGER.trace(new StringBuffer(logToken).append("circle.localJNDIName = "+circle.getLocalJNDIName()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.reportJNDIName = "+circle.getReportJNDIName()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.dnisType = "+circle.getDnisType()));
				LOGGER.trace(new StringBuffer(logToken).append("session var LANG = "+session.getAttribute("LANG")));
				
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToContinueChoice1 = "+circle.getToContinueChoice1()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToContinueChoice2 = "+circle.getToContinueChoice2()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToContinueChoice3 = "+circle.getToContinueChoice3()));
				
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToContinueChoice1Lang = "+circle.getToContinueChoice1Lang()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToContinueChoice2Lang = "+circle.getToContinueChoice2Lang()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToContinueChoice3Lang = "+circle.getToContinueChoice3Lang()));
				
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToSetChoice1 = "+circle.getToSetChoice1()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToSetChoice2 = "+circle.getToSetChoice2()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToSetChoice3 = "+circle.getToSetChoice3()));
				
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToSetChoice1Lang = "+circle.getToSetChoice1Lang()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToSetChoice2Lang = "+circle.getToSetChoice2Lang()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getToSetChoice3Lang = "+circle.getToSetChoice3Lang()));
				
				LOGGER.trace(new StringBuffer(logToken).append("circle.getDefVDNTypeA = "+circle.getDefVDNTypeA()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getDefVDNTypeB = "+circle.getDefVDNTypeB()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getDefVDNTypeC = "+circle.getDefVDNTypeC()));
				LOGGER.trace(new StringBuffer(logToken).append("circle.getDefVDNTypeD = "+circle.getDefVDNTypeD()));
			
				LOGGER.trace(new StringBuffer(logToken).append("circle.getDefVdnGPRS = "+circle.getDefVdnGPRS()));
			}
		
			// Set initial Customer class to session
			Customer customer = new Customer();
			session.setAttribute("customer", customer);
			
			// Set initial Report class to session
			Report report = new Report();
			session.setAttribute("report", report);	
		
			
			
			// Set initial values of audio dir and audio utils dir
			String audioDir = iCallRouting.getAudioDir();							
	        String audioUtilsDir = iCallRouting.getAudioDir() + "/utils";
	      
	        // Set Skeleton audio dir into session
	        session.setAttribute("audioSkeleton", audioDir);
	      
		    try {
                 // See if directory name has a variable reference. Supports one $var at this time
			    	int idx = audioDir.indexOf("$");
			    	if (idx != -1){
				     	String work = audioDir.substring(idx);
					    int idx1 = work.indexOf("/");
					    if (idx1 != -1){
					     	work.substring(0,idx1);					
				     	}
				      String workResult = (String) evaluate(req, work);
				      String workReplace = "["+work.substring(0,1)+"]"+work.substring(1);
				      
				      audioDir = audioDir.replaceFirst(workReplace, workResult);
				      session.setAttribute("audioDir", audioDir);
				      audioUtilsDir = audioDir+"/utils";
				      session.setAttribute("audioUtilsDir", audioUtilsDir);
				      
			    	}
		  } catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken).append(e.getMessage()));
			throw new JspException(e.getMessage());
		  }		

		  // Vodafone Logging added
		 if (testCall) {
			LOGGER.debug(new StringBuffer(logToken).append("testCall: [" + testCall+"]"));
			LOGGER.debug(new StringBuffer(logToken).append("audioDir: [" + audioDir+"]"));
		 	LOGGER.debug(new StringBuffer(logToken).append("audioUtilsDir: [" + audioUtilsDir+"]"));
		 }
					
			// Vodafone Logging added
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("audioDir:X [" + audioDir+"]"));
				LOGGER.debug(new StringBuffer(logToken).append("audioUtilsDir:X [" + audioUtilsDir+"]"));
			}
			
			
			RequestDispatcher dispatch = req.getRequestDispatcher("/WelcomeServlet");
			if (testCall)
				LOGGER
						.debug(new StringBuffer(logToken)
								.append("Leaving EntryPointServlet... nextPage: /WelcomeServlet"));

			dispatch.forward(req, resp);

		} catch (Exception ex) {
			ex.printStackTrace(); // Exceptions are too important not to have
			// the full stack trace in the server log
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(ex.getMessage()), ex);

			session.setAttribute("errorLogged", new Boolean(true));

			String nextPage = "/jsp/"
					+ (getInitParameter("errorPage") == null ? "Error.jsv"
							: getInitParameter("errorPage"));
			req.setAttribute("lastError", ex.toString());
			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving EntryPointServlet... nextPage: ").append(
						nextPage));

			dispatch.forward(req, resp);
		}
		NDC.remove();
	}
	
	/**
	 * Evaluate the string as literal string or session variable
	 * 
	 * @param var
	 *            literal string or session variable (starting with $)
	 * @return the value of session variable or literal string, null if not
	 *         found in session
	 * @throws Exception
	 */
	//Vodafone Added this method for processing audio directory content
	private Object evaluate(HttpServletRequest req, String var) throws Exception {
		HttpSession session = req.getSession();
		Object value = null;

		if (var != null && var.startsWith("$")) {
			value = Common.getSessionValue(var.substring(1), session);
			if (value == null){
				throw new JspException("session variable " + var.substring(1)
						+ " is not available at menu: ");
			}
			else
				return value;
		} else {
			return var;
		}
	}

}