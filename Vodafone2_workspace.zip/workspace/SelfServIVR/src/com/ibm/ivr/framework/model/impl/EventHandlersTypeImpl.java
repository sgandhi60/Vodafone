/**
 * <copyright>
 * </copyright>
 *
 * $Id: EventHandlersTypeImpl.java,v 1.4 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.EventHandlersType;
import com.ibm.ivr.framework.model.HelpType;
import com.ibm.ivr.framework.model.InputErrorType;
import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.NoInputType;
import com.ibm.ivr.framework.model.NoMatchType;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Handlers Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.EventHandlersTypeImpl#getInputError <em>Input Error</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.EventHandlersTypeImpl#getNoInput <em>No Input</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.EventHandlersTypeImpl#getNoMatch <em>No Match</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.EventHandlersTypeImpl#getHelp <em>Help</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EventHandlersTypeImpl extends EDataObjectImpl implements EventHandlersType
{
  /**
   * The cached value of the '{@link #getInputError() <em>Input Error</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputError()
   * @generated
   * @ordered
   */
  protected EList inputError = null;

  /**
   * The cached value of the '{@link #getNoInput() <em>No Input</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNoInput()
   * @generated
   * @ordered
   */
  protected EList noInput = null;

  /**
   * The cached value of the '{@link #getNoMatch() <em>No Match</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNoMatch()
   * @generated
   * @ordered
   */
  protected EList noMatch = null;

  /**
   * The cached value of the '{@link #getHelp() <em>Help</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHelp()
   * @generated
   * @ordered
   */
  protected HelpType help = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EventHandlersTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getEventHandlersType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getInputError()
  {
    if (inputError == null)
    {
      inputError = new EObjectContainmentEList(InputErrorType.class, this, ModelPackage.EVENT_HANDLERS_TYPE__INPUT_ERROR);
    }
    return inputError;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getNoInput()
  {
    if (noInput == null)
    {
      noInput = new EObjectContainmentEList(NoInputType.class, this, ModelPackage.EVENT_HANDLERS_TYPE__NO_INPUT);
    }
    return noInput;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getNoMatch()
  {
    if (noMatch == null)
    {
      noMatch = new EObjectContainmentEList(NoMatchType.class, this, ModelPackage.EVENT_HANDLERS_TYPE__NO_MATCH);
    }
    return noMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HelpType getHelp()
  {
    return help;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHelp(HelpType newHelp, NotificationChain msgs)
  {
    HelpType oldHelp = help;
    help = newHelp;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.EVENT_HANDLERS_TYPE__HELP, oldHelp, newHelp);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHelp(HelpType newHelp)
  {
    if (newHelp != help)
    {
      NotificationChain msgs = null;
      if (help != null)
        msgs = ((InternalEObject)help).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.EVENT_HANDLERS_TYPE__HELP, null, msgs);
      if (newHelp != null)
        msgs = ((InternalEObject)newHelp).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.EVENT_HANDLERS_TYPE__HELP, null, msgs);
      msgs = basicSetHelp(newHelp, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EVENT_HANDLERS_TYPE__HELP, newHelp, newHelp));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs)
  {
    if (featureID >= 0)
    {
      switch (eDerivedStructuralFeatureID(featureID, baseClass))
      {
        case ModelPackage.EVENT_HANDLERS_TYPE__INPUT_ERROR:
          return ((InternalEList)getInputError()).basicRemove(otherEnd, msgs);
        case ModelPackage.EVENT_HANDLERS_TYPE__NO_INPUT:
          return ((InternalEList)getNoInput()).basicRemove(otherEnd, msgs);
        case ModelPackage.EVENT_HANDLERS_TYPE__NO_MATCH:
          return ((InternalEList)getNoMatch()).basicRemove(otherEnd, msgs);
        case ModelPackage.EVENT_HANDLERS_TYPE__HELP:
          return basicSetHelp(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENT_HANDLERS_TYPE__INPUT_ERROR:
        return getInputError();
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_INPUT:
        return getNoInput();
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_MATCH:
        return getNoMatch();
      case ModelPackage.EVENT_HANDLERS_TYPE__HELP:
        return getHelp();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENT_HANDLERS_TYPE__INPUT_ERROR:
        getInputError().clear();
        getInputError().addAll((Collection)newValue);
        return;
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_INPUT:
        getNoInput().clear();
        getNoInput().addAll((Collection)newValue);
        return;
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_MATCH:
        getNoMatch().clear();
        getNoMatch().addAll((Collection)newValue);
        return;
      case ModelPackage.EVENT_HANDLERS_TYPE__HELP:
        setHelp((HelpType)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENT_HANDLERS_TYPE__INPUT_ERROR:
        getInputError().clear();
        return;
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_INPUT:
        getNoInput().clear();
        return;
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_MATCH:
        getNoMatch().clear();
        return;
      case ModelPackage.EVENT_HANDLERS_TYPE__HELP:
        setHelp((HelpType)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.EVENT_HANDLERS_TYPE__INPUT_ERROR:
        return inputError != null && !inputError.isEmpty();
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_INPUT:
        return noInput != null && !noInput.isEmpty();
      case ModelPackage.EVENT_HANDLERS_TYPE__NO_MATCH:
        return noMatch != null && !noMatch.isEmpty();
      case ModelPackage.EVENT_HANDLERS_TYPE__HELP:
        return help != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //EventHandlersTypeImpl
