package com.ibm.ivr.framework.tags;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.ibm.ivr.framework.model.ChoiceType;
import com.ibm.ivr.framework.model.SubMenuType;

/**
 * The Grammar custom tag
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-11: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-11
 *  
 */

public class GrammarTag extends TagSupport {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(GrammarTag.class);

	private String mode = "";

	public void setMode(String _mode) {
		this.mode = _mode;
	}

	public String getMode() {
		return this.mode;
	}

	public int doStartTag() throws JspException {
		StringBuffer grammartag = new StringBuffer();

		HttpSession session = pageContext.getSession();
		HttpServletRequest request =
			(HttpServletRequest) pageContext.getRequest();
		String contextPath = request.getContextPath();
		
		SubMenuType iSubMenu = (SubMenuType) session.getAttribute("iSubMenu");

		// get global properties
		Properties globalProp = (Properties) session.getServletContext()
				.getAttribute("globalProp");

		String callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append("GrammarTag mode: "
					+ mode));

		grammartag.append("<grammar mode=\"")
				.append(mode.equalsIgnoreCase("speech")?"voice":"dtmf")
				.append(
						"\" version=\"1.0\" root=\"submenu\" tag-format=\"semantics/1.0\">").append("\n");
		grammartag.append("	<rule id=\"submenu\" scope=\"public\">").append("\n");
		grammartag.append("		<one-of>").append("\n");

		List choices = iSubMenu.getChoice();

		Iterator it = choices.iterator();
		boolean itemPrinted = false;

		if (mode.equalsIgnoreCase("dtmf")) {
			while (it.hasNext()) {
				ChoiceType choice = (ChoiceType) it.next();
				String dtmf = choice.getDtmf().trim();
				if (dtmf.startsWith("@")) continue;
				
				//check the cond, if false, no need to generate the grammar entry
				String cond = choice.getCond();
				boolean condResult = true;
				if (cond != null && cond.length() != 0) {
					condResult = com.ibm.ivr.framework.utilities.Common
								.conditionsMatch(cond, session, logToken);
					if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(
									"GrammarTag cond: [" + cond).append(
									"] evaluated as: ").append(condResult));
				}
				if (!condResult) continue;
				
				itemPrinted = true;
				grammartag.append(			"<item>").append("\n");
				if (dtmf.endsWith(".grxml")) {
					grammartag.append(				"<ruleref	uri=\"").append(contextPath).append("/grammar/").append(dtmf)
							.append("\"/>").append("\n");
					grammartag.append(				"<tag>").append("\n");
					grammartag.append("$=$$+\",menuInput=").append(dtmf)
							.append("\"").append("\n");
					grammartag.append(				"</tag>").append("\n");
				} else {
					String dtmfWSpace = spacingDTMFString(dtmf);
					grammartag.append("				").append(dtmfWSpace).append("\n");
					grammartag.append("				<tag><![CDATA[$=\"").append(dtmf).append(
							"\";]]></tag>").append("\n");
				}
				grammartag.append(			"</item>").append("\n");
			}
		}else {//speech mode to be added later
			while (it.hasNext()) {
				ChoiceType choice = (ChoiceType) it.next();
				String annot = choice.getAnnot().trim();
				String speech = choice.getSpeech().trim();
				if (annot.startsWith("@")) continue;
				
				//check the cond, if false, no need to generate the grammar entry
				String cond = choice.getCond();
				boolean condResult = true;
				if (cond != null && cond.length() != 0) {
					condResult = com.ibm.ivr.framework.utilities.Common
								.conditionsMatch(cond, session, logToken);
					if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(
									"GrammarTag cond: [" + cond).append(
									"] evaluated as: ").append(condResult));
				}
				if (!condResult) continue;
				
				itemPrinted = true;
				grammartag.append(			"<item>").append("\n");
				if (speech.endsWith(".grxml")) {
					grammartag.append(				"<ruleref	uri=\"").append(contextPath).append("/grammar/").append(speech)
							.append("\"/>").append("\n");
					grammartag.append(				"<tag>").append("\n");
					grammartag.append("$=$$+\",menuInput=").append(speech)
							.append("\"").append("\n");
					grammartag.append(				"</tag>").append("\n");
				} else {
					grammartag.append("				").append(speech).append("\n");
					grammartag.append("				<tag><![CDATA[$=\"").append(annot).append(
							"\";]]></tag>").append("\n");
				}
				grammartag.append(			"</item>").append("\n");
			}			
		}

		grammartag.append("		</one-of>").append("\n");
		grammartag.append("	</rule>").append("\n");
		grammartag.append("</grammar>").append("\n");

		//if no items printed, clear the garmmar tag
		if (!itemPrinted) grammartag = new StringBuffer();
		
		if (testCall)
			LOGGER.trace(new StringBuffer(logToken).append("GarmmarTag content: "
					+ grammartag.toString()));
		try {
			pageContext.getOut().print(grammartag.toString());
		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken).append("GrammarTag Error: ").append(e.getMessage()));
			e.printStackTrace();
		}
		return SKIP_BODY;
	}

	public int doEndTag() {
		return EVAL_PAGE;
	}
	
	private String spacingDTMFString(String dtmf){
		StringBuffer sb = new StringBuffer();
		char s = ' ';
		for(int i=0; i<dtmf.length(); i++){
			char c = dtmf.charAt(i);
			if (c != s){
				sb.append(c).append(" ");
			}
			else continue;
		}
		return sb.toString();
	}

}
