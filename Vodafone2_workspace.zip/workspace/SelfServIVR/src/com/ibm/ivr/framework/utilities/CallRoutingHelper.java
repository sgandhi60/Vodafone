/*
 * Created on Jun 8, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.ivr.framework.utilities;

import java.io.FileOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.Vector;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.SubMenuType;
//import com.ibm.ivr.framework.dao.EmergencyDAO;

/**
 * @author Shailesh Gandhi
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CallRoutingHelper implements Serializable{

	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(CallRoutingHelper.class);

	private Hashtable iCRHashTable = null;

	/**
	 *  
	 */
	public CallRoutingHelper(CallRoutingType iCallRouting) {

		// build a hashtable for all menus for this call routing app
		iCRHashTable = new Hashtable();

		List submenus = iCallRouting.getSubMenu();
		int count = submenus.size();

		for (int i = 0; i < count; i++) {
			String menuName = ((SubMenuType) (submenus.get(i))).getName();
			String mode = ((SubMenuType) (submenus.get(i))).getMode();
			String mNameMode = menuName + mode;
			if (iCRHashTable.containsKey(mNameMode)) {
				LOGGER.warn("Menu: " + menuName + " mode: " + mode
						+ " already exists, will overwrite with new one");
			}
			iCRHashTable.put(mNameMode, ((SubMenuType) (submenus.get(i))));
		}
	}

	/**
	 *  
	 */
	public SubMenuType getMenu(String menuNameMode) {

		return (SubMenuType) iCRHashTable.get(menuNameMode);
	}

	/**
	 * Determines if the center is open, closed or on Holiday
	 * 
	 * @param servletContext
	 *            the servletContext to save the emergency information
	 */
	
//	public static void checkAndLoadEmergencyInfo(ServletContext servletContext)
//			throws Exception {
//		Properties props = (Properties) (servletContext
//				.getAttribute("globalProp"));
//
//		Enumeration enum = props.propertyNames();
//
//		String dataSource = props.getProperty("emergencyDataSource");
//		EmergencyDAO eDao = new EmergencyDAO(dataSource);
//		String extension = props.getProperty("audioFileExtension");
//		Hashtable emergencyTable = new Hashtable();
//
//		while (enum.hasMoreElements()) {
//			String property = enum.nextElement().toString();
//			if (!property.startsWith("emergencyCompany."))
//				continue;
//
//			//parsing out dnis and company value
//			int index = property.indexOf(".");
//			String dnis = property.substring(index + 1);
//			String c = props.getProperty(property);
//
//			//if this company has already being handled, skip
//			if (emergencyTable.get(c) != null)
//				continue;
//
//			String startTime = null;;
//			String endTime = null;
//			String type = null;
//			int msgSize = 0;
//			
//			try {
//				boolean mode = eDao.getEmergencyMode(c);
//				byte[] recording = eDao.getEmergencyMessage(c);
//				startTime = eDao.getEmergencyStartTime(c);
//				endTime = eDao.getEmergencyEndTime(c);
//				
//				//if the type in the database is defined, use it , otherwise the
//				//initial value is from the global properties
//				type = eDao.getEmergencyType(c);
//			    LOGGER.info("[init] emergency type for company: " + c + " is "
//							+ type);
//
//				LOGGER.info("[init] emergency mode for company: " + c + " is "
//						+ mode);
//
//				//save the recording to the local file system to be used by the
//				// Welcome.jsv only if mode is true and it is TYPE1 (type is either null or contains the three digit message number)
//				if (mode && (type == null || type.trim().length() == 0 || type.trim().length() == 3)) {
//					String emergencyMsgFile = servletContext
//							.getRealPath("/audio/Emergency" + c + extension);
//
//					FileOutputStream fos = new FileOutputStream(
//							emergencyMsgFile, false);
//
//					//finding the corresponding intro audio to concatenate the
//					// audio only if there is emergencyMsgLimit
//					byte[] introAudio = Common.findIntroAudio(dnis,
//							servletContext, "InitServlet");
//					if (introAudio == null) {
//						throw new Exception(
//								"failed to fetch introAudio for company: " + c);
//					}
//					int idx1 = 0;
//					int startIndex1 = 0;
//					//strip off the header only
//					if (introAudio.length != 0) {
//						String strContent = new String(introAudio);
//						String matchPattern = "data";
//						idx1 = strContent.indexOf(matchPattern);
//						startIndex1 = idx1 + matchPattern.length() + 4;
//					}
//					
//					//	strip off the header
//					String strContent = new String(recording);
//					String matchPattern = "data";
//					int idx2 = strContent.indexOf(matchPattern);
//					int startIndex2 = idx2 + matchPattern.length() + 4;
//
//					//insert emegency message after greeting
//					String insert = props.getProperty("emergencyMsgInsert");
//					if (insert != null && insert.equalsIgnoreCase("TRUE")){
//						fos.write(introAudio, startIndex1, introAudio.length
//								- startIndex1);
//						msgSize += introAudio.length - startIndex1;
//					
//						fos.write(recording, startIndex2 + 10, recording.length
//								- startIndex2 - 10);
//						
//						msgSize += recording.length - startIndex2 - 10;
//					}else{//insert emergency message before greeting
//						fos.write(recording, startIndex2, recording.length
//								- startIndex2);
//						msgSize += recording.length - startIndex2;				
//						fos.write(introAudio, startIndex1 + 10, introAudio.length
//								- startIndex1 - 10);
//						msgSize += introAudio.length - startIndex1 - 10;
//					}

//					fos.close();
//				}
//				emergencyTable.put(c, new EmergencyInfo(mode, startTime,
//						endTime, type, msgSize));
//
//				LOGGER
//						.info("[init] emergencyInfo loaded successfully for company: "
//								+ c);
//
//			} catch (Exception ex) {
//				emergencyTable.put(c, new EmergencyInfo(false, startTime,
//						endTime, type, msgSize));
//				LOGGER
//						.info("[init] failed to save emergency recording for company: "
//								+ c + "; emergency mode default as false");
//			}
//		}
//
//		servletContext.setAttribute("emergencyTable", emergencyTable);
//	}

	/**
	 * Determines if the center is open, closed or on Holiday
	 * 
	 * @param session
	 *            The session to get the value from
	 * @return "open", "closed" or "holiday"
	 */
	public static String checkHoursOfOperation(HttpSession session) {

		String centerStatus = "open";

		Properties props = (Properties) session.getAttribute("callProp");
		Properties globalProp = (Properties) session.getServletContext()
				.getAttribute("globalProp");
		String timeZone = globalProp.getProperty("timeZone");

		//if callProp is not specified, assume 24x7 operation
		if (props == null)
			return centerStatus;

		CallRoutingType iCallRouting = (CallRoutingType) session
				.getAttribute("iCallRouting");

		String ivrAppName = iCallRouting.getName();

		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		boolean goOn = true;

		String msg = null;
		Vector msgs = new Vector();
		String openHrsSearchStr = null;
		String openHours = null;

		/***********************************************************************
		 * Check if center is open or closed *
		 */
		// check for Holiday date
		Date dateNow = new Date();
		Calendar calNow = null;
		if (timeZone == null)
			calNow = Calendar.getInstance();
		else
			calNow = Calendar.getInstance(TimeZone.getTimeZone(timeZone));

		int hourNow = calNow.get(Calendar.HOUR_OF_DAY);
		int minNow = calNow.get(Calendar.MINUTE);
		int timeToday = (hourNow * 60) + minNow;

		SimpleDateFormat formatterDateTime = new SimpleDateFormat("MMddyyyy");

		int i = 1;
		while (true) {
			String holiday = props.getProperty("holiday" + i + "Date");
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append("holiday")
						.append(i).append("Date:").append(holiday));

			if (holiday == null || holiday.trim().length() == 0)
				break;

			String now = formatterDateTime.format(dateNow);

			if (now.equals(holiday.substring(0, 8))) {
				if (holiday.length() > 8) {
					String dayOfWeek = holiday.substring(0, 8);
					openHours = holiday.substring(9, 13)
							+ holiday.substring(14, 18);
					//reusing the open hours checking logic to check holiday hours
					//if true returned, it really means it is true for holiday
					if (checkOpenHours(timeToday, openHours, dayOfWeek,
							logToken, testCall))
						centerStatus = "holiday";
					else {//false returned, continue to the next holiday property
						i = i + 1;
						continue;
					}

					goOn = false; //skip the business hours checking
					break;
				}
				centerStatus = "holiday";
				goOn = false; //skip the business hours checking
				break;
			}
			i = i + 1;
		} // end holiday checking

		if (centerStatus.equalsIgnoreCase("holiday")){
			String DNIS = (String)session.getAttribute("DNIS");
			//check on the specific DNIS first
			String prompt = props.getProperty("holiday" + i + "Prompt." + DNIS);
			//check only on the date specific
			if (prompt == null || prompt.length() == 0)
				prompt = props.getProperty("holiday" + i + "Prompt");
			//check generic with specific DNIS first
			if (prompt == null || prompt.length() == 0)
				prompt = props.getProperty("holidayPrompt." + DNIS);
			//check generic prompt last
			if (prompt == null || prompt.length() == 0)
				prompt = props.getProperty("holidayPrompt");
			if (prompt == null || prompt.length() == 0)
				session.setAttribute("holidayAudio", "");
			else {
				session.setAttribute("holidayAudio", prompt);
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append("holidayAudio:")
							.append(prompt));
			}
			
		}
		//Check Open/Close time if not a holiday - holiday takes precedence
		//			String[] weekdays =
		//				{
		//					"undefined",
		//					"Sunday",
		//					"Monday",
		//					"Tuesday",
		//					"Wednesday",
		//					"Thursday",
		//					"Friday",
		//					"Saturday" };
		String[] weekdays = { "undefined", "sunday", "weekday", "weekday",
				"weekday", "weekday", "weekday", "saturday" };
		String dayOfWeek = "";

		if (goOn) {
			dayOfWeek = weekdays[calNow.get(Calendar.DAY_OF_WEEK)];

			openHours = null;
			if (ivrAppName != null) {
				openHrsSearchStr = ivrAppName + "." + dayOfWeek + "Hours";
				openHours = props.getProperty(openHrsSearchStr);
			}
			if (openHours == null)
				openHours = props.getProperty(dayOfWeek + "Hours");

			if (openHours != null) {
				openHours = openHours.trim();
			}
			SimpleDateFormat formatterTime = new SimpleDateFormat("kkmm");

			//Debug messages
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"Current Time Zone= ").append(
						TimeZone.getTimeZone(timeZone).getDisplayName()));
				LOGGER.debug(new StringBuffer(logToken)
						.append("CurrentTime = ").append(hourNow).append(":")
						.append(minNow));
				LOGGER.debug(new StringBuffer(logToken).append("DayOfWeek = ")
						.append(dayOfWeek));
				LOGGER.debug(new StringBuffer(logToken).append("OpenHours = ")
						.append(openHours));

			}

			//check the open hours
			if (checkOpenHours(timeToday, openHours, dayOfWeek, logToken,
					testCall))
				centerStatus = "open";
			else
				centerStatus = "closed";
		}

		return centerStatus;

	}

	/**
	 * Determines if the center is open or closed
	 * 
	 * @param timeToday
	 *            current time
	 * @param openHours
	 *            the openHours in HHmmHHmm format
	 * @param dayOfWeek
	 *            the day of week
	 * @param logToken
	 *            the token to be used in log message
	 * @param testCall
	 *            indicates if the current call is a test call
	 * @return true if open, closed otherwise
	 */
	private static boolean checkOpenHours(int timeToday, String openHours,
			String dayOfWeek, String logToken, boolean testCall) {
		boolean open = true;

		boolean goOn = true;
		int openHour = 0;
		int openMinute = 0;
		int openStartTime = 0;
		int closeHour = 0;
		int closeMinute = 0;
		int openStopTime = 0;

		try {

			if (openHours != null && !openHours.equals("")) {

				if (openHours.length() == 8) {
					openHour = Integer.parseInt(openHours.substring(0, 2));
					openMinute = Integer.parseInt(openHours.substring(2, 4));
					if ((openHour > 23) || (openMinute > 59)) {
						LOGGER.warn(new StringBuffer(logToken).append(
								"Invalid Time for ").append(dayOfWeek).append(
								":").append(openHour).append(openMinute));

						if (testCall)
							LOGGER.info(new StringBuffer(logToken)
								.append("Center open (invalid work hours)"));
						goOn = true;
					}
				} else {
					LOGGER.warn(new StringBuffer(logToken)
							.append("Daily hours invalid (not 8 characters)"));

					if (testCall)
						LOGGER.info(new StringBuffer(logToken)
							.append("Center open (daily hours not 8 chars)"));
					goOn = true;
				}
			} else {
				LOGGER.warn(new StringBuffer(logToken)
						.append("Daily hours invalid (blank or null)"));

				if (testCall)
					LOGGER.info(new StringBuffer(logToken)
						.append("Center open(daily hours blank or null)"));
				goOn = true;
			}
			if (goOn) {
				openStartTime = (openHour * 60) + (openMinute);

				closeHour = Integer.parseInt(openHours.substring(4, 6));
				closeMinute = Integer.parseInt(openHours.substring(6, 8));
				if ((closeHour > 23) || (closeMinute > 59)) {
					LOGGER.warn(new StringBuffer(logToken).append(
							"Invalid Time for ").append(dayOfWeek).append(":")
							.append(closeHour).append(closeMinute));

					if (testCall)
						LOGGER.info(new StringBuffer(logToken)
							.append("Center open (invalid work hours)"));
				} else {
					openStopTime = (closeHour * 60) + (closeMinute);
					if ((timeToday >= openStartTime)
							&& (timeToday <= openStopTime)) {
						//LOGGER.info(new StringBuffer(logToken)
						//		.append("Center open"));
						open = true;
					} else {
						open = false;
						//LOGGER.info(new StringBuffer(logToken)
						//		.append("Center closed"));
					}
				}
			}
		} catch (Exception e) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("Error parsing open hours"));
			if (testCall)
				LOGGER.info(new StringBuffer(logToken)
					.append("Center open (parsing exception)"));
		}
		return open;

	}

}
