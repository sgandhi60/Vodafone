/**
 * <copyright>
 * </copyright>
 *
 * $Id: ClosedAudioType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Closed Audio Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.ClosedAudioType#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.ClosedAudioType#getCaching <em>Caching</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.ClosedAudioType#getDir <em>Dir</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.ClosedAudioType#getFetchtimeout <em>Fetchtimeout</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.ClosedAudioType#getTerminate <em>Terminate</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.ClosedAudioType#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType()
 * @model 
 * @generated
 */
public interface ClosedAudioType
{
  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute.
   * @see #setValue(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType_Value()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getValue();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.ClosedAudioType#getValue <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' attribute.
   * @see #getValue()
   * @generated
   */
  void setValue(String value);

  /**
   * Returns the value of the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Caching</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Caching</em>' attribute.
   * @see #setCaching(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType_Caching()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCaching();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.ClosedAudioType#getCaching <em>Caching</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Caching</em>' attribute.
   * @see #getCaching()
   * @generated
   */
  void setCaching(String value);

  /**
   * Returns the value of the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dir</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dir</em>' attribute.
   * @see #setDir(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType_Dir()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDir();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.ClosedAudioType#getDir <em>Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dir</em>' attribute.
   * @see #getDir()
   * @generated
   */
  void setDir(String value);

  /**
   * Returns the value of the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Fetchtimeout</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Fetchtimeout</em>' attribute.
   * @see #setFetchtimeout(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType_Fetchtimeout()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getFetchtimeout();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.ClosedAudioType#getFetchtimeout <em>Fetchtimeout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Fetchtimeout</em>' attribute.
   * @see #getFetchtimeout()
   * @generated
   */
  void setFetchtimeout(String value);

  /**
   * Returns the value of the '<em><b>Terminate</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Terminate</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Terminate</em>' attribute.
   * @see #setTerminate(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType_Terminate()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTerminate();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.ClosedAudioType#getTerminate <em>Terminate</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Terminate</em>' attribute.
   * @see #getTerminate()
   * @generated
   */
  void setTerminate(String value);

  /**
   * Returns the value of the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tts</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tts</em>' attribute.
   * @see #setTts(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getClosedAudioType_Tts()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTts();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.ClosedAudioType#getTts <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tts</em>' attribute.
   * @see #getTts()
   * @generated
   */
  void setTts(String value);

} // ClosedAudioType
