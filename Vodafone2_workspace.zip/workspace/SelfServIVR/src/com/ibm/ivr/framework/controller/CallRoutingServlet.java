package com.ibm.ivr.framework.controller;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.ibm.ivr.framework.model.AudioType;
import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.HangupType;
import com.ibm.ivr.framework.model.MenuDefaultType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.utilities.CallRoutingHelper;
import com.ibm.ivr.framework.utilities.Common;
import com.ibm.ivr.framework.utilities.Reporter;

/**
 * The Core Servlet of IVR Framework
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2004-06-01: initial version
 * <p>
 * 
 * 2007-03-09: 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-09
 *  
 */
public class CallRoutingServlet extends HttpServlet implements Servlet {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(CallRoutingServlet.class);

	/**
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		// Get the classloader for loading resources and classes
		// Use the context classloader to search the servlet path, not the
		// servlet container path
		ClassLoader classloader = Thread.currentThread()
				.getContextClassLoader();

		String nMenuNameMode = null;

		// get session from Servlet request
		HttpSession session = req.getSession(false);

		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC
					.push((String) this.getServletContext().getAttribute(
							"hostName"));

		// retrieve iCallRouting from session
		String dnis = (String) session.getAttribute("DNIS");
		CallRoutingType iCallRouting = (CallRoutingType) session
				.getAttribute("iCallRouting");
		CallRoutingHelper iCRHelper = (CallRoutingHelper) session
				.getAttribute("iCRHelper");

		//get the reporter
		Reporter reporter = (Reporter) this.getServletContext().getAttribute(
				"reporter");
		String appName = iCallRouting.getName();
		//contains GVP call id for VAR reporter
		String gvpCallId = (String) session.getAttribute("gvpCallId");

		SubMenuType subMenu = ((SubMenuType) session.getAttribute("iSubMenu"));

		String callid = (String) req.getAttribute("callid");
		if (callid == null)
			callid = (String) req.getParameter("callid");
		if (callid == null)
			callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken)
				.append("Entering CallRoutingServlet doGet() ..."));

		//check if this is a forwarded request
		boolean forwarded = req.getAttribute("forwarded") != null;

		//check if delay is required
		String delay = null;
		if (forwarded)
			delay = (String) req.getAttribute("delay");
		else
			delay = (String) req.getParameter("delay");

		if (delay != null) {
			try {
				int time = Integer.parseInt(delay);
				//have some buffer to count the time in processing the request
				Thread.sleep(time * 1000 - 500);
			} catch (Exception ex) {
				LOGGER.error(new StringBuffer(logToken).append(
						"parameter delay parsing error: ").append(
						ex.getMessage()));
			}
		}

		//  get menu name/type and mode from request parameters/attributes
		String menuName = null;
		if (forwarded)
			menuName = (String) req.getAttribute("menuName");
		else 
			menuName = (String) req.getParameter("menuName");

		String menuType = null;
		if (forwarded)
			menuType = (String) req.getAttribute("menuType");
		else 
			menuType = (String) req.getParameter("menuType");

		String mode = null;
		if (forwarded)
			mode = (String) req.getAttribute("mode");
		else 
			mode = (String) req.getParameter("mode");
			
		if (testCall)
			LOGGER.info(new StringBuffer(logToken).append("menuName: ").append(
				menuName).append(" menuType: ").append(menuType).append(
				" mode: ").append(mode).append(
				" forwarded: ").append(forwarded));

		try {
			//post processing for the previous menu

			// build and save the call Route info in session
			StringBuffer callRoute = (StringBuffer) session
					.getAttribute("callRoute");
			if (callRoute == null)
				callRoute = new StringBuffer();

			String selection = null;
			if (forwarded)
				selection = (String) req.getAttribute("selection");
			else 
				selection = (String) req.getParameter("selection");

			// this is only logged when subMenu has atttribute markPosition set
			// not as "false", when the attribute is not specified, default as
			// "true"
			// it will be logged no matter what if this is test call
			if (subMenu != null) {
				String markPosition = subMenu.getMarkPosition();
				if (markPosition == null)
					markPosition = Common.TRUE;
				if (!markPosition.equalsIgnoreCase(Common.FALSE) || testCall) {
					if (selection != null) {
						int index = selection.indexOf(Common.COLON);
						if (index != -1) {
							selection = selection.substring(index + 1)
									.replaceAll(" ", "");
						}
					}

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(
								"selection: ").append(selection));

					String modeInSession = (String) session
							.getAttribute("mode");
					if ((selection != null) && (selection.length() != 0)) {
						callRoute.append(selection);
						if (modeInSession.equalsIgnoreCase(Common.SPEECH))
							callRoute.append(Common.SPEECH_MODE);
						else if (modeInSession.equalsIgnoreCase(Common.DTMF))
							callRoute.append(Common.DTMF_MODE);
						else if (modeInSession.equalsIgnoreCase(Common.HYBRID))
							callRoute.append(Common.HYBRID_MODE);
					}
				}
			}
			//get dest from request
			String dest = null;
			if (forwarded)
				dest = (String) req.getAttribute("dest");
			else 
				dest = (String) req.getParameter("dest");

			if (dest != null) {
				Common.parseSessionVarValuePair(dest, session, logToken,
						testCall);
			}

			//set/increment the counter for the parameter if submitted
			String counter = null;
			if (forwarded)
				counter = (String) req.getAttribute("counter");
			else 
				counter = (String) req.getParameter("counter");
			
			counter = Common.evaluateCounterName(counter, session);
			
			if (counter != null && counter.length() != 0) {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"increment counter: ").append(counter));
				}
				String[] counters = counter.split(",");
				for (int i = 0; i < counters.length; i++) {
					String c = counters[i].trim();
					if (c.length() != 0) {
						reporter.callEvent(gvpCallId, appName, c);
					}
				}
			}

			//need to update for forwarding scenario if uncoment
/*			if (subMenu != null && req.getParameter("selection") != null) {
				// TODO: Reconsider the ctrNumber design when the WVR external
				// grammar error is fixed
				// - Design fault - Breaks interface between grammar and rest of
				// app - you can't just drop in working grammar and have it work
				// - Design fault - Each unique combination of menu choices and
				// grammar requires another grammar file - 10 menus = 10 files
				// - Design fault - Only allows 1 menu choice to be matched by a
				// grammar
				// - App maintenance - Uses non-intuitive syntax
				// dtmf="@ctrNumber" instead of dtmf="GrammarFile.grxml"
				// - Framework maintenance - ctrNumber syntax is spread across
				// xml config file, this servlet, and the jsp file, instead of
				// just keeping it contained in the jsp file

				// The selection can be a single digit DTMF or the name of the
				// grammar that matched
				String selection = req.getParameter("selection") != null ? req
						.getParameter("selection") : req.getParameter("choice");

				// The utterance is the user's raw input
				String utterance = req.getParameter("utterance") != null ? req
						.getParameter("utterance") : req.getParameter("choice");

				// Store the value of the user's utterance in a session variable
				session.setAttribute(subMenu.getName(), utterance);
			}
*/
			//get handler from request			
			String handler = (String) req.getParameter("handler");
			if (forwarded)
				handler = (String) req.getAttribute("handler");
			else 
				handler = (String) req.getParameter("handler");

			try {
				if (handler != null && handler.length() > 0) {
					String[] handlers = handler.split(",");
					for (int i = 0; i < handlers.length; i++) {
						//HttpServlet servlet = (HttpServlet) classloader.loadClass(handlers[i].trim()).newInstance();
						//						Calling service should call doGet to be called
						
						HttpServlet servlet = (HttpServlet) Class.forName(handlers[i].trim()).newInstance();
						servlet.service(req, resp);
					}
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}

			//********************************* BEGIN TEST TOOL TESTING HOOK
			// ********************
			//if (menuName == null && choice != null) {
			//	// Choice and MenuDefault should implement the same interface
			//	menuName = (choice instanceof ChoiceType) ? ((ChoiceType) choice)
			//			.getTargetName() : ((MenuDefaultType) choice)
			//			.getTargetName();
			//	menuType = (choice instanceof ChoiceType) ? ((ChoiceType) choice)
			//			.getTargetType() : ((MenuDefaultType) choice)
			//			.getTargetType();
			//	mode = "DTMF";
			//}
			//********************************* END TEST TOOL TESTING HOOK
			// ********************

			//retrieving the next submenu

			//FWQ // if (session.getAttribute("MenuOperator") != null) {
			//remove the flag from session so the incorrect prompt is
			//not played at transfer time for certain situations
			//session.removeAttribute("MenuOperator");
			//}

			if (((menuType != null) && (menuType.equalsIgnoreCase("mainmenu")))
					|| ((menuName != null) && (menuName
							.equalsIgnoreCase(iCallRouting.getMain())))) {

				//clean all necessary session variables when caller returns to
				// main menu
			}

			//	first time invocation, all these fields are NULL
			if (menuName == null && menuType == null && mode == null) {
				// retrieve start menu and mode set by WelcomeServlet
				String startMenu = (String) session.getAttribute("entryMenu");
				String startMode = (String) session.getAttribute("mode");

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"startMenu: ").append(startMenu));
					LOGGER.debug(new StringBuffer(logToken).append(
							"startMode: ").append(startMode));
				}

				// check start menu and mode
				if (startMenu != null && startMenu.length() != 0) {
					mode = startMode;
					menuName = startMenu;
					menuType = "submenu";
					nMenuNameMode = startMenu + startMode;
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(
								"MenuNameMode: ").append(nMenuNameMode));
					}
					subMenu = iCRHelper.getMenu(nMenuNameMode);
				} else {
					throw new ServletException(
							"StartMenu is NOT defined in xml file");
				}
			}
			//  subsequent invocation
			else {
				// retrieve currentMenu from session to compare
				// with entry menu to decide
				// the next menu in case the caller has decided
				// to go back pressing dtmf key *
				// HOW TO DETECT IT IS GOBACK SENARIO INSTEAD OF FIRST VISIT
				//String goBackFromMenu = subMenu.getName();
				//if ((goBackFromMenu != null) && (goBackFromMenu.length() !=
				// 0)) {
				//	if (goBackFromMenu.equalsIgnoreCase((String) session
				//			.getAttribute("entryMenu"))) {
				//		menuName = goBackFromMenu;
				//	}
				//}

				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"mode from request: ").append(mode));

				if ((mode != null) && (mode.length() != 0)) {
					//if mode is submitted and different than the current value
					// in the session
					if (!(mode.equalsIgnoreCase((String) session
							.getAttribute("mode"))))
						session.setAttribute("mode", mode);
				} else {
					//if mode is not submitted or empty string, get the mode
					// from session
					mode = (String) session.getAttribute("mode");
				}

				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"mode from session: ").append(mode));

				if (menuType.equalsIgnoreCase("mainmenu")) {
					// modiifed to support the called IVR app support
					String entryMenu = (String) session
							.getAttribute("entryMenu");
					String startMenu = iCallRouting.getStart();
					if (entryMenu.equalsIgnoreCase(startMenu)) {
						menuName = iCallRouting.getMain();
					} else {
						menuName = entryMenu;
					}
				}

				nMenuNameMode = menuName + mode;
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"MenuNameMode: ").append(nMenuNameMode));
				subMenu = iCRHelper.getMenu(nMenuNameMode);

				//if the current mode is hybrid and corresponding submenu does
				//not exist, try the speech version first, then DTMF version
				if (mode.equalsIgnoreCase("hybrid") && subMenu == null) {
					subMenu = iCRHelper.getMenu(menuName + "speech");
					if (subMenu == null) {
						subMenu = iCRHelper.getMenu(menuName + "DTMF");
						mode = "DTMF";
					} else {
						mode = "speech";
					}
					session.setAttribute("mode", mode);
				}

				//if the current mode is DTMF and corresponding submenu does
				//not exist, try the hybrid version
				if (mode.equalsIgnoreCase("DTMF") && subMenu == null) {
					subMenu = iCRHelper.getMenu(menuName + "hybrid");
					if (subMenu != null) {
						mode = "hybrid";
					}
					session.setAttribute("mode", mode);
				}
			}

			if (subMenu == null) {
				throw new ServletException("subMenu for " + menuName
						+ " in mode " + mode + " is not configured");
			}

			// set current position of caller as menuname in the session for
			// later use to log at Hangup time for statistic report
			// this is only logged when subMenu has atttribute markPosition set
			// not as "false"
			// when the attribute is not specified, default as "true"
			String markPosition = subMenu.getMarkPosition();
			if (markPosition == null)
				markPosition = Common.TRUE;
			if (menuName != null
					&& markPosition.equalsIgnoreCase(Common.TRUE)) {
				session.setAttribute("currentPos", menuName);

				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"CurrentPos: ").append(menuName));
			}

			// this is only logged when subMenu has atttribute markPosition set
			// not as "false", when the attribute is not specified, default as
			// "true"
			// it will be logged no matter what if this is test call
			if (!markPosition.equalsIgnoreCase(Common.FALSE) || testCall) {
				if (callRoute.length() != 0)
					callRoute.append(Common.SEPARATOR);
				callRoute.append(menuName).append(Common.COLON);
			}

			session.setAttribute("callRoute", callRoute);

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append("callRoute: ")
						.append(callRoute));

			// store menu in session
			session.setAttribute("iSubMenu", subMenu);

			// pre-processing the session variable for submenu
			String set = subMenu.getSet();
			if (set != null) {
				Common.parseSessionVarValuePair(set, session, logToken,
						testCall);
			}

			//set/increment the counter for the submenu if specified
			counter = subMenu.getCounter();
			counter = Common.evaluateCounterName(counter, session);
			if (counter != null && counter.length() != 0) {
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"increment counter: ").append(counter));
				}
				String[] counters = counter.split(",");
				for (int i = 0; i < counters.length; i++) {
					String c = counters[i].trim();
					if (c.length() != 0) {
						if (c.length() != 0) {
							reporter.callEvent(gvpCallId, appName, c);
						}
					}
				}
			}

			//check the special counter associated with EventType
			EventsType events = subMenu.getEvents();
			//if not defined at the submenu, get fromt top level
			if (events == null)
				events = iCallRouting.getEvents();
			StringBuffer counterSB = new StringBuffer();

			if (events != null) {
				List hangups = events.getHangup();
				if (hangups != null) {
					for (int i = 0; i < hangups.size(); i++) {
						HangupType hangup = (HangupType) hangups.get(i);
						String c = hangup.getCond();
						boolean result = true;
						if (c != null && c.length() != 0) {
							result = Common.conditionsMatch(c, session,
									logToken);
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(
										"Events.Hangup cond: [" + c).append(
										"] evaluated as: ").append(result));
						}
						//only if cond is true or not specified
						if (result) {
							String ctr = hangup.getCounter();
							if (ctr != null && ctr.length() != 0) {
								counterSB.append(Common.evaluateCounterName(ctr, session)).append(",");
							}
						}
					}
				}
			}
			//set into request attribute for jsv to use
			if (counterSB.length() > 0)
				req.setAttribute("hangupCounter", counterSB.toString());

			String nextPage = null;

			String subMenuType = subMenu.getType_();
			if (mode.equalsIgnoreCase("hybrid"))
				nextPage = "/jsp/" + getInitParameter("HybridPage");
			if (mode.equalsIgnoreCase("speech"))
				nextPage = "/jsp/" + getInitParameter("SpeechPage");
			if (mode.equalsIgnoreCase("DTMF"))
				nextPage = "/jsp/" + getInitParameter("DTMFPage");

			//			special menu types need to be handled here
			boolean forward = false;
			if ((subMenuType != null)) {
				if (subMenuType.equalsIgnoreCase("PromptPlay")) {
					List audios = subMenu.getAudio();
					if (audios == null || audios.isEmpty())
						forward = true;
					else {
						forward = true;
						for(int i = 0; i < audios.size(); i++) {
							AudioType audio = (AudioType) audios.get(i);
							//check the cond of the Audio, if true, no need to continue
							String cond = audio.getCond();
							boolean condResult = true;
							if (cond != null && cond.length() != 0) {
								condResult = Common
										.conditionsMatch(cond, session, logToken);
								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(
											"AudioTag cond: [" + cond).append(
											"] evaluated as: ").append(condResult));
								if (condResult) {
									forward = false;
									break;
								}
							}
							else {
								forward = false;
								break;
							}
						}	
						if (forward == false)
							nextPage = "/jsp/" + getInitParameter("PromptPage");
					}
				} else if (subMenuType.equalsIgnoreCase("BusinessLogic"))
					forward = true;
				else if (subMenuType.equalsIgnoreCase("Record")) {
					if (mode.equalsIgnoreCase("hybrid"))
						nextPage = "/jsp/"
								+ getInitParameter("RecordHybridPage");
					if (mode.equalsIgnoreCase("speech"))
						nextPage = "/jsp/"
								+ getInitParameter("RecordSpeechPage");
					if (mode.equalsIgnoreCase("DTMF"))
						nextPage = "/jsp/" + getInitParameter("RecordDTMFPage");
				}
			}

			//if need to forward to CallRoutingServlet, clean request
			// attributes and set the right ones to be
			//used for the servlet in the chain
			if (forward) {

				//cleaning out all request attributes
//				Enumeration enum = req.getAttributeNames();
//				while (enum.hasMoreElements()) {
//					req.removeAttribute(enum.nextElement().toString());
//				}

				//set the attributes used by next callroutingservlet
				//mimic similar logic in routing tag (only MenuDefault needs to be considered)
				req.setAttribute("forwarded", "TRUE");
				List menuDefaults = subMenu.getMenuDefault();
				MenuDefaultType md = null;
				for (int i = 0; i < menuDefaults.size(); i++) {
					String cond = ((MenuDefaultType) (menuDefaults.get(i))).getCond();
					String tempDnis = ((MenuDefaultType) (menuDefaults.get(i))).getDnis();
					boolean condResult = true;
					if (cond != null && cond.length() != 0) {
						condResult = Common
								.conditionsMatch(cond, session, logToken);
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(
									"cond: [" + cond).append(
									"] evaluated as: ").append(condResult));
					}
					if (condResult) {
						String callDnis = (String) session.getAttribute("DNIS");
						if (callDnis != null) {
							if (tempDnis != null) {
								if (tempDnis.indexOf(callDnis) >= 0) {
									md = ((MenuDefaultType) (menuDefaults.get(i)));
									break;
								}
							} else {
								md = ((MenuDefaultType) (menuDefaults.get(i)));
								break;
							}
						} else {
							if (tempDnis == null) {
								md = ((MenuDefaultType) (menuDefaults.get(i)));
								break;
							}
						}
					}
				}
							
				//forward to CallRoutingServlet
				if (md.getTargetType().equalsIgnoreCase("submenu")){
					nextPage = "/CallRoutingServlet";
					
					req.setAttribute("menuName", evaluate(md.getTargetName(), session));
					req.setAttribute("menuType", "submenu");
					req.setAttribute("menuMode", md.getTargetMode());
					req.setAttribute("dest", evaluate(md.getDest(), session));
					req.setAttribute("counter", md.getCounter());
					req.setAttribute("handler", md.getHandler());
				}
				//forward to TransferServlet
				else if (md.getTargetType().equalsIgnoreCase("agent") || md.getTargetType().equalsIgnoreCase("ctiagent")
						||  md.getTargetType().equalsIgnoreCase("ctiagentdirect")){
					nextPage = "/TransferServlet";
					
					req.setAttribute("counter", md.getCounter());
					req.setAttribute("handler", md.getHandler());
					
					//store the current time in session as the time, this call was transferred
					Date ssReportCallEndXfer = new Date();
					session.setAttribute("ssReportCallEndXfer",ssReportCallEndXfer);				

					//evaluating dest
					Properties globalProp = (Properties) this.getServletContext().getAttribute("globalProp");
					String destType = md.getDestType();
					if (destType != null) {
						if (destType.equalsIgnoreCase("operator")) {
							if (testCall)
								LOGGER.info(new StringBuffer(logToken).append(
									"transfer dest: ").append(
									iCallRouting.getOperator()));
							dest = iCallRouting.getOperator().getValue();
						} else {
							if (destType.startsWith("$")) {//take the session var value
								dest = (String)Common.getSessionValue(destType.substring(1), session);
							} else {//take the property value
								//if the destType is not in callProp, then take it
								// from globalProp
								Properties callProp = (Properties) session
										.getAttribute("callProp");
								if (callProp == null
										|| callProp.get(destType.toUpperCase()) == null) {
									dest = (String) globalProp.get(destType
											.toUpperCase());
								} else {
									dest = (String) callProp.get(destType
											.toUpperCase());
								}
							}
						}

					} else {
						String key = dest;

						// build search string using dest field of xml and
						// target name
						// starts from the finest one then move to more generic
						// ones if
						// no numbers found on more specific target
						String value = null;
						while (key != null) {
							value = (String) globalProp.get(key);
							if (value != null && value.length() != 0)
								break;
							int i = key.lastIndexOf(".");
							if (i == -1)
								break;
							key = key.substring(0, i);
						}

						if (value != null && value.length() != 0) {
							dest = value;
						} else {
							dest = "";
						}
					}
					req.setAttribute("dest", evaluate(dest, session));
					req.setAttribute("reason", evaluate(md.getTargetName(), session));
					req.setAttribute("agentType", md.getTargetType());
					req.setAttribute("audio", evaluate(md.getTargetAudio(), session));
					req.setAttribute("tts", evaluate(md.getTts(), session));
					req.setAttribute("ctiEnabled", (String) session.getAttribute("ctiEnabled"));

				}
				else {
					throw new Exception("Unsupported Target Type: " + md.getTargetType());
				}
			}

			//for coming back to the same menu when diversed to other servlets
			String returnURL = req.getContextPath()
					+ "/CallRoutingServlet?menuType=" + menuType
					+ "&amp;menuName=" + menuName;
			req.setAttribute("returnURL", returnURL);

			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving CallRoutingServlet... nextPage: ").append(
						nextPage));
			dispatch.forward(req, resp);

		} catch (Exception ex) {
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(ex.getMessage()), ex);

			session.setAttribute("errorLogged", new Boolean(true));

			String nextPage = "/jsp/"
					+ (getInitParameter("errorPage") == null ? "Error.jsv"
							: getInitParameter("errorPage"));

			req.setAttribute("lastError", ex.toString());

			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving CallRoutingServlet... nextPage: ").append(
						nextPage));
			dispatch.forward(req, resp);
		}
		NDC.remove();
	}

	/**
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		// get session from Servlet request
		HttpSession session = req.getSession(false);

		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC
					.push((String) this.getServletContext().getAttribute(
							"hostName"));

		String callid = (String) req.getAttribute("callid");
		if (callid == null)
			callid = (String) req.getParameter("callid");
		if (callid == null)
			callid = (String) session.getAttribute("callid");

		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken)
				.append("Entering CallRoutingServlet doPost() ..."));

		try {
			parseRequest(req, logToken, testCall);
			//if recording saved successfully, continue the call flow
			req.setAttribute("forwarded", "TRUE");
			doGet(req, resp);
		} catch (Exception ex) {
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(ex.getMessage()), ex);

			session.setAttribute("errorLogged", new Boolean(true));

			String nextPage = "/jsp/"
					+ (getInitParameter("errorPage") == null ? "Error.jsv"
							: getInitParameter("errorPage"));
			req.setAttribute("lastError", ex.toString());
			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving CallRoutingServlet... nextPage: ").append(
						nextPage));
			dispatch.forward(req, resp);
		}
		NDC.remove();
	}

	/**
	 * Parse the multi-part request and set the parts into the request as
	 * attributes including the audio content set as recording=byte[]
	 * 
	 * @param request
	 * @param logToken
	 * @param testCall
	 * @throws IOException
	 */
	private void parseRequest(HttpServletRequest request, String logToken,
			boolean testCall) throws Exception {

		//		 Create a factory for disk-based file items
		DiskFileItemFactory factory = new DiskFileItemFactory();

		//		 Set factory constraints
		factory.setSizeThreshold(1000000);

		//		 Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);

		//		 Set overall request size constraint
		upload.setSizeMax(1000000L);

		try {
			//		 Parse the request
			List items = upload.parseRequest(request);

			//	Process the uploaded items
			Iterator iter = items.iterator();
			while (iter.hasNext()) {
				FileItem item = (FileItem) iter.next();

				//					 Process a regular form field
				if (item.isFormField()) {
					String name = item.getFieldName();
					String value = item.getString();

					if (testCall)
						LOGGER.debug(new StringBuffer(logToken)
								.append("name: ").append(name)
								.append(" value:").append(value));

					request.setAttribute(name, value);
				} else {
					String fieldName = item.getFieldName();
					String fileName = item.getName();
					String contentType = item.getContentType();
					boolean isInMemory = item.isInMemory();
					if (!isInMemory)
						LOGGER
								.warn(new StringBuffer(logToken)
										.append("recording is saved temporarily on disk"));
					long sizeInBytes = item.getSize();

					request.setAttribute("recording", item.get());
					if (testCall)
						LOGGER
								.debug(new StringBuffer(logToken)
										.append(
												"recording set into request with number of bytes: ")
										.append(sizeInBytes));
				}
			}

		} catch (Exception ex) {
			throw new Exception("failed to parse submitted recording: "
					+ ex.getMessage());
		}
	}


	/**
	 * Evaluate the string as literal string or session variable
	 * 
	 * @param var
	 *            literal string or session variable (starting with $)
	 * @param session
	 * 			  HttpSession to retrieve session value
	 * @return the value of session variable or literal string, null if not
	 *         found in session
	 * @throws Exception
	 */
	private Object evaluate(String var, HttpSession session) throws Exception {
		Object value = null;

		if (var != null && var.startsWith("$")) {
			value = Common.getSessionValue(var.substring(1), session);
			if (value == null)
				throw new Exception("session variable " + var.substring(1)
						+ " is not available");
			else
				return value;
		} else {
			return var;
		}
	}
}
