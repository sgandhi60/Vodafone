/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelAdapterFactory.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.util;

import com.ibm.ivr.framework.model.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see com.ibm.ivr.framework.model.ModelPackage
 * @generated
 */
public class ModelAdapterFactory extends AdapterFactoryImpl
{
  /**
   * The cached model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static ModelPackage modelPackage;

  /**
   * Creates an instance of the adapter factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModelAdapterFactory()
  {
    if (modelPackage == null)
    {
      modelPackage = ModelPackage.eINSTANCE;
    }
  }

  /**
   * Returns whether this factory is applicable for the type of the object.
   * <!-- begin-user-doc -->
   * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
   * <!-- end-user-doc -->
   * @return whether this factory is applicable for the type of the object.
   * @generated
   */
  public boolean isFactoryForType(Object object)
  {
    if (object == modelPackage)
    {
      return true;
    }
    if (object instanceof EObject)
    {
      return ((EObject)object).eClass().getEPackage() == modelPackage;
    }
    return false;
  }

  /**
   * The switch the delegates to the <code>createXXX</code> methods.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ModelSwitch modelSwitch =
    new ModelSwitch()
    {
      public Object caseAudioConfirmType(AudioConfirmType object)
      {
        return createAudioConfirmTypeAdapter();
      }
      public Object caseAudioType(AudioType object)
      {
        return createAudioTypeAdapter();
      }
      public Object caseCallRoutingType(CallRoutingType object)
      {
        return createCallRoutingTypeAdapter();
      }
      public Object caseChoiceType(ChoiceType object)
      {
        return createChoiceTypeAdapter();
      }
      public Object caseClosedAudioType(ClosedAudioType object)
      {
        return createClosedAudioTypeAdapter();
      }
      public Object caseDefaultRoutingType(DefaultRoutingType object)
      {
        return createDefaultRoutingTypeAdapter();
      }
      public Object caseDocumentRoot(DocumentRoot object)
      {
        return createDocumentRootAdapter();
      }
      public Object caseEventHandlersType(EventHandlersType object)
      {
        return createEventHandlersTypeAdapter();
      }
      public Object caseEventsType(EventsType object)
      {
        return createEventsTypeAdapter();
      }
      public Object caseGrammarType(GrammarType object)
      {
        return createGrammarTypeAdapter();
      }
      public Object caseHangupType(HangupType object)
      {
        return createHangupTypeAdapter();
      }
      public Object caseHelpType(HelpType object)
      {
        return createHelpTypeAdapter();
      }
      public Object caseHolidayAudioType(HolidayAudioType object)
      {
        return createHolidayAudioTypeAdapter();
      }
      public Object caseInputErrorType(InputErrorType object)
      {
        return createInputErrorTypeAdapter();
      }
      public Object caseIntroAudioType(IntroAudioType object)
      {
        return createIntroAudioTypeAdapter();
      }
      public Object caseMenuDefaultType(MenuDefaultType object)
      {
        return createMenuDefaultTypeAdapter();
      }
      public Object caseMenuOperatorType(MenuOperatorType object)
      {
        return createMenuOperatorTypeAdapter();
      }
      public Object caseNoInputType(NoInputType object)
      {
        return createNoInputTypeAdapter();
      }
      public Object caseNoMatchType(NoMatchType object)
      {
        return createNoMatchTypeAdapter();
      }
      public Object caseOperatorType(OperatorType object)
      {
        return createOperatorTypeAdapter();
      }
      public Object caseOutroAudioType(OutroAudioType object)
      {
        return createOutroAudioTypeAdapter();
      }
      public Object caseSubMenuType(SubMenuType object)
      {
        return createSubMenuTypeAdapter();
      }
      public Object caseTransferAudioType(TransferAudioType object)
      {
        return createTransferAudioTypeAdapter();
      }
      public Object caseTransferType(TransferType object)
      {
        return createTransferTypeAdapter();
      }
      public Object defaultCase(EObject object)
      {
        return createEObjectAdapter();
      }
    };

  /**
   * Creates an adapter for the <code>target</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param target the object to adapt.
   * @return the adapter for the <code>target</code>.
   * @generated
   */
  public Adapter createAdapter(Notifier target)
  {
    return (Adapter)modelSwitch.doSwitch((EObject)target);
  }


  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.AudioConfirmType <em>Audio Confirm Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.AudioConfirmType
   * @generated
   */
  public Adapter createAudioConfirmTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.AudioType <em>Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.AudioType
   * @generated
   */
  public Adapter createAudioTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.CallRoutingType <em>Call Routing Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.CallRoutingType
   * @generated
   */
  public Adapter createCallRoutingTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.ChoiceType <em>Choice Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.ChoiceType
   * @generated
   */
  public Adapter createChoiceTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.ClosedAudioType <em>Closed Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.ClosedAudioType
   * @generated
   */
  public Adapter createClosedAudioTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.DefaultRoutingType <em>Default Routing Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.DefaultRoutingType
   * @generated
   */
  public Adapter createDefaultRoutingTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.DocumentRoot <em>Document Root</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.DocumentRoot
   * @generated
   */
  public Adapter createDocumentRootAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.EventHandlersType <em>Event Handlers Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.EventHandlersType
   * @generated
   */
  public Adapter createEventHandlersTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.EventsType <em>Events Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.EventsType
   * @generated
   */
  public Adapter createEventsTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.GrammarType <em>Grammar Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.GrammarType
   * @generated
   */
  public Adapter createGrammarTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.HangupType <em>Hangup Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.HangupType
   * @generated
   */
  public Adapter createHangupTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.HelpType <em>Help Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.HelpType
   * @generated
   */
  public Adapter createHelpTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.HolidayAudioType <em>Holiday Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.HolidayAudioType
   * @generated
   */
  public Adapter createHolidayAudioTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.InputErrorType <em>Input Error Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.InputErrorType
   * @generated
   */
  public Adapter createInputErrorTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.IntroAudioType <em>Intro Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.IntroAudioType
   * @generated
   */
  public Adapter createIntroAudioTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.MenuDefaultType <em>Menu Default Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.MenuDefaultType
   * @generated
   */
  public Adapter createMenuDefaultTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.MenuOperatorType <em>Menu Operator Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.MenuOperatorType
   * @generated
   */
  public Adapter createMenuOperatorTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.NoInputType <em>No Input Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.NoInputType
   * @generated
   */
  public Adapter createNoInputTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.NoMatchType <em>No Match Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.NoMatchType
   * @generated
   */
  public Adapter createNoMatchTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.OperatorType <em>Operator Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.OperatorType
   * @generated
   */
  public Adapter createOperatorTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.OutroAudioType <em>Outro Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.OutroAudioType
   * @generated
   */
  public Adapter createOutroAudioTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.SubMenuType <em>Sub Menu Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.SubMenuType
   * @generated
   */
  public Adapter createSubMenuTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.TransferAudioType <em>Transfer Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.TransferAudioType
   * @generated
   */
  public Adapter createTransferAudioTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.ivr.framework.model.TransferType <em>Transfer Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.ivr.framework.model.TransferType
   * @generated
   */
  public Adapter createTransferTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for the default case.
   * <!-- begin-user-doc -->
   * This default implementation returns null.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @generated
   */
  public Adapter createEObjectAdapter()
  {
    return null;
  }

} //ModelAdapterFactory
