/**
 * <copyright>
 * </copyright>
 *
 * $Id: DocumentRootImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.AudioConfirmType;
import com.ibm.ivr.framework.model.AudioType;
import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.ChoiceType;
import com.ibm.ivr.framework.model.ClosedAudioType;
import com.ibm.ivr.framework.model.DefaultRoutingType;
import com.ibm.ivr.framework.model.DocumentRoot;
import com.ibm.ivr.framework.model.EventHandlersType;
import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.GrammarType;
import com.ibm.ivr.framework.model.HangupType;
import com.ibm.ivr.framework.model.HelpType;
import com.ibm.ivr.framework.model.HolidayAudioType;
import com.ibm.ivr.framework.model.InputErrorType;
import com.ibm.ivr.framework.model.IntroAudioType;
import com.ibm.ivr.framework.model.MenuDefaultType;
import com.ibm.ivr.framework.model.MenuOperatorType;
import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.NoInputType;
import com.ibm.ivr.framework.model.NoMatchType;
import com.ibm.ivr.framework.model.OperatorType;
import com.ibm.ivr.framework.model.OutroAudioType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.model.TransferAudioType;
import com.ibm.ivr.framework.model.TransferType;

import commonj.sdo.Sequence;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EMap;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EStringToStringMapEntryImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.sdo.util.BasicESequence;
import org.eclipse.emf.ecore.sdo.util.ESequence;

import org.eclipse.emf.ecore.util.BasicFeatureMap;
import org.eclipse.emf.ecore.util.EcoreEMap;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Document Root</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getMixed <em>Mixed</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getXSISchemaLocation <em>XSI Schema Location</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getAudio <em>Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getAudioConfirm <em>Audio Confirm</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getCallRouting <em>Call Routing</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getChoice <em>Choice</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getClosedAudio <em>Closed Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getDefaultRouting <em>Default Routing</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getEventHandlers <em>Event Handlers</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getEvents <em>Events</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getGrammar <em>Grammar</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getHangup <em>Hangup</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getHelp <em>Help</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getHolidayAudio <em>Holiday Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getInputError <em>Input Error</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getIntroAudio <em>Intro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getMenuDefault <em>Menu Default</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getMenuOperator <em>Menu Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getNoInput <em>No Input</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getNoMatch <em>No Match</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getOperator <em>Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getOutroAudio <em>Outro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getSubMenu <em>Sub Menu</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getTransfer <em>Transfer</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl#getTransferAudio <em>Transfer Audio</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DocumentRootImpl extends EDataObjectImpl implements DocumentRoot
{
  /**
   * The cached value of the '{@link #getMixed() <em>Mixed</em>}' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMixed()
   * @generated
   * @ordered
   */
  protected ESequence mixed = null;

  /**
   * The cached value of the '{@link #getXMLNSPrefixMap() <em>XMLNS Prefix Map</em>}' map.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getXMLNSPrefixMap()
   * @generated
   * @ordered
   */
  protected EMap xMLNSPrefixMap = null;

  /**
   * The cached value of the '{@link #getXSISchemaLocation() <em>XSI Schema Location</em>}' map.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getXSISchemaLocation()
   * @generated
   * @ordered
   */
  protected EMap xSISchemaLocation = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected DocumentRootImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getDocumentRoot();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Sequence getMixed()
  {
    if (mixed == null)
    {
      mixed = new BasicESequence(new BasicFeatureMap(this, ModelPackage.DOCUMENT_ROOT__MIXED));
    }
    return mixed;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Map getXMLNSPrefixMap()
  {
    if (xMLNSPrefixMap == null)
    {
      xMLNSPrefixMap = new EcoreEMap(EcorePackage.eINSTANCE.getEStringToStringMapEntry(), EStringToStringMapEntryImpl.class, this, ModelPackage.DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
    }
    return xMLNSPrefixMap.map();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Map getXSISchemaLocation()
  {
    if (xSISchemaLocation == null)
    {
      xSISchemaLocation = new EcoreEMap(EcorePackage.eINSTANCE.getEStringToStringMapEntry(), EStringToStringMapEntryImpl.class, this, ModelPackage.DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
    }
    return xSISchemaLocation.map();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AudioType getAudio()
  {
    return (AudioType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Audio(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetAudio(AudioType newAudio, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Audio(), newAudio, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAudio(AudioType newAudio)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Audio(), newAudio);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AudioConfirmType getAudioConfirm()
  {
    return (AudioConfirmType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_AudioConfirm(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetAudioConfirm(AudioConfirmType newAudioConfirm, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_AudioConfirm(), newAudioConfirm, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAudioConfirm(AudioConfirmType newAudioConfirm)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_AudioConfirm(), newAudioConfirm);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CallRoutingType getCallRouting()
  {
    return (CallRoutingType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_CallRouting(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetCallRouting(CallRoutingType newCallRouting, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_CallRouting(), newCallRouting, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCallRouting(CallRoutingType newCallRouting)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_CallRouting(), newCallRouting);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ChoiceType getChoice()
  {
    return (ChoiceType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Choice(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetChoice(ChoiceType newChoice, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Choice(), newChoice, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setChoice(ChoiceType newChoice)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Choice(), newChoice);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ClosedAudioType getClosedAudio()
  {
    return (ClosedAudioType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_ClosedAudio(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetClosedAudio(ClosedAudioType newClosedAudio, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_ClosedAudio(), newClosedAudio, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setClosedAudio(ClosedAudioType newClosedAudio)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_ClosedAudio(), newClosedAudio);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DefaultRoutingType getDefaultRouting()
  {
    return (DefaultRoutingType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_DefaultRouting(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetDefaultRouting(DefaultRoutingType newDefaultRouting, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_DefaultRouting(), newDefaultRouting, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDefaultRouting(DefaultRoutingType newDefaultRouting)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_DefaultRouting(), newDefaultRouting);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventHandlersType getEventHandlers()
  {
    return (EventHandlersType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_EventHandlers(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEventHandlers(EventHandlersType newEventHandlers, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_EventHandlers(), newEventHandlers, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEventHandlers(EventHandlersType newEventHandlers)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_EventHandlers(), newEventHandlers);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventsType getEvents()
  {
    return (EventsType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Events(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEvents(EventsType newEvents, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Events(), newEvents, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEvents(EventsType newEvents)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Events(), newEvents);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GrammarType getGrammar()
  {
    return (GrammarType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Grammar(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetGrammar(GrammarType newGrammar, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Grammar(), newGrammar, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGrammar(GrammarType newGrammar)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Grammar(), newGrammar);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HangupType getHangup()
  {
    return (HangupType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Hangup(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHangup(HangupType newHangup, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Hangup(), newHangup, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHangup(HangupType newHangup)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Hangup(), newHangup);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HelpType getHelp()
  {
    return (HelpType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Help(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHelp(HelpType newHelp, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Help(), newHelp, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHelp(HelpType newHelp)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Help(), newHelp);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HolidayAudioType getHolidayAudio()
  {
    return (HolidayAudioType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_HolidayAudio(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHolidayAudio(HolidayAudioType newHolidayAudio, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_HolidayAudio(), newHolidayAudio, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHolidayAudio(HolidayAudioType newHolidayAudio)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_HolidayAudio(), newHolidayAudio);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputErrorType getInputError()
  {
    return (InputErrorType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_InputError(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputError(InputErrorType newInputError, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_InputError(), newInputError, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputError(InputErrorType newInputError)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_InputError(), newInputError);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IntroAudioType getIntroAudio()
  {
    return (IntroAudioType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_IntroAudio(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetIntroAudio(IntroAudioType newIntroAudio, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_IntroAudio(), newIntroAudio, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIntroAudio(IntroAudioType newIntroAudio)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_IntroAudio(), newIntroAudio);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MenuDefaultType getMenuDefault()
  {
    return (MenuDefaultType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_MenuDefault(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetMenuDefault(MenuDefaultType newMenuDefault, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_MenuDefault(), newMenuDefault, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMenuDefault(MenuDefaultType newMenuDefault)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_MenuDefault(), newMenuDefault);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MenuOperatorType getMenuOperator()
  {
    return (MenuOperatorType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_MenuOperator(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetMenuOperator(MenuOperatorType newMenuOperator, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_MenuOperator(), newMenuOperator, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMenuOperator(MenuOperatorType newMenuOperator)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_MenuOperator(), newMenuOperator);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NoInputType getNoInput()
  {
    return (NoInputType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_NoInput(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetNoInput(NoInputType newNoInput, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_NoInput(), newNoInput, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setNoInput(NoInputType newNoInput)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_NoInput(), newNoInput);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NoMatchType getNoMatch()
  {
    return (NoMatchType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_NoMatch(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetNoMatch(NoMatchType newNoMatch, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_NoMatch(), newNoMatch, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setNoMatch(NoMatchType newNoMatch)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_NoMatch(), newNoMatch);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OperatorType getOperator()
  {
    return (OperatorType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Operator(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOperator(OperatorType newOperator, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Operator(), newOperator, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOperator(OperatorType newOperator)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Operator(), newOperator);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutroAudioType getOutroAudio()
  {
    return (OutroAudioType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_OutroAudio(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutroAudio(OutroAudioType newOutroAudio, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_OutroAudio(), newOutroAudio, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutroAudio(OutroAudioType newOutroAudio)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_OutroAudio(), newOutroAudio);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SubMenuType getSubMenu()
  {
    return (SubMenuType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_SubMenu(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetSubMenu(SubMenuType newSubMenu, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_SubMenu(), newSubMenu, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSubMenu(SubMenuType newSubMenu)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_SubMenu(), newSubMenu);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransferType getTransfer()
  {
    return (TransferType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_Transfer(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTransfer(TransferType newTransfer, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_Transfer(), newTransfer, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransfer(TransferType newTransfer)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_Transfer(), newTransfer);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransferAudioType getTransferAudio()
  {
    return (TransferAudioType)((ESequence)getMixed()).featureMap().get(ModelPackage.eINSTANCE.getDocumentRoot_TransferAudio(), true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTransferAudio(TransferAudioType newTransferAudio, NotificationChain msgs)
  {
    return ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).basicAdd(ModelPackage.eINSTANCE.getDocumentRoot_TransferAudio(), newTransferAudio, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransferAudio(TransferAudioType newTransferAudio)
  {
    ((FeatureMap.Internal)((ESequence)getMixed()).featureMap()).set(ModelPackage.eINSTANCE.getDocumentRoot_TransferAudio(), newTransferAudio);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs)
  {
    if (featureID >= 0)
    {
      switch (eDerivedStructuralFeatureID(featureID, baseClass))
      {
        case ModelPackage.DOCUMENT_ROOT__MIXED:
        return ((InternalEList)((ESequence)getMixed()).featureMap()).basicRemove(otherEnd, msgs);
        case ModelPackage.DOCUMENT_ROOT__XMLNS_PREFIX_MAP:
          return ((InternalEList)((EMap.InternalMapView)getXMLNSPrefixMap()).eMap()).basicRemove(otherEnd, msgs);
        case ModelPackage.DOCUMENT_ROOT__XSI_SCHEMA_LOCATION:
          return ((InternalEList)((EMap.InternalMapView)getXSISchemaLocation()).eMap()).basicRemove(otherEnd, msgs);
        case ModelPackage.DOCUMENT_ROOT__AUDIO:
          return basicSetAudio(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__AUDIO_CONFIRM:
          return basicSetAudioConfirm(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__CALL_ROUTING:
          return basicSetCallRouting(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__CHOICE:
          return basicSetChoice(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__CLOSED_AUDIO:
          return basicSetClosedAudio(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__DEFAULT_ROUTING:
          return basicSetDefaultRouting(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__EVENT_HANDLERS:
          return basicSetEventHandlers(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__EVENTS:
          return basicSetEvents(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__GRAMMAR:
          return basicSetGrammar(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__HANGUP:
          return basicSetHangup(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__HELP:
          return basicSetHelp(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__HOLIDAY_AUDIO:
          return basicSetHolidayAudio(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__INPUT_ERROR:
          return basicSetInputError(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__INTRO_AUDIO:
          return basicSetIntroAudio(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__MENU_DEFAULT:
          return basicSetMenuDefault(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__MENU_OPERATOR:
          return basicSetMenuOperator(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__NO_INPUT:
          return basicSetNoInput(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__NO_MATCH:
          return basicSetNoMatch(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__OPERATOR:
          return basicSetOperator(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__OUTRO_AUDIO:
          return basicSetOutroAudio(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__SUB_MENU:
          return basicSetSubMenu(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__TRANSFER:
          return basicSetTransfer(null, msgs);
        case ModelPackage.DOCUMENT_ROOT__TRANSFER_AUDIO:
          return basicSetTransferAudio(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DOCUMENT_ROOT__MIXED:
        return ((ESequence)getMixed()).featureMap();
      case ModelPackage.DOCUMENT_ROOT__XMLNS_PREFIX_MAP:
        return ((EMap.InternalMapView)getXMLNSPrefixMap()).eMap();
      case ModelPackage.DOCUMENT_ROOT__XSI_SCHEMA_LOCATION:
        return ((EMap.InternalMapView)getXSISchemaLocation()).eMap();
      case ModelPackage.DOCUMENT_ROOT__AUDIO:
        return getAudio();
      case ModelPackage.DOCUMENT_ROOT__AUDIO_CONFIRM:
        return getAudioConfirm();
      case ModelPackage.DOCUMENT_ROOT__CALL_ROUTING:
        return getCallRouting();
      case ModelPackage.DOCUMENT_ROOT__CHOICE:
        return getChoice();
      case ModelPackage.DOCUMENT_ROOT__CLOSED_AUDIO:
        return getClosedAudio();
      case ModelPackage.DOCUMENT_ROOT__DEFAULT_ROUTING:
        return getDefaultRouting();
      case ModelPackage.DOCUMENT_ROOT__EVENT_HANDLERS:
        return getEventHandlers();
      case ModelPackage.DOCUMENT_ROOT__EVENTS:
        return getEvents();
      case ModelPackage.DOCUMENT_ROOT__GRAMMAR:
        return getGrammar();
      case ModelPackage.DOCUMENT_ROOT__HANGUP:
        return getHangup();
      case ModelPackage.DOCUMENT_ROOT__HELP:
        return getHelp();
      case ModelPackage.DOCUMENT_ROOT__HOLIDAY_AUDIO:
        return getHolidayAudio();
      case ModelPackage.DOCUMENT_ROOT__INPUT_ERROR:
        return getInputError();
      case ModelPackage.DOCUMENT_ROOT__INTRO_AUDIO:
        return getIntroAudio();
      case ModelPackage.DOCUMENT_ROOT__MENU_DEFAULT:
        return getMenuDefault();
      case ModelPackage.DOCUMENT_ROOT__MENU_OPERATOR:
        return getMenuOperator();
      case ModelPackage.DOCUMENT_ROOT__NO_INPUT:
        return getNoInput();
      case ModelPackage.DOCUMENT_ROOT__NO_MATCH:
        return getNoMatch();
      case ModelPackage.DOCUMENT_ROOT__OPERATOR:
        return getOperator();
      case ModelPackage.DOCUMENT_ROOT__OUTRO_AUDIO:
        return getOutroAudio();
      case ModelPackage.DOCUMENT_ROOT__SUB_MENU:
        return getSubMenu();
      case ModelPackage.DOCUMENT_ROOT__TRANSFER:
        return getTransfer();
      case ModelPackage.DOCUMENT_ROOT__TRANSFER_AUDIO:
        return getTransferAudio();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DOCUMENT_ROOT__MIXED:
        ((ESequence)getMixed()).featureMap().clear();
        ((ESequence)getMixed()).featureMap().addAll((Collection)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__XMLNS_PREFIX_MAP:
        getXMLNSPrefixMap().clear();
        ((EMap.InternalMapView)getXMLNSPrefixMap()).eMap().addAll((Collection)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__XSI_SCHEMA_LOCATION:
        getXSISchemaLocation().clear();
        ((EMap.InternalMapView)getXSISchemaLocation()).eMap().addAll((Collection)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__AUDIO:
        setAudio((AudioType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__AUDIO_CONFIRM:
        setAudioConfirm((AudioConfirmType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__CALL_ROUTING:
        setCallRouting((CallRoutingType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__CHOICE:
        setChoice((ChoiceType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__CLOSED_AUDIO:
        setClosedAudio((ClosedAudioType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__DEFAULT_ROUTING:
        setDefaultRouting((DefaultRoutingType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__EVENT_HANDLERS:
        setEventHandlers((EventHandlersType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__EVENTS:
        setEvents((EventsType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__GRAMMAR:
        setGrammar((GrammarType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__HANGUP:
        setHangup((HangupType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__HELP:
        setHelp((HelpType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__HOLIDAY_AUDIO:
        setHolidayAudio((HolidayAudioType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__INPUT_ERROR:
        setInputError((InputErrorType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__INTRO_AUDIO:
        setIntroAudio((IntroAudioType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__MENU_DEFAULT:
        setMenuDefault((MenuDefaultType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__MENU_OPERATOR:
        setMenuOperator((MenuOperatorType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__NO_INPUT:
        setNoInput((NoInputType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__NO_MATCH:
        setNoMatch((NoMatchType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__OPERATOR:
        setOperator((OperatorType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__OUTRO_AUDIO:
        setOutroAudio((OutroAudioType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__SUB_MENU:
        setSubMenu((SubMenuType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__TRANSFER:
        setTransfer((TransferType)newValue);
        return;
      case ModelPackage.DOCUMENT_ROOT__TRANSFER_AUDIO:
        setTransferAudio((TransferAudioType)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DOCUMENT_ROOT__MIXED:
        ((ESequence)getMixed()).featureMap().clear();
        return;
      case ModelPackage.DOCUMENT_ROOT__XMLNS_PREFIX_MAP:
        getXMLNSPrefixMap().clear();
        return;
      case ModelPackage.DOCUMENT_ROOT__XSI_SCHEMA_LOCATION:
        getXSISchemaLocation().clear();
        return;
      case ModelPackage.DOCUMENT_ROOT__AUDIO:
        setAudio((AudioType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__AUDIO_CONFIRM:
        setAudioConfirm((AudioConfirmType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__CALL_ROUTING:
        setCallRouting((CallRoutingType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__CHOICE:
        setChoice((ChoiceType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__CLOSED_AUDIO:
        setClosedAudio((ClosedAudioType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__DEFAULT_ROUTING:
        setDefaultRouting((DefaultRoutingType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__EVENT_HANDLERS:
        setEventHandlers((EventHandlersType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__EVENTS:
        setEvents((EventsType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__GRAMMAR:
        setGrammar((GrammarType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__HANGUP:
        setHangup((HangupType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__HELP:
        setHelp((HelpType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__HOLIDAY_AUDIO:
        setHolidayAudio((HolidayAudioType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__INPUT_ERROR:
        setInputError((InputErrorType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__INTRO_AUDIO:
        setIntroAudio((IntroAudioType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__MENU_DEFAULT:
        setMenuDefault((MenuDefaultType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__MENU_OPERATOR:
        setMenuOperator((MenuOperatorType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__NO_INPUT:
        setNoInput((NoInputType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__NO_MATCH:
        setNoMatch((NoMatchType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__OPERATOR:
        setOperator((OperatorType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__OUTRO_AUDIO:
        setOutroAudio((OutroAudioType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__SUB_MENU:
        setSubMenu((SubMenuType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__TRANSFER:
        setTransfer((TransferType)null);
        return;
      case ModelPackage.DOCUMENT_ROOT__TRANSFER_AUDIO:
        setTransferAudio((TransferAudioType)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.DOCUMENT_ROOT__MIXED:
        return mixed != null && !mixed.featureMap().isEmpty();
      case ModelPackage.DOCUMENT_ROOT__XMLNS_PREFIX_MAP:
        return xMLNSPrefixMap != null && !xMLNSPrefixMap.isEmpty();
      case ModelPackage.DOCUMENT_ROOT__XSI_SCHEMA_LOCATION:
        return xSISchemaLocation != null && !xSISchemaLocation.isEmpty();
      case ModelPackage.DOCUMENT_ROOT__AUDIO:
        return getAudio() != null;
      case ModelPackage.DOCUMENT_ROOT__AUDIO_CONFIRM:
        return getAudioConfirm() != null;
      case ModelPackage.DOCUMENT_ROOT__CALL_ROUTING:
        return getCallRouting() != null;
      case ModelPackage.DOCUMENT_ROOT__CHOICE:
        return getChoice() != null;
      case ModelPackage.DOCUMENT_ROOT__CLOSED_AUDIO:
        return getClosedAudio() != null;
      case ModelPackage.DOCUMENT_ROOT__DEFAULT_ROUTING:
        return getDefaultRouting() != null;
      case ModelPackage.DOCUMENT_ROOT__EVENT_HANDLERS:
        return getEventHandlers() != null;
      case ModelPackage.DOCUMENT_ROOT__EVENTS:
        return getEvents() != null;
      case ModelPackage.DOCUMENT_ROOT__GRAMMAR:
        return getGrammar() != null;
      case ModelPackage.DOCUMENT_ROOT__HANGUP:
        return getHangup() != null;
      case ModelPackage.DOCUMENT_ROOT__HELP:
        return getHelp() != null;
      case ModelPackage.DOCUMENT_ROOT__HOLIDAY_AUDIO:
        return getHolidayAudio() != null;
      case ModelPackage.DOCUMENT_ROOT__INPUT_ERROR:
        return getInputError() != null;
      case ModelPackage.DOCUMENT_ROOT__INTRO_AUDIO:
        return getIntroAudio() != null;
      case ModelPackage.DOCUMENT_ROOT__MENU_DEFAULT:
        return getMenuDefault() != null;
      case ModelPackage.DOCUMENT_ROOT__MENU_OPERATOR:
        return getMenuOperator() != null;
      case ModelPackage.DOCUMENT_ROOT__NO_INPUT:
        return getNoInput() != null;
      case ModelPackage.DOCUMENT_ROOT__NO_MATCH:
        return getNoMatch() != null;
      case ModelPackage.DOCUMENT_ROOT__OPERATOR:
        return getOperator() != null;
      case ModelPackage.DOCUMENT_ROOT__OUTRO_AUDIO:
        return getOutroAudio() != null;
      case ModelPackage.DOCUMENT_ROOT__SUB_MENU:
        return getSubMenu() != null;
      case ModelPackage.DOCUMENT_ROOT__TRANSFER:
        return getTransfer() != null;
      case ModelPackage.DOCUMENT_ROOT__TRANSFER_AUDIO:
        return getTransferAudio() != null;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (mixed: ");
    result.append(mixed);
    result.append(')');
    return result.toString();
  }

} //DocumentRootImpl
