/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelFactory.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see com.ibm.ivr.framework.model.ModelPackage
 * @generated
 */
public interface ModelFactory extends EFactory
{
  /**
   * The singleton instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ModelFactory eINSTANCE = new com.ibm.ivr.framework.model.impl.ModelFactoryImpl();

  /**
   * Returns a new object of class '<em>Audio Confirm Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Audio Confirm Type</em>'.
   * @generated
   */
  AudioConfirmType createAudioConfirmType();

  /**
   * Returns a new object of class '<em>Audio Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Audio Type</em>'.
   * @generated
   */
  AudioType createAudioType();

  /**
   * Returns a new object of class '<em>Call Routing Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Call Routing Type</em>'.
   * @generated
   */
  CallRoutingType createCallRoutingType();

  /**
   * Returns a new object of class '<em>Choice Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Choice Type</em>'.
   * @generated
   */
  ChoiceType createChoiceType();

  /**
   * Returns a new object of class '<em>Closed Audio Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Closed Audio Type</em>'.
   * @generated
   */
  ClosedAudioType createClosedAudioType();

  /**
   * Returns a new object of class '<em>Default Routing Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Default Routing Type</em>'.
   * @generated
   */
  DefaultRoutingType createDefaultRoutingType();

  /**
   * Returns a new object of class '<em>Document Root</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Document Root</em>'.
   * @generated
   */
  DocumentRoot createDocumentRoot();

  /**
   * Returns a new object of class '<em>Event Handlers Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Event Handlers Type</em>'.
   * @generated
   */
  EventHandlersType createEventHandlersType();

  /**
   * Returns a new object of class '<em>Events Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Events Type</em>'.
   * @generated
   */
  EventsType createEventsType();

  /**
   * Returns a new object of class '<em>Grammar Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Grammar Type</em>'.
   * @generated
   */
  GrammarType createGrammarType();

  /**
   * Returns a new object of class '<em>Hangup Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Hangup Type</em>'.
   * @generated
   */
  HangupType createHangupType();

  /**
   * Returns a new object of class '<em>Help Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Help Type</em>'.
   * @generated
   */
  HelpType createHelpType();

  /**
   * Returns a new object of class '<em>Holiday Audio Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Holiday Audio Type</em>'.
   * @generated
   */
  HolidayAudioType createHolidayAudioType();

  /**
   * Returns a new object of class '<em>Input Error Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Error Type</em>'.
   * @generated
   */
  InputErrorType createInputErrorType();

  /**
   * Returns a new object of class '<em>Intro Audio Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Intro Audio Type</em>'.
   * @generated
   */
  IntroAudioType createIntroAudioType();

  /**
   * Returns a new object of class '<em>Menu Default Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Menu Default Type</em>'.
   * @generated
   */
  MenuDefaultType createMenuDefaultType();

  /**
   * Returns a new object of class '<em>Menu Operator Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Menu Operator Type</em>'.
   * @generated
   */
  MenuOperatorType createMenuOperatorType();

  /**
   * Returns a new object of class '<em>No Input Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>No Input Type</em>'.
   * @generated
   */
  NoInputType createNoInputType();

  /**
   * Returns a new object of class '<em>No Match Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>No Match Type</em>'.
   * @generated
   */
  NoMatchType createNoMatchType();

  /**
   * Returns a new object of class '<em>Operator Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Operator Type</em>'.
   * @generated
   */
  OperatorType createOperatorType();

  /**
   * Returns a new object of class '<em>Outro Audio Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Outro Audio Type</em>'.
   * @generated
   */
  OutroAudioType createOutroAudioType();

  /**
   * Returns a new object of class '<em>Sub Menu Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Sub Menu Type</em>'.
   * @generated
   */
  SubMenuType createSubMenuType();

  /**
   * Returns a new object of class '<em>Transfer Audio Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Transfer Audio Type</em>'.
   * @generated
   */
  TransferAudioType createTransferAudioType();

  /**
   * Returns a new object of class '<em>Transfer Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Transfer Type</em>'.
   * @generated
   */
  TransferType createTransferType();

  /**
   * Returns the package supported by this factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the package supported by this factory.
   * @generated
   */
  ModelPackage getModelPackage();

} //ModelFactory
