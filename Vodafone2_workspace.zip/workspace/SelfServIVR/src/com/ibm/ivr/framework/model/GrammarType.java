/**
 * <copyright>
 * </copyright>
 *
 * $Id: GrammarType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Grammar Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.GrammarType#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.GrammarType#getType_ <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getGrammarType()
 * @model 
 * @generated
 */
public interface GrammarType
{
  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute.
   * @see #setValue(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getGrammarType_Value()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getValue();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.GrammarType#getValue <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' attribute.
   * @see #getValue()
   * @generated
   */
  void setValue(String value);

  /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see #setType(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getGrammarType_Type()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getType_();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.GrammarType#getType_ <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see #getType_()
   * @generated
   */
  void setType(String value);

} // GrammarType
