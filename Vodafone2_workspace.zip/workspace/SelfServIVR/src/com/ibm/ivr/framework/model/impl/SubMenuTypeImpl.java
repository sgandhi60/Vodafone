/**
 * <copyright>
 * </copyright>
 *
 * $Id: SubMenuTypeImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.AudioConfirmType;
import com.ibm.ivr.framework.model.AudioType;
import com.ibm.ivr.framework.model.ChoiceType;
import com.ibm.ivr.framework.model.EventsType;
import com.ibm.ivr.framework.model.GrammarType;
import com.ibm.ivr.framework.model.HelpType;
import com.ibm.ivr.framework.model.InputErrorType;
import com.ibm.ivr.framework.model.MenuDefaultType;
import com.ibm.ivr.framework.model.MenuOperatorType;
import com.ibm.ivr.framework.model.ModelPackage;
import com.ibm.ivr.framework.model.NoInputType;
import com.ibm.ivr.framework.model.NoMatchType;
import com.ibm.ivr.framework.model.SubMenuType;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sub Menu Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getAudio <em>Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getAudioConfirm <em>Audio Confirm</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getGrammar <em>Grammar</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getChoice <em>Choice</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getMenuOperator <em>Menu Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getMenuDefault <em>Menu Default</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getInputError <em>Input Error</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getNoInput <em>No Input</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getNoMatch <em>No Match</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getHelp <em>Help</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getEvents <em>Events</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getClearDTMFBuffer <em>Clear DTMF Buffer</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getCounter <em>Counter</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getEndCall <em>End Call</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getHangup <em>Hangup</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getMarkPosition <em>Mark Position</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getMaxretries <em>Maxretries</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getMode <em>Mode</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getRecordingConfirmation <em>Recording Confirmation</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getRepeat <em>Repeat</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getRetry <em>Retry</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getSet <em>Set</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getType_ <em>Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getVxml <em>Vxml</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl#getWait <em>Wait</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SubMenuTypeImpl extends EDataObjectImpl implements SubMenuType
{
  /**
   * The cached value of the '{@link #getAudio() <em>Audio</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAudio()
   * @generated
   * @ordered
   */
  protected EList audio = null;

  /**
   * The cached value of the '{@link #getAudioConfirm() <em>Audio Confirm</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAudioConfirm()
   * @generated
   * @ordered
   */
  protected EList audioConfirm = null;

  /**
   * The cached value of the '{@link #getGrammar() <em>Grammar</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGrammar()
   * @generated
   * @ordered
   */
  protected GrammarType grammar = null;

  /**
   * The cached value of the '{@link #getChoice() <em>Choice</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getChoice()
   * @generated
   * @ordered
   */
  protected EList choice = null;

  /**
   * The cached value of the '{@link #getMenuOperator() <em>Menu Operator</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMenuOperator()
   * @generated
   * @ordered
   */
  protected EList menuOperator = null;

  /**
   * The cached value of the '{@link #getMenuDefault() <em>Menu Default</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMenuDefault()
   * @generated
   * @ordered
   */
  protected EList menuDefault = null;

  /**
   * The cached value of the '{@link #getInputError() <em>Input Error</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputError()
   * @generated
   * @ordered
   */
  protected EList inputError = null;

  /**
   * The cached value of the '{@link #getNoInput() <em>No Input</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNoInput()
   * @generated
   * @ordered
   */
  protected EList noInput = null;

  /**
   * The cached value of the '{@link #getNoMatch() <em>No Match</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getNoMatch()
   * @generated
   * @ordered
   */
  protected EList noMatch = null;

  /**
   * The cached value of the '{@link #getHelp() <em>Help</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHelp()
   * @generated
   * @ordered
   */
  protected HelpType help = null;

  /**
   * The cached value of the '{@link #getEvents() <em>Events</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEvents()
   * @generated
   * @ordered
   */
  protected EventsType events = null;

  /**
   * The default value of the '{@link #getClearDTMFBuffer() <em>Clear DTMF Buffer</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getClearDTMFBuffer()
   * @generated
   * @ordered
   */
  protected static final String CLEAR_DTMF_BUFFER_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getClearDTMFBuffer() <em>Clear DTMF Buffer</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getClearDTMFBuffer()
   * @generated
   * @ordered
   */
  protected String clearDTMFBuffer = CLEAR_DTMF_BUFFER_EDEFAULT;

  /**
   * The default value of the '{@link #getCounter() <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCounter()
   * @generated
   * @ordered
   */
  protected static final String COUNTER_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCounter() <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCounter()
   * @generated
   * @ordered
   */
  protected String counter = COUNTER_EDEFAULT;

  /**
   * The default value of the '{@link #getEndCall() <em>End Call</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEndCall()
   * @generated
   * @ordered
   */
  protected static final String END_CALL_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getEndCall() <em>End Call</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEndCall()
   * @generated
   * @ordered
   */
  protected String endCall = END_CALL_EDEFAULT;

  /**
   * The default value of the '{@link #getHangup() <em>Hangup</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHangup()
   * @generated
   * @ordered
   */
  protected static final String HANGUP_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getHangup() <em>Hangup</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHangup()
   * @generated
   * @ordered
   */
  protected String hangup = HANGUP_EDEFAULT;

  /**
   * The default value of the '{@link #getMarkPosition() <em>Mark Position</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarkPosition()
   * @generated
   * @ordered
   */
  protected static final String MARK_POSITION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getMarkPosition() <em>Mark Position</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarkPosition()
   * @generated
   * @ordered
   */
  protected String markPosition = MARK_POSITION_EDEFAULT;

  /**
   * The default value of the '{@link #getMaxretries() <em>Maxretries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMaxretries()
   * @generated
   * @ordered
   */
  protected static final int MAXRETRIES_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getMaxretries() <em>Maxretries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMaxretries()
   * @generated
   * @ordered
   */
  protected int maxretries = MAXRETRIES_EDEFAULT;

  /**
   * This is true if the Maxretries attribute has been set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  protected boolean maxretriesESet = false;

  /**
   * The default value of the '{@link #getMode() <em>Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMode()
   * @generated
   * @ordered
   */
  protected static final String MODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getMode() <em>Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMode()
   * @generated
   * @ordered
   */
  protected String mode = MODE_EDEFAULT;

  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getRecordingConfirmation() <em>Recording Confirmation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRecordingConfirmation()
   * @generated
   * @ordered
   */
  protected static final String RECORDING_CONFIRMATION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getRecordingConfirmation() <em>Recording Confirmation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRecordingConfirmation()
   * @generated
   * @ordered
   */
  protected String recordingConfirmation = RECORDING_CONFIRMATION_EDEFAULT;

  /**
   * The default value of the '{@link #getRepeat() <em>Repeat</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRepeat()
   * @generated
   * @ordered
   */
  protected static final String REPEAT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getRepeat() <em>Repeat</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRepeat()
   * @generated
   * @ordered
   */
  protected String repeat = REPEAT_EDEFAULT;

  /**
   * The default value of the '{@link #getRetry() <em>Retry</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRetry()
   * @generated
   * @ordered
   */
  protected static final String RETRY_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getRetry() <em>Retry</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRetry()
   * @generated
   * @ordered
   */
  protected String retry = RETRY_EDEFAULT;

  /**
   * The default value of the '{@link #getSet() <em>Set</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSet()
   * @generated
   * @ordered
   */
  protected static final String SET_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getSet() <em>Set</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSet()
   * @generated
   * @ordered
   */
  protected String set = SET_EDEFAULT;

  /**
   * The default value of the '{@link #getType_() <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getType_()
   * @generated
   * @ordered
   */
  protected static final String TYPE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getType_() <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getType_()
   * @generated
   * @ordered
   */
  protected String type = TYPE_EDEFAULT;

  /**
   * The default value of the '{@link #getVxml() <em>Vxml</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVxml()
   * @generated
   * @ordered
   */
  protected static final String VXML_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getVxml() <em>Vxml</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVxml()
   * @generated
   * @ordered
   */
  protected String vxml = VXML_EDEFAULT;

  /**
   * The default value of the '{@link #getWait() <em>Wait</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWait()
   * @generated
   * @ordered
   */
  protected static final String WAIT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getWait() <em>Wait</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWait()
   * @generated
   * @ordered
   */
  protected String wait = WAIT_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SubMenuTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getSubMenuType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getAudio()
  {
    if (audio == null)
    {
      audio = new EObjectContainmentEList(AudioType.class, this, ModelPackage.SUB_MENU_TYPE__AUDIO);
    }
    return audio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getAudioConfirm()
  {
    if (audioConfirm == null)
    {
      audioConfirm = new EObjectContainmentEList(AudioConfirmType.class, this, ModelPackage.SUB_MENU_TYPE__AUDIO_CONFIRM);
    }
    return audioConfirm;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GrammarType getGrammar()
  {
    return grammar;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetGrammar(GrammarType newGrammar, NotificationChain msgs)
  {
    GrammarType oldGrammar = grammar;
    grammar = newGrammar;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__GRAMMAR, oldGrammar, newGrammar);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGrammar(GrammarType newGrammar)
  {
    if (newGrammar != grammar)
    {
      NotificationChain msgs = null;
      if (grammar != null)
        msgs = ((InternalEObject)grammar).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.SUB_MENU_TYPE__GRAMMAR, null, msgs);
      if (newGrammar != null)
        msgs = ((InternalEObject)newGrammar).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.SUB_MENU_TYPE__GRAMMAR, null, msgs);
      msgs = basicSetGrammar(newGrammar, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__GRAMMAR, newGrammar, newGrammar));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getChoice()
  {
    if (choice == null)
    {
      choice = new EObjectContainmentEList(ChoiceType.class, this, ModelPackage.SUB_MENU_TYPE__CHOICE);
    }
    return choice;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getMenuOperator()
  {
    if (menuOperator == null)
    {
      menuOperator = new EObjectContainmentEList(MenuOperatorType.class, this, ModelPackage.SUB_MENU_TYPE__MENU_OPERATOR);
    }
    return menuOperator;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getMenuDefault()
  {
    if (menuDefault == null)
    {
      menuDefault = new EObjectContainmentEList(MenuDefaultType.class, this, ModelPackage.SUB_MENU_TYPE__MENU_DEFAULT);
    }
    return menuDefault;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getInputError()
  {
    if (inputError == null)
    {
      inputError = new EObjectContainmentEList(InputErrorType.class, this, ModelPackage.SUB_MENU_TYPE__INPUT_ERROR);
    }
    return inputError;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getNoInput()
  {
    if (noInput == null)
    {
      noInput = new EObjectContainmentEList(NoInputType.class, this, ModelPackage.SUB_MENU_TYPE__NO_INPUT);
    }
    return noInput;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getNoMatch()
  {
    if (noMatch == null)
    {
      noMatch = new EObjectContainmentEList(NoMatchType.class, this, ModelPackage.SUB_MENU_TYPE__NO_MATCH);
    }
    return noMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public HelpType getHelp()
  {
    return help;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHelp(HelpType newHelp, NotificationChain msgs)
  {
    HelpType oldHelp = help;
    help = newHelp;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__HELP, oldHelp, newHelp);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHelp(HelpType newHelp)
  {
    if (newHelp != help)
    {
      NotificationChain msgs = null;
      if (help != null)
        msgs = ((InternalEObject)help).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.SUB_MENU_TYPE__HELP, null, msgs);
      if (newHelp != null)
        msgs = ((InternalEObject)newHelp).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.SUB_MENU_TYPE__HELP, null, msgs);
      msgs = basicSetHelp(newHelp, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__HELP, newHelp, newHelp));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EventsType getEvents()
  {
    return events;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetEvents(EventsType newEvents, NotificationChain msgs)
  {
    EventsType oldEvents = events;
    events = newEvents;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__EVENTS, oldEvents, newEvents);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEvents(EventsType newEvents)
  {
    if (newEvents != events)
    {
      NotificationChain msgs = null;
      if (events != null)
        msgs = ((InternalEObject)events).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModelPackage.SUB_MENU_TYPE__EVENTS, null, msgs);
      if (newEvents != null)
        msgs = ((InternalEObject)newEvents).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModelPackage.SUB_MENU_TYPE__EVENTS, null, msgs);
      msgs = basicSetEvents(newEvents, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__EVENTS, newEvents, newEvents));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getClearDTMFBuffer()
  {
    return clearDTMFBuffer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setClearDTMFBuffer(String newClearDTMFBuffer)
  {
    String oldClearDTMFBuffer = clearDTMFBuffer;
    clearDTMFBuffer = newClearDTMFBuffer;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__CLEAR_DTMF_BUFFER, oldClearDTMFBuffer, clearDTMFBuffer));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCounter()
  {
    return counter;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCounter(String newCounter)
  {
    String oldCounter = counter;
    counter = newCounter;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__COUNTER, oldCounter, counter));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getEndCall()
  {
    return endCall;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEndCall(String newEndCall)
  {
    String oldEndCall = endCall;
    endCall = newEndCall;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__END_CALL, oldEndCall, endCall));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getHangup()
  {
    return hangup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHangup(String newHangup)
  {
    String oldHangup = hangup;
    hangup = newHangup;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__HANGUP, oldHangup, hangup));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getMarkPosition()
  {
    return markPosition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarkPosition(String newMarkPosition)
  {
    String oldMarkPosition = markPosition;
    markPosition = newMarkPosition;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__MARK_POSITION, oldMarkPosition, markPosition));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getMaxretries()
  {
    return maxretries;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMaxretries(int newMaxretries)
  {
    int oldMaxretries = maxretries;
    maxretries = newMaxretries;
    boolean oldMaxretriesESet = maxretriesESet;
    maxretriesESet = true;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__MAXRETRIES, oldMaxretries, maxretries, !oldMaxretriesESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void unsetMaxretries()
  {
    int oldMaxretries = maxretries;
    boolean oldMaxretriesESet = maxretriesESet;
    maxretries = MAXRETRIES_EDEFAULT;
    maxretriesESet = false;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.UNSET, ModelPackage.SUB_MENU_TYPE__MAXRETRIES, oldMaxretries, MAXRETRIES_EDEFAULT, oldMaxretriesESet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isSetMaxretries()
  {
    return maxretriesESet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getMode()
  {
    return mode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMode(String newMode)
  {
    String oldMode = mode;
    mode = newMode;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__MODE, oldMode, mode));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getRecordingConfirmation()
  {
    return recordingConfirmation;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRecordingConfirmation(String newRecordingConfirmation)
  {
    String oldRecordingConfirmation = recordingConfirmation;
    recordingConfirmation = newRecordingConfirmation;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__RECORDING_CONFIRMATION, oldRecordingConfirmation, recordingConfirmation));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getRepeat()
  {
    return repeat;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRepeat(String newRepeat)
  {
    String oldRepeat = repeat;
    repeat = newRepeat;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__REPEAT, oldRepeat, repeat));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getRetry()
  {
    return retry;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRetry(String newRetry)
  {
    String oldRetry = retry;
    retry = newRetry;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__RETRY, oldRetry, retry));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getSet()
  {
    return set;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSet(String newSet)
  {
    String oldSet = set;
    set = newSet;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__SET, oldSet, set));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getType_()
  {
    return type;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setType(String newType)
  {
    String oldType = type;
    type = newType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__TYPE, oldType, type));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getVxml()
  {
    return vxml;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVxml(String newVxml)
  {
    String oldVxml = vxml;
    vxml = newVxml;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__VXML, oldVxml, vxml));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getWait()
  {
    return wait;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWait(String newWait)
  {
    String oldWait = wait;
    wait = newWait;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.SUB_MENU_TYPE__WAIT, oldWait, wait));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs)
  {
    if (featureID >= 0)
    {
      switch (eDerivedStructuralFeatureID(featureID, baseClass))
      {
        case ModelPackage.SUB_MENU_TYPE__AUDIO:
          return ((InternalEList)getAudio()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__AUDIO_CONFIRM:
          return ((InternalEList)getAudioConfirm()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__GRAMMAR:
          return basicSetGrammar(null, msgs);
        case ModelPackage.SUB_MENU_TYPE__CHOICE:
          return ((InternalEList)getChoice()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__MENU_OPERATOR:
          return ((InternalEList)getMenuOperator()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__MENU_DEFAULT:
          return ((InternalEList)getMenuDefault()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__INPUT_ERROR:
          return ((InternalEList)getInputError()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__NO_INPUT:
          return ((InternalEList)getNoInput()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__NO_MATCH:
          return ((InternalEList)getNoMatch()).basicRemove(otherEnd, msgs);
        case ModelPackage.SUB_MENU_TYPE__HELP:
          return basicSetHelp(null, msgs);
        case ModelPackage.SUB_MENU_TYPE__EVENTS:
          return basicSetEvents(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.SUB_MENU_TYPE__AUDIO:
        return getAudio();
      case ModelPackage.SUB_MENU_TYPE__AUDIO_CONFIRM:
        return getAudioConfirm();
      case ModelPackage.SUB_MENU_TYPE__GRAMMAR:
        return getGrammar();
      case ModelPackage.SUB_MENU_TYPE__CHOICE:
        return getChoice();
      case ModelPackage.SUB_MENU_TYPE__MENU_OPERATOR:
        return getMenuOperator();
      case ModelPackage.SUB_MENU_TYPE__MENU_DEFAULT:
        return getMenuDefault();
      case ModelPackage.SUB_MENU_TYPE__INPUT_ERROR:
        return getInputError();
      case ModelPackage.SUB_MENU_TYPE__NO_INPUT:
        return getNoInput();
      case ModelPackage.SUB_MENU_TYPE__NO_MATCH:
        return getNoMatch();
      case ModelPackage.SUB_MENU_TYPE__HELP:
        return getHelp();
      case ModelPackage.SUB_MENU_TYPE__EVENTS:
        return getEvents();
      case ModelPackage.SUB_MENU_TYPE__CLEAR_DTMF_BUFFER:
        return getClearDTMFBuffer();
      case ModelPackage.SUB_MENU_TYPE__COUNTER:
        return getCounter();
      case ModelPackage.SUB_MENU_TYPE__END_CALL:
        return getEndCall();
      case ModelPackage.SUB_MENU_TYPE__HANGUP:
        return getHangup();
      case ModelPackage.SUB_MENU_TYPE__MARK_POSITION:
        return getMarkPosition();
      case ModelPackage.SUB_MENU_TYPE__MAXRETRIES:
        return new Integer(getMaxretries());
      case ModelPackage.SUB_MENU_TYPE__MODE:
        return getMode();
      case ModelPackage.SUB_MENU_TYPE__NAME:
        return getName();
      case ModelPackage.SUB_MENU_TYPE__RECORDING_CONFIRMATION:
        return getRecordingConfirmation();
      case ModelPackage.SUB_MENU_TYPE__REPEAT:
        return getRepeat();
      case ModelPackage.SUB_MENU_TYPE__RETRY:
        return getRetry();
      case ModelPackage.SUB_MENU_TYPE__SET:
        return getSet();
      case ModelPackage.SUB_MENU_TYPE__TYPE:
        return getType_();
      case ModelPackage.SUB_MENU_TYPE__VXML:
        return getVxml();
      case ModelPackage.SUB_MENU_TYPE__WAIT:
        return getWait();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.SUB_MENU_TYPE__AUDIO:
        getAudio().clear();
        getAudio().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__AUDIO_CONFIRM:
        getAudioConfirm().clear();
        getAudioConfirm().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__GRAMMAR:
        setGrammar((GrammarType)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__CHOICE:
        getChoice().clear();
        getChoice().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__MENU_OPERATOR:
        getMenuOperator().clear();
        getMenuOperator().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__MENU_DEFAULT:
        getMenuDefault().clear();
        getMenuDefault().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__INPUT_ERROR:
        getInputError().clear();
        getInputError().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__NO_INPUT:
        getNoInput().clear();
        getNoInput().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__NO_MATCH:
        getNoMatch().clear();
        getNoMatch().addAll((Collection)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__HELP:
        setHelp((HelpType)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__EVENTS:
        setEvents((EventsType)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__CLEAR_DTMF_BUFFER:
        setClearDTMFBuffer((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__COUNTER:
        setCounter((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__END_CALL:
        setEndCall((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__HANGUP:
        setHangup((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__MARK_POSITION:
        setMarkPosition((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__MAXRETRIES:
        setMaxretries(((Integer)newValue).intValue());
        return;
      case ModelPackage.SUB_MENU_TYPE__MODE:
        setMode((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__NAME:
        setName((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__RECORDING_CONFIRMATION:
        setRecordingConfirmation((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__REPEAT:
        setRepeat((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__RETRY:
        setRetry((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__SET:
        setSet((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__TYPE:
        setType((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__VXML:
        setVxml((String)newValue);
        return;
      case ModelPackage.SUB_MENU_TYPE__WAIT:
        setWait((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.SUB_MENU_TYPE__AUDIO:
        getAudio().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__AUDIO_CONFIRM:
        getAudioConfirm().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__GRAMMAR:
        setGrammar((GrammarType)null);
        return;
      case ModelPackage.SUB_MENU_TYPE__CHOICE:
        getChoice().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__MENU_OPERATOR:
        getMenuOperator().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__MENU_DEFAULT:
        getMenuDefault().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__INPUT_ERROR:
        getInputError().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__NO_INPUT:
        getNoInput().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__NO_MATCH:
        getNoMatch().clear();
        return;
      case ModelPackage.SUB_MENU_TYPE__HELP:
        setHelp((HelpType)null);
        return;
      case ModelPackage.SUB_MENU_TYPE__EVENTS:
        setEvents((EventsType)null);
        return;
      case ModelPackage.SUB_MENU_TYPE__CLEAR_DTMF_BUFFER:
        setClearDTMFBuffer(CLEAR_DTMF_BUFFER_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__COUNTER:
        setCounter(COUNTER_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__END_CALL:
        setEndCall(END_CALL_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__HANGUP:
        setHangup(HANGUP_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__MARK_POSITION:
        setMarkPosition(MARK_POSITION_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__MAXRETRIES:
        unsetMaxretries();
        return;
      case ModelPackage.SUB_MENU_TYPE__MODE:
        setMode(MODE_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__RECORDING_CONFIRMATION:
        setRecordingConfirmation(RECORDING_CONFIRMATION_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__REPEAT:
        setRepeat(REPEAT_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__RETRY:
        setRetry(RETRY_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__SET:
        setSet(SET_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__TYPE:
        setType(TYPE_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__VXML:
        setVxml(VXML_EDEFAULT);
        return;
      case ModelPackage.SUB_MENU_TYPE__WAIT:
        setWait(WAIT_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.SUB_MENU_TYPE__AUDIO:
        return audio != null && !audio.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__AUDIO_CONFIRM:
        return audioConfirm != null && !audioConfirm.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__GRAMMAR:
        return grammar != null;
      case ModelPackage.SUB_MENU_TYPE__CHOICE:
        return choice != null && !choice.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__MENU_OPERATOR:
        return menuOperator != null && !menuOperator.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__MENU_DEFAULT:
        return menuDefault != null && !menuDefault.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__INPUT_ERROR:
        return inputError != null && !inputError.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__NO_INPUT:
        return noInput != null && !noInput.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__NO_MATCH:
        return noMatch != null && !noMatch.isEmpty();
      case ModelPackage.SUB_MENU_TYPE__HELP:
        return help != null;
      case ModelPackage.SUB_MENU_TYPE__EVENTS:
        return events != null;
      case ModelPackage.SUB_MENU_TYPE__CLEAR_DTMF_BUFFER:
        return CLEAR_DTMF_BUFFER_EDEFAULT == null ? clearDTMFBuffer != null : !CLEAR_DTMF_BUFFER_EDEFAULT.equals(clearDTMFBuffer);
      case ModelPackage.SUB_MENU_TYPE__COUNTER:
        return COUNTER_EDEFAULT == null ? counter != null : !COUNTER_EDEFAULT.equals(counter);
      case ModelPackage.SUB_MENU_TYPE__END_CALL:
        return END_CALL_EDEFAULT == null ? endCall != null : !END_CALL_EDEFAULT.equals(endCall);
      case ModelPackage.SUB_MENU_TYPE__HANGUP:
        return HANGUP_EDEFAULT == null ? hangup != null : !HANGUP_EDEFAULT.equals(hangup);
      case ModelPackage.SUB_MENU_TYPE__MARK_POSITION:
        return MARK_POSITION_EDEFAULT == null ? markPosition != null : !MARK_POSITION_EDEFAULT.equals(markPosition);
      case ModelPackage.SUB_MENU_TYPE__MAXRETRIES:
        return isSetMaxretries();
      case ModelPackage.SUB_MENU_TYPE__MODE:
        return MODE_EDEFAULT == null ? mode != null : !MODE_EDEFAULT.equals(mode);
      case ModelPackage.SUB_MENU_TYPE__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ModelPackage.SUB_MENU_TYPE__RECORDING_CONFIRMATION:
        return RECORDING_CONFIRMATION_EDEFAULT == null ? recordingConfirmation != null : !RECORDING_CONFIRMATION_EDEFAULT.equals(recordingConfirmation);
      case ModelPackage.SUB_MENU_TYPE__REPEAT:
        return REPEAT_EDEFAULT == null ? repeat != null : !REPEAT_EDEFAULT.equals(repeat);
      case ModelPackage.SUB_MENU_TYPE__RETRY:
        return RETRY_EDEFAULT == null ? retry != null : !RETRY_EDEFAULT.equals(retry);
      case ModelPackage.SUB_MENU_TYPE__SET:
        return SET_EDEFAULT == null ? set != null : !SET_EDEFAULT.equals(set);
      case ModelPackage.SUB_MENU_TYPE__TYPE:
        return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
      case ModelPackage.SUB_MENU_TYPE__VXML:
        return VXML_EDEFAULT == null ? vxml != null : !VXML_EDEFAULT.equals(vxml);
      case ModelPackage.SUB_MENU_TYPE__WAIT:
        return WAIT_EDEFAULT == null ? wait != null : !WAIT_EDEFAULT.equals(wait);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (clearDTMFBuffer: ");
    result.append(clearDTMFBuffer);
    result.append(", counter: ");
    result.append(counter);
    result.append(", endCall: ");
    result.append(endCall);
    result.append(", hangup: ");
    result.append(hangup);
    result.append(", markPosition: ");
    result.append(markPosition);
    result.append(", maxretries: ");
    if (maxretriesESet) result.append(maxretries); else result.append("<unset>");
    result.append(", mode: ");
    result.append(mode);
    result.append(", name: ");
    result.append(name);
    result.append(", recordingConfirmation: ");
    result.append(recordingConfirmation);
    result.append(", repeat: ");
    result.append(repeat);
    result.append(", retry: ");
    result.append(retry);
    result.append(", set: ");
    result.append(set);
    result.append(", type: ");
    result.append(type);
    result.append(", vxml: ");
    result.append(vxml);
    result.append(", wait: ");
    result.append(wait);
    result.append(')');
    return result.toString();
  }

} //SubMenuTypeImpl
