package com.ibm.ivr.framework.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.utilities.AudioHelper;
import com.ibm.ivr.framework.utilities.CallRoutingHelper;
import com.ibm.ivr.framework.utilities.Common;
import com.ibm.ivr.framework.utilities.Reporter;
import com.selfserv.ivr.data.Circle;
import com.selfserv.ivr.data.Customer;
import com.selfserv.ivr.selfservdao.central.CreditMatrixDAO;
import com.selfserv.ivr.selfservdao.central.CreditMatrixXfer;
import com.selfserv.ivr.selfservdao.local.ReportErrorDAO;
import com.selfserv.ivr.selfservdao.local.TableGenDAO;
import com.selfserv.ivr.selfservdao.local.TableGenXfer;

/**
 * The TransferServlet decides attaches the call data to the call (if available)
 * and transfer the caller to the queue/route point
 * 
 * Revision history:
 * <p>
 * 
 * 2004-06-01: initial version
 * <p>
 * 2004-06-23: Shailesh Gandhi - Added support for "dest"
 * <p>
 * 2004-06-24: Shailesh Gandhi - Added support for multiple transfer audio files
 * <p>
 * 2007-03-09: Fang Wang - 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-09
 *  
 */
public class TransferServlet extends HttpServlet implements Servlet {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(TransferServlet.class);

	/**
	 * The regular service method as the controller to forward to next jsv page
	 * and/or error page in the case of exceptions
	 * 
	 * @param HttpServletRequest -
	 *            Servlet Request object
	 * @param HttpServletResponse -
	 *            Servlet Response object
	 * 
	 * @return void
	 * @throws ServletException,
	 *             IOException
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String callid = null;
		String dest = null;
		String currentPos = null;

		// get session from Servlet request
		HttpSession session = req.getSession(false);

		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC
					.push((String) this.getServletContext().getAttribute(
							"hostName"));

		// retrieve iCallRouting from session
		String dnis = (String) session.getAttribute("DNIS");
		CallRoutingType iCallRouting = (CallRoutingType) session
				.getAttribute("iCallRouting");
		CallRoutingHelper iCRHelper = (CallRoutingHelper) session
				.getAttribute("iCRHelper");

		//get the reporter
		Reporter reporter = (Reporter) this.getServletContext().getAttribute(
				"reporter");

		String appName = "UNKNOWN";
		if (iCallRouting != null)
			appName = iCallRouting.getName();

		//contains GVP call id for VAR reporter
		String gvpCallId = (String) session.getAttribute("gvpCallId");

		callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce
		// number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken)
				.append("Entering TransferServlet..."));

		//check if this is a forwarded request
		boolean forwarded = req.getAttribute("forwarded") != null;

		try {
			String routeRequest = (String) req.getParameter("routeRequest");

			StringBuffer counterSB = new StringBuffer();

			if (routeRequest == null)
				routeRequest = (String) req.getAttribute("routeRequest");
			if (routeRequest != null && routeRequest.equalsIgnoreCase("DONE")) {
				req.setAttribute("routeRequest", "DONE");
				if (testCall)
					LOGGER.info(new StringBuffer(logToken)
						.append("routeRequest: DONE"));

				//get audio filename for transfer
				req.setAttribute("iAudioHelper", session
						.getAttribute("transferAudioHelper"));
				req.setAttribute("tts", session.getAttribute("transferTTS"));

				String nextPage = "/jsp/" + getInitParameter("nextPage");
				RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"Leaving TransferServlet... nextPage: ").append(
							nextPage));
				}

				dispatch.forward(req, resp);
				return;
			}

			currentPos = (String) session.getAttribute("currentPos");

			String mode = null;
			if (forwarded)
				mode = (String) req.getAttribute("mode");
			else
				mode = (String) req.getParameter("mode");

			if (mode == null)
				mode = (String) session.getAttribute("mode");
			else
				session.setAttribute("mode", mode);

			//get the current submenu where transfer option was selected
			SubMenuType subMenu = ((SubMenuType) session
					.getAttribute("iSubMenu"));

			//set/increment the counter for the parameter if submitted
			String counter = null;
			if (forwarded)
				counter = (String) req.getAttribute("counter");
			else
				counter = (String) req.getParameter("counter");

			if (counter != null && counter.length() != 0) {
				counterSB.append(counter);
			}

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"increment counter: ").append(counterSB));
			}

			String[] counters = counterSB.toString().split(",");
			for (int i = 0; i < counters.length; i++) {
				String c = counters[i].trim();
				if (c.length() != 0) {
					reporter.callEvent(gvpCallId, appName, c);
				}
			}

			String selection = null;
			if (forwarded)
				selection = (String) req.getAttribute("selection");
			else
				selection = (String) req.getParameter("selection");

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("mode: ")
						.append(mode));
				LOGGER.debug(new StringBuffer(logToken).append("selection: ")
						.append(selection));
			}

			// build and save the call Route info in session
			StringBuffer callRoute = (StringBuffer) session
					.getAttribute("callRoute");
			if (callRoute == null)
				callRoute = new StringBuffer();

			// this is only logged when subMenu has atttribute markPosition set
			// not as "false", when the attribute is not specified, default as
			// "true"
			// it will be logged no matter what if this is test call
			if (subMenu != null) {
				String markPosition = subMenu.getMarkPosition();
				if (markPosition == null)
					markPosition = Common.TRUE;
				if (!markPosition.equalsIgnoreCase(Common.FALSE) || testCall) {
					if (selection != null) {
						int index = selection.indexOf(Common.COLON);
						if (index != -1) {
							selection = selection.substring(index + 1)
									.replaceAll(" ", "");
						}
					}

					if ((selection != null) && (selection.length() != 0)) {
						callRoute.append(selection);
						if (mode.equalsIgnoreCase(Common.SPEECH))
							callRoute.append(Common.SPEECH_MODE);
						else if (mode.equalsIgnoreCase(Common.DTMF))
							callRoute.append(Common.DTMF_MODE);
						else if (mode.equalsIgnoreCase(Common.HYBRID))
							callRoute.append(Common.HYBRID_MODE);
					}
				}
			}

			session.setAttribute("callRoute", callRoute);

			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("callRoute: ")
						.append(callRoute));
			}

			String reason = (String) req.getAttribute("reason");
			if (reason == null) {
				if (!forwarded)
					reason = req.getParameter("reason");
				if (reason == null)
					reason = "unknown";
				//do not need to update current position since reason and
				// current position will
				//be concatenated in ExitServlet
				/*
				 * if (currentPos != null) { currentPos = currentPos + "_" +
				 * reason; // set current position of caller in the session for
				 * later // use to log at Hangup time for statistic report
				 * session.setAttribute("currentPos", currentPos); if (testCall) {
				 * LOGGER.debug(new StringBuffer(logToken).append( "currentPos:
				 * ").append(currentPos)); } }
				 */
			}
			session.setAttribute("reason", reason);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append("reason: ")
						.append(reason));
			}

			dest = (String) req.getAttribute("dest");
			if (dest == null)
				if (!forwarded)
					dest = req.getParameter("dest");

			String agentType = null;
			if (forwarded)
				agentType = (String) req.getAttribute("agentType");
			else {
				agentType = req.getParameter("agentType");
				req.setAttribute("agentType", agentType);
			}
			if (testCall)
				LOGGER.info(new StringBuffer(logToken).append("agentType: ")
					.append(agentType));

			if (session != null) {

				//get audio filename for transfer
				String audio = null;
				if (forwarded)
					audio = (String) req.getAttribute("audio");
				else
					audio = req.getParameter("audio");

				String tts = null;
				if (forwarded)
					tts = (String) req.getAttribute("tts");
				else
					tts = req.getParameter("tts");

				if (audio == null || audio.length() == 0) {
					if (iCallRouting != null
							&& iCallRouting.getTransferAudio() != null) {
						audio = iCallRouting.getTransferAudio().getValue();
						tts = iCallRouting.getTransferAudio().getTts();
					}
				}

				if (audio != null && audio.length() != 0) {
					AudioHelper audioHelper = new AudioHelper(audio);
					req.setAttribute("iAudioHelper", audioHelper);
					session.setAttribute("transferAudioHelper", audioHelper);
				}

				if (tts != null) {
					req.setAttribute("tts", tts);
					session.setAttribute("transferTTS", tts);
				} else {
					req.setAttribute("tts", "");
					session.setAttribute("transferTTS", "");
				}

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"submitted audio: ").append(audio));
				}

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"submitted tts: ").append(tts));
				}

				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"submitted dest: ").append(dest));
				}
				if (!agentType.equalsIgnoreCase("CTIAGENTDIRECT")
						&& (dest == null || dest.length() == 0
								&& iCallRouting != null)) {
					dest = (String) iCallRouting.getOperator().getValue();
					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(
								"dest using operator: ").append(dest));
					}
				}
			}

			//for agentType = CTIAGENTDIRECT
			if (agentType.equalsIgnoreCase("CTIAGENTDIRECT")) {
				String ivrTarget = null;
				String ivrTargetLocation = null;
				String msgId = null;
				if (dest == null || dest.length() == 0) {
					//after more IVR call flow post URS routing, retrieve
					// IVRTarget information returned from URS (saved earlier in
					// the session)
					ivrTarget = (String) session.getAttribute("IVRTarget");
					ivrTargetLocation = (String) session
							.getAttribute("IVRTargetLocation");
					msgId = (String) session.getAttribute("MSGID");
				} else {//direct agent extension was specified in the xml
					String[] temp = dest.split(":");
					ivrTarget = temp[0];
					ivrTargetLocation = temp[1];
					msgId = "";
				}
				req.setAttribute("IVRTarget", ivrTarget);
				req.setAttribute("IVRTargetLocation", ivrTargetLocation);
				req.setAttribute("MSGID", msgId);
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"transfer IVRTarget: ").append(ivrTarget).append(
							" IVRTargetLocation:").append(ivrTargetLocation)
							.append(" MSGID:").append(msgId));
				}
			}
			//for other agent types
			if (!agentType.equalsIgnoreCase("CTIAGENTDIRECT")
					&& (dest == null || dest.length() == 0)) {
				// Check properties to search Hash Table for CallRouting class
				Properties prop = (Properties) this.getServletContext()
						.getAttribute("globalProp");
				dest = prop.getProperty("defaultOperator");
				if (testCall) {
					LOGGER.debug(new StringBuffer(logToken).append(
							"dest using defaultOperator: ").append(dest));
				}
			}

			if (dest != null || dest.length() != 0) {
				//  parse dest parameter to strip off dashes from phone number
				try {
					String destStr = null;
					String destStrTemp = "";
					StringTokenizer st = new StringTokenizer(dest, "-");
					while (st.hasMoreTokens()) {
						destStr = st.nextToken().trim();
						if (destStr != null) {
							destStrTemp = destStrTemp + destStr;
						}
					}
					dest = destStrTemp;
					if (testCall) {
						LOGGER.trace(new StringBuffer(logToken).append(
								"dest(from strings):  ").append(dest));
					}
				} catch (Exception ex) {
					throw new Exception("Invalid dest paramater value. dest = "
							+ dest);
				}
			}

			if (testCall)
				LOGGER.info(new StringBuffer(logToken).append("transfer to: ")
					.append(dest));

			req.setAttribute("dest", dest);
			
			// Mirt:  Added logging flag to pass into Transfer.jsv and TransferCTI.jsv
			//        If testCall
			//            Set ctiLogFlag to "true"
			//         else
			//            Set ctiLogFlag to "false"
			
			if (testCall)
				req.setAttribute("ctiLogFlag", "true");
			else
				req.setAttribute("ctiLogFlag", "false");
			
			
			String nextPage;
			String attachedData;
			
			String ctiEnabled = (String)req.getAttribute("ctiEnabled");
			if (ctiEnabled == null) 
				ctiEnabled = (String)session.getAttribute("ctiEnabled");
			if ( (ctiEnabled != null) && (ctiEnabled.equalsIgnoreCase("Y")) ) {
				
				Customer customer = null;			
				
				String mobile = null;
				Circle circ = null;
				String localJNDIName = null;
				TableGenXfer tblGenXfer = null;
			    String title = null;
			    String firstName = null;			    
			    String lastName = null;
			    String address1 = null;
			    String address2 = null;
			    String address3 = null;
			    String city = null;
			    String pincode = null;
				String birthDate = null;
				String creditType = null;
				String lastMenuValue = null;
				
				customer = (Customer)session.getAttribute("customer");			
				
				mobile = (String) customer.getMobile();
				circ = (Circle) session.getAttribute("circle");
				localJNDIName = circ.getLocalJNDIName();

				//TableGenDAO
				if (customer.isTableGenCalled()) {
					if (testCall) 
						LOGGER.debug(new StringBuffer(logToken).append(" TableGenDAO already called; not executing again."));
				} else {
					TableGenDAO tblGenDAO = null;

					try {
						tblGenDAO = new TableGenDAO(localJNDIName, mobile, callid, testCall);				
					} catch (SQLException sqle) {
						LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to LDB TBL_GEN: ").append(sqle.getMessage()));
						sqle.printStackTrace();
						return;
					}

					try { // retrieve email and pincode for this mobile #
						tblGenXfer = tblGenDAO.findRecord(mobile);
						String dbrc = tblGenXfer.getDBRC();

						if (dbrc.equals("S")){

							title = tblGenXfer.getTitle();
							firstName = tblGenXfer.getFname();
							lastName = tblGenXfer.getLname();
							address1 = tblGenXfer.getAddr1();
							address2 = tblGenXfer.getAddr2();
							address3 = tblGenXfer.getAddr3();
							city = tblGenXfer.getCity();
							
							pincode = tblGenXfer.getPinCode();
							if (pincode != null) {
								pincode = pincode.substring(0, 6);
							}

							SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
							if (tblGenXfer.getBirthDate() != null) {
								birthDate = formatter.format(tblGenXfer.getBirthDate());
							}

						} else {
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(" Error retrieving data from DB - Add entry into Error table"));
						}
					} catch (Exception e) {
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(" BirthDate NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
						e.printStackTrace();
					}
				} // else  TableGenDAO
				
				
				// CreditMatrixDAO
				if ( (customer.getDbCType() != null) &&
					 (customer.getDbCType().equalsIgnoreCase("POSTPAID")) ) {
					if (customer.isCreditMatrixCalled()) {
						if (testCall) 
							LOGGER.debug(new StringBuffer(logToken).append(" CreditMatrixDAO already called; not executing again."));
					} else {
						Properties callProp = null;			// properties key-value pair
						String coId = null;
						String custId = null;
						CreditMatrixDAO cmDAO = null;
						String centralJNDIName = null;			// JNDI name for Central DB
						String circle = null;					// Circle name 0001.....0023
						String pgmName = null;				   	// Program Name
						String serv_cd = null;			

						coId = customer.getCoid();
						custId= customer.getCust_id();
						pgmName = customer.getPrgname();
						serv_cd = (String) session.getAttribute("cmservCd");

						circle = circ.getCircle();
						
						callProp = (Properties) session.getAttribute("callProp");
						centralJNDIName = callProp.getProperty("centralJNDIName");
						try {
							cmDAO = new CreditMatrixDAO(centralJNDIName, mobile, callid, testCall, circ.getSpPackageName());
						} catch (SQLException sqle) {
							LOGGER.error(new StringBuffer(logToken).append(" - Exception connecting to CDB: ").append(sqle.getMessage()));
							sqle.printStackTrace();
							return;
						}
						
						int iCustId = -1;
						if ( (custId != null) && (custId.length() != 0 ) ) {
							iCustId = new Integer(custId).intValue();
						}
						int iCoId = -1;
						if ( (coId != null) && (coId.length() != 0 ) ) {
							iCoId = new Integer(coId).intValue();
						}

						try {
							CreditMatrixXfer cmXfer = cmDAO.executeSP(circle, iCustId, iCoId, pgmName, serv_cd);
							String dbrc = cmXfer.getDBRC();

							if (dbrc.equals("S")){
								creditType = cmXfer.getCreditType();
								
								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(" Credit MAtrix retrieval successful"));
							} else {
								if (testCall)
									LOGGER.debug(new StringBuffer(logToken).append(" Error while communicating with SP IVR_CREDIT_MATRIX - Add entry into Error table "));
							}
						} catch (Exception e) {
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(" MPin NOT retrieved from DB - Add entry into Error table - ").append(e.getMessage()));
							e.printStackTrace();
						}
					} 
				}// else CreditMatrixDAO
				
				//LastMenuHandler
				if (iCallRouting != null) {
					String handler = "com.selfserv.ivr.handler.LastMenu";

					try {
						if (handler != null && handler.length() > 0) {
							// Get the classloader for loading resources and classes
							// Use the context classloader to search the servlet
							// path,
							// not the
							// servlet container path
							ClassLoader classloader = Thread.currentThread()
									.getContextClassLoader();
							Servlet servlet = (Servlet) classloader.loadClass(
									handler).newInstance();

							//Calling service should call doGet to be called
							servlet.service(req, resp);
						}
					} catch (Exception e) {
						//throw new RuntimeException(e);
						LOGGER.error(new StringBuffer(logToken).append("Exception From LastMenu: "));
						e.printStackTrace();
					}
				} // LastMenuHandler
				
				lastMenuValue = (String)session.getAttribute("LastMenuValue");
				

				StringBuffer attDataBuffer = new StringBuffer();
				
				attDataBuffer.append("#Mobile Number#");
				if (mobile != null) {
					attDataBuffer.append(mobile);					
				}
				
				attDataBuffer.append("#D O B#");
				if (birthDate != null) {
					attDataBuffer.append(birthDate);					
				}
				
				attDataBuffer.append("#Customer Name#");				
				String custName = null;
				StringBuffer nameBuf = new StringBuffer();
				if (title != null) {
					nameBuf.append(title).append(" ");
				}
				if (firstName != null) {
					nameBuf.append(firstName).append(" ");
				}
				if (lastName != null) {
					nameBuf.append(lastName);
				}
				if (nameBuf.length() > 0) {
					custName = new String(nameBuf);
				}
				if (custName != null) {
					attDataBuffer.append(custName);					
				}				
				
				attDataBuffer.append("#Credit Limit#");
				float cdtLimit = customer.getBillCreditLimitAmt();
				attDataBuffer.append(cdtLimit);	
				
				attDataBuffer.append("#TYPE#");
				if (creditType != null) {
					attDataBuffer.append(creditType);					
				}
				attDataBuffer.append("#Last Option In IVR#");
				if (lastMenuValue != null) {
					attDataBuffer.append(lastMenuValue);					
				}
				
				attDataBuffer.append("#Customer Segment#");
				String custSeg = customer.getDbCType();
				if (custSeg != null) {
					attDataBuffer.append(custSeg);					
				}
				
				attDataBuffer.append("#Language Chosen#");
				String lang = customer.getPrefLang();
				if (lang != null) {
					attDataBuffer.append(lang);					
				}
				
				attDataBuffer.append("#Billing Address#");
				String billAddress = null;
				StringBuffer addrBuf = new StringBuffer();
				if (address1 != null) {
					addrBuf.append(address1).append(" ");
				}
				if (address2 != null) {
					addrBuf.append(address2).append(" ");
				}
				if (address3 != null) {
					addrBuf.append(address3).append(" ");
				}
				if (city != null) {
					addrBuf.append(city).append(" ");
				}
				if (pincode != null) {
					addrBuf.append(pincode);
				}
				if (nameBuf.length() > 0) {
					billAddress = new String(addrBuf);
				}
				if (billAddress != null) {
					attDataBuffer.append(billAddress);					
				}
				
				attDataBuffer.append("#IVR Education#");
//				String ivrEducation = customer.getMobile();
				String ivrEducation = null;
				if (ivrEducation != null) {
					attDataBuffer.append(ivrEducation);					
				}

				attDataBuffer.append("#Current History#");
//				String ivrEducation = customer.getMobile();
				String curHist = null;
				if (ivrEducation != null) {
					attDataBuffer.append(curHist);					
				}

				attDataBuffer.append("#Previous History#");
//				String ivrEducation = customer.getMobile();
				String prevHist = null;
				if (prevHist != null) {
					attDataBuffer.append(prevHist);					
				}

				attachedData = new String (attDataBuffer);
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append("attached data:  ").append(attachedData));
				
				req.setAttribute("attachedData", attachedData);
				req.setAttribute("cdtType", session.getAttribute("cdtType"));
				req.setAttribute("ctiSwitch", session.getAttribute("ctiSwitch"));
				req.setAttribute("ctiVDN", session.getAttribute("ctiVDN"));
	
				nextPage = "/jsp/" + getInitParameter("ctinextPage");
			} else {
				nextPage = "/jsp/" + getInitParameter("nextPage");
			}
			
			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving TransferServlet... nextPage: ").append(nextPage));
			}

			dispatch.forward(req, resp);

		} catch (Exception ex) {
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(ex.getMessage()), ex);

			session.setAttribute("errorLogged", new Boolean(true));

			String nextPage = null;
			if (((String) this.getServletContext().getInitParameter(
					"ivrPlatform")).equalsIgnoreCase("GVP")) {
				nextPage = "/TNTServlet";
				req.setAttribute("exitReason", "WebAppError.TransferFailed");
				req.setAttribute("defaultRouting", "true");
			} else {
				nextPage = "/jsp/"
						+ (getInitParameter("errorPage") == null ? "TransferError.jsv"
								: getInitParameter("errorPage"));
			}

			req.setAttribute("lastError", ex.toString());
			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving TransferServlet... nextPage: ").append(
						nextPage));
			}
			dispatch.forward(req, resp);
		}
		NDC.remove();
	}
	
	/**
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

			doGet(req, resp);
	}
}
