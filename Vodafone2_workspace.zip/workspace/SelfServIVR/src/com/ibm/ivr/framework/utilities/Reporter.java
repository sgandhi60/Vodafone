package com.ibm.ivr.framework.utilities;


/**
 * The interface to for reporting call statistics
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-16: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-16
 *  
 */
public interface Reporter {
	/**
	 * Used by IVR to report call start
	 * 
	 * @param ani		ani of the call
	 * @param dnis 		dnis of the call
	 * @param sessionID	unique session id of the call
	 * @param appName		application reached by the call
	 */
	public void callStart(String ani, String dnis, String sessionID, String appName);
	
	/**
	 * Used by IVR to report call end
	 * 
	 * @param sessionID		unique session id of the call
	 * @param appName		application reached by the call
	 * @param exitReason	the exit reason of the call
	 * @param mode			the ending mode of the call, DTMF/SPEECH/HYBRID
	 */
	public void callEnd (String sessionID, String appName, String exitReason, String mode);
	
	/**
	 * Used by IVR to report call events collectd at the end of the call
	 * 
	 * @param sessionID	unique session id of the call
	 * @param appName		application reached by the call
	 * @param eventName	the name of the event to be logged
	 */
	public void callEvent (String sessionID, String appName, String eventName);

	/**
	 * Used by IVR to check if callStart has been logged
	 * 
	 * @param sessionID	unique session id of the call
	 * @return true if already logged, false otherwise
	 */
	public boolean isCallStarted(String sessionID);
	
	/*
	 * get the current number of concurrent sessions
	 * 
	 * @return the integer value
	 */
	public int getNumOfSessions();
}
