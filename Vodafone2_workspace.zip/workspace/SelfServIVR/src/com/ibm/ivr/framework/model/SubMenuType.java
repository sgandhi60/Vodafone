/**
 * <copyright>
 * </copyright>
 *
 * $Id: SubMenuType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Menu Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getAudio <em>Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getAudioConfirm <em>Audio Confirm</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getGrammar <em>Grammar</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getChoice <em>Choice</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getMenuOperator <em>Menu Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getMenuDefault <em>Menu Default</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getInputError <em>Input Error</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getNoInput <em>No Input</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getNoMatch <em>No Match</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getHelp <em>Help</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getEvents <em>Events</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getClearDTMFBuffer <em>Clear DTMF Buffer</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getCounter <em>Counter</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getEndCall <em>End Call</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getHangup <em>Hangup</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getMarkPosition <em>Mark Position</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getMaxretries <em>Maxretries</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getMode <em>Mode</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getName <em>Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getRecordingConfirmation <em>Recording Confirmation</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getRepeat <em>Repeat</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getRetry <em>Retry</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getSet <em>Set</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getType_ <em>Type</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getVxml <em>Vxml</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.SubMenuType#getWait <em>Wait</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType()
 * @model 
 * @generated
 */
public interface SubMenuType
{
  /**
   * Returns the value of the '<em><b>Audio</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.AudioType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Audio</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Audio</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Audio()
   * @model type="com.ibm.ivr.framework.model.AudioType" containment="true" resolveProxies="false"
   * @generated
   */
  List getAudio();

  /**
   * Returns the value of the '<em><b>Audio Confirm</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.AudioConfirmType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Audio Confirm</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Audio Confirm</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_AudioConfirm()
   * @model type="com.ibm.ivr.framework.model.AudioConfirmType" containment="true" resolveProxies="false"
   * @generated
   */
  List getAudioConfirm();

  /**
   * Returns the value of the '<em><b>Grammar</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Grammar</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Grammar</em>' containment reference.
   * @see #setGrammar(GrammarType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Grammar()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  GrammarType getGrammar();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getGrammar <em>Grammar</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Grammar</em>' containment reference.
   * @see #getGrammar()
   * @generated
   */
  void setGrammar(GrammarType value);

  /**
   * Returns the value of the '<em><b>Choice</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.ChoiceType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Choice</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Choice</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Choice()
   * @model type="com.ibm.ivr.framework.model.ChoiceType" containment="true" resolveProxies="false"
   * @generated
   */
  List getChoice();

  /**
   * Returns the value of the '<em><b>Menu Operator</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.MenuOperatorType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Menu Operator</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Menu Operator</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_MenuOperator()
   * @model type="com.ibm.ivr.framework.model.MenuOperatorType" containment="true" resolveProxies="false"
   * @generated
   */
  List getMenuOperator();

  /**
   * Returns the value of the '<em><b>Menu Default</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.MenuDefaultType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Menu Default</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Menu Default</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_MenuDefault()
   * @model type="com.ibm.ivr.framework.model.MenuDefaultType" containment="true" resolveProxies="false"
   * @generated
   */
  List getMenuDefault();

  /**
   * Returns the value of the '<em><b>Input Error</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.InputErrorType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Error</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Error</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_InputError()
   * @model type="com.ibm.ivr.framework.model.InputErrorType" containment="true" resolveProxies="false"
   * @generated
   */
  List getInputError();

  /**
   * Returns the value of the '<em><b>No Input</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.NoInputType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>No Input</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>No Input</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_NoInput()
   * @model type="com.ibm.ivr.framework.model.NoInputType" containment="true" resolveProxies="false"
   * @generated
   */
  List getNoInput();

  /**
   * Returns the value of the '<em><b>No Match</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.NoMatchType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>No Match</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>No Match</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_NoMatch()
   * @model type="com.ibm.ivr.framework.model.NoMatchType" containment="true" resolveProxies="false"
   * @generated
   */
  List getNoMatch();

  /**
   * Returns the value of the '<em><b>Help</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Help</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Help</em>' containment reference.
   * @see #setHelp(HelpType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Help()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  HelpType getHelp();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getHelp <em>Help</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Help</em>' containment reference.
   * @see #getHelp()
   * @generated
   */
  void setHelp(HelpType value);

  /**
   * Returns the value of the '<em><b>Events</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Events</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Events</em>' containment reference.
   * @see #setEvents(EventsType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Events()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  EventsType getEvents();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getEvents <em>Events</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Events</em>' containment reference.
   * @see #getEvents()
   * @generated
   */
  void setEvents(EventsType value);

  /**
   * Returns the value of the '<em><b>Clear DTMF Buffer</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Clear DTMF Buffer</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Clear DTMF Buffer</em>' attribute.
   * @see #setClearDTMFBuffer(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_ClearDTMFBuffer()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getClearDTMFBuffer();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getClearDTMFBuffer <em>Clear DTMF Buffer</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Clear DTMF Buffer</em>' attribute.
   * @see #getClearDTMFBuffer()
   * @generated
   */
  void setClearDTMFBuffer(String value);

  /**
   * Returns the value of the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Counter</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Counter</em>' attribute.
   * @see #setCounter(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Counter()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCounter();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getCounter <em>Counter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Counter</em>' attribute.
   * @see #getCounter()
   * @generated
   */
  void setCounter(String value);

  /**
   * Returns the value of the '<em><b>End Call</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>End Call</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>End Call</em>' attribute.
   * @see #setEndCall(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_EndCall()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getEndCall();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getEndCall <em>End Call</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>End Call</em>' attribute.
   * @see #getEndCall()
   * @generated
   */
  void setEndCall(String value);

  /**
   * Returns the value of the '<em><b>Hangup</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hangup</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hangup</em>' attribute.
   * @see #setHangup(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Hangup()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getHangup();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getHangup <em>Hangup</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Hangup</em>' attribute.
   * @see #getHangup()
   * @generated
   */
  void setHangup(String value);

  /**
   * Returns the value of the '<em><b>Mark Position</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mark Position</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mark Position</em>' attribute.
   * @see #setMarkPosition(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_MarkPosition()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getMarkPosition();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getMarkPosition <em>Mark Position</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mark Position</em>' attribute.
   * @see #getMarkPosition()
   * @generated
   */
  void setMarkPosition(String value);

  /**
   * Returns the value of the '<em><b>Maxretries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Maxretries</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Maxretries</em>' attribute.
   * @see #isSetMaxretries()
   * @see #unsetMaxretries()
   * @see #setMaxretries(int)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Maxretries()
   * @model unique="false" unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Int"
   * @generated
   */
  int getMaxretries();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getMaxretries <em>Maxretries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Maxretries</em>' attribute.
   * @see #isSetMaxretries()
   * @see #unsetMaxretries()
   * @see #getMaxretries()
   * @generated
   */
  void setMaxretries(int value);

  /**
   * Unsets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getMaxretries <em>Maxretries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetMaxretries()
   * @see #getMaxretries()
   * @see #setMaxretries(int)
   * @generated
   */
  void unsetMaxretries();

  /**
   * Returns whether the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getMaxretries <em>Maxretries</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Maxretries</em>' attribute is set.
   * @see #unsetMaxretries()
   * @see #getMaxretries()
   * @see #setMaxretries(int)
   * @generated
   */
  boolean isSetMaxretries();

  /**
   * Returns the value of the '<em><b>Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mode</em>' attribute.
   * @see #setMode(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Mode()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getMode();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getMode <em>Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mode</em>' attribute.
   * @see #getMode()
   * @generated
   */
  void setMode(String value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Name()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Recording Confirmation</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Recording Confirmation</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Recording Confirmation</em>' attribute.
   * @see #setRecordingConfirmation(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_RecordingConfirmation()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getRecordingConfirmation();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getRecordingConfirmation <em>Recording Confirmation</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Recording Confirmation</em>' attribute.
   * @see #getRecordingConfirmation()
   * @generated
   */
  void setRecordingConfirmation(String value);

  /**
   * Returns the value of the '<em><b>Repeat</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Repeat</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Repeat</em>' attribute.
   * @see #setRepeat(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Repeat()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getRepeat();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getRepeat <em>Repeat</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Repeat</em>' attribute.
   * @see #getRepeat()
   * @generated
   */
  void setRepeat(String value);

  /**
   * Returns the value of the '<em><b>Retry</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Retry</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Retry</em>' attribute.
   * @see #setRetry(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Retry()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getRetry();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getRetry <em>Retry</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Retry</em>' attribute.
   * @see #getRetry()
   * @generated
   */
  void setRetry(String value);

  /**
   * Returns the value of the '<em><b>Set</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Set</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Set</em>' attribute.
   * @see #setSet(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Set()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getSet();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getSet <em>Set</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Set</em>' attribute.
   * @see #getSet()
   * @generated
   */
  void setSet(String value);

  /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see #setType(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Type()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getType_();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getType_ <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see #getType_()
   * @generated
   */
  void setType(String value);

  /**
   * Returns the value of the '<em><b>Vxml</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vxml</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vxml</em>' attribute.
   * @see #setVxml(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Vxml()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getVxml();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getVxml <em>Vxml</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Vxml</em>' attribute.
   * @see #getVxml()
   * @generated
   */
  void setVxml(String value);

  /**
   * Returns the value of the '<em><b>Wait</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Wait</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Wait</em>' attribute.
   * @see #setWait(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getSubMenuType_Wait()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getWait();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.SubMenuType#getWait <em>Wait</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Wait</em>' attribute.
   * @see #getWait()
   * @generated
   */
  void setWait(String value);

} // SubMenuType
