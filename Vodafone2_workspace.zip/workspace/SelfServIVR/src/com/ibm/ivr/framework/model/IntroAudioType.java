/**
 * <copyright>
 * </copyright>
 *
 * $Id: IntroAudioType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Intro Audio Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.IntroAudioType#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.IntroAudioType#getCaching <em>Caching</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.IntroAudioType#getDir <em>Dir</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.IntroAudioType#getDnis <em>Dnis</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.IntroAudioType#getFetchtimeout <em>Fetchtimeout</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.IntroAudioType#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType()
 * @model 
 * @generated
 */
public interface IntroAudioType
{
  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute.
   * @see #setValue(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType_Value()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getValue();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.IntroAudioType#getValue <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' attribute.
   * @see #getValue()
   * @generated
   */
  void setValue(String value);

  /**
   * Returns the value of the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Caching</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Caching</em>' attribute.
   * @see #setCaching(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType_Caching()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCaching();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.IntroAudioType#getCaching <em>Caching</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Caching</em>' attribute.
   * @see #getCaching()
   * @generated
   */
  void setCaching(String value);

  /**
   * Returns the value of the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dir</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dir</em>' attribute.
   * @see #setDir(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType_Dir()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDir();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.IntroAudioType#getDir <em>Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dir</em>' attribute.
   * @see #getDir()
   * @generated
   */
  void setDir(String value);

  /**
   * Returns the value of the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dnis</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dnis</em>' attribute.
   * @see #setDnis(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType_Dnis()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDnis();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.IntroAudioType#getDnis <em>Dnis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dnis</em>' attribute.
   * @see #getDnis()
   * @generated
   */
  void setDnis(String value);

  /**
   * Returns the value of the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Fetchtimeout</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Fetchtimeout</em>' attribute.
   * @see #setFetchtimeout(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType_Fetchtimeout()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getFetchtimeout();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.IntroAudioType#getFetchtimeout <em>Fetchtimeout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Fetchtimeout</em>' attribute.
   * @see #getFetchtimeout()
   * @generated
   */
  void setFetchtimeout(String value);

  /**
   * Returns the value of the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tts</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tts</em>' attribute.
   * @see #setTts(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getIntroAudioType_Tts()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTts();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.IntroAudioType#getTts <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tts</em>' attribute.
   * @see #getTts()
   * @generated
   */
  void setTts(String value);

} // IntroAudioType
