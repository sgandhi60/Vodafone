/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelPackage.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.ibm.ivr.framework.model.ModelFactory
 * @generated
 */
public interface ModelPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "model";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://ibm.com/ivr/framework/model";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "model";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ModelPackage eINSTANCE = com.ibm.ivr.framework.model.impl.ModelPackageImpl.init();

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl <em>Audio Confirm Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getAudioConfirmType()
   * @generated
   */
  int AUDIO_CONFIRM_TYPE = 0;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE__CACHING = 1;

  /**
   * The feature id for the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE__DIR = 2;

  /**
   * The feature id for the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE__FETCHTIMEOUT = 3;

  /**
   * The feature id for the '<em><b>List Count</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE__LIST_COUNT = 4;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE__TTS = 5;

  /**
   * The number of structural features of the the '<em>Audio Confirm Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_CONFIRM_TYPE_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.AudioTypeImpl <em>Audio Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.AudioTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getAudioType()
   * @generated
   */
  int AUDIO_TYPE = 1;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__CACHING = 1;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__COND = 2;

  /**
   * The feature id for the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__DIR = 3;

  /**
   * The feature id for the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__FETCHTIMEOUT = 4;

  /**
   * The feature id for the '<em><b>List Count</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__LIST_COUNT = 5;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE__TTS = 6;

  /**
   * The number of structural features of the the '<em>Audio Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_TYPE_FEATURE_COUNT = 7;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl <em>Call Routing Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.CallRoutingTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getCallRoutingType()
   * @generated
   */
  int CALL_ROUTING_TYPE = 2;

  /**
   * The feature id for the '<em><b>Intro Audio</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__INTRO_AUDIO = 0;

  /**
   * The feature id for the '<em><b>Outro Audio</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__OUTRO_AUDIO = 1;

  /**
   * The feature id for the '<em><b>Holiday Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__HOLIDAY_AUDIO = 2;

  /**
   * The feature id for the '<em><b>Closed Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__CLOSED_AUDIO = 3;

  /**
   * The feature id for the '<em><b>Transfer Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__TRANSFER_AUDIO = 4;

  /**
   * The feature id for the '<em><b>Operator</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__OPERATOR = 5;

  /**
   * The feature id for the '<em><b>Menu Operator</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__MENU_OPERATOR = 6;

  /**
   * The feature id for the '<em><b>Events</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__EVENTS = 7;

  /**
   * The feature id for the '<em><b>Event Handlers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__EVENT_HANDLERS = 8;

  /**
   * The feature id for the '<em><b>Default Routing</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__DEFAULT_ROUTING = 9;

  /**
   * The feature id for the '<em><b>Sub Menu</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__SUB_MENU = 10;

  /**
   * The feature id for the '<em><b>Audio Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__AUDIO_DIR = 11;

  /**
   * The feature id for the '<em><b>Call Properties</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__CALL_PROPERTIES = 12;

  /**
   * The feature id for the '<em><b>Cleanup Handler</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__CLEANUP_HANDLER = 13;

  /**
   * The feature id for the '<em><b>Common</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__COMMON = 14;

  /**
   * The feature id for the '<em><b>File Version</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__FILE_VERSION = 15;

  /**
   * The feature id for the '<em><b>Main</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__MAIN = 16;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__NAME = 17;

  /**
   * The feature id for the '<em><b>Release Version</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__RELEASE_VERSION = 18;

  /**
   * The feature id for the '<em><b>Start</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__START = 19;

  /**
   * The feature id for the '<em><b>Start Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE__START_MODE = 20;

  /**
   * The number of structural features of the the '<em>Call Routing Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CALL_ROUTING_TYPE_FEATURE_COUNT = 21;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.ChoiceTypeImpl <em>Choice Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.ChoiceTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getChoiceType()
   * @generated
   */
  int CHOICE_TYPE = 3;

  /**
   * The feature id for the '<em><b>Annot</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__ANNOT = 0;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__COND = 1;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__COUNTER = 2;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__DEST = 3;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__DEST_TYPE = 4;

  /**
   * The feature id for the '<em><b>Dtmf</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__DTMF = 5;

  /**
   * The feature id for the '<em><b>Handler</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__HANDLER = 6;

  /**
   * The feature id for the '<em><b>Speech</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__SPEECH = 7;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__TARGET_AUDIO = 8;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__TARGET_MODE = 9;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__TARGET_NAME = 10;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__TARGET_TYPE = 11;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE__TTS = 12;

  /**
   * The number of structural features of the the '<em>Choice Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHOICE_TYPE_FEATURE_COUNT = 13;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.ClosedAudioTypeImpl <em>Closed Audio Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.ClosedAudioTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getClosedAudioType()
   * @generated
   */
  int CLOSED_AUDIO_TYPE = 4;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE__CACHING = 1;

  /**
   * The feature id for the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE__DIR = 2;

  /**
   * The feature id for the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE__FETCHTIMEOUT = 3;

  /**
   * The feature id for the '<em><b>Terminate</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE__TERMINATE = 4;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE__TTS = 5;

  /**
   * The number of structural features of the the '<em>Closed Audio Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CLOSED_AUDIO_TYPE_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.DefaultRoutingTypeImpl <em>Default Routing Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.DefaultRoutingTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getDefaultRoutingType()
   * @generated
   */
  int DEFAULT_ROUTING_TYPE = 5;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFAULT_ROUTING_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Alternative</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFAULT_ROUTING_TYPE__ALTERNATIVE = 1;

  /**
   * The feature id for the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFAULT_ROUTING_TYPE__DNIS = 2;

  /**
   * The number of structural features of the the '<em>Default Routing Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DEFAULT_ROUTING_TYPE_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.DocumentRootImpl <em>Document Root</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.DocumentRootImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getDocumentRoot()
   * @generated
   */
  int DOCUMENT_ROOT = 6;

  /**
   * The feature id for the '<em><b>Mixed</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__MIXED = 0;

  /**
   * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

  /**
   * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

  /**
   * The feature id for the '<em><b>Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__AUDIO = 3;

  /**
   * The feature id for the '<em><b>Audio Confirm</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__AUDIO_CONFIRM = 4;

  /**
   * The feature id for the '<em><b>Call Routing</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__CALL_ROUTING = 5;

  /**
   * The feature id for the '<em><b>Choice</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__CHOICE = 6;

  /**
   * The feature id for the '<em><b>Closed Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__CLOSED_AUDIO = 7;

  /**
   * The feature id for the '<em><b>Default Routing</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__DEFAULT_ROUTING = 8;

  /**
   * The feature id for the '<em><b>Event Handlers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__EVENT_HANDLERS = 9;

  /**
   * The feature id for the '<em><b>Events</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__EVENTS = 10;

  /**
   * The feature id for the '<em><b>Grammar</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__GRAMMAR = 11;

  /**
   * The feature id for the '<em><b>Hangup</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__HANGUP = 12;

  /**
   * The feature id for the '<em><b>Help</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__HELP = 13;

  /**
   * The feature id for the '<em><b>Holiday Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__HOLIDAY_AUDIO = 14;

  /**
   * The feature id for the '<em><b>Input Error</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__INPUT_ERROR = 15;

  /**
   * The feature id for the '<em><b>Intro Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__INTRO_AUDIO = 16;

  /**
   * The feature id for the '<em><b>Menu Default</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__MENU_DEFAULT = 17;

  /**
   * The feature id for the '<em><b>Menu Operator</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__MENU_OPERATOR = 18;

  /**
   * The feature id for the '<em><b>No Input</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__NO_INPUT = 19;

  /**
   * The feature id for the '<em><b>No Match</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__NO_MATCH = 20;

  /**
   * The feature id for the '<em><b>Operator</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__OPERATOR = 21;

  /**
   * The feature id for the '<em><b>Outro Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__OUTRO_AUDIO = 22;

  /**
   * The feature id for the '<em><b>Sub Menu</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__SUB_MENU = 23;

  /**
   * The feature id for the '<em><b>Transfer</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__TRANSFER = 24;

  /**
   * The feature id for the '<em><b>Transfer Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT__TRANSFER_AUDIO = 25;

  /**
   * The number of structural features of the the '<em>Document Root</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DOCUMENT_ROOT_FEATURE_COUNT = 26;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.EventHandlersTypeImpl <em>Event Handlers Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.EventHandlersTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getEventHandlersType()
   * @generated
   */
  int EVENT_HANDLERS_TYPE = 7;

  /**
   * The feature id for the '<em><b>Input Error</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENT_HANDLERS_TYPE__INPUT_ERROR = 0;

  /**
   * The feature id for the '<em><b>No Input</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENT_HANDLERS_TYPE__NO_INPUT = 1;

  /**
   * The feature id for the '<em><b>No Match</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENT_HANDLERS_TYPE__NO_MATCH = 2;

  /**
   * The feature id for the '<em><b>Help</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENT_HANDLERS_TYPE__HELP = 3;

  /**
   * The number of structural features of the the '<em>Event Handlers Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENT_HANDLERS_TYPE_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.EventsTypeImpl <em>Events Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.EventsTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getEventsType()
   * @generated
   */
  int EVENTS_TYPE = 8;

  /**
   * The feature id for the '<em><b>Hangup</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENTS_TYPE__HANGUP = 0;

  /**
   * The feature id for the '<em><b>Transfer</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENTS_TYPE__TRANSFER = 1;

  /**
   * The number of structural features of the the '<em>Events Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EVENTS_TYPE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.GrammarTypeImpl <em>Grammar Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.GrammarTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getGrammarType()
   * @generated
   */
  int GRAMMAR_TYPE = 9;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GRAMMAR_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GRAMMAR_TYPE__TYPE = 1;

  /**
   * The number of structural features of the the '<em>Grammar Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GRAMMAR_TYPE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.HangupTypeImpl <em>Hangup Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.HangupTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getHangupType()
   * @generated
   */
  int HANGUP_TYPE = 10;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HANGUP_TYPE__COND = 0;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HANGUP_TYPE__COUNTER = 1;

  /**
   * The number of structural features of the the '<em>Hangup Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HANGUP_TYPE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.HelpTypeImpl <em>Help Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.HelpTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getHelpType()
   * @generated
   */
  int HELP_TYPE = 11;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__COND = 1;

  /**
   * The feature id for the '<em><b>Count</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__COUNT = 2;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__COUNTER = 3;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__DEST = 4;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__DEST_TYPE = 5;

  /**
   * The feature id for the '<em><b>Reprompt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__REPROMPT = 6;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__TARGET_AUDIO = 7;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__TARGET_MODE = 8;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__TARGET_NAME = 9;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__TARGET_TYPE = 10;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE__TTS = 11;

  /**
   * The number of structural features of the the '<em>Help Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HELP_TYPE_FEATURE_COUNT = 12;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.HolidayAudioTypeImpl <em>Holiday Audio Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.HolidayAudioTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getHolidayAudioType()
   * @generated
   */
  int HOLIDAY_AUDIO_TYPE = 12;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE__CACHING = 1;

  /**
   * The feature id for the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE__DIR = 2;

  /**
   * The feature id for the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE__FETCHTIMEOUT = 3;

  /**
   * The feature id for the '<em><b>Terminate</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE__TERMINATE = 4;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE__TTS = 5;

  /**
   * The number of structural features of the the '<em>Holiday Audio Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HOLIDAY_AUDIO_TYPE_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.InputErrorTypeImpl <em>Input Error Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.InputErrorTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getInputErrorType()
   * @generated
   */
  int INPUT_ERROR_TYPE = 13;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__COND = 1;

  /**
   * The feature id for the '<em><b>Count</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__COUNT = 2;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__COUNTER = 3;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__DEST = 4;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__DEST_TYPE = 5;

  /**
   * The feature id for the '<em><b>Event</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__EVENT = 6;

  /**
   * The feature id for the '<em><b>Reprompt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__REPROMPT = 7;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__TARGET_AUDIO = 8;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__TARGET_MODE = 9;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__TARGET_NAME = 10;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__TARGET_TYPE = 11;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE__TTS = 12;

  /**
   * The number of structural features of the the '<em>Input Error Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ERROR_TYPE_FEATURE_COUNT = 13;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.IntroAudioTypeImpl <em>Intro Audio Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.IntroAudioTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getIntroAudioType()
   * @generated
   */
  int INTRO_AUDIO_TYPE = 14;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE__CACHING = 1;

  /**
   * The feature id for the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE__DIR = 2;

  /**
   * The feature id for the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE__DNIS = 3;

  /**
   * The feature id for the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE__FETCHTIMEOUT = 4;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE__TTS = 5;

  /**
   * The number of structural features of the the '<em>Intro Audio Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INTRO_AUDIO_TYPE_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.MenuDefaultTypeImpl <em>Menu Default Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.MenuDefaultTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getMenuDefaultType()
   * @generated
   */
  int MENU_DEFAULT_TYPE = 15;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__COND = 0;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__COUNTER = 1;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__DEST = 2;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__DEST_TYPE = 3;

  /**
   * The feature id for the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__DNIS = 4;

  /**
   * The feature id for the '<em><b>Handler</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__HANDLER = 5;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__TARGET_AUDIO = 6;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__TARGET_MODE = 7;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__TARGET_NAME = 8;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__TARGET_TYPE = 9;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE__TTS = 10;

  /**
   * The number of structural features of the the '<em>Menu Default Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_DEFAULT_TYPE_FEATURE_COUNT = 11;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.MenuOperatorTypeImpl <em>Menu Operator Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.MenuOperatorTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getMenuOperatorType()
   * @generated
   */
  int MENU_OPERATOR_TYPE = 16;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__COND = 1;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__COUNTER = 2;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__DEST = 3;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__DEST_TYPE = 4;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__TARGET_AUDIO = 5;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__TARGET_MODE = 6;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__TARGET_NAME = 7;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__TARGET_TYPE = 8;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE__TTS = 9;

  /**
   * The number of structural features of the the '<em>Menu Operator Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MENU_OPERATOR_TYPE_FEATURE_COUNT = 10;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.NoInputTypeImpl <em>No Input Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.NoInputTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getNoInputType()
   * @generated
   */
  int NO_INPUT_TYPE = 17;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__COND = 1;

  /**
   * The feature id for the '<em><b>Count</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__COUNT = 2;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__COUNTER = 3;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__DEST = 4;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__DEST_TYPE = 5;

  /**
   * The feature id for the '<em><b>Reprompt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__REPROMPT = 6;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__TARGET_AUDIO = 7;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__TARGET_MODE = 8;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__TARGET_NAME = 9;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__TARGET_TYPE = 10;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE__TTS = 11;

  /**
   * The number of structural features of the the '<em>No Input Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_INPUT_TYPE_FEATURE_COUNT = 12;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.NoMatchTypeImpl <em>No Match Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.NoMatchTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getNoMatchType()
   * @generated
   */
  int NO_MATCH_TYPE = 18;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__COND = 1;

  /**
   * The feature id for the '<em><b>Count</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__COUNT = 2;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__COUNTER = 3;

  /**
   * The feature id for the '<em><b>Dest</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__DEST = 4;

  /**
   * The feature id for the '<em><b>Dest Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__DEST_TYPE = 5;

  /**
   * The feature id for the '<em><b>Reprompt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__REPROMPT = 6;

  /**
   * The feature id for the '<em><b>Target Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__TARGET_AUDIO = 7;

  /**
   * The feature id for the '<em><b>Target Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__TARGET_MODE = 8;

  /**
   * The feature id for the '<em><b>Target Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__TARGET_NAME = 9;

  /**
   * The feature id for the '<em><b>Target Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__TARGET_TYPE = 10;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE__TTS = 11;

  /**
   * The number of structural features of the the '<em>No Match Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NO_MATCH_TYPE_FEATURE_COUNT = 12;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.OperatorTypeImpl <em>Operator Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.OperatorTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getOperatorType()
   * @generated
   */
  int OPERATOR_TYPE = 19;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPERATOR_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPERATOR_TYPE__DNIS = 1;

  /**
   * The number of structural features of the the '<em>Operator Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPERATOR_TYPE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.OutroAudioTypeImpl <em>Outro Audio Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.OutroAudioTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getOutroAudioType()
   * @generated
   */
  int OUTRO_AUDIO_TYPE = 20;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Caching</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE__CACHING = 1;

  /**
   * The feature id for the '<em><b>Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE__DIR = 2;

  /**
   * The feature id for the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE__DNIS = 3;

  /**
   * The feature id for the '<em><b>Fetchtimeout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE__FETCHTIMEOUT = 4;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE__TTS = 5;

  /**
   * The number of structural features of the the '<em>Outro Audio Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTRO_AUDIO_TYPE_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.SubMenuTypeImpl <em>Sub Menu Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.SubMenuTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getSubMenuType()
   * @generated
   */
  int SUB_MENU_TYPE = 21;

  /**
   * The feature id for the '<em><b>Audio</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__AUDIO = 0;

  /**
   * The feature id for the '<em><b>Audio Confirm</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__AUDIO_CONFIRM = 1;

  /**
   * The feature id for the '<em><b>Grammar</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__GRAMMAR = 2;

  /**
   * The feature id for the '<em><b>Choice</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__CHOICE = 3;

  /**
   * The feature id for the '<em><b>Menu Operator</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__MENU_OPERATOR = 4;

  /**
   * The feature id for the '<em><b>Menu Default</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__MENU_DEFAULT = 5;

  /**
   * The feature id for the '<em><b>Input Error</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__INPUT_ERROR = 6;

  /**
   * The feature id for the '<em><b>No Input</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__NO_INPUT = 7;

  /**
   * The feature id for the '<em><b>No Match</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__NO_MATCH = 8;

  /**
   * The feature id for the '<em><b>Help</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__HELP = 9;

  /**
   * The feature id for the '<em><b>Events</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__EVENTS = 10;

  /**
   * The feature id for the '<em><b>Clear DTMF Buffer</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__CLEAR_DTMF_BUFFER = 11;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__COUNTER = 12;

  /**
   * The feature id for the '<em><b>End Call</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__END_CALL = 13;

  /**
   * The feature id for the '<em><b>Hangup</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__HANGUP = 14;

  /**
   * The feature id for the '<em><b>Mark Position</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__MARK_POSITION = 15;

  /**
   * The feature id for the '<em><b>Maxretries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__MAXRETRIES = 16;

  /**
   * The feature id for the '<em><b>Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__MODE = 17;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__NAME = 18;

  /**
   * The feature id for the '<em><b>Recording Confirmation</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__RECORDING_CONFIRMATION = 19;

  /**
   * The feature id for the '<em><b>Repeat</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__REPEAT = 20;

  /**
   * The feature id for the '<em><b>Retry</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__RETRY = 21;

  /**
   * The feature id for the '<em><b>Set</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__SET = 22;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__TYPE = 23;

  /**
   * The feature id for the '<em><b>Vxml</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__VXML = 24;

  /**
   * The feature id for the '<em><b>Wait</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE__WAIT = 25;

  /**
   * The number of structural features of the the '<em>Sub Menu Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SUB_MENU_TYPE_FEATURE_COUNT = 26;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.TransferAudioTypeImpl <em>Transfer Audio Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.TransferAudioTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getTransferAudioType()
   * @generated
   */
  int TRANSFER_AUDIO_TYPE = 22;

  /**
   * The feature id for the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFER_AUDIO_TYPE__VALUE = 0;

  /**
   * The feature id for the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFER_AUDIO_TYPE__TTS = 1;

  /**
   * The number of structural features of the the '<em>Transfer Audio Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFER_AUDIO_TYPE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.ibm.ivr.framework.model.impl.TransferTypeImpl <em>Transfer Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ibm.ivr.framework.model.impl.TransferTypeImpl
   * @see com.ibm.ivr.framework.model.impl.ModelPackageImpl#getTransferType()
   * @generated
   */
  int TRANSFER_TYPE = 23;

  /**
   * The feature id for the '<em><b>Cond</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFER_TYPE__COND = 0;

  /**
   * The feature id for the '<em><b>Counter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFER_TYPE__COUNTER = 1;

  /**
   * The number of structural features of the the '<em>Transfer Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFER_TYPE_FEATURE_COUNT = 2;


  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.AudioConfirmType <em>Audio Confirm Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Audio Confirm Type</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType
   * @generated
   */
  EClass getAudioConfirmType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioConfirmType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType#getValue()
   * @see #getAudioConfirmType()
   * @generated
   */
  EAttribute getAudioConfirmType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioConfirmType#getCaching <em>Caching</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Caching</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType#getCaching()
   * @see #getAudioConfirmType()
   * @generated
   */
  EAttribute getAudioConfirmType_Caching();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioConfirmType#getDir <em>Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType#getDir()
   * @see #getAudioConfirmType()
   * @generated
   */
  EAttribute getAudioConfirmType_Dir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioConfirmType#getFetchtimeout <em>Fetchtimeout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Fetchtimeout</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType#getFetchtimeout()
   * @see #getAudioConfirmType()
   * @generated
   */
  EAttribute getAudioConfirmType_Fetchtimeout();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioConfirmType#getListCount <em>List Count</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>List Count</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType#getListCount()
   * @see #getAudioConfirmType()
   * @generated
   */
  EAttribute getAudioConfirmType_ListCount();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioConfirmType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.AudioConfirmType#getTts()
   * @see #getAudioConfirmType()
   * @generated
   */
  EAttribute getAudioConfirmType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.AudioType <em>Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Audio Type</em>'.
   * @see com.ibm.ivr.framework.model.AudioType
   * @generated
   */
  EClass getAudioType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getValue()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getCaching <em>Caching</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Caching</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getCaching()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_Caching();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getCond()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getDir <em>Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getDir()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_Dir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getFetchtimeout <em>Fetchtimeout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Fetchtimeout</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getFetchtimeout()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_Fetchtimeout();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getListCount <em>List Count</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>List Count</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getListCount()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_ListCount();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.AudioType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.AudioType#getTts()
   * @see #getAudioType()
   * @generated
   */
  EAttribute getAudioType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.CallRoutingType <em>Call Routing Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Call Routing Type</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType
   * @generated
   */
  EClass getCallRoutingType();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.CallRoutingType#getIntroAudio <em>Intro Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Intro Audio</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getIntroAudio()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_IntroAudio();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.CallRoutingType#getOutroAudio <em>Outro Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Outro Audio</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getOutroAudio()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_OutroAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.CallRoutingType#getHolidayAudio <em>Holiday Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Holiday Audio</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getHolidayAudio()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_HolidayAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.CallRoutingType#getClosedAudio <em>Closed Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Closed Audio</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getClosedAudio()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_ClosedAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.CallRoutingType#getTransferAudio <em>Transfer Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Transfer Audio</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getTransferAudio()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_TransferAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.CallRoutingType#getOperator <em>Operator</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Operator</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getOperator()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_Operator();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.CallRoutingType#getMenuOperator <em>Menu Operator</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Menu Operator</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getMenuOperator()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_MenuOperator();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.CallRoutingType#getEvents <em>Events</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Events</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getEvents()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_Events();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.CallRoutingType#getEventHandlers <em>Event Handlers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Event Handlers</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getEventHandlers()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_EventHandlers();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.CallRoutingType#getDefaultRouting <em>Default Routing</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Default Routing</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getDefaultRouting()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_DefaultRouting();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.CallRoutingType#getSubMenu <em>Sub Menu</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sub Menu</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getSubMenu()
   * @see #getCallRoutingType()
   * @generated
   */
  EReference getCallRoutingType_SubMenu();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getAudioDir <em>Audio Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Audio Dir</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getAudioDir()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_AudioDir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getCallProperties <em>Call Properties</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Call Properties</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getCallProperties()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_CallProperties();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getCleanupHandler <em>Cleanup Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cleanup Handler</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getCleanupHandler()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_CleanupHandler();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getCommon <em>Common</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Common</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getCommon()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_Common();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getFileVersion <em>File Version</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>File Version</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getFileVersion()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_FileVersion();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getMain <em>Main</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Main</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getMain()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_Main();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getName()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_Name();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getReleaseVersion <em>Release Version</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Release Version</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getReleaseVersion()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_ReleaseVersion();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getStart <em>Start</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Start</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getStart()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_Start();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.CallRoutingType#getStartMode <em>Start Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Start Mode</em>'.
   * @see com.ibm.ivr.framework.model.CallRoutingType#getStartMode()
   * @see #getCallRoutingType()
   * @generated
   */
  EAttribute getCallRoutingType_StartMode();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.ChoiceType <em>Choice Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Choice Type</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType
   * @generated
   */
  EClass getChoiceType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getAnnot <em>Annot</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Annot</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getAnnot()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Annot();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getCond()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getCounter()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getDest()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getDestType()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getDtmf <em>Dtmf</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dtmf</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getDtmf()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Dtmf();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getHandler <em>Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Handler</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getHandler()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Handler();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getSpeech <em>Speech</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Speech</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getSpeech()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Speech();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getTargetAudio()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getTargetMode()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getTargetName()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getTargetType()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ChoiceType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.ChoiceType#getTts()
   * @see #getChoiceType()
   * @generated
   */
  EAttribute getChoiceType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.ClosedAudioType <em>Closed Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Closed Audio Type</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType
   * @generated
   */
  EClass getClosedAudioType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ClosedAudioType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType#getValue()
   * @see #getClosedAudioType()
   * @generated
   */
  EAttribute getClosedAudioType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ClosedAudioType#getCaching <em>Caching</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Caching</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType#getCaching()
   * @see #getClosedAudioType()
   * @generated
   */
  EAttribute getClosedAudioType_Caching();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ClosedAudioType#getDir <em>Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType#getDir()
   * @see #getClosedAudioType()
   * @generated
   */
  EAttribute getClosedAudioType_Dir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ClosedAudioType#getFetchtimeout <em>Fetchtimeout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Fetchtimeout</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType#getFetchtimeout()
   * @see #getClosedAudioType()
   * @generated
   */
  EAttribute getClosedAudioType_Fetchtimeout();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ClosedAudioType#getTerminate <em>Terminate</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Terminate</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType#getTerminate()
   * @see #getClosedAudioType()
   * @generated
   */
  EAttribute getClosedAudioType_Terminate();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.ClosedAudioType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.ClosedAudioType#getTts()
   * @see #getClosedAudioType()
   * @generated
   */
  EAttribute getClosedAudioType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.DefaultRoutingType <em>Default Routing Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Default Routing Type</em>'.
   * @see com.ibm.ivr.framework.model.DefaultRoutingType
   * @generated
   */
  EClass getDefaultRoutingType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.DefaultRoutingType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.DefaultRoutingType#getValue()
   * @see #getDefaultRoutingType()
   * @generated
   */
  EAttribute getDefaultRoutingType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.DefaultRoutingType#getAlternative <em>Alternative</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Alternative</em>'.
   * @see com.ibm.ivr.framework.model.DefaultRoutingType#getAlternative()
   * @see #getDefaultRoutingType()
   * @generated
   */
  EAttribute getDefaultRoutingType_Alternative();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.DefaultRoutingType#getDnis <em>Dnis</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dnis</em>'.
   * @see com.ibm.ivr.framework.model.DefaultRoutingType#getDnis()
   * @see #getDefaultRoutingType()
   * @generated
   */
  EAttribute getDefaultRoutingType_Dnis();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.DocumentRoot <em>Document Root</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Document Root</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot
   * @generated
   */
  EClass getDocumentRoot();

  /**
   * Returns the meta object for the attribute list '{@link com.ibm.ivr.framework.model.DocumentRoot#getMixed <em>Mixed</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Mixed</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getMixed()
   * @see #getDocumentRoot()
   * @generated
   */
  EAttribute getDocumentRoot_Mixed();

  /**
   * Returns the meta object for the map '{@link com.ibm.ivr.framework.model.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getXMLNSPrefixMap()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_XMLNSPrefixMap();

  /**
   * Returns the meta object for the map '{@link com.ibm.ivr.framework.model.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the map '<em>XSI Schema Location</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getXSISchemaLocation()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_XSISchemaLocation();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getAudio <em>Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Audio</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getAudio()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Audio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getAudioConfirm <em>Audio Confirm</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Audio Confirm</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getAudioConfirm()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_AudioConfirm();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getCallRouting <em>Call Routing</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Call Routing</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getCallRouting()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_CallRouting();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getChoice <em>Choice</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Choice</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getChoice()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Choice();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getClosedAudio <em>Closed Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Closed Audio</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getClosedAudio()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_ClosedAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getDefaultRouting <em>Default Routing</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Default Routing</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getDefaultRouting()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_DefaultRouting();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getEventHandlers <em>Event Handlers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Event Handlers</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getEventHandlers()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_EventHandlers();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getEvents <em>Events</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Events</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getEvents()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Events();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getGrammar <em>Grammar</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Grammar</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getGrammar()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Grammar();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getHangup <em>Hangup</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Hangup</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getHangup()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Hangup();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getHelp <em>Help</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Help</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getHelp()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Help();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getHolidayAudio <em>Holiday Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Holiday Audio</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getHolidayAudio()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_HolidayAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getInputError <em>Input Error</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Error</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getInputError()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_InputError();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getIntroAudio <em>Intro Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Intro Audio</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getIntroAudio()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_IntroAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getMenuDefault <em>Menu Default</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Menu Default</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getMenuDefault()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_MenuDefault();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getMenuOperator <em>Menu Operator</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Menu Operator</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getMenuOperator()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_MenuOperator();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getNoInput <em>No Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>No Input</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getNoInput()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_NoInput();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getNoMatch <em>No Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>No Match</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getNoMatch()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_NoMatch();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getOperator <em>Operator</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Operator</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getOperator()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Operator();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getOutroAudio <em>Outro Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Outro Audio</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getOutroAudio()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_OutroAudio();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getSubMenu <em>Sub Menu</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Sub Menu</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getSubMenu()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_SubMenu();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getTransfer <em>Transfer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Transfer</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getTransfer()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_Transfer();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.DocumentRoot#getTransferAudio <em>Transfer Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Transfer Audio</em>'.
   * @see com.ibm.ivr.framework.model.DocumentRoot#getTransferAudio()
   * @see #getDocumentRoot()
   * @generated
   */
  EReference getDocumentRoot_TransferAudio();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.EventHandlersType <em>Event Handlers Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Event Handlers Type</em>'.
   * @see com.ibm.ivr.framework.model.EventHandlersType
   * @generated
   */
  EClass getEventHandlersType();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.EventHandlersType#getInputError <em>Input Error</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Input Error</em>'.
   * @see com.ibm.ivr.framework.model.EventHandlersType#getInputError()
   * @see #getEventHandlersType()
   * @generated
   */
  EReference getEventHandlersType_InputError();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.EventHandlersType#getNoInput <em>No Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>No Input</em>'.
   * @see com.ibm.ivr.framework.model.EventHandlersType#getNoInput()
   * @see #getEventHandlersType()
   * @generated
   */
  EReference getEventHandlersType_NoInput();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.EventHandlersType#getNoMatch <em>No Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>No Match</em>'.
   * @see com.ibm.ivr.framework.model.EventHandlersType#getNoMatch()
   * @see #getEventHandlersType()
   * @generated
   */
  EReference getEventHandlersType_NoMatch();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.EventHandlersType#getHelp <em>Help</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Help</em>'.
   * @see com.ibm.ivr.framework.model.EventHandlersType#getHelp()
   * @see #getEventHandlersType()
   * @generated
   */
  EReference getEventHandlersType_Help();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.EventsType <em>Events Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Events Type</em>'.
   * @see com.ibm.ivr.framework.model.EventsType
   * @generated
   */
  EClass getEventsType();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.EventsType#getHangup <em>Hangup</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Hangup</em>'.
   * @see com.ibm.ivr.framework.model.EventsType#getHangup()
   * @see #getEventsType()
   * @generated
   */
  EReference getEventsType_Hangup();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.EventsType#getTransfer <em>Transfer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Transfer</em>'.
   * @see com.ibm.ivr.framework.model.EventsType#getTransfer()
   * @see #getEventsType()
   * @generated
   */
  EReference getEventsType_Transfer();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.GrammarType <em>Grammar Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Grammar Type</em>'.
   * @see com.ibm.ivr.framework.model.GrammarType
   * @generated
   */
  EClass getGrammarType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.GrammarType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.GrammarType#getValue()
   * @see #getGrammarType()
   * @generated
   */
  EAttribute getGrammarType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.GrammarType#getType_ <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see com.ibm.ivr.framework.model.GrammarType#getType_()
   * @see #getGrammarType()
   * @generated
   */
  EAttribute getGrammarType_Type();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.HangupType <em>Hangup Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Hangup Type</em>'.
   * @see com.ibm.ivr.framework.model.HangupType
   * @generated
   */
  EClass getHangupType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HangupType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.HangupType#getCond()
   * @see #getHangupType()
   * @generated
   */
  EAttribute getHangupType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HangupType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.HangupType#getCounter()
   * @see #getHangupType()
   * @generated
   */
  EAttribute getHangupType_Counter();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.HelpType <em>Help Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Help Type</em>'.
   * @see com.ibm.ivr.framework.model.HelpType
   * @generated
   */
  EClass getHelpType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getValue()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getCond()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getCount <em>Count</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Count</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getCount()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Count();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getCounter()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getDest()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getDestType()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getReprompt <em>Reprompt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Reprompt</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getReprompt()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Reprompt();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getTargetAudio()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getTargetMode()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getTargetName()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getTargetType()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HelpType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.HelpType#getTts()
   * @see #getHelpType()
   * @generated
   */
  EAttribute getHelpType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.HolidayAudioType <em>Holiday Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Holiday Audio Type</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType
   * @generated
   */
  EClass getHolidayAudioType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HolidayAudioType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType#getValue()
   * @see #getHolidayAudioType()
   * @generated
   */
  EAttribute getHolidayAudioType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HolidayAudioType#getCaching <em>Caching</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Caching</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType#getCaching()
   * @see #getHolidayAudioType()
   * @generated
   */
  EAttribute getHolidayAudioType_Caching();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HolidayAudioType#getDir <em>Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType#getDir()
   * @see #getHolidayAudioType()
   * @generated
   */
  EAttribute getHolidayAudioType_Dir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HolidayAudioType#getFetchtimeout <em>Fetchtimeout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Fetchtimeout</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType#getFetchtimeout()
   * @see #getHolidayAudioType()
   * @generated
   */
  EAttribute getHolidayAudioType_Fetchtimeout();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HolidayAudioType#getTerminate <em>Terminate</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Terminate</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType#getTerminate()
   * @see #getHolidayAudioType()
   * @generated
   */
  EAttribute getHolidayAudioType_Terminate();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.HolidayAudioType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.HolidayAudioType#getTts()
   * @see #getHolidayAudioType()
   * @generated
   */
  EAttribute getHolidayAudioType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.InputErrorType <em>Input Error Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Error Type</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType
   * @generated
   */
  EClass getInputErrorType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getValue()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getCond()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getCount <em>Count</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Count</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getCount()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Count();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getCounter()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getDest()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getDestType()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getEvent <em>Event</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Event</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getEvent()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Event();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getReprompt <em>Reprompt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Reprompt</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getReprompt()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Reprompt();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getTargetAudio()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getTargetMode()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getTargetName()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getTargetType()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.InputErrorType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.InputErrorType#getTts()
   * @see #getInputErrorType()
   * @generated
   */
  EAttribute getInputErrorType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.IntroAudioType <em>Intro Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Intro Audio Type</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType
   * @generated
   */
  EClass getIntroAudioType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.IntroAudioType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType#getValue()
   * @see #getIntroAudioType()
   * @generated
   */
  EAttribute getIntroAudioType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.IntroAudioType#getCaching <em>Caching</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Caching</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType#getCaching()
   * @see #getIntroAudioType()
   * @generated
   */
  EAttribute getIntroAudioType_Caching();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.IntroAudioType#getDir <em>Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType#getDir()
   * @see #getIntroAudioType()
   * @generated
   */
  EAttribute getIntroAudioType_Dir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.IntroAudioType#getDnis <em>Dnis</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dnis</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType#getDnis()
   * @see #getIntroAudioType()
   * @generated
   */
  EAttribute getIntroAudioType_Dnis();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.IntroAudioType#getFetchtimeout <em>Fetchtimeout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Fetchtimeout</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType#getFetchtimeout()
   * @see #getIntroAudioType()
   * @generated
   */
  EAttribute getIntroAudioType_Fetchtimeout();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.IntroAudioType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.IntroAudioType#getTts()
   * @see #getIntroAudioType()
   * @generated
   */
  EAttribute getIntroAudioType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.MenuDefaultType <em>Menu Default Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Menu Default Type</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType
   * @generated
   */
  EClass getMenuDefaultType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getCond()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getCounter()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getDest()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getDestType()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getDnis <em>Dnis</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dnis</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getDnis()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_Dnis();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getHandler <em>Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Handler</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getHandler()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_Handler();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getTargetAudio()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getTargetMode()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getTargetName()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getTargetType()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuDefaultType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.MenuDefaultType#getTts()
   * @see #getMenuDefaultType()
   * @generated
   */
  EAttribute getMenuDefaultType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.MenuOperatorType <em>Menu Operator Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Menu Operator Type</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType
   * @generated
   */
  EClass getMenuOperatorType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getValue()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getCond()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getCounter()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getDest()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getDestType()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getTargetAudio()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getTargetMode()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getTargetName()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getTargetType()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.MenuOperatorType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.MenuOperatorType#getTts()
   * @see #getMenuOperatorType()
   * @generated
   */
  EAttribute getMenuOperatorType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.NoInputType <em>No Input Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>No Input Type</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType
   * @generated
   */
  EClass getNoInputType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getValue()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getCond()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getCount <em>Count</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Count</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getCount()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Count();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getCounter()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getDest()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getDestType()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getReprompt <em>Reprompt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Reprompt</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getReprompt()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Reprompt();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getTargetAudio()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getTargetMode()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getTargetName()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getTargetType()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoInputType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.NoInputType#getTts()
   * @see #getNoInputType()
   * @generated
   */
  EAttribute getNoInputType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.NoMatchType <em>No Match Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>No Match Type</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType
   * @generated
   */
  EClass getNoMatchType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getValue()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getCond()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getCount <em>Count</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Count</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getCount()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Count();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getCounter()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getDest <em>Dest</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getDest()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Dest();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getDestType <em>Dest Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dest Type</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getDestType()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_DestType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getReprompt <em>Reprompt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Reprompt</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getReprompt()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Reprompt();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getTargetAudio <em>Target Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Audio</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getTargetAudio()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_TargetAudio();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getTargetMode <em>Target Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Mode</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getTargetMode()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_TargetMode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getTargetName <em>Target Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Name</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getTargetName()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_TargetName();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getTargetType <em>Target Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Target Type</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getTargetType()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_TargetType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.NoMatchType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.NoMatchType#getTts()
   * @see #getNoMatchType()
   * @generated
   */
  EAttribute getNoMatchType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.OperatorType <em>Operator Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Operator Type</em>'.
   * @see com.ibm.ivr.framework.model.OperatorType
   * @generated
   */
  EClass getOperatorType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OperatorType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.OperatorType#getValue()
   * @see #getOperatorType()
   * @generated
   */
  EAttribute getOperatorType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OperatorType#getDnis <em>Dnis</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dnis</em>'.
   * @see com.ibm.ivr.framework.model.OperatorType#getDnis()
   * @see #getOperatorType()
   * @generated
   */
  EAttribute getOperatorType_Dnis();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.OutroAudioType <em>Outro Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Outro Audio Type</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType
   * @generated
   */
  EClass getOutroAudioType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OutroAudioType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType#getValue()
   * @see #getOutroAudioType()
   * @generated
   */
  EAttribute getOutroAudioType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OutroAudioType#getCaching <em>Caching</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Caching</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType#getCaching()
   * @see #getOutroAudioType()
   * @generated
   */
  EAttribute getOutroAudioType_Caching();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OutroAudioType#getDir <em>Dir</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType#getDir()
   * @see #getOutroAudioType()
   * @generated
   */
  EAttribute getOutroAudioType_Dir();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OutroAudioType#getDnis <em>Dnis</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dnis</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType#getDnis()
   * @see #getOutroAudioType()
   * @generated
   */
  EAttribute getOutroAudioType_Dnis();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OutroAudioType#getFetchtimeout <em>Fetchtimeout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Fetchtimeout</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType#getFetchtimeout()
   * @see #getOutroAudioType()
   * @generated
   */
  EAttribute getOutroAudioType_Fetchtimeout();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.OutroAudioType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.OutroAudioType#getTts()
   * @see #getOutroAudioType()
   * @generated
   */
  EAttribute getOutroAudioType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.SubMenuType <em>Sub Menu Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Sub Menu Type</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType
   * @generated
   */
  EClass getSubMenuType();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getAudio <em>Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Audio</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getAudio()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_Audio();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getAudioConfirm <em>Audio Confirm</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Audio Confirm</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getAudioConfirm()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_AudioConfirm();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.SubMenuType#getGrammar <em>Grammar</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Grammar</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getGrammar()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_Grammar();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getChoice <em>Choice</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Choice</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getChoice()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_Choice();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getMenuOperator <em>Menu Operator</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Menu Operator</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getMenuOperator()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_MenuOperator();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getMenuDefault <em>Menu Default</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Menu Default</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getMenuDefault()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_MenuDefault();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getInputError <em>Input Error</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Input Error</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getInputError()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_InputError();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getNoInput <em>No Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>No Input</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getNoInput()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_NoInput();

  /**
   * Returns the meta object for the containment reference list '{@link com.ibm.ivr.framework.model.SubMenuType#getNoMatch <em>No Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>No Match</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getNoMatch()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_NoMatch();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.SubMenuType#getHelp <em>Help</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Help</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getHelp()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_Help();

  /**
   * Returns the meta object for the containment reference '{@link com.ibm.ivr.framework.model.SubMenuType#getEvents <em>Events</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Events</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getEvents()
   * @see #getSubMenuType()
   * @generated
   */
  EReference getSubMenuType_Events();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getClearDTMFBuffer <em>Clear DTMF Buffer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Clear DTMF Buffer</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getClearDTMFBuffer()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_ClearDTMFBuffer();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getCounter()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Counter();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getEndCall <em>End Call</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>End Call</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getEndCall()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_EndCall();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getHangup <em>Hangup</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Hangup</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getHangup()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Hangup();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getMarkPosition <em>Mark Position</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Mark Position</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getMarkPosition()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_MarkPosition();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getMaxretries <em>Maxretries</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Maxretries</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getMaxretries()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Maxretries();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getMode <em>Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Mode</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getMode()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Mode();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getName()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Name();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getRecordingConfirmation <em>Recording Confirmation</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Recording Confirmation</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getRecordingConfirmation()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_RecordingConfirmation();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getRepeat <em>Repeat</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Repeat</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getRepeat()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Repeat();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getRetry <em>Retry</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Retry</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getRetry()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Retry();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getSet <em>Set</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Set</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getSet()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Set();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getType_ <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getType_()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Type();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getVxml <em>Vxml</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Vxml</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getVxml()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Vxml();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.SubMenuType#getWait <em>Wait</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Wait</em>'.
   * @see com.ibm.ivr.framework.model.SubMenuType#getWait()
   * @see #getSubMenuType()
   * @generated
   */
  EAttribute getSubMenuType_Wait();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.TransferAudioType <em>Transfer Audio Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Transfer Audio Type</em>'.
   * @see com.ibm.ivr.framework.model.TransferAudioType
   * @generated
   */
  EClass getTransferAudioType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.TransferAudioType#getValue <em>Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Value</em>'.
   * @see com.ibm.ivr.framework.model.TransferAudioType#getValue()
   * @see #getTransferAudioType()
   * @generated
   */
  EAttribute getTransferAudioType_Value();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.TransferAudioType#getTts <em>Tts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Tts</em>'.
   * @see com.ibm.ivr.framework.model.TransferAudioType#getTts()
   * @see #getTransferAudioType()
   * @generated
   */
  EAttribute getTransferAudioType_Tts();

  /**
   * Returns the meta object for class '{@link com.ibm.ivr.framework.model.TransferType <em>Transfer Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Transfer Type</em>'.
   * @see com.ibm.ivr.framework.model.TransferType
   * @generated
   */
  EClass getTransferType();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.TransferType#getCond <em>Cond</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Cond</em>'.
   * @see com.ibm.ivr.framework.model.TransferType#getCond()
   * @see #getTransferType()
   * @generated
   */
  EAttribute getTransferType_Cond();

  /**
   * Returns the meta object for the attribute '{@link com.ibm.ivr.framework.model.TransferType#getCounter <em>Counter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Counter</em>'.
   * @see com.ibm.ivr.framework.model.TransferType#getCounter()
   * @see #getTransferType()
   * @generated
   */
  EAttribute getTransferType_Counter();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  ModelFactory getModelFactory();

} //ModelPackage
