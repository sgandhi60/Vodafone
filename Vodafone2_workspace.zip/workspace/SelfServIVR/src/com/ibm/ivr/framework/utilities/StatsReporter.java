package com.ibm.ivr.framework.utilities;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.log4j.Logger;

/**
 * The default reporter to write statistics in a file
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-16: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-16
 *  
 */
public class StatsReporter implements Reporter {
	//define the private logger
	private static Logger LOGGER = Logger.getLogger(StatsReporter.class);

	//define the static hashtable for holding the call information during the
	// call
	private static Hashtable callTable = new Hashtable();

	/**
	 * Used by IVR to report call start
	 * 
	 * @param ani
	 *            ani of the call
	 * @param dnis
	 *            dnis of the call
	 * @param sessionID
	 *            unique session id of the call
	 * @param appName
	 *            application reached by the call
	 */
	public void callStart(String ani, String dnis, String sessionID,
			String appName) {

		String logToken = new StringBuffer("[").append(sessionID).append("] ").append("[").append(appName).append("]: ")
		.toString();

		if (sessionID == null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("sessionID is null, returning..."));
			return;
		}
		
		if (callTable.get(sessionID) != null)
		{
			LOGGER.warn(new StringBuffer(logToken).append("START event already sent, returning..."));
			return;		
		}
		
		CallStats callStats = new CallStats(ani, dnis, sessionID, appName);

		// log call starting timestamp
		Timestamp curTS = new Timestamp((new java.util.Date()).getTime());
		callStats.setCallStartTime(curTS);

		callTable.put(sessionID, callStats);

		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken).append("call started at: ")
				.append(curTS).append("; DNIS=").append(dnis).append("; ANI=")
				.append(ani));

	}

	/**
	 * Used by IVR to report call end
	 * 
	 * @param sessionID
	 *            unique session id of the call
	 * @param appName
	 *            application reached by the call
	 * @param exitReason
	 *            the exit reason of the call
	 * @param mode
	 *            the ending mode of the call, DTMF/SPEECH/HYBRID
	 */
	public void callEnd(String sessionID, String appName, String exitReason,
			String mode) {

		String logToken = new StringBuffer("[").append(sessionID).append("] ").append("[").append(appName).append("]: ")
		.toString();

		if (sessionID == null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("sessionID is null, returning..."));
			return;
		}

		CallStats callStats = (CallStats) callTable.get(sessionID);

		Timestamp startTS = callStats.getCallStartTime();

		Timestamp curTS = new Timestamp((new java.util.Date()).getTime());

		long diff = curTS.getTime() - startTS.getTime();


		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken).append("call ended at: ")
				.append(curTS));

		StringBuffer sb = new StringBuffer(logToken);
		sb.append("status=").append(exitReason).append("; mode=").append(mode)
				.append("; duration=").append(diff / 1000).append("s");

		HashMap events = callStats.getEvents();
		if (events != null) {
			Iterator keys = events.keySet().iterator();
			while (keys.hasNext()) {
				String eventKey = (String) keys.next();
				String eventValue = events.get(eventKey).toString();
				sb.append("; ").append(eventKey).append("=").append(eventValue);
			}			
		}
		if (LOGGER.isTraceEnabled())
			LOGGER.info(sb);
		
		callTable.remove(sessionID);
	}

	/**
	 * Used by IVR to report call events collectd at the end of the call
	 * 
	 * @param sessionID	unique session id of the call
	 * @param appName		application reached by the call
	 * @param eventName	the name of the event to be logged
	 */
	public void callEvent (String sessionID, String appName, String eventName){

		String logToken = new StringBuffer("[").append(sessionID).append("] ").append("[").append(appName).append("]: ")
		.toString();

		if (sessionID == null) {
			LOGGER.warn(new StringBuffer(logToken)
					.append("sessionID is null, returning..."));
			return;
		}
		
		CallStats callStats = (CallStats) callTable.get(sessionID);

		callStats.addEvent(eventName);

	}
	
	/**
	 * Used by IVR to check if callStart has been logged
	 * 
	 * @param sessionID	unique session id of the call
	 * @return true if already logged, false otherwise
	 */
	public boolean isCallStarted(String sessionID){
		return (callTable.get(sessionID) != null);
	}
	
	/*
	 * get the current number of concurrent sessions
	 * 
	 * @return the size of the callTable
	 */
	public int getNumOfSessions(){
		return callTable.size();
	}

}
