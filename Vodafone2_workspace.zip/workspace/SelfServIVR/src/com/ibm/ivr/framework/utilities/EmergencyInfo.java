/*
 * Created on Apr 15, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.ivr.framework.utilities;

/**
 * @author fangwang
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EmergencyInfo {
	private boolean mode = false;
	private String startTime = "0000";
	private String endTime = "2359";
	private String type = null;
	private int msgSize = 0;
	
	/**
	 * @return Returns the msgSize.
	 */
	public int getMsgSize() {
		return msgSize;
	}
	/**
	 * Constructor
	 */
	public EmergencyInfo(boolean mode, String startTime, String endTime, String type, int msgSize){
		this.mode = mode;
		this.startTime = startTime;
		this.endTime = endTime;
		this.type = type;
		this.msgSize = msgSize;
	}
	
	/**
	 * @return Returns the endTime.
	 */
	public String getEndTime() {
		return endTime;
	}
	/**
	 * @return Returns the mode.
	 */
	public boolean isMode() {
		return mode;
	}
	/**
	 * @return Returns the startTime.
	 */
	public String getStartTime() {
		return startTime;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
}
