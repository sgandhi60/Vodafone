/**
 * <copyright>
 * </copyright>
 *
 * $Id: AudioConfirmTypeImpl.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.impl;

import com.ibm.ivr.framework.model.AudioConfirmType;
import com.ibm.ivr.framework.model.ModelPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Audio Confirm Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl#getCaching <em>Caching</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl#getDir <em>Dir</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl#getFetchtimeout <em>Fetchtimeout</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl#getListCount <em>List Count</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.impl.AudioConfirmTypeImpl#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AudioConfirmTypeImpl extends EDataObjectImpl implements AudioConfirmType
{
  /**
   * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected static final String VALUE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected String value = VALUE_EDEFAULT;

  /**
   * The default value of the '{@link #getCaching() <em>Caching</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCaching()
   * @generated
   * @ordered
   */
  protected static final String CACHING_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCaching() <em>Caching</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCaching()
   * @generated
   * @ordered
   */
  protected String caching = CACHING_EDEFAULT;

  /**
   * The default value of the '{@link #getDir() <em>Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDir()
   * @generated
   * @ordered
   */
  protected static final String DIR_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDir() <em>Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDir()
   * @generated
   * @ordered
   */
  protected String dir = DIR_EDEFAULT;

  /**
   * The default value of the '{@link #getFetchtimeout() <em>Fetchtimeout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFetchtimeout()
   * @generated
   * @ordered
   */
  protected static final String FETCHTIMEOUT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getFetchtimeout() <em>Fetchtimeout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFetchtimeout()
   * @generated
   * @ordered
   */
  protected String fetchtimeout = FETCHTIMEOUT_EDEFAULT;

  /**
   * The default value of the '{@link #getListCount() <em>List Count</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getListCount()
   * @generated
   * @ordered
   */
  protected static final String LIST_COUNT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getListCount() <em>List Count</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getListCount()
   * @generated
   * @ordered
   */
  protected String listCount = LIST_COUNT_EDEFAULT;

  /**
   * The default value of the '{@link #getTts() <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTts()
   * @generated
   * @ordered
   */
  protected static final String TTS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTts() <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTts()
   * @generated
   * @ordered
   */
  protected String tts = TTS_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AudioConfirmTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ModelPackage.eINSTANCE.getAudioConfirmType();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValue(String newValue)
  {
    String oldValue = value;
    value = newValue;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.AUDIO_CONFIRM_TYPE__VALUE, oldValue, value));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCaching()
  {
    return caching;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCaching(String newCaching)
  {
    String oldCaching = caching;
    caching = newCaching;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.AUDIO_CONFIRM_TYPE__CACHING, oldCaching, caching));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDir()
  {
    return dir;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDir(String newDir)
  {
    String oldDir = dir;
    dir = newDir;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.AUDIO_CONFIRM_TYPE__DIR, oldDir, dir));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getFetchtimeout()
  {
    return fetchtimeout;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFetchtimeout(String newFetchtimeout)
  {
    String oldFetchtimeout = fetchtimeout;
    fetchtimeout = newFetchtimeout;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.AUDIO_CONFIRM_TYPE__FETCHTIMEOUT, oldFetchtimeout, fetchtimeout));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getListCount()
  {
    return listCount;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setListCount(String newListCount)
  {
    String oldListCount = listCount;
    listCount = newListCount;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.AUDIO_CONFIRM_TYPE__LIST_COUNT, oldListCount, listCount));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTts()
  {
    return tts;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTts(String newTts)
  {
    String oldTts = tts;
    tts = newTts;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.AUDIO_CONFIRM_TYPE__TTS, oldTts, tts));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.AUDIO_CONFIRM_TYPE__VALUE:
        return getValue();
      case ModelPackage.AUDIO_CONFIRM_TYPE__CACHING:
        return getCaching();
      case ModelPackage.AUDIO_CONFIRM_TYPE__DIR:
        return getDir();
      case ModelPackage.AUDIO_CONFIRM_TYPE__FETCHTIMEOUT:
        return getFetchtimeout();
      case ModelPackage.AUDIO_CONFIRM_TYPE__LIST_COUNT:
        return getListCount();
      case ModelPackage.AUDIO_CONFIRM_TYPE__TTS:
        return getTts();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.AUDIO_CONFIRM_TYPE__VALUE:
        setValue((String)newValue);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__CACHING:
        setCaching((String)newValue);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__DIR:
        setDir((String)newValue);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__FETCHTIMEOUT:
        setFetchtimeout((String)newValue);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__LIST_COUNT:
        setListCount((String)newValue);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__TTS:
        setTts((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.AUDIO_CONFIRM_TYPE__VALUE:
        setValue(VALUE_EDEFAULT);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__CACHING:
        setCaching(CACHING_EDEFAULT);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__DIR:
        setDir(DIR_EDEFAULT);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__FETCHTIMEOUT:
        setFetchtimeout(FETCHTIMEOUT_EDEFAULT);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__LIST_COUNT:
        setListCount(LIST_COUNT_EDEFAULT);
        return;
      case ModelPackage.AUDIO_CONFIRM_TYPE__TTS:
        setTts(TTS_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case ModelPackage.AUDIO_CONFIRM_TYPE__VALUE:
        return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
      case ModelPackage.AUDIO_CONFIRM_TYPE__CACHING:
        return CACHING_EDEFAULT == null ? caching != null : !CACHING_EDEFAULT.equals(caching);
      case ModelPackage.AUDIO_CONFIRM_TYPE__DIR:
        return DIR_EDEFAULT == null ? dir != null : !DIR_EDEFAULT.equals(dir);
      case ModelPackage.AUDIO_CONFIRM_TYPE__FETCHTIMEOUT:
        return FETCHTIMEOUT_EDEFAULT == null ? fetchtimeout != null : !FETCHTIMEOUT_EDEFAULT.equals(fetchtimeout);
      case ModelPackage.AUDIO_CONFIRM_TYPE__LIST_COUNT:
        return LIST_COUNT_EDEFAULT == null ? listCount != null : !LIST_COUNT_EDEFAULT.equals(listCount);
      case ModelPackage.AUDIO_CONFIRM_TYPE__TTS:
        return TTS_EDEFAULT == null ? tts != null : !TTS_EDEFAULT.equals(tts);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (value: ");
    result.append(value);
    result.append(", caching: ");
    result.append(caching);
    result.append(", dir: ");
    result.append(dir);
    result.append(", fetchtimeout: ");
    result.append(fetchtimeout);
    result.append(", listCount: ");
    result.append(listCount);
    result.append(", tts: ");
    result.append(tts);
    result.append(')');
    return result.toString();
  }

} //AudioConfirmTypeImpl
