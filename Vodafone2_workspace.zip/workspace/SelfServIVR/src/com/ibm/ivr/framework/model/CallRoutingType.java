/**
 * <copyright>
 * </copyright>
 *
 * $Id: CallRoutingType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Call Routing Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getIntroAudio <em>Intro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getOutroAudio <em>Outro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getHolidayAudio <em>Holiday Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getClosedAudio <em>Closed Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getTransferAudio <em>Transfer Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getOperator <em>Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getMenuOperator <em>Menu Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getEvents <em>Events</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getEventHandlers <em>Event Handlers</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getDefaultRouting <em>Default Routing</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getSubMenu <em>Sub Menu</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getAudioDir <em>Audio Dir</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getCallProperties <em>Call Properties</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getCleanupHandler <em>Cleanup Handler</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getCommon <em>Common</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getFileVersion <em>File Version</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getMain <em>Main</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getName <em>Name</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getReleaseVersion <em>Release Version</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getStart <em>Start</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.CallRoutingType#getStartMode <em>Start Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType()
 * @model 
 * @generated
 */
public interface CallRoutingType
{
  /**
   * Returns the value of the '<em><b>Intro Audio</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.IntroAudioType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Intro Audio</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Intro Audio</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_IntroAudio()
   * @model type="com.ibm.ivr.framework.model.IntroAudioType" containment="true" resolveProxies="false"
   * @generated
   */
  List getIntroAudio();

  /**
   * Returns the value of the '<em><b>Outro Audio</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.OutroAudioType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Outro Audio</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Outro Audio</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_OutroAudio()
   * @model type="com.ibm.ivr.framework.model.OutroAudioType" containment="true" resolveProxies="false"
   * @generated
   */
  List getOutroAudio();

  /**
   * Returns the value of the '<em><b>Holiday Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Holiday Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Holiday Audio</em>' containment reference.
   * @see #setHolidayAudio(HolidayAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_HolidayAudio()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  HolidayAudioType getHolidayAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getHolidayAudio <em>Holiday Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Holiday Audio</em>' containment reference.
   * @see #getHolidayAudio()
   * @generated
   */
  void setHolidayAudio(HolidayAudioType value);

  /**
   * Returns the value of the '<em><b>Closed Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Closed Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Closed Audio</em>' containment reference.
   * @see #setClosedAudio(ClosedAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_ClosedAudio()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  ClosedAudioType getClosedAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getClosedAudio <em>Closed Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Closed Audio</em>' containment reference.
   * @see #getClosedAudio()
   * @generated
   */
  void setClosedAudio(ClosedAudioType value);

  /**
   * Returns the value of the '<em><b>Transfer Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transfer Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transfer Audio</em>' containment reference.
   * @see #setTransferAudio(TransferAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_TransferAudio()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  TransferAudioType getTransferAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getTransferAudio <em>Transfer Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Transfer Audio</em>' containment reference.
   * @see #getTransferAudio()
   * @generated
   */
  void setTransferAudio(TransferAudioType value);

  /**
   * Returns the value of the '<em><b>Operator</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Operator</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Operator</em>' containment reference.
   * @see #setOperator(OperatorType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_Operator()
   * @model containment="true" resolveProxies="false" required="true"
   * @generated
   */
  OperatorType getOperator();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getOperator <em>Operator</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Operator</em>' containment reference.
   * @see #getOperator()
   * @generated
   */
  void setOperator(OperatorType value);

  /**
   * Returns the value of the '<em><b>Menu Operator</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.MenuOperatorType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Menu Operator</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Menu Operator</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_MenuOperator()
   * @model type="com.ibm.ivr.framework.model.MenuOperatorType" containment="true" resolveProxies="false"
   * @generated
   */
  List getMenuOperator();

  /**
   * Returns the value of the '<em><b>Events</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Events</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Events</em>' containment reference.
   * @see #setEvents(EventsType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_Events()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  EventsType getEvents();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getEvents <em>Events</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Events</em>' containment reference.
   * @see #getEvents()
   * @generated
   */
  void setEvents(EventsType value);

  /**
   * Returns the value of the '<em><b>Event Handlers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Event Handlers</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Event Handlers</em>' containment reference.
   * @see #setEventHandlers(EventHandlersType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_EventHandlers()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  EventHandlersType getEventHandlers();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getEventHandlers <em>Event Handlers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Event Handlers</em>' containment reference.
   * @see #getEventHandlers()
   * @generated
   */
  void setEventHandlers(EventHandlersType value);

  /**
   * Returns the value of the '<em><b>Default Routing</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.DefaultRoutingType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Default Routing</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Default Routing</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_DefaultRouting()
   * @model type="com.ibm.ivr.framework.model.DefaultRoutingType" containment="true" resolveProxies="false"
   * @generated
   */
  List getDefaultRouting();

  /**
   * Returns the value of the '<em><b>Sub Menu</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.SubMenuType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub Menu</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub Menu</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_SubMenu()
   * @model type="com.ibm.ivr.framework.model.SubMenuType" containment="true" resolveProxies="false" required="true"
   * @generated
   */
  List getSubMenu();

  /**
   * Returns the value of the '<em><b>Audio Dir</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Audio Dir</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Audio Dir</em>' attribute.
   * @see #setAudioDir(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_AudioDir()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getAudioDir();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getAudioDir <em>Audio Dir</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Audio Dir</em>' attribute.
   * @see #getAudioDir()
   * @generated
   */
  void setAudioDir(String value);

  /**
   * Returns the value of the '<em><b>Call Properties</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Call Properties</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Call Properties</em>' attribute.
   * @see #setCallProperties(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_CallProperties()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCallProperties();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getCallProperties <em>Call Properties</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Call Properties</em>' attribute.
   * @see #getCallProperties()
   * @generated
   */
  void setCallProperties(String value);

  /**
   * Returns the value of the '<em><b>Cleanup Handler</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Cleanup Handler</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Cleanup Handler</em>' attribute.
   * @see #setCleanupHandler(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_CleanupHandler()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCleanupHandler();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getCleanupHandler <em>Cleanup Handler</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Cleanup Handler</em>' attribute.
   * @see #getCleanupHandler()
   * @generated
   */
  void setCleanupHandler(String value);

  /**
   * Returns the value of the '<em><b>Common</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Common</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Common</em>' attribute.
   * @see #setCommon(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_Common()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getCommon();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getCommon <em>Common</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Common</em>' attribute.
   * @see #getCommon()
   * @generated
   */
  void setCommon(String value);

  /**
   * Returns the value of the '<em><b>File Version</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>File Version</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>File Version</em>' attribute.
   * @see #setFileVersion(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_FileVersion()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getFileVersion();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getFileVersion <em>File Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>File Version</em>' attribute.
   * @see #getFileVersion()
   * @generated
   */
  void setFileVersion(String value);

  /**
   * Returns the value of the '<em><b>Main</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Main</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Main</em>' attribute.
   * @see #setMain(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_Main()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getMain();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getMain <em>Main</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Main</em>' attribute.
   * @see #getMain()
   * @generated
   */
  void setMain(String value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_Name()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Release Version</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Release Version</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Release Version</em>' attribute.
   * @see #setReleaseVersion(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_ReleaseVersion()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getReleaseVersion();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getReleaseVersion <em>Release Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Release Version</em>' attribute.
   * @see #getReleaseVersion()
   * @generated
   */
  void setReleaseVersion(String value);

  /**
   * Returns the value of the '<em><b>Start</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Start</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Start</em>' attribute.
   * @see #setStart(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_Start()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getStart();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getStart <em>Start</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Start</em>' attribute.
   * @see #getStart()
   * @generated
   */
  void setStart(String value);

  /**
   * Returns the value of the '<em><b>Start Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Start Mode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Start Mode</em>' attribute.
   * @see #setStartMode(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getCallRoutingType_StartMode()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   * @generated
   */
  String getStartMode();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.CallRoutingType#getStartMode <em>Start Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Start Mode</em>' attribute.
   * @see #getStartMode()
   * @generated
   */
  void setStartMode(String value);

} // CallRoutingType
