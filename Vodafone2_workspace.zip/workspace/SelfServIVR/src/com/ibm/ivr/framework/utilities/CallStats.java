package com.ibm.ivr.framework.utilities;

import java.sql.Timestamp;
import java.util.HashMap;


/**
 * The class holding the call statistics information
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-16: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-16
 *  
 */
public class CallStats {
	String ani = null;
	String dnis = null;
	String sessionID = null;
	String appID = null;
	Timestamp callStartTime = null;
	HashMap events = new HashMap();
	int varEventSeq = 0;

	/**
	 * Constructor
	 * 
	 * @param ani		ani of the call
	 * @param dnis 		dnis of the call
	 * @param sessionID	unique session id of the call
	 * @param appID		application reached by the call
	 */
	public CallStats(String ani, String dnis, String sessionID, String appID) {
		super();
		this.ani = ani;
		this.dnis = dnis;
		this.sessionID = sessionID;
		this.appID = appID;
	}
	
	/**
	 * Add event to the events hashmap
	 * @param eventName the name of the event
	 */
	public void addEvent(String eventName){
		if (eventName.length() != 0) {
			if (events.containsKey(eventName)) {
				int value = ((Integer) events.get(eventName))
						.intValue();
				events.put(eventName, new Integer(value + 1));
			} else {
				events.put(eventName, new Integer(1));
			}
		}
	}
	
	/**
	 * @return Returns the events.
	 */
	public HashMap getEvents() {
		return events;
	}
	/**
	 * @param events The events to set.
	 */
	public void setEvents(HashMap events) {
		this.events = events;
	}
	/**
	 * @return Returns the ani.
	 */
	public String getAni() {
		return ani;
	}
	/**
	 * @return Returns the appID.
	 */
	public String getAppID() {
		return appID;
	}
	/**
	 * @return Returns the callStartTime.
	 */
	public Timestamp getCallStartTime() {
		return callStartTime;
	}
	/**
	 * @return Returns the dnis.
	 */
	public String getDnis() {
		return dnis;
	}
	/**
	 * @return Returns the sessionID.
	 */
	public String getSessionID() {
		return sessionID;
	}
	/**
	 * @param callStartTime The callStartTime to set.
	 */
	public void setCallStartTime(Timestamp callStartTime) {
		this.callStartTime = callStartTime;
	}
	
	/**
	 * @return Returns the varEventSeq.
	 */
	public int getVarEventSeq() {
		return varEventSeq;
	}
	/**
	 * @param varEventSeq The varEventSeq to set.
	 */
	public void setVarEventSeq(int varEventSeq) {
		this.varEventSeq = varEventSeq;
	}
}
