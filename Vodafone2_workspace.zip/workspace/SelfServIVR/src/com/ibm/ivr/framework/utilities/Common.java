/*
 * Created on Mar 7, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.ivr.framework.utilities;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.sdo.EDataGraph;
import org.eclipse.emf.ecore.sdo.SDOFactory;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.DocumentRoot;
import com.ibm.ivr.framework.model.IntroAudioType;
import com.ibm.ivr.framework.model.util.ModelResourceUtil;

/**
 * The Java class provide common utilities methods to the framework
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-05: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-07
 *  
 */
public class Common {

	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(Common.class);

	/*
	 * Fields used for logging selections in callRoute
	 */
	public static String SPEECH_MODE = "s";

	public static String DTMF_MODE = "d";

	public static String HYBRID_MODE = "h";

	public static String SPEECH = "speech";

	public static String DTMF = "dtmf";

	public static String HYBRID = "hybrid";

	public static String COLON = ":";

	public static String SEPARATOR = "->";

	public static String SPACE = " ";
	
	public static String EMPTYSTRING = "";

	/*
	 * true and false constant
	 */
	public static String TRUE = "true";

	public static String FALSE = "false";

	/*
	 * Fields used for logging end status in callRoute
	 */
	public static String HUP = "HUP";

	public static String OPERATOR = "OPER";

	public static String ERROR = "ERR";

	
	/*
	 * Fields used for logging end action in VARReporter
	 */
	public static String END_NORMAL = "01";

	public static String END_TRANSFERRED = "02";

	public static String END_ABANDONED = "03";

	
	/*
	 * Fields used for logging application result in VARReporter
	 */
	public static String END_SUCCESS = "S";

	public static String END_FAILED = "F";
	
	/*
	 * Fields used for condition checking and session var assignment
	 */
	public static String SPACECHAR = "SPACECHAR";
	
	public static String NULL = "NULL";
	
	/*
	 * Fields used for by RoutingTag
	 */
	public static String SCOPE_LOCAL = "LOCAL";

	public static String SCOPE_GLOBAL = "GLOBAL";
	/*
	 * Month audio file name
	 */

	public static String[] MONTHS = new String[] { "", "january", "february",
			"march", "april", "may", "june", "july", "august", "september",
			"october", "november", "december" };

	/*
	 * Date audio file name
	 */

	public static String[] DATE = new String[] { "", "first", "second",
			"third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth",
			"tenth", "eleventh", "twelfth", "thirteenth", "fourteenth",
			"fifteenth", "sixteenth", "seventeenth", "eighteenth",
			"nineteenth", "twentieth", "twenty-first", "twenty-second",
			"twenty-third", "twenty-fourth", "twenty-fifth", "twenty-sixth",
			"twenty-seventh", "twenty-eighth", "twenty-ninth", "thirtieth",
			"thirty-first" };

	/*
	 * Number audio file name
	 */

	public static String[] NUMBER = new String[] { "zero", "one", "two", "three",
			"four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
			"twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
			"eighteen", "nineteen", "twenty", "twenty-one", "twenty-two",
			"twenty-three", "twenty-four", "twenty-five", "twenty-six",
			"twenty-seven", "twenty-eight", "twenty-nine", "thirty",
			"thirty-one", "thirty-two", "thirty-three", "thirty-four",
			"thirty-five", "thirty-six", "thirty-seven", "thirty-eight",
			"thirty-nine", "forty", "forty-one", "forty-two", "forty-three",
			"forty-four", "forty-five", "forty-six", "forty-seven",
			"forty-eight", "forty-nine", "fifty", "fifty-one", "fifty-two",
			"fifty-three", "fifty-four", "fifty-five", "fifty-six",
			"fifty-seven", "fifty-eight", "fifty-nine", "sixty", "sixty-one",
			"sixty-two", "sixty-three", "sixty-four", "sixty-five",
			"sixty-six", "sixty-seven", "sixty-eight", "sixty-nine", "seventy",
			"seventy-one", "seventy-two", "seventy-three", "seventy-four",
			"seventy-five", "seventy-six", "seventy-seven", "seventy-eight",
			"seventy-nine", "eighty", "eighty-one", "eighty-two",
			"eighty-three", "eighty-four", "eighty-five", "eighty-six",
			"eighty-seven", "eighty-eight", "eighty-nine", "ninety",
			"ninety-one", "ninety-two", "ninety-three", "ninety-four",
			"ninety-five", "ninety-six", "ninety-seven", "ninety-eight",
			"ninety-nine", "one-hundred" };

	/**
	 * loads XML file
	 * 
	 * @param xmlFileURL
	 * @return CallRoutingType object in the xml file
	 */
	public static CallRoutingType loadXML(String xmlFileURL) throws Exception {

		CallRoutingType iCallRouting = null;

		ModelResourceUtil ivrResourceUtil = ModelResourceUtil.getInstance();

		try {
			// Load the document
			DocumentRoot dr = ivrResourceUtil.load(xmlFileURL);
			EDataGraph eDataGraph = SDOFactory.eINSTANCE.createEDataGraph();
			eDataGraph.setERootObject((EObject)dr);
			iCallRouting = (CallRoutingType) dr.getCallRouting();
		} catch (Exception e) {
			LOGGER
					.fatal("Unable to open " + xmlFileURL + ": "
							+ e.getMessage());
			throw (new Exception("Unable to open " + xmlFileURL + ": "
					+ e.getMessage()));
		}

		if (iCallRouting == null) {
			LOGGER.fatal("Loading " + xmlFileURL + " failed");
			throw new Exception("Loading " + xmlFileURL + " failed");
		}

		if (LOGGER.isTraceEnabled())
			LOGGER.info(xmlFileURL + " loaded successfully");

		return iCallRouting;

	}

	/**
	 * Get session Variable value from an array
	 * 
	 * @param var
	 *            session variable or the member/property/key of session
	 *            variable, in Array type
	 * @param session
	 *            The session to get the value from
	 * @param index
	 *            the index in the array to get the value
	 * @return session variable value, null if not existing
	 */
	public static Object getSessionValueFromArray(String var,
			HttpSession session, int index) {
		Object[] array = null;
		Object value = null;
		int i = var.indexOf(".");

		if (i == -1) {
			array = (Object[]) session.getAttribute(var);
			if (array == null)
				return null;
		} else {
			Object v = session.getAttribute(var.substring(0, i));
			String m = var.substring(i + 1);

			if (v == null) {
				return null;
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.Hashtable")) {
				array = (Object[]) ((Hashtable) v).get(m);
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.HashMap")) {
				array = (Object[]) ((HashMap) v).get(m);
			} else {
				try {
					String name = "get" + m.substring(0, 1).toUpperCase()
							+ m.substring(1);
					Method method = v.getClass().getMethod(name, null);
					array = (Object[]) method.invoke(v, null);
				} catch (Exception e) {
					return null;
				}

			}
		}
		value = array[index];

		return value;
	}

	/**
	 * Get session Variable value
	 * 
	 * @param var
	 *            session variable or the member/property/key of session
	 *            variable
	 * @param session
	 *            The session to get the value from
	 * @return session variable value, null if not existing
	 */
	public static Object getSessionValue(String var, HttpSession session) {
		Object value = null;
		int index = var.indexOf(".");
		if (index == -1) {
			value = session.getAttribute(var);
		} else {
			Object v = session.getAttribute(var.substring(0, index));
			String m = var.substring(index + 1);

			if (v == null) {
				value = null;
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.Properties")) {
				value = ((Properties) v).getProperty(m);
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.Hashtable")) {
				value = ((Hashtable) v).get(m);
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.HashMap")) {
				value = ((HashMap) v).get(m);
			} else {
				try {
					String name = "get" + m.substring(0, 1).toUpperCase()
							+ m.substring(1);
					Method method = v.getClass().getMethod(name, null);
					value = method.invoke(v, null);
				} catch (Exception e) {
					value = null;
				}

			}
		}
		return value;
	}

	/**
	 * Set session Variable value
	 * 
	 * @param var
	 *            session variable or the member/property/key of session
	 *            variable
	 * @param value
	 *            the String value to be set to the member/property/key of
	 *            session variable
	 * @param session
	 *            The session to set the value to
	 */
	public static void setSessionValue(String var, Object value,
			HttpSession session) throws Exception {
		
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall"))
		.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
			.toString();

		int index = var.indexOf(".");
		
		//if value has the reserved word "SPACECHAR", then it is converted to space string before continue
		if (value != null && value.toString().equalsIgnoreCase(Common.SPACECHAR))
			value = Common.SPACE;
		
		//if value has the reserved word "NULL", then it is converted to null before continue
		if (value != null && value.toString().equalsIgnoreCase(Common.NULL))
			value = null;
		
		if (index == -1) {
			if (value == null)
				session.removeAttribute(var);
			else
				session.setAttribute(var, value);
		} else {
			String vName = var.substring(0, index);
			Object v = session.getAttribute(vName);
			String m = var.substring(index + 1);

			if (v == null) {
				throw new Exception(vName + " does not exist in session");
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.Properties")) {
				if (value == null)
					((Properties) v).setProperty(m, null);
				else
					((Properties) v).setProperty(m, value.toString());
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.Hashtable")) {
				//commented out the String NULL checking
				//if (value == null || value.toString().equalsIgnoreCase("NULL"))
				if (value == null){
					((Hashtable) v).remove(m);  
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken)
							.append("Remove ").append(var));
				}
				else
					((Hashtable) v).put(m, value);
			} else if (v.getClass().getName().equalsIgnoreCase(
					"java.util.HashMap")) {
				if (value == null){
					((HashMap) v).remove(m);
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken)
							.append("Remove ").append(var));
				}
				else 
					((HashMap) v).put(m, value);
			} else {
				try {
					String name = "set" + m.substring(0, 1).toUpperCase()
							+ m.substring(1);
					//this code will have problem if value is null, need
					//find a better way to work around this when value is null 
					//to dynamically find the method
					Class[] paramType = new Class[] { value.getClass() };
					Method method = v.getClass().getMethod(name, paramType);
					Object[] param = new Object[] { value };
					value = method.invoke(v, param);
				} catch (Exception e) {
					throw new Exception("setter method of " + m + " on "
							+ vName + " execution failed: " + e.getMessage());
				}
			}
			session.setAttribute(vName, v);
		}
	}

	/**
	 * Parse session Variable value pairs
	 * 
	 * @param expression
	 *            the string contains list of session variable value pairs
	 * @param session
	 *            The session to set the value to and get value from
	 * @param logToken
	 *            the logToken to be used in the log message
	 * @param testCall
	 *            the indicator if the this is test call
	 */
	public static void parseSessionVarValuePair(String expression,
			HttpSession session, String logToken, boolean testCall)
			throws Exception {

		String sessionVar = null;
		Object sessionValue = null;
		if (LOGGER.isTraceEnabled())
			LOGGER.info(new StringBuffer(logToken).append("expression: ").append(
				expression));

		//modified by Fang Wang to allow the dest parameter to take
		// multiple session varaibles
		StringTokenizer st = new StringTokenizer(expression, ";");
		while (st.hasMoreTokens()) {
			String var = st.nextToken();
			if (var != null) {
				int index = var.indexOf(":");
				if (index != -1) {
					sessionVar = var.substring(0, index).trim();
					//doesn't sound like we need to remove the space in the values
					//sessionValue = var.substring(index + 1).replaceAll(" ", "")
					//		.trim();
					sessionValue = var.substring(index + 1).trim();
					if (((String) sessionValue).startsWith("$")) {
						sessionValue = getSessionValue(((String) sessionValue)
								.substring(1), session);
					}

					if (testCall) {
						LOGGER.debug(new StringBuffer(logToken).append(
								"sessionVar: ").append(sessionVar));
						LOGGER.debug(new StringBuffer(logToken).append(
								"sessionValue: ").append(sessionValue));
					}
					setSessionValue(sessionVar, sessionValue, session);
				}
			}
		}
	}

	/**
	 * Determines if a set of conditions are true. The conditions are of the
	 * form
	 * 
	 * @param cond
	 *            �SV Op RV, SV Op RV, SV� the Op and RV are optional
	 * @param session
	 *            The session to get the value from
	 * @param logToken
	 *            the logToken to be used in the log message
	 */
	public static boolean conditionsMatch(String cond, HttpSession session,
			String logToken) {
		if (cond == null || cond.trim().length() == 0)
			return (true);

		boolean condResult = true;
		String[] conditions = cond.split(",");
		try {
			for (int i = 0; i < conditions.length; i++) {
				if (!conditionMatches(conditions[i].trim(), session))
					condResult = false;
			}
		} catch (Exception e) {
			if (LOGGER.isTraceEnabled())
				LOGGER.info(new StringBuffer(logToken).append(
					"Exception caught in condition evaluation: ").append(
					e.getMessage()));
			return (false);
		}
		return (condResult);
	}

	/**
	 * Determines if a condition is true. The condition is of the form
	 * 
	 * @param cond
	 *            �SV Op RV�, the Op and RV are optional
	 * @param session
	 *            The session to get the value from
	 */
	private static boolean conditionMatches(String cond, HttpSession session)
			throws Exception {
		if (cond == null || cond.trim().length() == 0)
			return (true);

		if (LOGGER.isTraceEnabled())
			LOGGER.trace("cond:" + cond);
		String[] items = cond.split("\\s+");
		if (items.length == 1) {
			Object value = getSessionValue(items[0].trim(), session);
			if (LOGGER.isTraceEnabled()){
				LOGGER.trace("lhs:" + items[0].trim());
				LOGGER.trace("value:" + (value != null ? value.toString():"null"));
			}
			if (value == null || "false".equals(value.toString()))
				return (false);
		} else {
			String lhsStr = items[0].trim();
			String op = items[1].trim();
			String rhsStr = items[2].trim();

			//need to handle space in rhs
			if (items.length >= 4) {
				StringBuffer sb = new StringBuffer(rhsStr);
				sb.append(Common.SPACE);
				for (int i = 3; i < items.length; i++) {
					sb.append(items[i]).append(Common.SPACE);
				}
				rhsStr = sb.toString().trim();
			}

			try {
				//get the real value for the lhs
				//rhs has to be get at the individual case
				Object lhs = null;
				//check the reserved word on LHS
				String timeZone = null;
				if (lhsStr.equalsIgnoreCase("TIMENOW")) {
					timeZone = ((Properties)session.getServletContext().getAttribute("globalProp")).getProperty("timeZone");
					Calendar now = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
					lhs = now.getTime();
				}
				else
					lhs = getSessionValue(lhsStr, session);
				
				if (LOGGER.isTraceEnabled()){
					LOGGER.trace("lhs:" + lhsStr);
					LOGGER.trace("value:" + (lhs != null? lhs.toString():"null"));
					LOGGER.trace("op:" + op);
					LOGGER.trace("rhs:" + rhsStr);
				}

				if (lhs == null){
					//check if the condition meant to check a NULL condition
					if (op.equalsIgnoreCase("EQ") && rhsStr.equalsIgnoreCase("NULL"))
						return true;
					//otherwise, condition can't be true anyway
					return false;
				}
				
				if (op.startsWith("SizeOf")) {
					int rhs = 0;
					if (rhsStr.startsWith("$"))
						rhs = ((Integer) getSessionValue(rhsStr.substring(1),
								session)).intValue();
					else
						rhs = Integer.parseInt(rhsStr);
					return sizeConditionEval(lhs.toString(), op, rhs);

				} else if (op.startsWith("Date")) {
					String dateFormat = (String) session
						.getServletContext().getAttribute("dateFormat");
					SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
					Date lDate = formatter.parse(lhs.toString());
					Date rDate = null;
					if (rhsStr.equalsIgnoreCase("TODAY")) {
						if (timeZone == null)
							timeZone = ((Properties)session.getServletContext().getAttribute("globalProp")).getProperty("timeZone");
						rDate = Calendar.getInstance(TimeZone.getTimeZone(timeZone)).getTime();
					} else {
						if (rhsStr.startsWith("$"))
							rhsStr = (String) getSessionValue(rhsStr
									.substring(1), session);
						rDate = formatter.parse(rhsStr);
					}
					return dateConditionEval(lDate, op, rDate);

				} else if (op.startsWith("Time")) {
					String timeFormat = (String) session
						.getServletContext().getAttribute("timeFormat");
					SimpleDateFormat formatter = new SimpleDateFormat(timeFormat);
					
					Date lDate = null;
					Date rDate = null;
					
					if (rhsStr.equalsIgnoreCase("TIMENOW")) {
						if (timeZone == null)
							timeZone = ((Properties)session.getServletContext().getAttribute("globalProp")).getProperty("timeZone");
						Calendar now = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
						rDate = now.getTime();
						if (lhs instanceof Date) {
							lDate = (Date)lhs;
						}
						else {
							lhsStr = lhs.toString();
							now.set(Calendar.HOUR_OF_DAY, Integer.parseInt(lhsStr.substring(0,2)));
							now.set(Calendar.MINUTE, Integer.parseInt(lhsStr.substring(3,4)));
							lDate = now.getTime();
						}
					} 
					else {
						if (rhsStr.startsWith("$"))
							rhsStr = (String) getSessionValue(rhsStr
									.substring(1), session);
						
						if (lhs instanceof Date) {
							lDate = (Date)lhs;
						}
						else 
							lDate = formatter.parse(lhs.toString());
						
						if (rhsStr.length() == 4) {
							formatter = new SimpleDateFormat("HHmm");
						} else if (rhsStr.length() == 6) {
							formatter = new SimpleDateFormat("HHmma");
						}
						else 
							throw new Exception(rhsStr + " is not the allowed format");
						rDate = formatter.parse(rhsStr);
					}
					return timeConditionEval(lDate, op, rDate);

				} else if (op.startsWith("Currency")) {
					float lFloat = ((Float) lhs).floatValue();
					float rFloat = 0.0f;
					if (rhsStr.startsWith("$"))
						rFloat = ((Float) getSessionValue(rhsStr.substring(1),
								session)).floatValue();
					else
						rFloat = Float.parseFloat(rhsStr);
					return currencyConditionEval(lFloat, op, rFloat);

				} else {
					Object rhs = null;
					if (lhs instanceof Integer) { // interpret as int
						int lInt = ((Integer) lhs).intValue();
						if (rhsStr.startsWith("$")) {
							rhs = getSessionValue(rhsStr.substring(1), session);
							int rInt = ((Integer) rhs).intValue();
							return intConditionEval(lInt, op, rInt);
						} else if (rhsStr.matches("\\p{Digit}+")) { //if
							// pure
							// digits,
							int rInt = Integer.parseInt(rhsStr);
							return intConditionEval(lInt, op, rInt);
						} else {
							throw new Exception("RHS: " + rhsStr
									+ " is not an integer");
						}
					} else {//otherwise, interpret as string
						if (rhsStr.equalsIgnoreCase(Common.SPACECHAR)){
							if (op.equalsIgnoreCase("EQ")) 
								return lhs.toString().trim().length() == 0;
							else if (op.equalsIgnoreCase("NE")) 
								return lhs.toString().trim().length() != 0;
							else
								throw new Exception(op
										+ " is not supported operator");
						}
						if (rhsStr.startsWith("$"))
							rhs = getSessionValue(rhsStr.substring(1), session);
						else
							rhs = rhsStr;
						if (op.equalsIgnoreCase("EQ")) {
							return lhs.toString().trim().equalsIgnoreCase(
									rhs.toString());
						} else if (op.equalsIgnoreCase("NE")) {
							return !lhs.toString().trim().equalsIgnoreCase(
									rhs.toString());
						} else {
							throw new Exception(op
									+ " is not supported operator");
						}
					}
				}
			} catch (Exception e) {
				throw new Exception(cond + "->" + e.getMessage());
			}
		}

		return (true);
	}

	/**
	 * Determines if a size condition is true. The condition is of the form
	 * 
	 * @param lhs
	 *            the LHS String
	 * @param op
	 *            the operation String which takes the following values
	 *            SizeOfLT, SizeOfGT, SizeOfEQ, SizeOfLE, SizeOfGE, SizeOfNE
	 * @param size
	 *            the int value to compare with the size of lhs
	 */
	private static boolean sizeConditionEval(String lhs, String op, int size)
			throws Exception {
		if (op.equalsIgnoreCase("SizeOfLT")) {
			return (lhs.length() < size);
		} else if (op.equalsIgnoreCase("SizeOfGT")) {
			return (lhs.length() > size);
		} else if (op.equalsIgnoreCase("SizeOfEQ")) {
			return (lhs.length() == size);
		} else if (op.equalsIgnoreCase("SizeOfLE")) {
			return (lhs.length() <= size);
		} else if (op.equalsIgnoreCase("SizeOfGE")) {
			return (lhs.length() >= size);
		} else if (op.equalsIgnoreCase("SizeOfNE")) {
			return (lhs.length() != size);
		} else {
			throw new Exception(op + " is not supported operator");
		}
	}

	/**
	 * Determines if a date condition is true. The condition is of the form
	 * 
	 * @param lDate
	 *            the LHS Date object
	 * @param op
	 *            the operation String which takes the following values DateLT,
	 *            DateGT, DateEQ, DateLE, DateGE, DateNE
	 * @param rDate
	 *            the RHS Date object
	 */
	private static boolean dateConditionEval(Date lDate, String op, Date rDate)
			throws Exception {
		if (op.equalsIgnoreCase("DateLT")) {
			return (lDate.compareTo(rDate) < 0);
		} else if (op.equalsIgnoreCase("DateGT")) {
			return (lDate.compareTo(rDate) > 0);
		} else if (op.equalsIgnoreCase("DateEQ")) {
			return (lDate.compareTo(rDate) == 0);
		} else if (op.equalsIgnoreCase("DateLE")) {
			return (lDate.compareTo(rDate) <= 0);
		} else if (op.equalsIgnoreCase("DateGE")) {
			return (lDate.compareTo(rDate) >= 0);
		} else if (op.equalsIgnoreCase("DateNE")) {
			return (lDate.compareTo(rDate) != 0);
		} else {
			throw new Exception(op + " is not supported operator");
		}
	}

	/**
	 * Determines if a time condition is true. The condition is of the form
	 * 
	 * @param lDate
	 *            the LHS Date object
	 * @param op
	 *            the operation String which takes the following values TimeLT,
	 *            TimeGT, TimeEQ, TimeLE, TimeGE, TimeNE
	 * @param rDate
	 *            the RHS Date object
	 */
	private static boolean timeConditionEval(Date lDate, String op, Date rDate)
			throws Exception {
		if (op.equalsIgnoreCase("TimeLT")) {
			return (lDate.compareTo(rDate) < 0);
		} else if (op.equalsIgnoreCase("TimeGT")) {
			return (lDate.compareTo(rDate) > 0);
		} else if (op.equalsIgnoreCase("TimeEQ")) {
			return (lDate.compareTo(rDate) == 0);
		} else if (op.equalsIgnoreCase("TimeLE")) {
			return (lDate.compareTo(rDate) <= 0);
		} else if (op.equalsIgnoreCase("TimeGE")) {
			return (lDate.compareTo(rDate) >= 0);
		} else if (op.equalsIgnoreCase("TimeNE")) {
			return (lDate.compareTo(rDate) != 0);
		} else {
			throw new Exception(op + " is not supported operator");
		}
	}

	/**
	 * Determines if a currency condition is true. The condition is of the form
	 * 
	 * @param lFloat
	 *            the LHS currency float value
	 * @param op
	 *            the operation String which takes the following values
	 *            CurrencyLT, CurrencyGT, CurrencyEQ, CurrencyLE, CurrencyGE,
	 *            CurrencyNE
	 * @param rFloat
	 *            the RHS currency float vlaue
	 */
	private static boolean currencyConditionEval(float lFloat, String op,
			float rFloat) throws Exception {
		if (op.equalsIgnoreCase("CurrencyLT")) {
			return (lFloat < rFloat);
		} else if (op.equalsIgnoreCase("CurrencyGT")) {
			return (lFloat > rFloat);
		} else if (op.equalsIgnoreCase("CurrencyLE")) {
			return (lFloat <= rFloat);
		} else if (op.equalsIgnoreCase("CurrencyGE")) {
			return (lFloat >= rFloat);
		} else if (op.equalsIgnoreCase("CurrencyNE")) {
			return (lFloat != rFloat);
		} else if (op.equalsIgnoreCase("CurrencyEQ")) {
			return (lFloat == rFloat);
		} else {
			throw new Exception(op + " is not supported operator");
		}
	}

	/**
	 * Determines if an int condition is true. The condition is of the form
	 * 
	 * @param lInt
	 *            the LHS int value
	 * @param op
	 *            the operation String which takes the following values LT, GT,
	 *            EQ, LE, GE, NE
	 * @param rFloat
	 *            the RHS currency float vlaue
	 */
	private static boolean intConditionEval(int lInt, String op, int rInt)
			throws Exception {
		if (op.equalsIgnoreCase("LT")) {
			return (lInt < rInt);
		} else if (op.equalsIgnoreCase("GT")) {
			return (lInt > rInt);
		} else if (op.equalsIgnoreCase("LE")) {
			return (lInt <= rInt);
		} else if (op.equalsIgnoreCase("GE")) {
			return (lInt >= rInt);
		} else if (op.equalsIgnoreCase("NE")) {
			return (lInt != rInt);
		} else if (op.equalsIgnoreCase("EQ")) {
			return (lInt == rInt);
		} else {
			throw new Exception(op + " is not supported operator");
		}
	}

	/**
	 * Evaluate counter names with embedded session variable(s) resolved
	 * suported format: ABC$xxx,abc$yyy and $zzz where ABC and abc are literal string, 
	 * 					xxx, yyy and zzz are session variables; currently only 
	 * 					appended session variable supported
	 * 
	 * @param counterStr
	 *            counter string which may contain session variable 
	 * @param session
	 *            The session to get the value from for evaluating the counter names
	 * @return counter names with session variable resolved
	 */
	public static String evaluateCounterName(String counterStr, HttpSession session) {
		if (counterStr == null) return null;
		String[] counters = counterStr.split(",");
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < counters.length; i++) {
			String c = counters[i].trim();
			if (c.length() != 0){
				int index = c.indexOf("$");
				if ( index < 0) 
					sb.append(c).append(",");
				else {
					String val = (String)getSessionValue(counterStr.substring(index+1), session);
					if (val != null) sb.append(counterStr.substring(0,index)).append(val).append(",");
				}
			}
		}	
		return sb.toString();
	}
	
	/**
	 * Find the corresponding intro audio for the given dnis and fetch the audio
	 * to return byte[]
	 * 
	 * @param dnis
	 *            the dnis for which introAudio should be collected
	 * @param context
	 * 			  the servlet context to retrieve confirmation information
	 * @param requestOwner
	 * 			  to construct logToken
	 * @return the found introAudio bytes only if emergencyMsgLimit is
	 *         specified, empty byte[] array if not, null if no introAudio found
	 */
	public static byte[] findIntroAudio(String dnis, ServletContext context, String requestOwner) {

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(requestOwner).append("] ")
				.toString();
		
		// Check properties to search Hash Table for CallRouting class
		Properties prop = (Properties) context.getAttribute(
				"mappingProp");
		Hashtable hs = (Hashtable) context.getAttribute(
				"callRoutingTable");

		// extract value for this DNIS from ivrmapping properties
		// for called IVR apps, this value will be in
		// xxxx.xml#xxxmenu.dtmf format
		String callFlow = prop.getProperty("callflow." + dnis);

		// if DNIS not defined in the ivrmapping.properties
		if (callFlow == null) {
			LOGGER.warn(new StringBuffer().append("DNIS ").append(dnis).append(
					" not defined in the ivrmapping.properties"));
			return null;
		}

		CallRoutingType iCallRouting = (CallRoutingType) hs.get("callflow."
				+ dnis);

		//load call.properties only if it is specified
		String callPropFile = iCallRouting.getCallProperties();
		if (callPropFile != null) {
			try {
				ClassLoader classLoader = Thread.currentThread()
						.getContextClassLoader();
				InputStream is = classLoader.getResourceAsStream("/"
						+ callPropFile);
				Properties callProp = new Properties();
				callProp.load(is);
				is.close();

				if (callProp.getProperty("emergencyMsgLimit") == null)
					return new byte[0];

			} catch (IOException ioe) {
				LOGGER.warn(new StringBuffer().append("Can't load ").append(
						callPropFile).append(
						". Assuming emergencyMsgLimit is not defined."));
				return new byte[0];
			}

			//find the corresponding introAudio for the dnis
			List introAudios = iCallRouting.getIntroAudio();
			String iaFile = "";
			IntroAudioType iaDefault = null;
			for (int i = 0; i < introAudios.size(); i++) {
				IntroAudioType ia = (IntroAudioType) introAudios.get(i);
				if (ia.getDnis() == null) {
					iaDefault = ia;
				} else {
					if (ia.getDnis().indexOf(dnis) != -1) {
						iaFile = ia.getValue();
						break;
					}
				}
			}
			if (iaFile.length() == 0 && iaDefault != null) {//no matching dnis
				// is found on
				// IntroAudio
				iaFile = iaDefault.getValue();
			}

			//fetch the introAudio byte
			prop = (Properties) context.getAttribute(
				"globalProp");
			String introAudioURL = prop.getProperty("audioFileRoot") + "/audio/"
					+ iCallRouting.getAudioDir() + "/" + iaFile.trim();
			try{
				URL url = new URL(introAudioURL);
				InputStream is = url.openStream();
				
				byte b[] = new byte[4096];
				int len = -1;
				ByteArrayOutputStream bstream = new ByteArrayOutputStream();

	            while ((len=is.read(b, 0, 4096)) != -1)
	            	bstream.write(b, 0, len);
	            
	            byte bcontent[] = bstream.toByteArray();
	            bstream.close();
	            is.close();
	            
	            return bcontent;
			}
			catch (Exception ioe) {
				LOGGER.warn(new StringBuffer().append("Can't fetch ").append(
						introAudioURL).append(
						". Assuming no introAudio needs to be played before emergency message"));
				return new byte[0];
			}
		}
		return new byte[0];
	}
}
