/**
 * <copyright>
 * </copyright>
 *
 * $Id: TransferAudioType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transfer Audio Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.TransferAudioType#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.TransferAudioType#getTts <em>Tts</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getTransferAudioType()
 * @model 
 * @generated
 */
public interface TransferAudioType
{
  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute.
   * @see #setValue(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getTransferAudioType_Value()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getValue();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.TransferAudioType#getValue <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' attribute.
   * @see #getValue()
   * @generated
   */
  void setValue(String value);

  /**
   * Returns the value of the '<em><b>Tts</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tts</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tts</em>' attribute.
   * @see #setTts(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getTransferAudioType_Tts()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getTts();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.TransferAudioType#getTts <em>Tts</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tts</em>' attribute.
   * @see #getTts()
   * @generated
   */
  void setTts(String value);

} // TransferAudioType
