/**
 * <copyright>
 * </copyright>
 *
 * $Id: OperatorType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operator Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.OperatorType#getValue <em>Value</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.OperatorType#getDnis <em>Dnis</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getOperatorType()
 * @model 
 * @generated
 */
public interface OperatorType
{
  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute.
   * @see #setValue(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getOperatorType_Value()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getValue();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.OperatorType#getValue <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value</em>' attribute.
   * @see #getValue()
   * @generated
   */
  void setValue(String value);

  /**
   * Returns the value of the '<em><b>Dnis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dnis</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dnis</em>' attribute.
   * @see #setDnis(String)
   * @see com.ibm.ivr.framework.model.ModelPackage#getOperatorType_Dnis()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   * @generated
   */
  String getDnis();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.OperatorType#getDnis <em>Dnis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dnis</em>' attribute.
   * @see #getDnis()
   * @generated
   */
  void setDnis(String value);

} // OperatorType
