/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelResourceUtil.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.EObject;

import com.ibm.ivr.framework.model.DocumentRoot;
import com.ibm.ivr.framework.model.ModelFactory;
import com.ibm.ivr.framework.model.ModelPackage;

/**
 * The utility class for loading and storing SDO instances as XML files.
 * @generated
 */
public class ModelResourceUtil 
{
  /**
   * The single instance of this class.
   * @generated
   */
  private static ModelResourceUtil instance;

  /**
   * Return the single instance of this class.
   * @generated
   */  
  public static ModelResourceUtil getInstance()
  {
  	if (instance == null)
  	{	
  	  instance = new ModelResourceUtil();
  	}
  	return instance;
  }
  
  /**
   * The default constructor.
   * @generated
   */  
  public ModelResourceUtil() 
  {
    initialize();
  }

  /**
   * @generated
   */
  private void initialize()
  {
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xml", new ModelResourceFactoryImpl());
    ModelPackage pkg = ModelPackage.eINSTANCE;   
    ModelFactory factory = ModelFactory.eINSTANCE;
  }

  /**
   * Load an existing XML file.
   * @param filename the absolute path name of the XML file to be loaded.
   * @exception IOException failed loading from an XML file.
   * @return DocumentRoot
   * @generated
   */  
  public DocumentRoot load(String filename) throws IOException
  {
    ModelResourceImpl resource = (ModelResourceImpl)(new ModelResourceFactoryImpl()).createResource(URI.createURI(filename));
    resource.load(null);
    DocumentRoot documentRoot = (DocumentRoot)resource.getContents().get(0);
    return documentRoot;
  }

  /**
   * Load an existing XML file.
   * @param istream the InputStream to load the XML content from.
   * @exception IOException failed loading from an XML file.
   * @return DocumentRoot
   * @generated
   */   
  public DocumentRoot load(InputStream istream) throws IOException
  {
    ModelResourceImpl resource = (ModelResourceImpl)(new ModelResourceFactoryImpl()).createResource(URI.createURI("*.xml"));
    resource.load(istream,null);
    DocumentRoot documentRoot = (DocumentRoot)resource.getContents().get(0);
    return documentRoot;
  }
  
  /**
   * Save as an XML file.
   * @param documentRoot the document root of the SDO instances.
   * @param filename the absolute path name of the XML file to be created.
   * @exception IOException failed storing to an XML file.
   * @generated
   */
  public void save(DocumentRoot documentRoot, String filename) throws IOException
  {
  	ModelResourceImpl resource = getModelResourceImpl(documentRoot);
    resource.setURI(URI.createURI(filename));
    if (!resource.getContents().contains(documentRoot))
    { 	
      resource.getContents().add(documentRoot);
    }  
    resource.setEncoding("UTF-8");
    resource.save(null);
  } 
 
  /**
   * Save as an XML output stream.
   * @param documentRoot the document root of the SDO instances.
   * @param ostream the OutputStream where the XML content is to be written.
   * @exception IOException failed storing to an XML file.
   * @generated
   */ 
  public void save(DocumentRoot documentRoot, OutputStream ostream) throws IOException
  {
  	ModelResourceImpl resource = getModelResourceImpl(documentRoot);
    if (!resource.getContents().contains(documentRoot))
    { 	
      resource.getContents().add(documentRoot);
    }  
    resource.setEncoding("UTF-8");
    resource.save(ostream,null);
  } 
  
  /**
   * Return a resource associated with documentRoot.
   * @param documentRoot the document root of the SDO instances.
   * @return ModelResourceImpl
   * @generated
   */   
  private ModelResourceImpl getModelResourceImpl(DocumentRoot documentRoot)
  {
  	ModelResourceImpl resource = (ModelResourceImpl)((EObject)documentRoot).eResource();
    if (resource == null)
      resource = (ModelResourceImpl)(new ModelResourceFactoryImpl()).createResource(URI.createURI("*.xml"));
    return resource;    
  }

}
