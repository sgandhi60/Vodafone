/**
 * <copyright>
 * </copyright>
 *
 * $Id: DocumentRoot.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import commonj.sdo.Sequence;

import java.util.Map;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Document Root</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getMixed <em>Mixed</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getAudio <em>Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getAudioConfirm <em>Audio Confirm</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getCallRouting <em>Call Routing</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getChoice <em>Choice</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getClosedAudio <em>Closed Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getDefaultRouting <em>Default Routing</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getEventHandlers <em>Event Handlers</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getEvents <em>Events</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getGrammar <em>Grammar</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getHangup <em>Hangup</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getHelp <em>Help</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getHolidayAudio <em>Holiday Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getInputError <em>Input Error</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getIntroAudio <em>Intro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getMenuDefault <em>Menu Default</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getMenuOperator <em>Menu Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getNoInput <em>No Input</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getNoMatch <em>No Match</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getOperator <em>Operator</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getOutroAudio <em>Outro Audio</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getSubMenu <em>Sub Menu</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getTransfer <em>Transfer</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.DocumentRoot#getTransferAudio <em>Transfer Audio</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot()
 * @model 
 * @generated
 */
public interface DocumentRoot
{
  /**
   * Returns the value of the '<em><b>Mixed</b></em>' attribute list.
   * The list contents are of type {@link org.eclipse.emf.ecore.util.FeatureMap.Entry}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mixed</em>' attribute list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mixed</em>' attribute list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Mixed()
   * @model unique="false" dataType="org.eclipse.emf.ecore.EFeatureMapEntry" many="true"
   * @generated
   */
  Sequence getMixed();

  /**
   * Returns the value of the '<em><b>XMLNS Prefix Map</b></em>' map.
   * The key is of type {@link java.lang.String},
   * and the value is of type {@link java.lang.String},
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>XMLNS Prefix Map</em>' map isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>XMLNS Prefix Map</em>' map.
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_XMLNSPrefixMap()
   * @model mapType="org.eclipse.emf.ecore.EStringToStringMapEntry" keyType="java.lang.String" valueType="java.lang.String" transient="true"
   * @generated
   */
  Map getXMLNSPrefixMap();

  /**
   * Returns the value of the '<em><b>XSI Schema Location</b></em>' map.
   * The key is of type {@link java.lang.String},
   * and the value is of type {@link java.lang.String},
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>XSI Schema Location</em>' map isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>XSI Schema Location</em>' map.
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_XSISchemaLocation()
   * @model mapType="org.eclipse.emf.ecore.EStringToStringMapEntry" keyType="java.lang.String" valueType="java.lang.String" transient="true"
   * @generated
   */
  Map getXSISchemaLocation();

  /**
   * Returns the value of the '<em><b>Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Audio</em>' containment reference.
   * @see #setAudio(AudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Audio()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  AudioType getAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getAudio <em>Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Audio</em>' containment reference.
   * @see #getAudio()
   * @generated
   */
  void setAudio(AudioType value);

  /**
   * Returns the value of the '<em><b>Audio Confirm</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Audio Confirm</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Audio Confirm</em>' containment reference.
   * @see #setAudioConfirm(AudioConfirmType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_AudioConfirm()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  AudioConfirmType getAudioConfirm();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getAudioConfirm <em>Audio Confirm</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Audio Confirm</em>' containment reference.
   * @see #getAudioConfirm()
   * @generated
   */
  void setAudioConfirm(AudioConfirmType value);

  /**
   * Returns the value of the '<em><b>Call Routing</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Call Routing</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Call Routing</em>' containment reference.
   * @see #setCallRouting(CallRoutingType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_CallRouting()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  CallRoutingType getCallRouting();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getCallRouting <em>Call Routing</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Call Routing</em>' containment reference.
   * @see #getCallRouting()
   * @generated
   */
  void setCallRouting(CallRoutingType value);

  /**
   * Returns the value of the '<em><b>Choice</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Choice</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Choice</em>' containment reference.
   * @see #setChoice(ChoiceType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Choice()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  ChoiceType getChoice();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getChoice <em>Choice</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Choice</em>' containment reference.
   * @see #getChoice()
   * @generated
   */
  void setChoice(ChoiceType value);

  /**
   * Returns the value of the '<em><b>Closed Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Closed Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Closed Audio</em>' containment reference.
   * @see #setClosedAudio(ClosedAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_ClosedAudio()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  ClosedAudioType getClosedAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getClosedAudio <em>Closed Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Closed Audio</em>' containment reference.
   * @see #getClosedAudio()
   * @generated
   */
  void setClosedAudio(ClosedAudioType value);

  /**
   * Returns the value of the '<em><b>Default Routing</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Default Routing</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Default Routing</em>' containment reference.
   * @see #setDefaultRouting(DefaultRoutingType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_DefaultRouting()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  DefaultRoutingType getDefaultRouting();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getDefaultRouting <em>Default Routing</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Default Routing</em>' containment reference.
   * @see #getDefaultRouting()
   * @generated
   */
  void setDefaultRouting(DefaultRoutingType value);

  /**
   * Returns the value of the '<em><b>Event Handlers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Event Handlers</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Event Handlers</em>' containment reference.
   * @see #setEventHandlers(EventHandlersType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_EventHandlers()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  EventHandlersType getEventHandlers();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getEventHandlers <em>Event Handlers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Event Handlers</em>' containment reference.
   * @see #getEventHandlers()
   * @generated
   */
  void setEventHandlers(EventHandlersType value);

  /**
   * Returns the value of the '<em><b>Events</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Events</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Events</em>' containment reference.
   * @see #setEvents(EventsType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Events()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  EventsType getEvents();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getEvents <em>Events</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Events</em>' containment reference.
   * @see #getEvents()
   * @generated
   */
  void setEvents(EventsType value);

  /**
   * Returns the value of the '<em><b>Grammar</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Grammar</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Grammar</em>' containment reference.
   * @see #setGrammar(GrammarType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Grammar()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  GrammarType getGrammar();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getGrammar <em>Grammar</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Grammar</em>' containment reference.
   * @see #getGrammar()
   * @generated
   */
  void setGrammar(GrammarType value);

  /**
   * Returns the value of the '<em><b>Hangup</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hangup</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hangup</em>' containment reference.
   * @see #setHangup(HangupType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Hangup()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  HangupType getHangup();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getHangup <em>Hangup</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Hangup</em>' containment reference.
   * @see #getHangup()
   * @generated
   */
  void setHangup(HangupType value);

  /**
   * Returns the value of the '<em><b>Help</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Help</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Help</em>' containment reference.
   * @see #setHelp(HelpType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Help()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  HelpType getHelp();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getHelp <em>Help</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Help</em>' containment reference.
   * @see #getHelp()
   * @generated
   */
  void setHelp(HelpType value);

  /**
   * Returns the value of the '<em><b>Holiday Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Holiday Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Holiday Audio</em>' containment reference.
   * @see #setHolidayAudio(HolidayAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_HolidayAudio()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  HolidayAudioType getHolidayAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getHolidayAudio <em>Holiday Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Holiday Audio</em>' containment reference.
   * @see #getHolidayAudio()
   * @generated
   */
  void setHolidayAudio(HolidayAudioType value);

  /**
   * Returns the value of the '<em><b>Input Error</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Error</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Error</em>' containment reference.
   * @see #setInputError(InputErrorType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_InputError()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  InputErrorType getInputError();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getInputError <em>Input Error</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Error</em>' containment reference.
   * @see #getInputError()
   * @generated
   */
  void setInputError(InputErrorType value);

  /**
   * Returns the value of the '<em><b>Intro Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Intro Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Intro Audio</em>' containment reference.
   * @see #setIntroAudio(IntroAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_IntroAudio()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  IntroAudioType getIntroAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getIntroAudio <em>Intro Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Intro Audio</em>' containment reference.
   * @see #getIntroAudio()
   * @generated
   */
  void setIntroAudio(IntroAudioType value);

  /**
   * Returns the value of the '<em><b>Menu Default</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Menu Default</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Menu Default</em>' containment reference.
   * @see #setMenuDefault(MenuDefaultType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_MenuDefault()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  MenuDefaultType getMenuDefault();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getMenuDefault <em>Menu Default</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Menu Default</em>' containment reference.
   * @see #getMenuDefault()
   * @generated
   */
  void setMenuDefault(MenuDefaultType value);

  /**
   * Returns the value of the '<em><b>Menu Operator</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Menu Operator</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Menu Operator</em>' containment reference.
   * @see #setMenuOperator(MenuOperatorType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_MenuOperator()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  MenuOperatorType getMenuOperator();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getMenuOperator <em>Menu Operator</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Menu Operator</em>' containment reference.
   * @see #getMenuOperator()
   * @generated
   */
  void setMenuOperator(MenuOperatorType value);

  /**
   * Returns the value of the '<em><b>No Input</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>No Input</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>No Input</em>' containment reference.
   * @see #setNoInput(NoInputType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_NoInput()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  NoInputType getNoInput();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getNoInput <em>No Input</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>No Input</em>' containment reference.
   * @see #getNoInput()
   * @generated
   */
  void setNoInput(NoInputType value);

  /**
   * Returns the value of the '<em><b>No Match</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>No Match</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>No Match</em>' containment reference.
   * @see #setNoMatch(NoMatchType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_NoMatch()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  NoMatchType getNoMatch();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getNoMatch <em>No Match</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>No Match</em>' containment reference.
   * @see #getNoMatch()
   * @generated
   */
  void setNoMatch(NoMatchType value);

  /**
   * Returns the value of the '<em><b>Operator</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Operator</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Operator</em>' containment reference.
   * @see #setOperator(OperatorType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Operator()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  OperatorType getOperator();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getOperator <em>Operator</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Operator</em>' containment reference.
   * @see #getOperator()
   * @generated
   */
  void setOperator(OperatorType value);

  /**
   * Returns the value of the '<em><b>Outro Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Outro Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Outro Audio</em>' containment reference.
   * @see #setOutroAudio(OutroAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_OutroAudio()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  OutroAudioType getOutroAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getOutroAudio <em>Outro Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Outro Audio</em>' containment reference.
   * @see #getOutroAudio()
   * @generated
   */
  void setOutroAudio(OutroAudioType value);

  /**
   * Returns the value of the '<em><b>Sub Menu</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub Menu</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub Menu</em>' containment reference.
   * @see #setSubMenu(SubMenuType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_SubMenu()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  SubMenuType getSubMenu();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getSubMenu <em>Sub Menu</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Sub Menu</em>' containment reference.
   * @see #getSubMenu()
   * @generated
   */
  void setSubMenu(SubMenuType value);

  /**
   * Returns the value of the '<em><b>Transfer</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transfer</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transfer</em>' containment reference.
   * @see #setTransfer(TransferType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_Transfer()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  TransferType getTransfer();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getTransfer <em>Transfer</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Transfer</em>' containment reference.
   * @see #getTransfer()
   * @generated
   */
  void setTransfer(TransferType value);

  /**
   * Returns the value of the '<em><b>Transfer Audio</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transfer Audio</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transfer Audio</em>' containment reference.
   * @see #setTransferAudio(TransferAudioType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getDocumentRoot_TransferAudio()
   * @model containment="true" resolveProxies="false" transient="true" volatile="true" derived="true"
   * @generated
   */
  TransferAudioType getTransferAudio();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.DocumentRoot#getTransferAudio <em>Transfer Audio</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Transfer Audio</em>' containment reference.
   * @see #getTransferAudio()
   * @generated
   */
  void setTransferAudio(TransferAudioType value);

} // DocumentRoot
