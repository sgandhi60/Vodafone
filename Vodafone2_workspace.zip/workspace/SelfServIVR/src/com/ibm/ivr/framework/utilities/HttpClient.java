package com.ibm.ivr.framework.utilities;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

/**
 * Proxy class to access the backend service to search service centers <p>
 *
 * 2006-03-14: initial version. <p>
 *
 * @author Shailesh Gandhi
 * @version 
 *
 */
public class HttpClient {
	/**
	 * The private log4j logger.
	 */
	private static Logger LOGGER = Logger.getLogger(HttpClient.class);

	/**
	 * The private callid field for logging message only.
	 */
	private String callid = null;

	/**
	 * The private logToken field for logging message only.
	 */
	private String logToken = null;

	/**
	 * The private testcall field for logging message only.
	 */
	private boolean testCall = false;

	/**
	 * @return Returns the testCall.
	 */
	public boolean isTestCall() {
		return testCall;
	}
	
	/**
	 * The static endPointURL holding http service end point.
	 */
	private URL endPointURL;

	/**
	 * @return Returns the callid.
	 */
	public String getCallid() {
		return callid;
	}

	/**
	 * @return Returns the logToken.
	 */
	public String getLogToken() {
		return logToken;
	}

	/**
	 * Constructor for setting ivrPort for the current call.
	 *
	 * @param channel the portNumber of the current call
	 */
	public HttpClient(String callid, boolean testCall)
	{
		//set the callid and testcall for logging purpose
		this.callid = callid;
		this.testCall = testCall;

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		logToken = new StringBuffer("[").append(callid).append("] ").toString();
	}
	
	/**
	 * Parse the endpoint string into a URL.
	 *
	 * @param url (as string)
	 *
	 * @throws Exception If url malformed
	 */
	public void setEndPoint(String url) throws Exception
	{
		if (url == null) {
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken)
					.append("HttpClient.setEndPoint tried to contact NULL url"));
			throw new Exception("HttpClient:NULL url");
		} else {
			try {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken)
						.append("Trying to connect to url = ").append(url));
//				endPointURL.openStream();
//				new URL(url).openConnection().getInputStream().close();
				endPointURL = new URL(url);
			} catch (Exception ex) {
				throw new Exception(" HttpClient:endPointURL bad: " + url);
			}
		}
	}

	/**
	 * Get Response as XML string by sending requset to URL.
	 *
	 * @param cmdStr (cmdStr as string, possible values are activate, deactivate, or changeTime)
	 * @param dnis (dnis as string, for this company)
	 * @return contents of URL as XML string 
	 * @throws Exception If there is any exception
	 */
	public String execute(String cmdStr, String dnis) throws Exception {

		String respXML = "";

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append(" Input Parms:")
					.append(" command = ").append(cmdStr).append(" Dnis = ").append(dnis));

		try {
			// build HTTP request for ServiceBench service and receive XML string
			String url = endPointURL + "?command=" + cmdStr 
					+ "&companyDNIS=" + dnis;

			if (testCall)
				LOGGER.debug(new StringBuffer(logToken)
					.append("URL = ").append(url));
			
			// send request to service and get XML response
			respXML = callServiceRequest(url);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken)
					.append("Returned XML String = ").append(respXML));
			
			if (respXML == null) 
				throw(new Exception("Returned XML string is NULL")); 
			
		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(e.getMessage()));
			throw(e);
		}
		return respXML;
	}

	/**
	 * send request to url specified in urlString and return the contents of url.
	 *
	 * @param urlString (url as a string to send request to)
	 * @return contents of URL as XML string 
	 */
	private String callServiceRequest(String urlString)
	{
		BufferedReader br = null;
		String response = null;
		
		try {
			if (urlString.indexOf('$') != -1) { //still have non-resolved parameters
				LOGGER.error(new StringBuffer(logToken).append("Still have non-resolved parameters in URLString"));
				return response;
			}
			
			URL url = new URL(urlString);
			DataInputStream theHTML = new DataInputStream(url.openStream());
			br = new BufferedReader(new InputStreamReader(theHTML));

			if (br == null) {
				response = "";
				LOGGER.error(new StringBuffer(logToken).append("URL connection open failed."));
				return response;
			}

			String thisLine = null;
			response = "";
			
			while ((thisLine = br.readLine()) != null) {
				response = response + thisLine;
			}
			
			br.close();
		}
		catch (MalformedURLException ex) {
			response = null;
			LOGGER.error(new StringBuffer(logToken)
					.append(urlString).append(" is not a parseable URL."));
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(ex.getMessage()));
		}
		
		catch (Exception e) {
			response = null;
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(e.getMessage()));
		}
		
		return response;
	}
}
