/*
 * Created on Jun 24, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.ivr.framework.utilities;

import java.util.StringTokenizer;

/**
 * @author SGandhi
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AudioHelper {
	
	private String audiofiles = null;
	private String tts = null;
	
	/**
	 * 
	 */
	public AudioHelper(String audio) {

		audiofiles = audio;
	}
	
	/**
	 * 
	 */
	public String getAudioFiles() {

		return audiofiles;
	}

	/**
	 * 
	 */
	public String getTTS() {

		return tts;
	}
	/**
	 * 
	 */
	public void setTTS(String TTS) {

		tts = TTS;
	}
	/**
	 * 
	 */
	public String [] getAudioFilesInArray() {
		
		int i = 0;
		
		StringTokenizer st = new StringTokenizer(audiofiles, " ");
		int audioCount = st.countTokens();
		String [] audioList = new String[audioCount];
		
		while (st.hasMoreTokens()) {
			String audio = st.nextToken();
			if ( (audio != null) && (audio.length() != 0) ) {
				audioList[i] = audio.trim();
				i++;
			}
		}
		
		return audioList;
	}

}
