package com.ibm.ivr.framework.tags;

import java.net.URL;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.ChoiceType;
import com.ibm.ivr.framework.model.InputErrorType;
import com.ibm.ivr.framework.model.MenuDefaultType;
import com.ibm.ivr.framework.model.MenuOperatorType;
import com.ibm.ivr.framework.model.NoInputType;
import com.ibm.ivr.framework.model.NoMatchType;
import com.ibm.ivr.framework.model.SubMenuType;
import com.ibm.ivr.framework.utilities.Common;

/**
 * The Routing custom tag
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2007-03-11: 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-11
 *  
 */
public class RoutingTag extends TagSupport {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(RoutingTag.class);

	private String type = null;

	private int index = -1;
	
	private String scope = Common.SCOPE_LOCAL;

	private Set availableURLs = new HashSet();

	public void setType(String _type) {
		this.type = _type;
	}

	public String getType() {
		return this.type;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int _index) {
		index = _index;
	}

	public void setScope(String _scope) {
		this.scope = _scope;
	}

	public String getScope() {
		return this.scope;
	}
	
	public int doStartTag() throws JspException {
		StringBuffer routingtag = new StringBuffer();

		HttpSession session = pageContext.getSession();
		HttpServletRequest request = (HttpServletRequest) pageContext
				.getRequest();
		String contextPath = request.getContextPath();

		CallRoutingType iCallRouting = (CallRoutingType) session
				.getAttribute("iCallRouting");

		String callid = (String) session.getAttribute("callid");
		String callDnis = (String) session.getAttribute("DNIS");

		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.trace(new StringBuffer(logToken).append("RoutingTag type: "
					+ type));

		SubMenuType iSubMenu = (SubMenuType) session.getAttribute("iSubMenu");
		String appName = iCallRouting.getName();
		String menuType = iSubMenu.getType_();
		boolean isRecordType = false;
		if (menuType != null && menuType.equalsIgnoreCase("record"))
			isRecordType = true;

		// get global properties
		Properties globalProp = (Properties) session.getServletContext()
				.getAttribute("globalProp");

		// set the correct local variables
		String targetType = null;
		String targetName = null;
		String targetAudio = null;
		String targetMode = null;
		String dest = null;
		String tts = null;
		String destType = null;
		String callRoute = null;
		String selection = "";
		String tempDest = "";
		String mode = "";
		String handler = null;
		String counter = null;
		String dnis = null;
		String cond = null;
		ChoiceType choiceAtIndex = null;
		boolean errorRouting = false;

		if (type.equalsIgnoreCase("inputerror")) {
			try{
				List inputErrors = (scope.equalsIgnoreCase(Common.SCOPE_LOCAL)? 
					iSubMenu.getInputError():iCallRouting.getEventHandlers().getInputError());
				targetType = ((InputErrorType) (inputErrors.get(index)))
					.getTargetType();
				targetName = ((InputErrorType) (inputErrors.get(index)))
					.getTargetName();
				targetAudio = ((InputErrorType) (inputErrors.get(index)))
					.getTargetAudio();
				tts = ((InputErrorType) (inputErrors.get(index))).getTts();
				counter = ((InputErrorType) (inputErrors.get(index))).getCounter();
				targetMode = ((InputErrorType) (inputErrors.get(index)))
					.getTargetMode();
				dest = ((InputErrorType) (inputErrors.get(index))).getDest();
				destType = ((InputErrorType) (inputErrors.get(index)))
					.getDestType();
				selection = "-1";
				errorRouting = true;
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append("InputError error: ").append(ex.getMessage()));
				throw new JspException("InputError: " + ex.getMessage());
			}
		} else if (type.equalsIgnoreCase("noinput")) {
			try{
				List noInputs = (scope.equalsIgnoreCase(Common.SCOPE_LOCAL)? 
					iSubMenu.getNoInput():iCallRouting.getEventHandlers().getNoInput());
				targetType = ((NoInputType) (noInputs.get(index))).getTargetType();
				targetName = ((NoInputType) (noInputs.get(index))).getTargetName();
				targetAudio = ((NoInputType) (noInputs.get(index)))
					.getTargetAudio();
				tts = ((NoInputType) (noInputs.get(index))).getTts();
				counter = ((NoInputType) (noInputs.get(index))).getCounter();
				targetMode = ((NoInputType) (noInputs.get(index))).getTargetMode();
				dest = ((NoInputType) (noInputs.get(index))).getDest();
				destType = ((NoInputType) (noInputs.get(index))).getDestType();
				selection = "-1";
				errorRouting = true;
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append("NoInput error: ").append(ex.getMessage()));
				throw new JspException("NoInput: " + ex.getMessage());
			}
		} else if (type.equalsIgnoreCase("nomatch")) {
			try{
				List noMatches = (scope.equalsIgnoreCase(Common.SCOPE_LOCAL)? 
					iSubMenu.getNoMatch():iCallRouting.getEventHandlers().getNoMatch());
				targetType = ((NoMatchType) (noMatches.get(index))).getTargetType();
				targetName = ((NoMatchType) (noMatches.get(index))).getTargetName();
				targetAudio = ((NoMatchType) (noMatches.get(index)))
					.getTargetAudio();
				tts = ((NoMatchType) (noMatches.get(index))).getTts();
				counter = ((NoMatchType) (noMatches.get(index))).getCounter();
				targetMode = ((NoMatchType) (noMatches.get(index))).getTargetMode();
				dest = ((NoMatchType) (noMatches.get(index))).getDest();
				destType = ((NoMatchType) (noMatches.get(index))).getDestType();
				selection = "-1";
				errorRouting = true;
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append("NoMatch error: ").append(ex.getMessage()));
				throw new JspException("NoMatch: " + ex.getMessage());
			}
		} else if (type.equalsIgnoreCase("choice")) {
			try{
				List choices = iSubMenu.getChoice();
				choiceAtIndex = ((ChoiceType) (choices.get(index)));
			
			//this logic is moved to jsp page to make sure VXML if cond will not printed either when 
			//cond is false
			//cond = choiceAtIndex.getCond();
			//if (cond != null && cond.length() != 0) {
			//	boolean result = Common
			//			.conditionsMatch(cond, session, logToken);
			//	if (testCall)
			//		LOGGER.debug(new StringBuffer(logToken).append(
			//				"RoutingTag cond: [" + cond).append(
			//				"] evaluated as: ").append(result));
			//	if (!result) {
			//		try {
			//			pageContext.getOut().print(routingtag.toString());
			//		} catch (Exception e) {
			//			throw new JspException(
			//					"Exception caught when writing routing tag content to the jsp stream");
			//		}
			//		return SKIP_BODY;
			//	}
			//}
			
				targetType = choiceAtIndex.getTargetType();
				targetName = choiceAtIndex.getTargetName();
				targetAudio = choiceAtIndex.getTargetAudio();
				tts = choiceAtIndex.getTts();
				counter = choiceAtIndex.getCounter();
				targetMode = choiceAtIndex.getTargetMode();
				dest = choiceAtIndex.getDest();
				destType = choiceAtIndex.getDestType();
				handler = choiceAtIndex.getHandler();

				mode = (String) session.getAttribute("mode");
				if (mode.equalsIgnoreCase("speech"))
					selection = choiceAtIndex.getAnnot().trim();
				else
					selection = choiceAtIndex.getDtmf().trim();
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append("Choice error: ").append(ex.getMessage()));
				throw new JspException("Choice error: " + ex.getMessage());
			}
		} else if (type.equalsIgnoreCase("menuoperator")) {
			try{
				List menuOperators = (scope.equalsIgnoreCase(Common.SCOPE_LOCAL)? 
					iSubMenu.getMenuOperator():iCallRouting.getMenuOperator());
				targetType = ((MenuOperatorType) (menuOperators.get(index))).getTargetType();
				targetName = ((MenuOperatorType) (menuOperators.get(index))).getTargetName();
				targetAudio = ((MenuOperatorType) (menuOperators.get(index))).getTargetAudio();
				tts = ((MenuOperatorType) (menuOperators.get(index))).getTts();
				counter = ((MenuOperatorType) (menuOperators.get(index))).getCounter();
				targetMode = ((MenuOperatorType) (menuOperators.get(index))).getTargetMode();
				dest = ((MenuOperatorType) (menuOperators.get(index))).getDest();
				destType = ((MenuOperatorType) (menuOperators.get(index))).getDestType();
				selection = "0";
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append("MenuOperator error: ").append(ex.getMessage()));
				throw new JspException("MenuOperator: " + ex.getMessage());
			}
		} else if (type.equalsIgnoreCase("menudefault")) {
			String tempDnis;

			// If the index is not specified, find the MenuDefault based on the
			// dnis attribute and cond
			try{
				List menuDefaults = iSubMenu.getMenuDefault();
				for (int i = 0; i < menuDefaults.size(); i++) {
					tempDnis = ((MenuDefaultType) (menuDefaults.get(i))).getDnis();
					cond = ((MenuDefaultType) (menuDefaults.get(i))).getCond();
					boolean condResult = true;
					if (cond != null && cond.length() != 0) {
						condResult = Common
							.conditionsMatch(cond, session, logToken);
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(
								"RoutingTag cond: [" + cond).append(
								"] evaluated as: ").append(condResult));
					}

					if (condResult) {
						if (callDnis != null) {
							if (tempDnis != null) {
								if (tempDnis.indexOf(callDnis) >= 0) {
									index = i;
									break;
								}
							} else {
								index = i;
								break;
							}
						} else {
							if (tempDnis == null) {
								index = i;
								break;
							}
						}
					}
				}

				targetType = ((MenuDefaultType) (menuDefaults.get(index)))
					.getTargetType();
				targetName = ((MenuDefaultType) (menuDefaults.get(index)))
					.getTargetName();
				targetAudio = ((MenuDefaultType) (menuDefaults.get(index)))
					.getTargetAudio();
				tts = ((MenuDefaultType) (menuDefaults.get(index))).getTts();
				counter = ((MenuDefaultType) (menuDefaults.get(index)))
					.getCounter();
				targetMode = ((MenuDefaultType) (menuDefaults.get(index)))
					.getTargetMode();
				dest = ((MenuDefaultType) (menuDefaults.get(index))).getDest();
				handler = ((MenuDefaultType) (menuDefaults.get(index)))
					.getHandler();
				dnis = ((MenuDefaultType) (menuDefaults.get(index))).getDnis();
				destType = ((MenuDefaultType) (menuDefaults.get(index)))
					.getDestType();
			}catch(Exception ex){
				LOGGER.error(new StringBuffer(logToken).append("MenuDefault error: ").append(ex.getMessage()));
				throw new JspException("MenuDefault: " + ex.getMessage());
			}
		} else{
			LOGGER.error(new StringBuffer(logToken).append("not supported type for Routing Tag"));
			throw new JspException("not supported type for Routing Tag");
		}

		// routing logic
		if (targetType != null) {

			//only append counter if it is specified after evaluating session var, but always assign counter
			counter = Common.evaluateCounterName(counter, session);
			if (counter != null && counter.length() != 0)
				routingtag.append("<assign name=\"counter\" expr=\"counter + '").append(
						counter).append("'\"/>").append("\n");

			if (type.equalsIgnoreCase("inputerror")
					|| type.equalsIgnoreCase("noinput")
					|| type.equalsIgnoreCase("nomatch")) {
				routingtag.append("<assign name=\"selection\" expr=\"'")
						.append(selection).append("'\"/>").append("\n");
			} else {
				if (choiceAtIndex == null) {
					routingtag.append("<assign name=\"selection\" expr=\"'")
							.append(selection).append("'\"/>").append("\n");
				} else {
					routingtag.append("<assign name=\"selection\" expr=\"")
							.append("application.lastresult$.interpretation")
							.append("\"/>").append("\n");
				}
			}

			//changed by Fang Wang on 3/12/2007 to allow the following
			// attributes be
			// a session variable name includng properties,
			// hashmap/hashtable, or arbitrary classes
			try {
				targetName = (String) evaluate(targetName);
				targetAudio = (String) evaluate(targetAudio);
				dest = (String) evaluate(dest);
				//destType = (String) evaluate(destType);
				tts = (String) evaluate(tts);
			} catch (Exception e) {
				LOGGER.error(new StringBuffer(logToken).append(e.getMessage() + iSubMenu.getName()));
				throw new JspException(e.getMessage() + iSubMenu.getName());
			}

			//if tts not enabled, set tts string as null
			if (!session.getServletContext().getInitParameter("ttsEnabled")
					.equalsIgnoreCase(Common.TRUE))
				tts = "";

			if (targetType.equalsIgnoreCase("submenu")) {
				if (choiceAtIndex != null) {
					String value = choiceAtIndex.getAnnot();
					if (value == null)
						value = choiceAtIndex.getDtmf();
					if (value.trim().startsWith("@")) {
						if (dest != null) {
							dest = "dest + application.lastresult$.interpretation"
									+ " + ';" + dest + "'";
						} else {
							dest = "dest + application.lastresult$.interpretation";
						}
					} else {
						if (dest != null)
							dest = "dest + '" + dest + "'";
					}
				} else {
					if (dest != null)
						dest = "dest + '" + dest + "'";
				}

				// Play this prompt when this choice is selected
				// TODO: Consider the case where we play the prompt as submit
				// audio
				String audioFileRoot = globalProp.getProperty("audioFileRoot");
				
				//always play the audio no matter if handler is set or not
				//if ((handler == null) || (handler.length() == 0)) {
					if (targetAudio != null) {
						routingtag.append("<prompt><audio src=\"").append(
								audioFileRoot).append("/audio/").append(
								session.getAttribute("audioDir")).append("/").append(
								targetAudio).append("\">").append(tts).append(
								"</audio></prompt>\n");
					}
				//}

				routingtag.append("<assign name=\"menuName\" expr=\"'").append(
						targetName).append("'\"/>").append("\n");
				routingtag.append("<assign name=\"menuType\" expr=\"'").append(
						targetType).append("'\"/>").append("\n");
				if (targetMode != null) {
					routingtag.append("<assign name=\"mode\" expr=\"'").append(
							targetMode).append("'\"/>").append("\n");
					if (dest != null) {
						routingtag.append("<assign name=\"dest\" expr=\"")
								.append(dest).append("\"/>").append("\n");

						if ((handler != null) && (handler.length() > 0)) {
							routingtag.append(
									"<assign name=\"handler\" expr=\"'")
									.append(handler).append("'\"/>").append(
											"\n");
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName mode menuType dest selection utterance handler counter recording\"/>")
									.append("\n");
						} else {
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName mode menuType dest selection utterance counter recording\"/>")
									.append("\n");
						}
					} else {
						if ((handler != null) && (handler.length() > 0)) {
							routingtag.append(
									"<assign name=\"handler\" expr=\"'")
									.append(handler).append("'\"/>").append(
											"\n");
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName mode menuType selection utterance handler counter recording\"/>")
									.append("\n");
						} else {
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName mode menuType selection utterance counter recording\"/>")
									.append("\n");
						}
					}
				} else {
					if (dest != null) {
						routingtag.append("<assign name=\"dest\" expr=\"")
								.append(dest).append("\"/>").append("\n");

						if ((handler != null) && (handler.length() > 0)) {
							routingtag.append(
									"<assign name=\"handler\" expr=\"'")
									.append(handler).append("'\"/>").append(
											"\n");
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName menuType dest selection utterance handler counter recording\"/>")
									.append("\n");
						} else {
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName menuType dest selection utterance counter recording\"/>")
									.append("\n");
						}
					} else {
						if ((handler != null) && (handler.length() > 0)) {
							routingtag.append(
									"<assign name=\"handler\" expr=\"'")
									.append(handler).append("'\"/>").append(
											"\n");
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName menuType selection utterance handler counter recording\"/>")
									.append("\n");

						} else {
							routingtag
									.append("<submit ")
									.append(
											isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
													: "method=\"get\"")
									.append(" next=\"")
									.append(contextPath)
									.append(
											"/CallRoutingServlet\" namelist=\"menuName menuType selection utterance counter recording\"/>")
									.append("\n");
						}
					}
				}
			}//end if (targetType.equalsIgnoreCase("submenu"))
			else if (targetType.equalsIgnoreCase("servlet")) {
				routingtag.append("<assign name=\"dest\" expr=\"'")
						.append(dest).append("'\"/>").append("\n");
				routingtag.append("<submit next=\"").append(contextPath)
						.append("/").append(targetName).append(
								"\" namelist=\"dest selection utterance\"/>")
						.append("\n");
			}//end if (targetType.equalsIgnoreCase("servlet"))
			else if (targetType.equalsIgnoreCase("ivrapp")) {
				// We need the full URL to the target application so that
				// we can open a connection to that application to verify
				// that it exists. We construct the full URL by
				// Taking the existing URL as a base and appending the new
				// context root and servlet
				String requestURL = request.getRequestURL().toString();

				// Get the beginning of the URL up to the context root
				requestURL = requestURL.split(request.getContextPath())[0];
				String oldContextRoot = request.getContextPath();
				String fullURLToApplication = requestURL + "/" + targetName
						+ "/EntryPointServlet";

				if (testCall)
					LOGGER.info(new StringBuffer(logToken).append("New App URL: ")
						.append(fullURLToApplication));

				// failover design - need to modify -------------
				try {
					if (!availableURLs.contains(fullURLToApplication)) {
						new URL(fullURLToApplication).openConnection()
								.getInputStream().close();
						availableURLs.add(fullURLToApplication);

						//split dest field value in key value pairs
						StringTokenizer st = new StringTokenizer(dest, ";");
						String appDnisKey = "";
						String appDnisValue = "";
						while (st.hasMoreTokens()) {
							String var = st.nextToken();
							if (var != null) {
								int index = var.indexOf(":");
								if (index != -1) {
									appDnisKey = var.substring(0, index);
									appDnisValue = var.substring(index + 1);
									if (testCall) {
										LOGGER.debug(new StringBuffer(logToken)
												.append("DNIS: ").append(
														appDnisKey));
										LOGGER.debug(new StringBuffer(logToken)
												.append("dest: ").append(
														appDnisValue));
									}
									if (appDnisKey.equalsIgnoreCase(dnis)) {
										dest = appDnisValue;
										break;
									}
								} else {
									dest = var;
								}
							}
						}

						// build the exit reason string
						// exitReason = ContextRoot + virual DNIS
						String exitReason = targetName + "-" + dest;

						routingtag.append("<var name=\"newAppLink\" expr=\"'")
								.append(fullURLToApplication).append("'\"/>")
								.append("\n");
						routingtag.append("<var name=\"DNIS\" expr=\"'")
								.append(dest).append("'\"/>").append("\n");
						routingtag.append("<var name=\"callid\" expr=\"'")
								.append(callid).append("'\"/>").append("\n");
						routingtag.append("<var name=\"exitReason\" expr=\"'")
								.append(exitReason).append("'\"/>")
								.append("\n");
						routingtag
								.append("<submit next=\"")
								.append(
										"ExitServlet\" namelist=\"newAppLink DNIS callid exitReason counter recording\"/>")
								.append("\n");
					}
				} catch (Exception e) {
					LOGGER.warn(new StringBuffer(logToken).append(
							"Failed to submit request to ").append(
							fullURLToApplication));
					routingtag.append("<throw event=\"error.badfetch\" />")
							.append("\n");
				}//end if (targetType.equalsIgnoreCase("ivrapp"))
				//----------------

			} else if (targetType.equalsIgnoreCase("agent")
					|| targetType.equalsIgnoreCase("ctiagent")
					|| targetType.equalsIgnoreCase("ctiagentdirect")) {
				//			---
				if (destType != null) {
					if (destType.equalsIgnoreCase("operator")) {
						if (testCall)
							LOGGER.info(new StringBuffer(logToken).append(
								"transfer dest: ").append(
								iCallRouting.getOperator()));
						dest = iCallRouting.getOperator().getValue();
					} else {
						if (destType.startsWith("$")) {//take the session var value
							dest = (String)Common.getSessionValue(destType.substring(1), session);
						} else {//take the property value
							//if the destType is not in callProp, then take it
							// from globalProp
							Properties callProp = (Properties) session
									.getAttribute("callProp");
							if (callProp == null
									|| callProp.get(destType.toUpperCase()) == null) {
								dest = (String) globalProp.get(destType
										.toUpperCase());
							} else {
								dest = (String) callProp.get(destType
										.toUpperCase());
							}
						}
					}

				} else {
					if (dest != null && dest.startsWith("$")) //take the session var value
						dest = (String)Common.getSessionValue(dest.substring(1), session);
				}
				routingtag.append("<assign name=\"dest\" expr=\"'")
						.append(dest==null?"":dest).append("'\"/>").append("\n");

				routingtag.append("<assign name=\"reason\" expr=\"'").append(
						targetName==null?"":targetName).append("'\"/>").append("\n");

				routingtag.append("<assign name=\"agentType\" expr=\"'")
						.append(targetType).append("'\"/>").append("\n");

				if (targetAudio != null) {
					routingtag.append("<assign name=\"audio\" expr=\"'")
							.append(targetAudio).append("'\"/>").append("\n");
					if (tts != null) {
						routingtag.append("<assign name=\"tts\" expr=\"'")
								.append(tts).append("'\"/>").append("\n");
						routingtag
								.append("<submit ")
								.append(
										isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
												: "method=\"get\"")
								.append(" next=\"")
								.append(contextPath)
								.append(
										"/TransferServlet\" namelist=\"agentType dest reason audio tts selection utterance counter recording\"/>")
								.append("\n");
					} else
						routingtag
								.append("<submit ")
								.append(
										isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
												: "method=\"get\"")
								.append(" next=\"")
								.append(contextPath)
								.append(
										"/TransferServlet\" namelist=\"agentType dest reason audio selection utterance counter recording\"/>")
								.append("\n");
				} else {
					routingtag
							.append("<submit ")
							.append(
									isRecordType && !errorRouting ? "method=\"post\" enctype=\"multipart/form-data\""
											: "method=\"get\"")
							.append(" next=\"")
							.append(contextPath)
							.append(
									"/TransferServlet\" namelist=\"agentType dest reason selection utterance counter recording\"/>")
							.append("\n");
				}
			}//end if (targetType.equalsIgnoreCase("agent"))
			else {
				LOGGER.error(new StringBuffer(logToken).append("unsupported target type for routing tag:").append(targetType));
				throw new JspException(
						"unsupported target type for routing tag: "
								+ targetType);
			}
		}//end if (targetType != null)
		else {
			if (testCall)
				LOGGER.trace(new StringBuffer(logToken).append("target type is null."));
		}

		if (testCall)
			LOGGER.trace(new StringBuffer(logToken)
					.append("RoutingTag content: " + routingtag.toString()));

		try {
			pageContext.getOut().print(routingtag.toString());
		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception caught when writing routing tag content to the jsp stream"));
			throw new JspException(
					"Exception caught when writing routing tag content to the jsp stream");
		}
		return SKIP_BODY;
	}

	public int doEndTag() {
		return EVAL_PAGE;
	}

	/**
	 * Evaluate the string as literal string or session variable
	 * 
	 * @param var
	 *            literal string or session variable (starting with $)
	 * @return the value of session variable or literal string, null if not
	 *         found in session
	 * @throws Exception
	 */
	//Vodafone use this method to access session variable.   Copy this method to audiotag
	private Object evaluate(String var) throws Exception {
		HttpSession session = pageContext.getSession();
		Object value = null;

		if (var != null && var.startsWith("$")) {
			value = Common.getSessionValue(var.substring(1), session);
			if (value == null){
				throw new JspException("session variable " + var.substring(1)
						+ " is not available at menu: ");
			}
			else
				return value;
		} else {
			return var;
		}
	}

}
