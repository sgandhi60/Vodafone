/*
 * Created on Dec 1, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.ivr.framework.utilities;

import org.apache.log4j.Logger;

/**
 * @author FSWilson
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CallRouteStats {
	private static Logger LOGGER = Logger.getLogger(CallRouteStats.class);

	public static void logStats(
		String sessionID,
		String appID,
		String callRoute) {

		String logString = "";
		int i = 1;

		// put preface in logString
		String logToken = new StringBuffer("[").append(sessionID).append("] ")
		.toString();

		if (LOGGER.isTraceEnabled())
				LOGGER.info(new StringBuffer(logToken).append("[").append(appID).append("]: ").append("callroute=")
						.append(callRoute));
	}

}
