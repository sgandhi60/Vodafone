package com.ibm.ivr.framework.controller;

import java.io.IOException;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.ibm.ivr.framework.model.CallRoutingType;
import com.ibm.ivr.framework.model.ClosedAudioType;
import com.ibm.ivr.framework.model.HolidayAudioType;
import com.ibm.ivr.framework.model.IntroAudioType;
import com.ibm.ivr.framework.utilities.CallRoutingHelper;
import com.ibm.ivr.framework.utilities.EmergencyInfo;

/**
 * The WelcomeServlet checks the hours of operation and play the corresponding
 * audios
 * <p>
 * 
 * Revision history:
 * <p>
 * 
 * 2004-06-01: initial version
 * <p>
 * 
 * 2007-03-08: 
 * <p>
 * 
 * @author Fang Wang
 * @version 2007-03-08
 *  
 */

public class WelcomeServlet extends HttpServlet implements Servlet {
	/**
	 * The private log4j logger
	 */
	private static Logger LOGGER = Logger.getLogger(WelcomeServlet.class);

	public Properties props = null;;

	/**
	 * @see javax.servlet.http.HttpServlet#void
	 *      (javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(false);
		
		//set log4j Nested Debug Context
		if (NDC.getDepth() == 0)
			NDC.push((String)this.getServletContext().getAttribute("hostName"));

		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall"))
				.booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ")
				.toString();

		if (testCall)
			LOGGER.info(new StringBuffer(logToken)
				.append("Entering WelcomeServlet..."));

		// set current position of caller as "Welcome" in the session for later
		// use
		// to log at Hangup time for statistic report
		String currentPos = "Welcome";
		session.setAttribute("currentPos", currentPos);

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append("CurrentPos: ")
					.append(currentPos));

		// build and save the call Route info in session
		StringBuffer callRoute = new StringBuffer(currentPos);
		session.setAttribute("callRoute", callRoute);

		if (testCall)
			LOGGER.debug(new StringBuffer(logToken).append("CallRoute: ")
					.append(callRoute));

		String centerStatus = "open";

		try {
			//check center operation status
			centerStatus = CallRoutingHelper.checkHoursOfOperation(session);
			session.setAttribute("centerStatus", centerStatus);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken)
						.append("centerStatus: ").append(centerStatus));

			//check the intro audio files
			String dnis = (String) session.getAttribute("DNIS");
			CallRoutingType iCallRouting = (CallRoutingType) session
					.getAttribute("iCallRouting");
			List introAudios = iCallRouting.getIntroAudio();
			String iaFile = "";
			String iaFileTTS = "";
			IntroAudioType iaDefault = null;
			for (int i = 0; i < introAudios.size(); i++) {
				IntroAudioType ia = (IntroAudioType) introAudios.get(i);
				if (ia.getDnis() == null) {
					iaDefault = ia;
				} else {
					if (ia.getDnis().indexOf(dnis) != -1) {
						iaFile = ia.getValue();
						iaFileTTS = ia.getTts();
						break;
					}
				}
			}
			if (iaFile.length() == 0 && iaDefault != null) {//no matching dnis
				// is found on
				// IntroAudio
				iaFile = iaDefault.getValue().trim();
				iaFileTTS = iaDefault.getTts();
			}

			//set into request attribute to be used by jsv
			req.setAttribute("introAudioFile", iaFile);
			req.setAttribute("introAudioTTS", iaFileTTS);
			if (testCall) {
				LOGGER.debug(new StringBuffer(logToken).append(
						"introAudioFile: ").append(iaFile));
				LOGGER.debug(new StringBuffer(logToken).append(
						"introAudioTTS: ").append(iaFileTTS));
			}

			//check for emergency mode only if emergencyDataSource is specified
			Properties globalProp = (Properties) (this.getServletContext()
					.getAttribute("globalProp"));
			Properties prop = (Properties) session.getAttribute("callProp");

			if (globalProp.getProperty("emergencyDataSource") != null) {
				String company = globalProp.getProperty("emergencyCompany."
						+ dnis);
				if (company == null)
					company = globalProp.getProperty("emergencyCompany");

				if (company == null){
					LOGGER
							.warn("emergencyCompany is not specified in globalProp for dnis: "
									+ dnis + " and for default");
					req.setAttribute("emergencyMode", "false");
				}
				else {
					Hashtable eTable = (Hashtable) this.getServletContext()
							.getAttribute("emergencyTable");
					EmergencyInfo eInfo = (EmergencyInfo) eTable.get(company);
					if (testCall)
						LOGGER.debug(new StringBuffer(logToken).append(
								"EmergencyInfo for ").append(company).append(
								" : ").append(eInfo.isMode()).append(",")
								.append(eInfo.getStartTime()).append(",")
								.append(eInfo.getEndTime()).append(",").append(
										eInfo.getType()));

					if (!eInfo.isMode()) {
						req.setAttribute("emergencyMode", "false");
						if (testCall)
							LOGGER.debug(new StringBuffer(logToken).append(
									"emergencyMode: ").append("false"));
					} else {

						try {
							Calendar calNow = Calendar.getInstance(TimeZone
									.getTimeZone(globalProp
											.getProperty("timeZone")));
							int hourNow = calNow.get(Calendar.HOUR_OF_DAY);
							int minNow = calNow.get(Calendar.MINUTE);
							int timeToday = (hourNow * 60) + minNow;

							int startHour = Integer.parseInt(eInfo
									.getStartTime().substring(0, 2));
							int startMinute = Integer.parseInt(eInfo
									.getStartTime().substring(2, 4));
							int endHour = Integer.parseInt(eInfo.getEndTime()
									.substring(0, 2));
							int endMinute = Integer.parseInt(eInfo.getEndTime()
									.substring(2, 4));

							int startTime = startHour * 60 + startMinute;
							int endTime = endHour * 60 + endMinute;
							if (startTime <= endTime){// on the same day
								if (timeToday >= startTime && timeToday <= endTime) {
									req.setAttribute("emergencyMode", "true");
									if (testCall)
										LOGGER.debug(new StringBuffer(logToken)
											.append("emergencyMode: ").append(
													"true"));
								} else {
									req.setAttribute("emergencyMode", "false");
									if (testCall)
										LOGGER.debug(new StringBuffer(logToken)
											.append("emergencyMode: ").append(
													"false"));
								}
							}
							else{//cross midnight
								if (timeToday >= startTime || timeToday <= endTime) {
									req.setAttribute("emergencyMode", "true");
									if (testCall)
										LOGGER.debug(new StringBuffer(logToken)
											.append("emergencyMode: ").append(
													"true"));
								} else {
									req.setAttribute("emergencyMode", "false");
									if (testCall)
										LOGGER.debug(new StringBuffer(logToken)
											.append("emergencyMode: ").append(
													"false"));
								}								
							}

							session.setAttribute("emergencyMsgFile",
									"Emergency" + company);
							req.setAttribute("emergencyAudioFile",
									"(emergencyMsgFile:localaufile)");

						} catch (Exception ex) {
							LOGGER
									.error("Exception caught while evaluating emergency mode with currect time (assuming emergency mode off): "
											+ ex.getMessage());
							req.setAttribute("emergencyMode", "false");
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(
										"emergencyMode: ").append("false"));
						}

						String type = eInfo.getType();
						if (type == null || type.trim().length() == 0 || type.trim().length() == 3)
							req.setAttribute("emergencyType", "TYPE1");
						else
							req.setAttribute("emergencyType", "TYPE" + type.trim());

						//if non TYPE1 message, find the entry point submenu
						
						if ( type != null && type.trim().length() != 0 && type.trim().length() != 3 ){
					
							// Check properties to find the start menu
							Properties mappingProp = (Properties) this.getServletContext()
									.getAttribute("mappingProp");

							// extract value for this DNIS from ivrmapping
							// properties
							// for called IVR apps, this value will be in
							// xxxx.xml#xxxmenu.dtmf format
							String callFlow = mappingProp.getProperty("callflow.Emergency"
									+ type.trim());
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken).append(
										"callFlow ").append(callFlow));

							// if DNIS not defined in the ivrmapping.properties
							if (callFlow == null) {
								throw new Exception(
										"Entrypoint Emergency"	+ eInfo.getType()
												+ " not defined in the ivrmapping.properties"); 
							}

							// parse the value found corresponding to key to
							// determine the start
							// menu/mode
							String xmlFile = null;
							String menuMode = null;
							String menu = null;
							String mode = null;
							int index = callFlow.indexOf("#");
							if (index != -1) {
								xmlFile = callFlow.substring(0, index);
								menuMode = callFlow.substring(index + 1);
								index = menuMode.indexOf(".");
								if (index != -1) {
									menu = menuMode.substring(0, index);
									mode = menuMode.substring(index + 1);
								}
							}

							if (menu == null) {
								menu = (String) iCallRouting.getStart();
								mode = (String) iCallRouting.getStartMode();
							}
							session.setAttribute("entryMenu", menu);
							//set the mode in session
							session.setAttribute("mode", mode);							
						}
						
						if (prop != null) {
							String limit = prop
									.getProperty("emergencyMsgLimit");
							if (testCall)
								LOGGER.debug(new StringBuffer(logToken)
										.append("emergencyMsgLimit: ")
										.append(limit));
							if (limit != null && !limit.equals("0")) {
								int sizeLimit = Integer.parseInt(limit);
								int msgSize = eInfo.getMsgSize();
								//leave some buffer as 8000 is just a rough scaling factor
								//only use the limit if the actual msg size is greater than limit-1 s
								if (msgSize >= (sizeLimit - 1) * 8000)
									req.setAttribute("emergencyMsgLimit", limit);
							}
						}
					}
				}
			} else {
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
						"emergencyMode: ").append("false"));
				req.setAttribute("emergencyMode", "false");
			}

			// Check if there is a time limit on initial prompt
			if (prop != null) {
				String limit = prop.getProperty("initialPromptTimeLimit");
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append(
							"initialPromptTimeLimit: ").append(limit));
				if (limit != null && !limit.equals("0")) 
					req.setAttribute("initialPromptTimeLimit", limit);
			}

			if (session.getAttribute("entryMenu") == null){//if entryMenu is not set yet by emergency mode check
				// Check properties to find the start menu
				prop = (Properties) this.getServletContext().getAttribute(
					"mappingProp");
				if (testCall)
					LOGGER.trace(new StringBuffer(logToken)
						.append("after mappingproperties"));

				// extract value for this DNIS from ivrmapping properties
				// for called IVR apps, this value will be in
				// xxxx.xml#xxxmenu.dtmf format
				String callFlow = prop.getProperty("callflow." + dnis);
				if (testCall)
					LOGGER.debug(new StringBuffer(logToken).append("callFlow ")
						.append(callFlow));

				// if DNIS not defined in the ivrmapping.properties
				if (callFlow == null) {
					throw new Exception("DNIS " + dnis
						+ " not defined in the ivrmapping.properties");
				}

				// parse the value found corresponding to key to determine the start
				// menu/mode
				String xmlFile = null;
				String menuMode = null;
				String menu = null;
				String mode = null;
				int index = callFlow.indexOf("#");
				if (index != -1) {
					xmlFile = callFlow.substring(0, index);
					menuMode = callFlow.substring(index + 1);
					index = menuMode.indexOf(".");
					if (index != -1) {
						menu = menuMode.substring(0, index);
						mode = menuMode.substring(index + 1);
					}
				}

				if (menu == null) {
					menu = (String) iCallRouting.getStart();
					mode = (String) iCallRouting.getStartMode();
				}

				if ((menu != null) && (menu.length()) != 0) {
					req.setAttribute("menuName", menu);
					req.setAttribute("mode", mode == null ? "DTMF" : mode);
					req.setAttribute("menuType", "submenu");
				}
				session.setAttribute("entryMenu", menu);
				//set the mode in session
				session.setAttribute("mode", mode);
			}

			String nextPage = "/jsp/" + getInitParameter("welcomePage");
			if (centerStatus.equalsIgnoreCase("closed")) {
				ClosedAudioType closedAudio = (ClosedAudioType) iCallRouting
						.getClosedAudio();
				if (closedAudio != null) {
					String terminate = closedAudio.getTerminate();
					if (terminate != null && terminate.equalsIgnoreCase("true")) {
						iaFile = closedAudio.getValue();
						iaFileTTS = closedAudio.getTts();
						nextPage = "/jsp/" + getInitParameter("closedPage");
					}
				}
			}

			if (centerStatus.equalsIgnoreCase("holiday")) {
				HolidayAudioType holidayAudio = (HolidayAudioType) iCallRouting
						.getHolidayAudio();
				if (holidayAudio != null) {
					String terminate = holidayAudio.getTerminate();
					if (terminate != null && terminate.equalsIgnoreCase("true")) {
						iaFile = holidayAudio.getValue();
						iaFileTTS = holidayAudio.getTts();
						nextPage = "/jsp/" + getInitParameter("closedPage");
					}
				}
			}

			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving WelcomeServlet... nextPage: ")
						.append(nextPage));
			dispatch.forward(req, resp);

		} catch (Exception e) {
			LOGGER.error(new StringBuffer(logToken)
					.append("Exception caught: ").append(e.getMessage()), e);

			session.setAttribute("errorLogged", new Boolean(true));
			
			session.setAttribute("centerStatus", centerStatus);

			String nextPage = "/jsp/"
					+ (getInitParameter("errorPage") == null ? "Error.jsv"
							: getInitParameter("errorPage"));
			req.setAttribute("lastError", e.toString());
			RequestDispatcher dispatch = req.getRequestDispatcher(nextPage);
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append(
						"Leaving WelcomeServlet... nextPage: ")
						.append(nextPage));
			dispatch.forward(req, resp);
		}
		NDC.remove();
	}

}
