/**
 * <copyright>
 * </copyright>
 *
 * $Id: ModelSwitch.java,v 1.1 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model.util;

import com.ibm.ivr.framework.model.*;

import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see com.ibm.ivr.framework.model.ModelPackage
 * @generated
 */
public class ModelSwitch
{
  /**
   * The cached model package
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static ModelPackage modelPackage;

  /**
   * Creates an instance of the switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ModelSwitch()
  {
    if (modelPackage == null)
    {
      modelPackage = ModelPackage.eINSTANCE;
    }
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  public Object doSwitch(EObject theEObject)
  {
    return doSwitch(theEObject.eClass(), theEObject);
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  protected Object doSwitch(EClass theEClass, EObject theEObject)
  {
    if (theEClass.eContainer() == modelPackage)
    {
      return doSwitch(theEClass.getClassifierID(), theEObject);
    }
    else
    {
      List eSuperTypes = theEClass.getESuperTypes();
      return
        eSuperTypes.isEmpty() ?
          defaultCase(theEObject) :
          doSwitch((EClass)eSuperTypes.get(0), theEObject);
    }
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  protected Object doSwitch(int classifierID, EObject theEObject)
  {
    switch (classifierID)
    {
      case ModelPackage.AUDIO_CONFIRM_TYPE:
      {
        AudioConfirmType audioConfirmType = (AudioConfirmType)theEObject;
        Object result = caseAudioConfirmType(audioConfirmType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.AUDIO_TYPE:
      {
        AudioType audioType = (AudioType)theEObject;
        Object result = caseAudioType(audioType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.CALL_ROUTING_TYPE:
      {
        CallRoutingType callRoutingType = (CallRoutingType)theEObject;
        Object result = caseCallRoutingType(callRoutingType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.CHOICE_TYPE:
      {
        ChoiceType choiceType = (ChoiceType)theEObject;
        Object result = caseChoiceType(choiceType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.CLOSED_AUDIO_TYPE:
      {
        ClosedAudioType closedAudioType = (ClosedAudioType)theEObject;
        Object result = caseClosedAudioType(closedAudioType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.DEFAULT_ROUTING_TYPE:
      {
        DefaultRoutingType defaultRoutingType = (DefaultRoutingType)theEObject;
        Object result = caseDefaultRoutingType(defaultRoutingType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.DOCUMENT_ROOT:
      {
        DocumentRoot documentRoot = (DocumentRoot)theEObject;
        Object result = caseDocumentRoot(documentRoot);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.EVENT_HANDLERS_TYPE:
      {
        EventHandlersType eventHandlersType = (EventHandlersType)theEObject;
        Object result = caseEventHandlersType(eventHandlersType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.EVENTS_TYPE:
      {
        EventsType eventsType = (EventsType)theEObject;
        Object result = caseEventsType(eventsType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.GRAMMAR_TYPE:
      {
        GrammarType grammarType = (GrammarType)theEObject;
        Object result = caseGrammarType(grammarType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.HANGUP_TYPE:
      {
        HangupType hangupType = (HangupType)theEObject;
        Object result = caseHangupType(hangupType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.HELP_TYPE:
      {
        HelpType helpType = (HelpType)theEObject;
        Object result = caseHelpType(helpType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.HOLIDAY_AUDIO_TYPE:
      {
        HolidayAudioType holidayAudioType = (HolidayAudioType)theEObject;
        Object result = caseHolidayAudioType(holidayAudioType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.INPUT_ERROR_TYPE:
      {
        InputErrorType inputErrorType = (InputErrorType)theEObject;
        Object result = caseInputErrorType(inputErrorType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.INTRO_AUDIO_TYPE:
      {
        IntroAudioType introAudioType = (IntroAudioType)theEObject;
        Object result = caseIntroAudioType(introAudioType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.MENU_DEFAULT_TYPE:
      {
        MenuDefaultType menuDefaultType = (MenuDefaultType)theEObject;
        Object result = caseMenuDefaultType(menuDefaultType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.MENU_OPERATOR_TYPE:
      {
        MenuOperatorType menuOperatorType = (MenuOperatorType)theEObject;
        Object result = caseMenuOperatorType(menuOperatorType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.NO_INPUT_TYPE:
      {
        NoInputType noInputType = (NoInputType)theEObject;
        Object result = caseNoInputType(noInputType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.NO_MATCH_TYPE:
      {
        NoMatchType noMatchType = (NoMatchType)theEObject;
        Object result = caseNoMatchType(noMatchType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.OPERATOR_TYPE:
      {
        OperatorType operatorType = (OperatorType)theEObject;
        Object result = caseOperatorType(operatorType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.OUTRO_AUDIO_TYPE:
      {
        OutroAudioType outroAudioType = (OutroAudioType)theEObject;
        Object result = caseOutroAudioType(outroAudioType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.SUB_MENU_TYPE:
      {
        SubMenuType subMenuType = (SubMenuType)theEObject;
        Object result = caseSubMenuType(subMenuType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.TRANSFER_AUDIO_TYPE:
      {
        TransferAudioType transferAudioType = (TransferAudioType)theEObject;
        Object result = caseTransferAudioType(transferAudioType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ModelPackage.TRANSFER_TYPE:
      {
        TransferType transferType = (TransferType)theEObject;
        Object result = caseTransferType(transferType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      default: return defaultCase(theEObject);
    }
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Audio Confirm Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Audio Confirm Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseAudioConfirmType(AudioConfirmType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Audio Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Audio Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseAudioType(AudioType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Call Routing Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Call Routing Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseCallRoutingType(CallRoutingType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Choice Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Choice Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseChoiceType(ChoiceType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Closed Audio Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Closed Audio Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseClosedAudioType(ClosedAudioType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Default Routing Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Default Routing Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseDefaultRoutingType(DefaultRoutingType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Document Root</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Document Root</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseDocumentRoot(DocumentRoot object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Event Handlers Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Event Handlers Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseEventHandlersType(EventHandlersType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Events Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Events Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseEventsType(EventsType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Grammar Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Grammar Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseGrammarType(GrammarType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Hangup Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Hangup Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseHangupType(HangupType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Help Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Help Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseHelpType(HelpType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Holiday Audio Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Holiday Audio Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseHolidayAudioType(HolidayAudioType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Input Error Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Input Error Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseInputErrorType(InputErrorType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Intro Audio Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Intro Audio Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseIntroAudioType(IntroAudioType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Menu Default Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Menu Default Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseMenuDefaultType(MenuDefaultType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Menu Operator Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Menu Operator Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseMenuOperatorType(MenuOperatorType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>No Input Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>No Input Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseNoInputType(NoInputType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>No Match Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>No Match Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseNoMatchType(NoMatchType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Operator Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Operator Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseOperatorType(OperatorType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Outro Audio Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Outro Audio Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseOutroAudioType(OutroAudioType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Sub Menu Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Sub Menu Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseSubMenuType(SubMenuType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Transfer Audio Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Transfer Audio Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseTransferAudioType(TransferAudioType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>Transfer Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>Transfer Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public Object caseTransferType(TransferType object)
  {
    return null;
  }

  /**
   * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch, but this is the last case anyway.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject)
   * @generated
   */
  public Object defaultCase(EObject object)
  {
    return null;
  }

} //ModelSwitch
