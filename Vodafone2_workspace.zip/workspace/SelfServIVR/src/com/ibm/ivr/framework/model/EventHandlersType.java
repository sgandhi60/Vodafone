/**
 * <copyright>
 * </copyright>
 *
 * $Id: EventHandlersType.java,v 1.4 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Handlers Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.EventHandlersType#getInputError <em>Input Error</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.EventHandlersType#getNoInput <em>No Input</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.EventHandlersType#getNoMatch <em>No Match</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.EventHandlersType#getHelp <em>Help</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getEventHandlersType()
 * @model 
 * @generated
 */
public interface EventHandlersType
{
  /**
   * Returns the value of the '<em><b>Input Error</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.InputErrorType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Error</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Error</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getEventHandlersType_InputError()
   * @model type="com.ibm.ivr.framework.model.InputErrorType" containment="true" resolveProxies="false"
   * @generated
   */
  List getInputError();

  /**
   * Returns the value of the '<em><b>No Input</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.NoInputType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>No Input</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>No Input</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getEventHandlersType_NoInput()
   * @model type="com.ibm.ivr.framework.model.NoInputType" containment="true" resolveProxies="false"
   * @generated
   */
  List getNoInput();

  /**
   * Returns the value of the '<em><b>No Match</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.NoMatchType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>No Match</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>No Match</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getEventHandlersType_NoMatch()
   * @model type="com.ibm.ivr.framework.model.NoMatchType" containment="true" resolveProxies="false"
   * @generated
   */
  List getNoMatch();

  /**
   * Returns the value of the '<em><b>Help</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Help</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Help</em>' containment reference.
   * @see #setHelp(HelpType)
   * @see com.ibm.ivr.framework.model.ModelPackage#getEventHandlersType_Help()
   * @model containment="true" resolveProxies="false"
   * @generated
   */
  HelpType getHelp();

  /**
   * Sets the value of the '{@link com.ibm.ivr.framework.model.EventHandlersType#getHelp <em>Help</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Help</em>' containment reference.
   * @see #getHelp()
   * @generated
   */
  void setHelp(HelpType value);

} // EventHandlersType
