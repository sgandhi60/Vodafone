package com.ibm.ivr.framework.utilities;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

/**
 * A java class to be used by servlet and VXML object tag for sending emails <p>
 * if used by servlet, the constructor with arguments will be used. <p>
 * if used by VXML object tag, the contructor without arguments will be used. <p>
 *
 * Revision History:<p>
 *
 * 2006-02-20: constructor without arguments and a set of APIs including execute() <p?
 * 				are added to support access from VXML object tag
 * 2004-07-15: initial version
 *
 * @author Fang Wang
 * @version 2006-02-20
 *
 *<p>
 *
 * Usage example in VXML code: <p>
 *
 * <![CDATA[ 
 * <object name="emailer" classid="method://com.thomson.ivr.utilities.EmailAlert/execute" codetype="javacode">
 *			<param name="setFrom" expr="'ThomsonIVRPlatform'"/>
 *			<param name="setTo" expr="'xxx@xxx.com'"/>
 *			<param name="setSubject" expr="'system down'"/>
 *			<param name="setMailHost" expr="'smtp.xxx.com"/>
 * </object> ]]>
 *
 * @copyright 2006, International Business Machine, Inc.
 */

public class EmailAlert {

       /**
        * The private log4j logger used by the constructor with arguments, i.e., called
        * from servlet
        */
       private static Logger logger = Logger.getLogger(EmailAlert.class);

       /**
        * The constructor used by servlet to send an email with given information
        * 
        * @param from		the sender of the email
        * @param to			the receipient of the email
        * @param subject	the subject of the email
        * @param mailhost	the SMTP server address
        */
       public EmailAlert(String from, String to, String subject, String mailhost) {

              String mailer = "msgsend";
              boolean debug = false;

              try {
                     logger.debug("From: " + from);
                     logger.debug("To: " + to);
                     logger.debug("Subject: " + subject);
                     logger.debug("Mail Host: " + mailhost);

                     Properties props = System.getProperties();
                     // XXX - could use Session.getTransport() and Transport.connect()
                     // XXX - assume we're using SMTP
                      if (mailhost != null)
                            props.put("mail.smtp.host", mailhost);

                     // Get a Session object
                     Session session = Session.getDefaultInstance(props, null);
                     if (debug)
                            session.setDebug(true);

                     // construct the message
                     logger.debug("Instantiating Message object..");
                     Message msg = new MimeMessage(session);
                     logger.debug("Message object instantiated");
                     if (from != null)
                            msg.setFrom(new InternetAddress(from));
                     else
                            msg.setFrom();

                     msg.setRecipients(
                            Message.RecipientType.TO,
                            InternetAddress.parse(to, false));

                     msg.setSubject(subject);

                     msg.setText(" ");

                     msg.setHeader("X-Mailer", mailer);
                     msg.setSentDate(new Date());
                     logger.debug("msg: " + msg);

                     logger.debug("Before Send method");
                     // send the thing off
                     Transport.send(msg);
                     logger.debug("After Send method");

                     logger.info("Mail was sent successfully to " + to + " for " + subject);

              } catch (Exception e) {
                     logger.error("Failed to send email to " + to + " for " + subject + e.getMessage(), e);
                     e.printStackTrace();
              }
       }

   	/**
   	* Constructs an instance of EmailAlert class to be used by VXML object tag
   	*
   	*/
   	public EmailAlert()
   	{
   	}
   	
   	/**
   	 * The sender to be set before execute() called by VXML tag
   	 */
   	private String from = null;
   	
  	/**
   	 * The recepient to be set before execute() called by VXML tag
   	 */
   	private String to = null;   	
   	
  	/**
   	 * The subject to be set before execute() called by VXML tag
   	 */
   	private String subject = null;    	
   	
  	/**
   	 * The smtp server variable to be set before execute() called by VXML tag
   	 */
   	private String mailhost = null; 
   	
    public Object execute() {

    	// NOTE:  Please do NOT use logger methods here to logs
    	// Use system methods to print logs
        String mailer = "msgsend";
        boolean debug = false;

        try {
               Properties props = System.getProperties();
               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "Mail Host2: " + mailhost);
               // XXX - could use Session.getTransport() and Transport.connect()
               // XXX - assume we're using SMTP
               if (mailhost != null)
                      props.put("mail.smtp.host", mailhost);

               // Get a Session object
               Session session = Session.getDefaultInstance(props, null);
               if (debug)
                      session.setDebug(true);

               // construct the message
//               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "Instantiating Message object..2");
               Message msg = new MimeMessage(session);
//               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "Message object instantiated...2");
              if (from != null)
                      msg.setFrom(new InternetAddress(from));
               else
                      msg.setFrom();

               msg.setRecipients(
                      Message.RecipientType.TO,
                      InternetAddress.parse(to, false));

               msg.setSubject(subject);

               msg.setText(" ");

               msg.setHeader("X-Mailer", mailer);
               msg.setSentDate(new Date());

//               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "msg2: " + msg);

//               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "Before Send method...2");
               // send the thing off
               Transport.send(msg);
//               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "After Send method...2");

               System.out.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "Mail was sent successfully to " + to + " for " + subject);
        } catch (Exception e) {
               System.err.println(new java.sql.Timestamp((new java.util.Date()).getTime()) + "Failed to send email to " + to + " for " + subject + e.getMessage());
               e.printStackTrace();
        }
        
        return new Object();
    }
    
    
	/**
	 * @param from The from to set.
	 */
	public void setFrom(String from) {
		this.from = from;
	}
	/**
	 * @param mailhost The mailhost to set.
	 */
	public void setMailHost(String mailhost) {
		this.mailhost = mailhost;
	}
	/**
	 * @param subject The subject to set.
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	/**
	 * @param to The to to set.
	 */
	public void setTo(String to) {
		this.to = to;
	}
}
