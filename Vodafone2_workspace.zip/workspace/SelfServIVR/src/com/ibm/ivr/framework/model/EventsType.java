/**
 * <copyright>
 * </copyright>
 *
 * $Id: EventsType.java,v 1.8 2007/10/23 21:47:36 u803887 Exp $
 */
package com.ibm.ivr.framework.model;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Events Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ibm.ivr.framework.model.EventsType#getHangup <em>Hangup</em>}</li>
 *   <li>{@link com.ibm.ivr.framework.model.EventsType#getTransfer <em>Transfer</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ibm.ivr.framework.model.ModelPackage#getEventsType()
 * @model 
 * @generated
 */
public interface EventsType
{
  /**
   * Returns the value of the '<em><b>Hangup</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.HangupType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hangup</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hangup</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getEventsType_Hangup()
   * @model type="com.ibm.ivr.framework.model.HangupType" containment="true" resolveProxies="false"
   * @generated
   */
  List getHangup();

  /**
   * Returns the value of the '<em><b>Transfer</b></em>' containment reference list.
   * The list contents are of type {@link com.ibm.ivr.framework.model.TransferType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transfer</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transfer</em>' containment reference list.
   * @see com.ibm.ivr.framework.model.ModelPackage#getEventsType_Transfer()
   * @model type="com.ibm.ivr.framework.model.TransferType" containment="true" resolveProxies="false"
   * @generated
   */
  List getTransfer();

} // EventsType
